// packages/db/prisma/seed.ts
import { config } from "dotenv";
import { resolve } from "node:path";
import { PrismaClient } from "@prisma/client";
import { hash } from "@node-rs/argon2";

// packages/db/src/seed-config.ts
var STAGE_DEFAULTS = [
  { nome: "Novo", ordem: 0, cor: "#2DA8E1" },
  { nome: "Qualifica\xE7\xE3o", ordem: 1, cor: "#003591" },
  { nome: "Proposta", ordem: 2, cor: "#30AD73" },
  { nome: "Negocia\xE7\xE3o", ordem: 3, cor: "#F59E0B" },
  { nome: "Fechado", ordem: 4, cor: "#30AD73" }
];
var EQUIPE_REAL = [
  { chaveEmail: "SEED_ROOT_EMAIL", emailPadrao: "root@medconsultoria.com.br", nome: "Root", role: "ROOT" },
  {
    chaveEmail: "SEED_ADMIN_EMAIL",
    emailPadrao: "thais.garcia@medconsultoria.com.br",
    nome: "Tha\xEDs Garcia",
    role: "ADMIN"
  }
];

// packages/db/prisma/seed.ts
config({ path: resolve(process.cwd(), ".env") });
config({ path: resolve(process.cwd(), "../../.env") });
var prisma = new PrismaClient();
async function main() {
  const senha = process.env.SEED_ROOT_PASSWORD;
  if (!senha) {
    throw new Error("Defina SEED_ROOT_PASSWORD no .env antes de rodar o seed.");
  }
  for (const membro of EQUIPE_REAL) {
    const email = process.env[membro.chaveEmail] ?? membro.emailPadrao;
    const nome = process.env[`SEED_${membro.role}_NOME`] ?? membro.nome;
    const existente = await prisma.user.findUnique({ where: { email }, select: { id: true } });
    if (existente) {
      console.log(`\u2022 ${membro.role} j\xE1 existe: ${email} \u2014 senha preservada.`);
      continue;
    }
    await prisma.user.create({ data: { nome, email, passwordHash: await hash(senha), role: membro.role } });
    console.log(`\u2714 ${membro.role} criado: ${email}`);
  }
  const stages = await prisma.pipelineStage.count();
  if (stages === 0) {
    await prisma.pipelineStage.createMany({ data: STAGE_DEFAULTS });
    console.log(`\u2714 Etapas do funil criadas: ${STAGE_DEFAULTS.map((s) => s.nome).join(" \u2192 ")}`);
  } else {
    console.log(`\u2022 Etapas do funil j\xE1 existem (${stages}) \u2014 mantidas.`);
  }
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
}).finally(() => prisma.$disconnect());
