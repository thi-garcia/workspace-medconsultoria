function a(o){var t;return!!o&&typeof o=="object"&&"data"in o&&((t=o.data)==null?void 0:t.code)==="NOT_FOUND"}export{a as i};
