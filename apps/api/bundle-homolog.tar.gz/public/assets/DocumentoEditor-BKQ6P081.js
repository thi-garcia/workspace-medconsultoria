import{c as i,r as L,j as s,T as N,aq as T}from"./index-CB6P5mt6.js";import{L as z}from"./list-D-GxtcLx.js";import{L as C}from"./link-2-DSG6svNG.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=i("Bold",[["path",{d:"M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8",key:"mg9rjx"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=i("Heading2",[["path",{d:"M4 12h8",key:"17cfdx"}],["path",{d:"M4 18V6",key:"1rz3zl"}],["path",{d:"M12 18V6",key:"zqpxq5"}],["path",{d:"M21 18h-4c0-4 4-3 4-6 0-1.5-2-2.5-4-1",key:"9jr5yi"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=i("Italic",[["line",{x1:"19",x2:"10",y1:"4",y2:"4",key:"15jd3p"}],["line",{x1:"14",x2:"5",y1:"20",y2:"20",key:"bu0au3"}],["line",{x1:"15",x2:"9",y1:"4",y2:"20",key:"uljnxc"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=i("ListOrdered",[["path",{d:"M10 12h11",key:"6m4ad9"}],["path",{d:"M10 18h11",key:"11hvi2"}],["path",{d:"M10 6h11",key:"c7qv1k"}],["path",{d:"M4 10h2",key:"16xx2s"}],["path",{d:"M4 6h1v4",key:"cnovpq"}],["path",{d:"M6 18H4c0-1 2-2 2-3s-1-1.5-2-1",key:"m9a95d"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=i("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=i("Quote",[["path",{d:"M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"rib7q0"}],["path",{d:"M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"1ymkrd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=i("Table",[["path",{d:"M12 3v18",key:"108xh3"}],["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M3 15h18",key:"5xshup"}]]);function S({value:c,onChange:f,className:v}){const y=L.useRef(null);function u(e){const t=y.current;if(!t)return;const o=t.selectionStart,n=t.selectionEnd,a=e({start:o,end:n,text:c,selected:c.slice(o,n)});f(a.text),requestAnimationFrame(()=>{t.focus(),t.setSelectionRange(a.start,a.end)})}const l=(e,t=e,o="texto")=>u(({start:n,end:a,text:r,selected:h})=>{const x=h||o,p=r.slice(0,n)+e+x+t+r.slice(a),m=n+e.length;return{text:p,start:m,end:m+x.length}}),d=e=>u(({start:t,end:o,text:n})=>{const a=n.lastIndexOf(`
`,t-1)+1,r=n.indexOf(`
`,o),h=r===-1?n.length:r,p=n.slice(a,h).split(`
`).map((m,w)=>e(w)+m).join(`
`);return{text:n.slice(0,a)+p+n.slice(h),start:a,end:a+p.length}}),k=e=>u(({start:t,text:o})=>{const a=(t===0||o[t-1]===`
`?"":`

`)+e+`
`,r=t+a.length;return{text:o.slice(0,t)+a+o.slice(t),start:r,end:r}}),b=`| Coluna 1 | Coluna 2 |
| --- | --- |
| Item | Valor |`,M=e=>{if(!(e.ctrlKey||e.metaKey))return;const t=e.key.toLowerCase();t==="b"?(e.preventDefault(),l("**","**","negrito")):t==="i"&&(e.preventDefault(),l("*","*","itálico"))},j=[[{icon:q,title:"Negrito (Ctrl+B)",fn:()=>l("**","**","negrito")},{icon:I,title:"Itálico (Ctrl+I)",fn:()=>l("*","*","itálico")}],[{icon:E,title:"Título de seção",fn:()=>d(()=>"## ")},{icon:z,title:"Lista com marcadores",fn:()=>d(()=>"- ")},{icon:V,title:"Lista numerada",fn:()=>d(e=>`${e+1}. `)},{icon:D,title:"Citação",fn:()=>d(()=>"> ")}],[{icon:C,title:"Link",fn:()=>l("[","](https://)","texto do link")},{icon:H,title:"Tabela",fn:()=>k(b)},{icon:B,title:"Linha divisória",fn:()=>k("---")}]],g=c.trim()?c.trim().split(/\s+/).length:0;return s.jsxs("div",{className:T("flex flex-col overflow-hidden rounded-xl border bg-card shadow-sm",v),children:[s.jsx("div",{className:"flex flex-wrap items-center gap-1 border-b bg-muted/30 px-2 py-1.5",children:j.map((e,t)=>s.jsxs("div",{className:"flex items-center gap-0.5",children:[t>0&&s.jsx("span",{className:"mx-1 h-5 w-px bg-border"}),e.map((o,n)=>s.jsx("button",{type:"button",title:o.title,onClick:o.fn,className:"flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",children:s.jsx(o.icon,{className:"h-4 w-4"})},n))]},t))}),s.jsx(N,{ref:y,value:c,onChange:e=>f(e.target.value),onKeyDown:M,spellCheck:!0,placeholder:"Escreva o documento. Selecione um trecho e use a barra acima para formatar (ou escreva em Markdown).",className:"min-h-[62vh] flex-1 resize-none rounded-none border-0 bg-card px-4 py-3 font-mono text-[13px] leading-relaxed shadow-none focus-visible:ring-0"}),s.jsxs("div",{className:"flex items-center justify-between border-t bg-muted/20 px-4 py-1.5 text-[11px] text-muted-foreground",children:[s.jsx("span",{children:"Formate pela barra ou digite Markdown — o preview ao lado atualiza sozinho."}),s.jsxs("span",{className:"tabular-nums",children:[g," palavra",g===1?"":"s"]})]})]})}export{S as D};
