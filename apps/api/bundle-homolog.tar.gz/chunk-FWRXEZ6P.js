import {
  config,
  contarConexoesSocket,
  enviarEmailTemplate,
  getSlowQueries,
  isAiEnabled,
  notificar,
  prisma,
  src_exports
} from "./chunk-RQVINKOG.js";

// src/modules/sistema/sistema.service.ts
import { createHash } from "crypto";

// src/modules/financeiro/contas.service.ts
import { TRPCError } from "@trpc/server";
var clean = (v) => {
  const t = v?.trim();
  return t ? t : null;
};
var mapConta = (c) => ({
  ...c,
  valor: c.valor.toNumber()
});
var inicioDoDia = (d = /* @__PURE__ */ new Date()) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
var somarDias = (d, n) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};
function proximo(data, r) {
  const d = new Date(data);
  if (r === "DIARIA") d.setDate(d.getDate() + 1);
  else if (r === "SEMANAL") d.setDate(d.getDate() + 7);
  else if (r === "MENSAL") d.setMonth(d.getMonth() + 1);
  return d;
}
function whereCarteira(carteira, ctx) {
  if (carteira === "PESSOAL") return { escopo: "PESSOAL", donoId: ctx.userId };
  if (carteira === "TUDO")
    return { OR: [{ escopo: "EMPRESA" }, { escopo: "PESSOAL", donoId: ctx.userId }] };
  return { escopo: "EMPRESA" };
}
async function contaComPosse(id, ctx) {
  const conta = await prisma.conta.findFirst({ where: { id, deletedAt: null } });
  if (!conta) throw new TRPCError({ code: "NOT_FOUND", message: "Conta n\xE3o encontrada" });
  if (conta.escopo === "PESSOAL" && conta.donoId !== ctx.userId)
    throw new TRPCError({ code: "FORBIDDEN", message: "Esta \xE9 uma conta pessoal de outra pessoa." });
  return conta;
}
async function listContas(input, ctx) {
  const contas = await prisma.conta.findMany({
    where: {
      deletedAt: null,
      ...whereCarteira(input.carteira, ctx),
      ...input.tipo ? { tipo: input.tipo } : {},
      ...input.status === "PENDENTES" ? { pago: false } : input.status === "PAGAS" ? { pago: true } : {}
    },
    orderBy: [{ pago: "asc" }, { vencimento: "asc" }],
    include: {
      categoria: { select: { nome: true, cor: true } },
      cliente: { select: { nome: true } }
    }
  });
  return contas.map(mapConta);
}
async function createConta(input, ctx) {
  const escopo = input.escopo ?? "EMPRESA";
  const recorrencia = input.recorrencia ?? "NENHUMA";
  const conta = await prisma.conta.create({
    data: {
      tipo: input.tipo,
      escopo,
      donoId: escopo === "PESSOAL" ? ctx.userId : null,
      descricao: input.descricao.trim(),
      valor: input.valor,
      vencimento: input.vencimento,
      categoriaId: clean(input.categoriaId),
      clienteId: clean(input.clienteId),
      recorrencia,
      recorrenciaAte: input.recorrenciaAte ?? null,
      observacoes: clean(input.observacoes)
    }
  });
  if (recorrencia !== "NENHUMA") {
    await prisma.conta.update({ where: { id: conta.id }, data: { recorrenteId: conta.id } });
    conta.recorrenteId = conta.id;
  }
  return mapConta(conta);
}
async function updateConta(input, ctx) {
  const { id, ...rest } = input;
  await contaComPosse(id, ctx);
  const data = {};
  if (rest.tipo !== void 0) data.tipo = rest.tipo;
  if (rest.descricao !== void 0) data.descricao = rest.descricao.trim();
  if (rest.valor !== void 0) data.valor = rest.valor;
  if (rest.vencimento !== void 0) data.vencimento = rest.vencimento;
  if (rest.categoriaId !== void 0) data.categoriaId = clean(rest.categoriaId);
  if (rest.clienteId !== void 0) data.clienteId = clean(rest.clienteId);
  if (rest.recorrencia !== void 0) data.recorrencia = rest.recorrencia;
  if (rest.recorrenciaAte !== void 0) data.recorrenciaAte = rest.recorrenciaAte ?? null;
  if (rest.observacoes !== void 0) data.observacoes = clean(rest.observacoes);
  const conta = await prisma.conta.update({ where: { id }, data });
  return mapConta(conta);
}
async function removeConta(id, ctx) {
  await contaComPosse(id, ctx);
  await prisma.conta.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  return { ok: true };
}
async function marcarPaga(id, pago, ctx) {
  const atual = await contaComPosse(id, ctx);
  const conta = await prisma.conta.update({
    where: { id },
    data: { pago, pagoEm: pago ? /* @__PURE__ */ new Date() : null }
  });
  if (pago && conta.recorrencia !== "NENHUMA") await gerarProximaOcorrencia(conta);
  void atual;
  return mapConta(conta);
}
async function gerarProximaOcorrencia(conta) {
  if (conta.recorrencia === "NENHUMA") return false;
  const serie = conta.recorrenteId ?? conta.id;
  const prox = proximo(conta.vencimento, conta.recorrencia);
  if (conta.recorrenciaAte && prox > conta.recorrenciaAte) return false;
  const existe = await prisma.conta.findFirst({
    where: { deletedAt: null, vencimento: prox, OR: [{ id: serie }, { recorrenteId: serie }] },
    select: { id: true }
  });
  if (existe) return false;
  await prisma.conta.create({
    data: {
      tipo: conta.tipo,
      escopo: conta.escopo,
      donoId: conta.donoId,
      descricao: conta.descricao,
      valor: conta.valor,
      vencimento: prox,
      categoriaId: conta.categoriaId,
      clienteId: conta.clienteId,
      recorrencia: conta.recorrencia,
      recorrenciaAte: conta.recorrenciaAte,
      recorrenteId: serie
    }
  });
  return true;
}
async function garantirProximasRecorrencias() {
  const recorrentes = await prisma.conta.findMany({
    where: { deletedAt: null, recorrencia: { not: "NENHUMA" } },
    select: {
      id: true,
      tipo: true,
      escopo: true,
      donoId: true,
      descricao: true,
      valor: true,
      vencimento: true,
      categoriaId: true,
      clienteId: true,
      recorrencia: true,
      recorrenciaAte: true,
      recorrenteId: true,
      pago: true
    }
  });
  const ultimaPorSerie = /* @__PURE__ */ new Map();
  for (const c of recorrentes) {
    const serie = c.recorrenteId ?? c.id;
    const atual = ultimaPorSerie.get(serie);
    if (!atual || c.vencimento > atual.vencimento) ultimaPorSerie.set(serie, c);
  }
  let criadas = 0;
  for (const ultima of ultimaPorSerie.values()) {
    if (!ultima.pago) continue;
    if (await gerarProximaOcorrencia(ultima)) criadas++;
  }
  return { criadas };
}
async function resumo(carteira, ctx) {
  const base = { deletedAt: null, ...whereCarteira(carteira, ctx) };
  const hoje = inicioDoDia();
  const em7 = somarDias(hoje, 7);
  const mesInicio = /* @__PURE__ */ new Date();
  mesInicio.setDate(1);
  mesInicio.setHours(0, 0, 0, 0);
  const mesFim = new Date(mesInicio);
  mesFim.setMonth(mesFim.getMonth() + 1);
  const soma = async (where) => (await prisma.conta.aggregate({ _sum: { valor: true }, where: { ...base, ...where } }))._sum.valor?.toNumber() ?? 0;
  const cont = (where) => prisma.conta.count({ where: { ...base, ...where } });
  const [
    aReceberPendente,
    aPagarPendente,
    recebidoMes,
    pagoMes,
    vencReceberSoma,
    vencPagarSoma,
    vencReceberN,
    vencPagarN,
    aVencer7ReceberSoma,
    aVencer7PagarSoma,
    aVencer7ReceberN,
    aVencer7PagarN
  ] = await Promise.all([
    soma({ tipo: "RECEBER", pago: false }),
    soma({ tipo: "PAGAR", pago: false }),
    soma({ tipo: "RECEBER", pago: true, pagoEm: { gte: mesInicio, lt: mesFim } }),
    soma({ tipo: "PAGAR", pago: true, pagoEm: { gte: mesInicio, lt: mesFim } }),
    soma({ tipo: "RECEBER", pago: false, vencimento: { lt: hoje } }),
    soma({ tipo: "PAGAR", pago: false, vencimento: { lt: hoje } }),
    cont({ tipo: "RECEBER", pago: false, vencimento: { lt: hoje } }),
    cont({ tipo: "PAGAR", pago: false, vencimento: { lt: hoje } }),
    soma({ tipo: "RECEBER", pago: false, vencimento: { gte: hoje, lt: em7 } }),
    soma({ tipo: "PAGAR", pago: false, vencimento: { gte: hoje, lt: em7 } }),
    cont({ tipo: "RECEBER", pago: false, vencimento: { gte: hoje, lt: em7 } }),
    cont({ tipo: "PAGAR", pago: false, vencimento: { gte: hoje, lt: em7 } })
  ]);
  return {
    aReceberPendente,
    aPagarPendente,
    saldoPrevisto: aReceberPendente - aPagarPendente,
    recebidoMes,
    pagoMes,
    resultadoMes: recebidoMes - pagoMes,
    vencidasReceber: { total: vencReceberSoma, count: vencReceberN },
    vencidasPagar: { total: vencPagarSoma, count: vencPagarN },
    aVencer7Receber: { total: aVencer7ReceberSoma, count: aVencer7ReceberN },
    aVencer7Pagar: { total: aVencer7PagarSoma, count: aVencer7PagarN }
  };
}
async function porCategoria(carteira, ctx) {
  const mesInicio = /* @__PURE__ */ new Date();
  mesInicio.setDate(1);
  mesInicio.setHours(0, 0, 0, 0);
  const mesFim = new Date(mesInicio);
  mesFim.setMonth(mesFim.getMonth() + 1);
  const contas = await prisma.conta.findMany({
    where: { deletedAt: null, ...whereCarteira(carteira, ctx), vencimento: { gte: mesInicio, lt: mesFim } },
    select: { tipo: true, valor: true, categoria: { select: { nome: true, cor: true } } }
  });
  const agrupar = (tipo) => {
    const mapa = /* @__PURE__ */ new Map();
    for (const c of contas.filter((x) => x.tipo === tipo)) {
      const nome = c.categoria?.nome ?? "Sem categoria";
      const cor = c.categoria?.cor ?? null;
      const item = mapa.get(nome) ?? { nome, cor, total: 0 };
      item.total += c.valor.toNumber();
      mapa.set(nome, item);
    }
    return [...mapa.values()].sort((a, b) => b.total - a.total);
  };
  return { despesas: agrupar("PAGAR"), receitas: agrupar("RECEBER") };
}
async function agendaFinanceira(carteira, ctx) {
  const hoje = inicioDoDia();
  const amanha = somarDias(hoje, 1);
  const em7 = somarDias(hoje, 8);
  const pendentes = await prisma.conta.findMany({
    where: { deletedAt: null, pago: false, ...whereCarteira(carteira, ctx) },
    orderBy: { vencimento: "asc" },
    include: {
      categoria: { select: { nome: true, cor: true } },
      cliente: { select: { nome: true } }
    }
  });
  const itens = pendentes.map(mapConta);
  return {
    vencidas: itens.filter((c) => c.vencimento < hoje),
    hoje: itens.filter((c) => c.vencimento >= hoje && c.vencimento < amanha),
    semana: itens.filter((c) => c.vencimento >= amanha && c.vencimento < em7),
    depois: itens.filter((c) => c.vencimento >= em7)
  };
}

// src/realtime/reminders.ts
var JANELA_MIN = 15;
var SCAN_MIN = 10;
var LEMBRETE_CLIENTE_MIN = 30;
var JANELA_CLIENTE_H = 24;
var ultimoLembreteEm = null;
var ultimoScanEm = null;
function statusJobs() {
  return { ultimoLembreteEm, ultimoScanEm, janelaLembreteMin: JANELA_MIN, scanMin: SCAN_MIN };
}
var brl = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
var dataFmt = (d) => d.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" });
var horaFmt = (d) => d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" });
var quandoFmt = (d) => new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo" }).format(d);
function startReminderLoop() {
  const check = async () => {
    ultimoLembreteEm = /* @__PURE__ */ new Date();
    const agora = /* @__PURE__ */ new Date();
    const limite = new Date(agora.getTime() + JANELA_MIN * 60 * 1e3);
    const eventos = await prisma.evento.findMany({
      where: {
        deletedAt: null,
        lembreteEnviado: false,
        recorrencia: "NENHUMA",
        inicio: { gte: agora, lte: limite }
      },
      include: { participantes: { select: { userId: true } } }
    });
    for (const ev of eventos) {
      const hora = horaFmt(ev.inicio);
      const destinatarios = /* @__PURE__ */ new Set([ev.donoId, ...ev.participantes.map((p) => p.userId)]);
      for (const uid of destinatarios) {
        await notificar(
          uid,
          "lembrete",
          { evento: ev.titulo, hora },
          { entidadeTipo: "evento", entidadeId: ev.id }
        );
      }
      await prisma.evento.update({ where: { id: ev.id }, data: { lembreteEnviado: true } });
    }
  };
  setInterval(() => void check().catch(() => {
  }), 6e4);
  void check().catch(() => {
  });
  setInterval(() => void scanProativo().catch(() => {
  }), SCAN_MIN * 60 * 1e3);
  void scanProativo().catch(() => {
  });
  setInterval(() => void lembrarClientes().catch(() => {
  }), LEMBRETE_CLIENTE_MIN * 60 * 1e3);
  void lembrarClientes().catch(() => {
  });
}
async function lembrarClientes() {
  const agora = /* @__PURE__ */ new Date();
  const limite = new Date(agora.getTime() + JANELA_CLIENTE_H * 60 * 60 * 1e3);
  const eventos = await prisma.evento.findMany({
    where: {
      deletedAt: null,
      lembreteClienteEnviado: false,
      recorrencia: "NENHUMA",
      escopo: "EMPRESA",
      tipo: { in: ["REUNIAO", "COMPROMISSO"] },
      inicio: { gte: agora, lte: limite },
      cliente: { is: { email: { not: null } } }
    },
    select: {
      id: true,
      titulo: true,
      inicio: true,
      diaInteiro: true,
      linkReuniao: true,
      cliente: { select: { nome: true, email: true } }
    }
  });
  for (const ev of eventos) {
    if (ev.cliente?.email) {
      void enviarEmailTemplate("lembrete_reuniao_cliente", ev.cliente.email, {
        nome: ev.cliente.nome,
        titulo: ev.titulo,
        quando: ev.diaInteiro ? `${dataFmt(ev.inicio)} (dia inteiro)` : quandoFmt(ev.inicio),
        link: ev.linkReuniao ?? ""
      }).catch(() => {
      });
    }
    await prisma.evento.update({ where: { id: ev.id }, data: { lembreteClienteEnviado: true } });
  }
}
async function scanProativo() {
  ultimoScanEm = /* @__PURE__ */ new Date();
  const agora = /* @__PURE__ */ new Date();
  const cards = await prisma.card.findMany({
    where: {
      deletedAt: null,
      status: { not: "CONCLUIDO" },
      responsavelId: { not: null },
      prazo: { lt: agora }
    },
    select: { responsavelId: true, projetoId: true, projeto: { select: { nome: true } } }
  });
  const grupos = /* @__PURE__ */ new Map();
  for (const c of cards) {
    if (!c.responsavelId) continue;
    const key = `${c.responsavelId}:${c.projetoId}`;
    const g = grupos.get(key);
    if (g) g.qtd++;
    else
      grupos.set(key, {
        userId: c.responsavelId,
        projetoId: c.projetoId,
        nome: c.projeto.nome,
        qtd: 1
      });
  }
  for (const g of grupos.values()) {
    await notificar(
      g.userId,
      "tarefa_atrasada",
      { qtd: String(g.qtd), projeto: g.nome },
      { entidadeTipo: "projeto", entidadeId: g.projetoId, unico: true }
    );
  }
  const admins = await prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
    select: { id: true }
  });
  await garantirProximasRecorrencias().catch(() => {
  });
  const inicioHoje = new Date(agora);
  inicioHoje.setHours(0, 0, 0, 0);
  const em7diasContas = new Date(inicioHoje.getTime() + 7 * 864e5);
  const contas = await prisma.conta.findMany({
    where: { deletedAt: null, pago: false, vencimento: { lt: em7diasContas } },
    select: { id: true, descricao: true, tipo: true, valor: true, vencimento: true, escopo: true, donoId: true }
  });
  const alvosDe = (c) => c.escopo === "PESSOAL" ? c.donoId ? [c.donoId] : [] : admins.map((a) => a.id);
  for (const conta of contas) {
    const rotulo = conta.tipo === "RECEBER" ? "A receber" : "A pagar";
    const vencida = conta.vencimento < inicioHoje;
    const vars = {
      descricao: conta.descricao,
      tipo: rotulo,
      valor: brl.format(Number(conta.valor)),
      vencimento: dataFmt(conta.vencimento)
    };
    for (const uid of alvosDe(conta)) {
      await notificar(uid, vencida ? "conta_vencida" : "conta_a_vencer", vars, {
        entidadeTipo: "conta",
        entidadeId: conta.id,
        unico: true
      });
    }
  }
  const docs = await prisma.documento.findMany({
    where: { deletedAt: null, status: "EM_REVISAO" },
    select: { id: true, titulo: true }
  });
  for (const doc of docs) {
    for (const a of admins) {
      await notificar(
        a.id,
        "documento_revisao",
        { documento: doc.titulo },
        { entidadeTipo: "documento", entidadeId: doc.id, unico: true }
      );
    }
  }
  const idAdmins = admins.map((a) => a.id);
  try {
    const em7dias = new Date(inicioHoje.getTime() + 7 * 864e5);
    const eventosProx = await prisma.evento.findMany({
      where: { deletedAt: null, recorrencia: "NENHUMA", diaInteiro: false, inicio: { gte: agora, lte: em7dias } },
      select: { id: true, titulo: true, inicio: true, fim: true, donoId: true, participantes: { select: { userId: true } } }
    });
    const porPessoa = /* @__PURE__ */ new Map();
    for (const ev of eventosProx) {
      for (const uid of /* @__PURE__ */ new Set([ev.donoId, ...ev.participantes.map((p) => p.userId)])) {
        const arr = porPessoa.get(uid) ?? [];
        arr.push({ id: ev.id, titulo: ev.titulo, inicio: ev.inicio, fim: ev.fim });
        porPessoa.set(uid, arr);
      }
    }
    for (const [uid, evs] of porPessoa) {
      const ord = [...evs].sort((a, b) => +a.inicio - +b.inicio);
      const conflitantes = /* @__PURE__ */ new Set();
      for (let i = 0; i < ord.length; i++) {
        const a = ord[i];
        const af = a.fim ? +a.fim : +a.inicio + 30 * 6e4;
        for (let j = i + 1; j < ord.length; j++) {
          const b = ord[j];
          const bi = +b.inicio;
          if (bi >= af) break;
          conflitantes.add(a.id);
          conflitantes.add(b.id);
        }
      }
      for (const ev of ord) {
        if (!conflitantes.has(ev.id)) continue;
        await notificar(
          uid,
          "conflito_agenda",
          { titulo: ev.titulo, quando: quandoFmt(ev.inicio) },
          { entidadeTipo: "evento", entidadeId: ev.id, unico: true }
        ).catch(() => {
        });
      }
    }
  } catch {
  }
  try {
    const d14 = new Date(agora.getTime() - 14 * 864e5);
    const parados = await prisma.projeto.findMany({
      where: { deletedAt: null, status: "ATIVO", updatedAt: { lt: d14 } },
      select: { id: true, nome: true, responsavelId: true }
    });
    for (const p of parados) {
      const alvo = p.responsavelId ? [p.responsavelId] : idAdmins;
      for (const uid of alvo) {
        await notificar(uid, "projeto_parado", { projeto: p.nome }, { entidadeTipo: "projeto", entidadeId: p.id, unico: true }).catch(() => {
        });
      }
    }
    const semResp = await prisma.projeto.findMany({
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: null },
      select: { id: true, nome: true }
    });
    for (const p of semResp) {
      for (const uid of idAdmins) {
        await notificar(uid, "projeto_sem_responsavel", { projeto: p.nome }, { entidadeTipo: "projeto", entidadeId: p.id, unico: true }).catch(() => {
        });
      }
    }
  } catch {
  }
  try {
    const oportunidades = await prisma.lead.findMany({
      where: {
        deletedAt: null,
        convertidoEmClienteId: null,
        perdidoEm: null,
        clientePortal: { is: { situacaoComercial: { in: ["ATIVO", "INATIVO"] } } }
      },
      select: { id: true, responsavelId: true, clientePortal: { select: { nome: true } } }
    });
    for (const o of oportunidades) {
      const alvo = o.responsavelId ? [o.responsavelId] : idAdmins;
      for (const uid of alvo) {
        await notificar(uid, "upsell_oportunidade", { cliente: o.clientePortal?.nome ?? "Cliente" }, { entidadeTipo: "lead", entidadeId: o.id, unico: true }).catch(() => {
        });
      }
    }
  } catch {
  }
  try {
    const d5 = new Date(agora.getTime() - 5 * 864e5);
    const parados = await prisma.documento.findMany({
      where: {
        deletedAt: null,
        OR: [
          { propostaStatus: "PENDENTE", propostaSolicitadaEm: { lt: d5 }, propostaRespondidaEm: null },
          { assinaturaSolicitadaEm: { lt: d5 }, assinadoEm: null }
        ]
      },
      select: { id: true, titulo: true, criadoPorId: true }
    });
    for (const doc of parados) {
      for (const uid of new Set([doc.criadoPorId, ...idAdmins].filter((x) => !!x))) {
        await notificar(uid, "documento_parado", { documento: doc.titulo }, { entidadeTipo: "documento", entidadeId: doc.id, unico: true }).catch(() => {
        });
      }
    }
  } catch {
  }
  try {
    const d14lead = new Date(agora.getTime() - 14 * 864e5);
    const leadsParados = await prisma.lead.findMany({
      where: { deletedAt: null, convertidoEmClienteId: null, perdidoEm: null, updatedAt: { lt: d14lead } },
      select: { id: true, nome: true, empresa: true, responsavelId: true }
    });
    for (const l of leadsParados) {
      const contato = l.empresa ? `${l.nome} \xB7 ${l.empresa}` : l.nome;
      const alvo = l.responsavelId ? [l.responsavelId] : idAdmins;
      for (const uid of alvo) {
        await notificar(uid, "lead_parado", { contato }, { entidadeTipo: "lead", entidadeId: l.id, unico: true }).catch(() => {
        });
      }
    }
  } catch {
  }
}

// src/observability/monitor.ts
import {
  monitorEventLoopDelay,
  performance,
  PerformanceObserver,
  constants
} from "perf_hooks";
import v8 from "v8";
var NS_PER_MS = 1e6;
var eld = monitorEventLoopDelay({ resolution: 10 });
eld.enable();
var eluPrev = performance.eventLoopUtilization();
var cpuPrev = process.cpuUsage();
var cpuHrPrev = process.hrtime.bigint();
var gcMajorMs = 0;
var gcObs = new PerformanceObserver((list) => {
  for (const e of list.getEntries()) {
    const kind = e.detail?.kind;
    if (kind === constants.NODE_PERFORMANCE_GC_MAJOR) gcMajorMs += e.duration;
  }
});
gcObs.observe({ entryTypes: ["gc"] });
var BUCKET_BOUNDS = [
  1,
  2,
  4,
  8,
  16,
  32,
  64,
  128,
  256,
  512,
  1024,
  2048,
  4096,
  8192,
  16384,
  Infinity
];
var endpoints = /* @__PURE__ */ new Map();
var winReq = 0;
var winErr = 0;
function recordCall(path, ok, durationMs) {
  let s = endpoints.get(path);
  if (!s) {
    s = { count: 0, errors: 0, totalMs: 0, maxMs: 0, lastMs: 0, buckets: new Array(BUCKET_BOUNDS.length).fill(0) };
    endpoints.set(path, s);
  }
  s.count++;
  if (!ok) s.errors++;
  s.totalMs += durationMs;
  s.lastMs = durationMs;
  if (durationMs > s.maxMs) s.maxMs = durationMs;
  let bi = BUCKET_BOUNDS.findIndex((b) => durationMs <= b);
  if (bi < 0) bi = BUCKET_BOUNDS.length - 1;
  s.buckets[bi] = (s.buckets[bi] ?? 0) + 1;
  winReq++;
  if (!ok) winErr++;
}
function percentilBuckets(buckets, count, p) {
  if (count === 0) return 0;
  const alvo = Math.ceil(p / 100 * count);
  let acc = 0;
  for (let i = 0; i < buckets.length; i++) {
    acc += buckets[i] ?? 0;
    if (acc >= alvo) {
      const bound = BUCKET_BOUNDS[i] ?? 0;
      return bound === Infinity ? BUCKET_BOUNDS[i - 1] ?? 0 : bound;
    }
  }
  return 0;
}
var RING = 60;
var ring = [];
function amostrar() {
  const loopP50 = eld.percentile(50) / NS_PER_MS;
  const loopP99 = eld.percentile(99) / NS_PER_MS;
  eld.reset();
  const elu = performance.eventLoopUtilization(eluPrev).utilization;
  eluPrev = performance.eventLoopUtilization();
  const mem = process.memoryUsage();
  const cpuNow = process.cpuUsage(cpuPrev);
  const hrNow = process.hrtime.bigint();
  const wallMs = Number(hrNow - cpuHrPrev) / NS_PER_MS;
  cpuPrev = process.cpuUsage();
  cpuHrPrev = hrNow;
  const cpuPct = wallMs > 0 ? (cpuNow.user + cpuNow.system) / 1e3 / wallMs * 100 : 0;
  ring.push({
    ts: Date.now(),
    loopP50: round1(loopP50),
    loopP99: round1(loopP99),
    elu: Math.round(elu * 100) / 100,
    heapMB: Math.round(mem.heapUsed / 1e6),
    rssMB: Math.round(mem.rss / 1e6),
    cpuPct: Math.round(cpuPct),
    gcMs: Math.round(gcMajorMs),
    req: winReq,
    err: winErr
  });
  if (ring.length > RING) ring.shift();
  gcMajorMs = 0;
  winReq = 0;
  winErr = 0;
}
function round1(n) {
  return Math.round(n * 10) / 10;
}
var intervalo = null;
function startMonitor() {
  if (intervalo) return;
  intervalo = setInterval(amostrar, 1e4);
  intervalo.unref();
}
function getSerie() {
  return [...ring];
}
function getEndpoints() {
  const out = [];
  for (const [path, s] of endpoints) {
    out.push({
      path,
      count: s.count,
      errors: s.errors,
      taxaErro: s.count ? Math.round(s.errors / s.count * 1e3) / 10 : 0,
      mediaMs: s.count ? Math.round(s.totalMs / s.count) : 0,
      p95Ms: percentilBuckets(s.buckets, s.count, 95),
      maxMs: Math.round(s.maxMs)
    });
  }
  return out.sort((a, b) => b.count - a.count);
}
function getProcessoAgora() {
  const mem = process.memoryUsage();
  const heap = v8.getHeapStatistics();
  const ultima = ring[ring.length - 1];
  return {
    heapUsadoMB: Math.round(mem.heapUsed / 1e6),
    heapLimiteMB: Math.round(heap.heap_size_limit / 1e6),
    heapUsoPct: Math.round(mem.heapUsed / heap.heap_size_limit * 100),
    rssMB: Math.round(mem.rss / 1e6),
    loopP99: ultima?.loopP99 ?? 0,
    elu: ultima?.elu ?? 0,
    cpuPct: ultima?.cpuPct ?? 0,
    gcMs: ultima?.gcMs ?? 0
  };
}
function getResumoTrafego() {
  const recentes = ring.slice(-6);
  const req = recentes.reduce((a, s) => a + s.req, 0);
  const err = recentes.reduce((a, s) => a + s.err, 0);
  let totalReq = 0;
  let totalErr = 0;
  for (const s of endpoints.values()) {
    totalReq += s.count;
    totalErr += s.errors;
  }
  return {
    reqUltimoMin: req,
    errUltimoMin: err,
    taxaErroUltimoMin: req ? Math.round(err / req * 1e3) / 10 : 0,
    totalReq,
    totalErr
  };
}

// src/modules/sistema/sistema.service.ts
var DIA = 864e5;
var num = (v) => v == null ? 0 : Number(v);
var RANK = { ok: 0, degradado: 1, critico: 2 };
var pior = (a, b) => RANK[a] >= RANK[b] ? a : b;
async function saude() {
  const t0 = Date.now();
  let dbOk = true;
  try {
    await prisma.$queryRaw`SELECT 1`;
  } catch {
    dbOk = false;
  }
  const dbLatenciaMs = Date.now() - t0;
  const proc = getProcessoAgora();
  const trafego = getResumoTrafego();
  const jobs = statusJobs();
  const componentes = [];
  const nivelDb = !dbOk ? "critico" : dbLatenciaMs > 400 ? "degradado" : "ok";
  componentes.push({
    nome: "Banco de dados",
    nivel: nivelDb,
    detalhe: dbOk ? `${dbLatenciaMs}ms de lat\xEAncia` : "inacess\xEDvel"
  });
  let nivelProc = "ok";
  if (proc.loopP99 >= 250 || proc.heapUsoPct >= 90) nivelProc = "critico";
  else if (proc.loopP99 >= 100 || proc.heapUsoPct >= 85) nivelProc = "degradado";
  componentes.push({
    nome: "Processo (event loop)",
    nivel: nivelProc,
    detalhe: `event loop p99 ${proc.loopP99}ms \xB7 heap ${proc.heapUsoPct}%`
  });
  const idadeMin = (d) => d ? (Date.now() - new Date(d).getTime()) / 6e4 : Infinity;
  const idadeLembrete = idadeMin(jobs.ultimoLembreteEm);
  const idadeScan = idadeMin(jobs.ultimoScanEm);
  let nivelJobs = "ok";
  if (idadeLembrete > 15 || idadeScan > 30) nivelJobs = "critico";
  else if (idadeLembrete > 5 || idadeScan > 25) nivelJobs = "degradado";
  componentes.push({
    nome: "Jobs em segundo plano",
    nivel: nivelJobs,
    detalhe: Number.isFinite(idadeLembrete) ? `lembrete h\xE1 ${Math.round(idadeLembrete)}min \xB7 scan h\xE1 ${Math.round(idadeScan)}min` : "ainda n\xE3o executaram"
  });
  const nivelErros = trafego.taxaErroUltimoMin >= 20 ? "critico" : trafego.taxaErroUltimoMin >= 5 ? "degradado" : "ok";
  componentes.push({
    nome: "Taxa de erro",
    nivel: nivelErros,
    detalhe: `${trafego.taxaErroUltimoMin}% no \xFAltimo minuto (${trafego.reqUltimoMin} req)`
  });
  componentes.push({
    nome: "Tempo real",
    nivel: "ok",
    detalhe: `${contarConexoesSocket()} conex\xE3o(\xF5es) ativa(s)`
  });
  const statusGeral = componentes.reduce((acc, c) => pior(acc, c.nivel), "ok");
  return {
    statusGeral,
    componentes,
    uptimeSeg: Math.floor(process.uptime()),
    nodeVersao: process.version,
    ambiente: config.NODE_ENV,
    memoria: proc,
    db: { ok: dbOk, latenciaMs: dbLatenciaMs },
    trafego,
    conexoesSocket: contarConexoesSocket(),
    iaAtiva: isAiEnabled,
    jobs
  };
}
function desempenho() {
  return {
    serie: getSerie(),
    endpoints: getEndpoints(),
    maisLentos: [...getEndpoints()].sort((a, b) => b.p95Ms - a.p95Ms).slice(0, 8),
    comErro: getEndpoints().filter((e) => e.errors > 0).sort((a, b) => b.taxaErro - a.taxaErro).slice(0, 8),
    queriesLentas: getSlowQueries()
  };
}
async function metricas() {
  const d7 = new Date(Date.now() - 7 * DIA);
  const d30 = new Date(Date.now() - 30 * DIA);
  const agora = /* @__PURE__ */ new Date();
  const [
    porPapelRaw,
    clientes,
    leads,
    projetos,
    cards,
    documentos,
    contas,
    mensagens,
    eventos,
    novos7,
    novos30,
    sessoesAtivas
  ] = await Promise.all([
    prisma.user.groupBy({ by: ["role"], where: { deletedAt: null }, _count: true }),
    prisma.cliente.count({ where: { deletedAt: null } }),
    prisma.lead.count({ where: { deletedAt: null, convertidoEmClienteId: null } }),
    prisma.projeto.count({ where: { deletedAt: null } }),
    prisma.card.count({ where: { deletedAt: null } }),
    prisma.documento.count({ where: { deletedAt: null } }),
    prisma.conta.count({ where: { deletedAt: null } }),
    prisma.mensagem.count({ where: { deletedAt: null } }),
    prisma.evento.count({ where: { deletedAt: null } }),
    prisma.cliente.count({ where: { deletedAt: null, createdAt: { gte: d7 } } }),
    prisma.cliente.count({ where: { deletedAt: null, createdAt: { gte: d30 } } }),
    prisma.session.count({ where: { expiresAt: { gt: agora } } })
  ]);
  const porPapel = {};
  for (const g of porPapelRaw) porPapel[g.role] = g._count;
  return {
    porPapel,
    clientes,
    leads,
    projetos,
    cards,
    documentos,
    contas,
    mensagens,
    eventos,
    novosClientes7: novos7,
    novosClientes30: novos30,
    sessoesAtivas
  };
}
function sessoes() {
  return prisma.session.findMany({
    where: { expiresAt: { gt: /* @__PURE__ */ new Date() } },
    include: { user: { select: { nome: true, email: true, role: true } } },
    orderBy: { createdAt: "desc" },
    take: 100
  });
}
async function revogarSessao(id) {
  await prisma.session.deleteMany({ where: { id } });
  return { ok: true };
}
function atividade() {
  return prisma.activityLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 60,
    include: { user: { select: { nome: true } } }
  });
}
function erros(ocultos = false) {
  return prisma.errorLog.findMany({
    where: ocultos ? { ignorado: true } : { ignorado: false },
    orderBy: [{ resolvido: "asc" }, { ultimaVez: "desc" }],
    take: 100
  });
}
async function resolverErro(id) {
  await prisma.errorLog.update({
    where: { id },
    data: { resolvido: true, resolvidoEm: /* @__PURE__ */ new Date(), regrediu: false }
  });
  return { ok: true };
}
async function ignorarErro(id) {
  await prisma.errorLog.update({ where: { id }, data: { ignorado: true, resolvido: true } });
  return { ok: true };
}
async function reexibirErro(id) {
  await prisma.errorLog.update({ where: { id }, data: { ignorado: false, resolvido: false, resolvidoEm: null } });
  return { ok: true };
}
async function resolverTodosErros() {
  const r = await prisma.errorLog.updateMany({
    where: { resolvido: false, ignorado: false },
    data: { resolvido: true, resolvidoEm: /* @__PURE__ */ new Date(), regrediu: false }
  });
  return { ok: true, quantidade: r.count };
}
async function resolverTodosIncidentes() {
  const r = await prisma.incidente.updateMany({
    where: { status: { not: "RESOLVIDO" } },
    data: { status: "RESOLVIDO", resolvidoEm: /* @__PURE__ */ new Date() }
  });
  return { ok: true, quantidade: r.count };
}
async function rodarVarredura() {
  await scanProativo();
  return { ok: true };
}
async function notificarRootErro(titulo, resumo2, errorId) {
  const roots = await prisma.user.findMany({
    where: { role: "ROOT", ativo: true, deletedAt: null },
    select: { id: true }
  });
  for (const r of roots) {
    await notificar(r.id, "erro", { titulo, resumo: resumo2 }, { entidadeTipo: "erro", entidadeId: errorId });
  }
}
function normalizarMensagem(msg) {
  return msg.toLowerCase().replace(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/g, "<email>").replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, "<uuid>").replace(/c[a-z0-9]{24,}/g, "<id>").replace(/0x[0-9a-f]+/g, "<hex>").replace(/\d+/g, "<n>").trim();
}
function frameDoApp(stack) {
  if (!stack) return "";
  for (const linha of stack.split("\n")) {
    const l = linha.trim();
    if (l.startsWith("at ") && !l.includes("node_modules") && !l.includes("node:")) {
      return l.replace(/:\d+:\d+/g, "");
    }
  }
  return "";
}
async function registrarErro(data) {
  const fingerprint = createHash("sha1").update(`${normalizarMensagem(data.mensagem)}|${frameDoApp(data.stack)}|${data.rota ?? ""}`).digest("hex").slice(0, 32);
  const existente = await prisma.errorLog.findUnique({ where: { fingerprint } });
  const agora = /* @__PURE__ */ new Date();
  const resumo2 = data.mensagem.slice(0, 140);
  if (!existente) {
    const criado = await prisma.errorLog.create({
      data: {
        fingerprint,
        rota: data.rota ?? null,
        mensagem: data.mensagem.slice(0, 5e3),
        stack: data.stack?.slice(0, 8e3) ?? null,
        userId: data.userId ?? null,
        ultimaVez: agora
      }
    });
    await notificarRootErro("Novo erro no sistema", resumo2, criado.id).catch(() => {
    });
    return criado;
  }
  const regressao = existente.resolvido && !existente.ignorado;
  const atualizado = await prisma.errorLog.update({
    where: { fingerprint },
    data: {
      ocorrencias: { increment: 1 },
      ultimaVez: agora,
      mensagem: data.mensagem.slice(0, 5e3),
      stack: data.stack?.slice(0, 8e3) ?? null,
      userId: data.userId ?? null,
      ...regressao ? { resolvido: false, regrediu: true } : {}
    }
  });
  if (regressao) {
    await notificarRootErro("Erro voltou (regress\xE3o)", resumo2, atualizado.id).catch(() => {
    });
  }
  return atualizado;
}
async function banco() {
  const status = async (nome) => {
    try {
      const rows = await prisma.$queryRawUnsafe(
        `SHOW GLOBAL STATUS LIKE '${nome}'`
      );
      return rows[0] ? num(rows[0].Value) : null;
    } catch {
      return null;
    }
  };
  const variavel = async (nome) => {
    try {
      const rows = await prisma.$queryRawUnsafe(
        `SHOW VARIABLES LIKE '${nome}'`
      );
      return rows[0] ? num(rows[0].Value) : null;
    } catch {
      return null;
    }
  };
  const t0 = Date.now();
  let ok = true;
  try {
    await prisma.$queryRaw`SELECT 1`;
  } catch {
    ok = false;
  }
  const latenciaMs = Date.now() - t0;
  const [uptime, threadsConectadas, threadsRodando, picoConexoes, maxConnections] = await Promise.all([
    status("Uptime"),
    status("Threads_connected"),
    status("Threads_running"),
    status("Max_used_connections"),
    variavel("max_connections")
  ]);
  let tabelas = [];
  let totalMB = 0;
  try {
    const rows = await prisma.$queryRaw`
      SELECT table_name AS table_name,
        ROUND(data_length / 1024 / 1024, 2)  AS data_mb,
        ROUND(index_length / 1024 / 1024, 2) AS index_mb,
        ROUND((data_length + index_length) / 1024 / 1024, 2) AS total_mb,
        table_rows AS table_rows
      FROM information_schema.tables
      WHERE table_schema = DATABASE()
      ORDER BY (data_length + index_length) DESC`;
    tabelas = rows.map((r) => ({
      nome: r.table_name,
      dadosMB: num(r.data_mb),
      indiceMB: num(r.index_mb),
      totalMB: num(r.total_mb),
      linhas: num(r.table_rows)
    }));
    totalMB = Math.round(tabelas.reduce((a, t) => a + t.totalMB, 0) * 100) / 100;
  } catch {
    tabelas = [];
  }
  const usoConexoesPct = maxConnections && threadsConectadas ? Math.round(threadsConectadas / maxConnections * 100) : null;
  let tabelasSemIndice = [];
  try {
    const rows = await prisma.$queryRaw`
      SELECT t.TABLE_NAME
      FROM information_schema.TABLES t
      LEFT JOIN information_schema.STATISTICS s
        ON t.TABLE_SCHEMA = s.TABLE_SCHEMA AND t.TABLE_NAME = s.TABLE_NAME
      WHERE t.TABLE_SCHEMA = DATABASE()
        AND t.TABLE_TYPE = 'BASE TABLE'
        AND s.INDEX_NAME IS NULL
        AND (t.TABLE_ROWS > 1000 OR (t.DATA_LENGTH + t.INDEX_LENGTH) > 5242880)`;
    tabelasSemIndice = rows.map((r) => r.TABLE_NAME);
  } catch {
    tabelasSemIndice = [];
  }
  return {
    ok,
    latenciaMs,
    uptimeSeg: uptime,
    threadsConectadas,
    threadsRodando,
    picoConexoes,
    maxConnections,
    usoConexoesPct,
    totalMB,
    tabelas,
    tabelasSemIndice
  };
}
function incidentes() {
  return prisma.incidente.findMany({ orderBy: [{ status: "asc" }, { createdAt: "desc" }], take: 100 });
}
async function reconhecerIncidente(id) {
  await prisma.incidente.update({
    where: { id },
    data: { status: "RECONHECIDO", reconhecidoEm: /* @__PURE__ */ new Date() }
  });
  return { ok: true };
}
async function resolverIncidente(id) {
  await prisma.incidente.update({
    where: { id },
    data: { status: "RESOLVIDO", resolvidoEm: /* @__PURE__ */ new Date() }
  });
  return { ok: true };
}
async function historicoUptime() {
  const inicio = /* @__PURE__ */ new Date();
  inicio.setHours(0, 0, 0, 0);
  inicio.setDate(inicio.getDate() - 89);
  const incs = await prisma.incidente.findMany({
    where: { createdAt: { gte: inicio } },
    select: { createdAt: true, severidade: true }
  });
  const porDia = /* @__PURE__ */ new Map();
  for (const i of incs) {
    const chave = new Date(i.createdAt).toISOString().slice(0, 10);
    const nivel = i.severidade === "critico" ? "critico" : "degradado";
    porDia.set(chave, pior(porDia.get(chave) ?? "ok", nivel));
  }
  const dias = [];
  let diasOk = 0;
  for (let d = 0; d < 90; d++) {
    const data = new Date(inicio);
    data.setDate(inicio.getDate() + d);
    const chave = data.toISOString().slice(0, 10);
    const nivel = porDia.get(chave) ?? "ok";
    if (nivel === "ok") diasOk++;
    dias.push({ dia: chave, nivel });
  }
  return { dias, uptimePct: Math.round(diasOk / 90 * 1e3) / 10 };
}
async function diagnostico() {
  const s = await saude();
  const errosAbertos = await prisma.errorLog.count({ where: { resolvido: false } });
  return {
    geradoEm: (/* @__PURE__ */ new Date()).toISOString(),
    ambiente: s.ambiente,
    nodeVersao: s.nodeVersao,
    statusGeral: s.statusGeral,
    uptimeSeg: s.uptimeSeg,
    memoria: s.memoria,
    db: s.db,
    trafego: s.trafego,
    componentes: s.componentes,
    errosAbertos,
    jobs: s.jobs,
    endpointsMaisLentos: [...getEndpoints()].sort((a, b) => b.p95Ms - a.p95Ms).slice(0, 5)
  };
}
async function atencao() {
  const agora = /* @__PURE__ */ new Date();
  const d14 = new Date(Date.now() - 14 * DIA);
  const [
    projetosSemResp,
    clientesSemResp,
    docsRevisao,
    contasVencidas,
    leadsParados,
    usuariosInativos,
    sessoesExpiradas,
    errosAbertos
  ] = await Promise.all([
    prisma.projeto.count({ where: { deletedAt: null, responsavelId: null } }),
    prisma.cliente.count({ where: { deletedAt: null, responsavelId: null } }),
    prisma.documento.count({ where: { deletedAt: null, status: "EM_REVISAO" } }),
    prisma.conta.count({ where: { deletedAt: null, pago: false, vencimento: { lt: agora } } }),
    prisma.lead.count({
      where: { deletedAt: null, convertidoEmClienteId: null, updatedAt: { lt: d14 } }
    }),
    prisma.user.count({ where: { deletedAt: null, ativo: false } }),
    prisma.session.count({ where: { expiresAt: { lt: agora } } }),
    prisma.errorLog.count({ where: { resolvido: false, ignorado: false } })
  ]);
  return {
    projetosSemResp,
    clientesSemResp,
    docsRevisao,
    contasVencidas,
    leadsParados,
    usuariosInativos,
    sessoesExpiradas,
    errosAbertos
  };
}
async function limparSessoesExpiradas() {
  const r = await prisma.session.deleteMany({ where: { expiresAt: { lt: /* @__PURE__ */ new Date() } } });
  return { removidas: r.count };
}
async function migracoes() {
  try {
    const rows = await prisma.$queryRaw`
      SELECT migration_name, finished_at FROM _prisma_migrations
      ORDER BY finished_at DESC LIMIT 40`;
    return rows.map((r) => ({ nome: r.migration_name, aplicadaEm: r.finished_at }));
  } catch {
    return [];
  }
}
function configInfo() {
  return {
    ambiente: config.NODE_ENV,
    apiPort: config.API_PORT,
    webOrigin: config.WEB_ORIGIN,
    iaAtiva: isAiEnabled,
    cspLigada: false
    // Helmet com CSP desativada por ora (ver docs/DEPLOY.md)
  };
}

export {
  recordCall,
  startMonitor,
  getProcessoAgora,
  getResumoTrafego,
  listContas,
  createConta,
  updateConta,
  removeConta,
  marcarPaga,
  resumo,
  porCategoria,
  agendaFinanceira,
  statusJobs,
  startReminderLoop,
  saude,
  desempenho,
  metricas,
  sessoes,
  revogarSessao,
  atividade,
  erros,
  resolverErro,
  ignorarErro,
  reexibirErro,
  resolverTodosErros,
  resolverTodosIncidentes,
  rodarVarredura,
  registrarErro,
  banco,
  incidentes,
  reconhecerIncidente,
  resolverIncidente,
  historicoUptime,
  diagnostico,
  atencao,
  limparSessoesExpiradas,
  migracoes,
  configInfo
};
//# sourceMappingURL=chunk-FWRXEZ6P.js.map