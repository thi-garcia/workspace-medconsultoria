// Gerado por bundle-deploy.mjs — startup file do CloudLinux Passenger (NÃO editar à mão).
process.on("unhandledRejection", (e) => { console.error(e); process.exit(1); });
import("./server.js").catch((e) => { console.error("Falha ao iniciar server.js:", e); process.exit(1); });
