import {
  garantirCardDoServicoContratado
} from "./chunk-RC5JM4L5.js";
import {
  ROLE_LEVEL,
  config,
  enviarEmailTemplate,
  isAiEnabled,
  notificar,
  prisma,
  qualificacaoContratada,
  situacaoDocumento,
  src_exports
} from "./chunk-RQVINKOG.js";

// src/modules/documentos/documentos.service.ts
import { TRPCError as TRPCError4 } from "@trpc/server";

// src/lib/ai.ts
import OpenAI, { toFile } from "openai";
var MODELO = "gpt-4o-mini";
var client = null;
function getClient() {
  if (!isAiEnabled) {
    throw new Error("IA n\xE3o configurada. Defina OPENAI_API_KEY no .env.");
  }
  if (!client) client = new OpenAI({ apiKey: config.OPENAI_API_KEY });
  return client;
}
var aiService = {
  async gerarRascunho(system, user) {
    const resp = await getClient().chat.completions.create({
      model: MODELO,
      temperature: 0.4,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user }
      ]
    });
    return resp.choices[0]?.message?.content?.trim() ?? "";
  },
  async transcrever(buffer, filename) {
    const file = await toFile(buffer, filename);
    const resp = await getClient().audio.transcriptions.create({ file, model: "whisper-1", language: "pt" });
    return (resp.text ?? "").trim();
  }
};

// src/modules/leads/leads.service.ts
import { TRPCError as TRPCError2 } from "@trpc/server";

// src/modules/pipeline/pipeline.service.ts
var DEFAULTS = [
  { nome: "Novo", ordem: 0, cor: "#2DA8E1", chaveAuto: "novo" },
  { nome: "Qualifica\xE7\xE3o", ordem: 1, cor: "#003591", chaveAuto: "qualificacao" },
  { nome: "Proposta", ordem: 2, cor: "#30AD73", chaveAuto: "proposta" },
  { nome: "Negocia\xE7\xE3o", ordem: 3, cor: "#F59E0B", chaveAuto: "negociacao" },
  { nome: "Fechado", ordem: 4, cor: "#30AD73", chaveAuto: "fechado" }
];
async function listStages() {
  const count = await prisma.pipelineStage.count();
  if (count === 0) {
    await prisma.pipelineStage.createMany({ data: DEFAULTS });
  } else {
    const semChave = await prisma.pipelineStage.findMany({ where: { chaveAuto: null } });
    for (const s of semChave) {
      const padrao = DEFAULTS.find((d) => d.nome === s.nome);
      if (padrao) await prisma.pipelineStage.update({ where: { id: s.id }, data: { chaveAuto: padrao.chaveAuto } });
    }
  }
  return prisma.pipelineStage.findMany({ orderBy: { ordem: "asc" } });
}

// src/modules/usuarios/usuarios.service.ts
import { TRPCError } from "@trpc/server";

// src/lib/password.ts
var ARGON2_PREFIX = "$argon2";
var BCRYPT_PREFIX_RE = /^\$2[aby]?\$/;
var argonMod;
var bcryptMod;
async function getArgon() {
  if (argonMod === void 0) {
    try {
      argonMod = await import("@node-rs/argon2");
    } catch {
      argonMod = null;
    }
  }
  return argonMod;
}
async function getBcrypt() {
  if (bcryptMod === void 0) {
    try {
      const m = await import("bcryptjs");
      bcryptMod = m.default ?? m;
    } catch {
      bcryptMod = null;
    }
  }
  return bcryptMod;
}
function algoritmoDoHash(hash) {
  if (hash.startsWith(ARGON2_PREFIX)) return "argon2id";
  if (BCRYPT_PREFIX_RE.test(hash)) return "bcrypt";
  return "desconhecido";
}
async function hashPassword(senha) {
  const argon = await getArgon();
  if (argon) return argon.hash(senha);
  const bcrypt = await getBcrypt();
  if (bcrypt) return bcrypt.hash(senha, 12);
  throw new Error("Nenhum algoritmo de hash dispon\xEDvel: '@node-rs/argon2' e 'bcryptjs' falharam ao carregar.");
}
async function verifyPassword(hashArmazenado, senha) {
  const algo = algoritmoDoHash(hashArmazenado);
  if (algo === "argon2id") {
    const argon = await getArgon();
    if (!argon) {
      throw new Error("Hash Argon2 encontrado, mas '@node-rs/argon2' n\xE3o p\xF4de ser carregado neste ambiente.");
    }
    try {
      return await argon.verify(hashArmazenado, senha);
    } catch {
      return false;
    }
  }
  if (algo === "bcrypt") {
    const bcrypt = await getBcrypt();
    if (!bcrypt) {
      throw new Error("Hash bcrypt encontrado, mas 'bcryptjs' (Plano B) n\xE3o est\xE1 instalado.");
    }
    try {
      return await bcrypt.compare(senha, hashArmazenado);
    } catch {
      return false;
    }
  }
  return false;
}
async function precisaRehash(hashArmazenado) {
  if (algoritmoDoHash(hashArmazenado) === "argon2id") return false;
  return await getArgon() !== null;
}

// src/lib/tokens.ts
import { randomBytes, createHash } from "crypto";
function gerarTokenPublico() {
  return randomBytes(32).toString("base64url");
}
function hashToken(raw) {
  return createHash("sha256").update(raw).digest("hex");
}
async function criarToken(userId, tipo, ttlMs) {
  const raw = randomBytes(32).toString("base64url");
  await prisma.$transaction([
    prisma.token.deleteMany({ where: { userId, tipo, usedAt: null } }),
    prisma.token.create({
      data: { tokenHash: hashToken(raw), tipo, userId, expiresAt: new Date(Date.now() + ttlMs) }
    })
  ]);
  return raw;
}
async function inspecionarToken(raw, tipo) {
  const token = await prisma.token.findUnique({
    where: { tokenHash: hashToken(raw) },
    include: { user: { select: { nome: true, email: true, deletedAt: true } } }
  });
  if (!token || token.tipo !== tipo || token.usedAt || token.expiresAt < /* @__PURE__ */ new Date() || token.user.deletedAt) {
    return null;
  }
  return { userId: token.userId, nome: token.user.nome, email: token.user.email };
}
async function consumirToken(raw, tipo) {
  const token = await prisma.token.findUnique({ where: { tokenHash: hashToken(raw) } });
  if (!token || token.tipo !== tipo || token.usedAt || token.expiresAt < /* @__PURE__ */ new Date()) return null;
  const res = await prisma.token.updateMany({
    where: { id: token.id, usedAt: null },
    data: { usedAt: /* @__PURE__ */ new Date() }
  });
  return res.count === 1 ? token.userId : null;
}

// src/modules/usuarios/usuarios.service.ts
var CONVITE_TTL_MS = 72 * 60 * 60 * 1e3;
async function gerarConvite(userId, nome, email, role) {
  const token = await criarToken(userId, "CONVITE", CONVITE_TTL_MS);
  const url = `${config.WEB_ORIGIN}/definir-senha?token=${token}`;
  const template = role === "CLIENTE" ? "portal_boas_vindas" : "convite";
  const { enviado } = await enviarEmailTemplate(template, email, { nome, link: url });
  return { conviteUrl: enviado ? null : url, emailEnviado: enviado };
}
async function garantirAcessoPortal(clienteId, nome, email) {
  const nada = { criou: false, jaTinhaAcesso: false, emailEnviado: false, conviteUrl: null };
  if (!email) return nada;
  const doCliente = await prisma.user.findFirst({
    where: { clienteId, role: "CLIENTE", deletedAt: null },
    select: { id: true }
  });
  if (doCliente) return { ...nada, jaTinhaAcesso: true };
  const doEmail = await prisma.user.findFirst({ where: { email, deletedAt: null }, select: { id: true } });
  if (doEmail) return { ...nada, jaTinhaAcesso: true };
  const usuario = await prisma.user.create({
    data: { nome: nome.trim(), email, passwordHash: null, ativo: false, role: "CLIENTE", clienteId },
    select: { id: true, nome: true, email: true }
  });
  const r = await gerarConvite(usuario.id, usuario.nome, usuario.email, "CLIENTE");
  return { criou: true, jaTinhaAcesso: false, ...r };
}
var publicSelect = {
  id: true,
  nome: true,
  email: true,
  role: true,
  ativo: true,
  avatarUrl: true,
  clienteId: true,
  createdAt: true,
  cliente: { select: { nome: true } }
};
function assertPodeAtribuir(atorRole, alvoRole) {
  if (ROLE_LEVEL[alvoRole] >= ROLE_LEVEL[atorRole]) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Voc\xEA s\xF3 pode atribuir pap\xE9is abaixo do seu."
    });
  }
}
async function assertClienteValido(clienteId) {
  const cliente = await prisma.cliente.findFirst({
    where: { id: clienteId, deletedAt: null },
    select: { id: true }
  });
  if (!cliente) throw new TRPCError({ code: "BAD_REQUEST", message: "Cliente inv\xE1lido." });
}
async function listUsuarios() {
  const users = await prisma.user.findMany({
    where: { deletedAt: null },
    select: { ...publicSelect, passwordHash: true },
    orderBy: [{ ativo: "desc" }, { nome: "asc" }]
  });
  return users.map(({ passwordHash, ...u }) => ({ ...u, pendente: passwordHash === null }));
}
function listEquipe() {
  return prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { not: "CLIENTE" } },
    select: { id: true, nome: true, avatarUrl: true },
    orderBy: { nome: "asc" }
  });
}
async function createUsuario(atorRole, input) {
  assertPodeAtribuir(atorRole, input.role);
  const clienteId = input.clienteId || null;
  if (input.role === "CLIENTE") {
    if (!clienteId) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "Selecione o cliente para o acesso ao Portal."
      });
    }
    await assertClienteValido(clienteId);
  }
  const existe = await prisma.user.findUnique({ where: { email: input.email } });
  if (existe) {
    throw new TRPCError({ code: "CONFLICT", message: "J\xE1 existe um usu\xE1rio com este e-mail." });
  }
  return prisma.user.create({
    data: {
      nome: input.nome.trim(),
      email: input.email,
      passwordHash: await hashPassword(input.senha),
      role: input.role,
      clienteId: input.role === "CLIENTE" ? clienteId : null
    },
    select: publicSelect
  });
}
async function convidarUsuario(atorRole, input) {
  assertPodeAtribuir(atorRole, input.role);
  const clienteId = input.clienteId || null;
  if (input.role === "CLIENTE") {
    if (!clienteId) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Selecione o cliente para o acesso ao Portal." });
    }
    await assertClienteValido(clienteId);
  }
  const existe = await prisma.user.findFirst({ where: { email: input.email, deletedAt: null } });
  if (existe) {
    throw new TRPCError({ code: "CONFLICT", message: "J\xE1 existe um usu\xE1rio com este e-mail." });
  }
  const usuario = await prisma.user.create({
    data: {
      nome: input.nome.trim(),
      email: input.email,
      passwordHash: null,
      // pendente até aceitar o convite
      ativo: false,
      role: input.role,
      clienteId: input.role === "CLIENTE" ? clienteId : null
    },
    select: publicSelect
  });
  const convite = await gerarConvite(usuario.id, usuario.nome, usuario.email, usuario.role);
  return { usuario, ...convite };
}
async function reenviarConvite(atorRole, id) {
  const alvo = await prisma.user.findFirst({
    where: { id, deletedAt: null },
    select: { id: true, nome: true, email: true, role: true, passwordHash: true }
  });
  if (!alvo) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Usu\xE1rio n\xE3o encontrado." });
  }
  if (alvo.passwordHash !== null) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Este usu\xE1rio j\xE1 definiu a senha." });
  }
  if (ROLE_LEVEL[alvo.role] >= ROLE_LEVEL[atorRole]) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sem permiss\xE3o sobre este usu\xE1rio." });
  }
  const convite = await gerarConvite(alvo.id, alvo.nome, alvo.email, alvo.role);
  return { ...convite, email: alvo.email };
}
async function updateUsuario(atorId, atorRole, input) {
  const alvo = await prisma.user.findUnique({ where: { id: input.id } });
  if (!alvo || alvo.deletedAt) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Usu\xE1rio n\xE3o encontrado." });
  }
  if (input.id !== atorId && ROLE_LEVEL[alvo.role] >= ROLE_LEVEL[atorRole]) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sem permiss\xE3o sobre este usu\xE1rio." });
  }
  const data = {};
  if (input.nome !== void 0) data.nome = input.nome.trim();
  if (input.email !== void 0 && input.email !== alvo.email) {
    const emailEmUso = await prisma.user.findFirst({
      where: { email: input.email, deletedAt: null, id: { not: input.id } },
      select: { id: true }
    });
    if (emailEmUso) {
      throw new TRPCError({ code: "CONFLICT", message: "J\xE1 existe um usu\xE1rio com este e-mail." });
    }
    data.email = input.email;
  }
  if (input.role !== void 0 && input.role !== alvo.role) {
    if (input.id === atorId) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Voc\xEA n\xE3o pode alterar o pr\xF3prio papel." });
    }
    assertPodeAtribuir(atorRole, input.role);
    data.role = input.role;
  }
  if (input.ativo !== void 0) {
    if (input.id === atorId && input.ativo === false) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Voc\xEA n\xE3o pode desativar a pr\xF3pria conta." });
    }
    data.ativo = input.ativo;
  }
  const finalRole = data.role ?? alvo.role;
  const clienteInformado = input.clienteId !== void 0;
  const finalClienteId = clienteInformado ? input.clienteId || null : alvo.clienteId;
  if (finalRole === "CLIENTE") {
    if (!finalClienteId) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "Cliente \xE9 obrigat\xF3rio para acesso ao Portal."
      });
    }
    await assertClienteValido(finalClienteId);
    data.clienteId = finalClienteId;
  } else {
    data.clienteId = null;
  }
  if (input.novaSenha) data.passwordHash = await hashPassword(input.novaSenha);
  const user = await prisma.user.update({ where: { id: input.id }, data, select: publicSelect });
  if (data.ativo === false || data.passwordHash || data.email) {
    await prisma.session.deleteMany({ where: { userId: input.id } });
  }
  return user;
}
async function resumoResponsabilidades(id) {
  const [clientes, leads, projetos, tarefas, participacoes] = await Promise.all([
    prisma.cliente.count({ where: { responsavelId: id, deletedAt: null } }),
    prisma.lead.count({ where: { responsavelId: id, deletedAt: null } }),
    prisma.projeto.count({ where: { responsavelId: id, deletedAt: null } }),
    prisma.card.count({ where: { responsavelId: id } }),
    prisma.projetoParticipante.count({ where: { userId: id } })
  ]);
  const total = clientes + leads + projetos + tarefas;
  return { clientes, leads, projetos, tarefas, participacoes, total };
}
async function deleteUsuario(atorId, atorRole, id, transferirParaId) {
  if (id === atorId) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Voc\xEA n\xE3o pode excluir a pr\xF3pria conta." });
  }
  const alvo = await prisma.user.findUnique({ where: { id } });
  if (!alvo || alvo.deletedAt) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Usu\xE1rio n\xE3o encontrado." });
  }
  if (ROLE_LEVEL[alvo.role] >= ROLE_LEVEL[atorRole]) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sem permiss\xE3o para excluir este usu\xE1rio." });
  }
  const destinoId = transferirParaId || null;
  if (destinoId) {
    if (destinoId === id) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Destino inv\xE1lido para a transfer\xEAncia." });
    }
    const destino = await prisma.user.findFirst({
      where: { id: destinoId, ativo: true, deletedAt: null, role: { not: "CLIENTE" } },
      select: { id: true }
    });
    if (!destino) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Escolha um membro da equipe ativo para receber as responsabilidades." });
    }
  }
  const transferencia = await prisma.$transaction(async (tx) => {
    const [clientes, leads, projetos, tarefas] = await Promise.all([
      tx.cliente.updateMany({ where: { responsavelId: id }, data: { responsavelId: destinoId } }),
      tx.lead.updateMany({ where: { responsavelId: id }, data: { responsavelId: destinoId } }),
      tx.projeto.updateMany({ where: { responsavelId: id }, data: { responsavelId: destinoId } }),
      tx.card.updateMany({ where: { responsavelId: id }, data: { responsavelId: destinoId } })
    ]);
    await tx.projetoParticipante.deleteMany({ where: { userId: id } });
    await tx.user.update({
      where: { id },
      data: {
        deletedAt: /* @__PURE__ */ new Date(),
        ativo: false,
        // Libera o e-mail (mantém o @unique) para permitir recadastro futuro.
        email: `deleted+${Date.now()}+${alvo.email}`.slice(0, 190)
      }
    });
    await tx.session.deleteMany({ where: { userId: id } });
    return {
      clientes: clientes.count,
      leads: leads.count,
      projetos: projetos.count,
      tarefas: tarefas.count
    };
  });
  return { id, transferido: !!destinoId, ...transferencia };
}

// src/modules/leads/leads.service.ts
var clean = (v) => {
  const t = v?.trim();
  return t ? t : null;
};
function hostDe(url) {
  if (!url) return null;
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}
function derivarRastreioOrigem(t) {
  const refHost = hostDe(t.referrer);
  const s = (t.utmSource ?? "").toLowerCase();
  const m = (t.utmMedium ?? "").toLowerCase();
  const r = (refHost ?? "").toLowerCase();
  const tem = (...ks) => ks.some((k) => s.includes(k) || r.includes(k));
  let origem = "P\xE1gina de Captura";
  if (t.fbclid || tem("facebook", "instagram", "fbclid") || s === "fb" || s === "ig") origem = "Facebook/Instagram";
  else if (tem("linkedin")) origem = "LinkedIn";
  else if (tem("whatsapp", "wa.me", "whats")) origem = "WhatsApp";
  else if (tem("tiktok")) origem = "TikTok";
  else if (tem("telegram", "t.me")) origem = "Telegram";
  else if (t.gclid || tem("google", "bing", "duckduckgo", "yahoo", "ecosia", "search")) origem = "Google";
  else if (tem("youtube", "youtu.be")) origem = "YouTube";
  else if (tem("t.co", "twitter", "x.com")) origem = "Twitter/X";
  else if (m.includes("email") || m.includes("e-mail") || m.includes("newsletter") || tem("mailchimp", "rdstation")) origem = "E-mail marketing";
  else if (t.utmSource) origem = t.utmSource;
  else if (refHost) origem = "Site";
  const partes = [];
  if (t.utmSource) partes.push(`Fonte (utm_source): ${t.utmSource}`);
  if (t.utmMedium) partes.push(`Meio (utm_medium): ${t.utmMedium}`);
  if (t.utmCampaign) partes.push(`Campanha: ${t.utmCampaign}`);
  if (t.gclid) partes.push("Clique de an\xFAncio do Google (gclid)");
  if (t.fbclid) partes.push("Clique de an\xFAncio do Facebook/Instagram (fbclid)");
  if (refHost) partes.push(`Veio de: ${refHost}`);
  else if (!t.utmSource) partes.push("Acesso direto (digitou o link ou favorito)");
  return { origem, rastreio: `Recebido pelo formul\xE1rio de capta\xE7\xE3o do site.
${partes.join("\n")}`.trim() };
}
async function nomeUsuario(userId) {
  const u = await prisma.user.findUnique({ where: { id: userId }, select: { nome: true } });
  return u?.nome ?? null;
}
function proximoDiaUtil(dias, hora) {
  const d = /* @__PURE__ */ new Date();
  let restantes = dias;
  while (restantes > 0) {
    d.setDate(d.getDate() + 1);
    const dow = d.getDay();
    if (dow !== 0 && dow !== 6) restantes--;
  }
  d.setHours(hora, 0, 0, 0);
  return d;
}
var CAPTURA_MAX = 5;
var CAPTURA_JANELA_MS = 60 * 60 * 1e3;
var capturasPorIp = /* @__PURE__ */ new Map();
function capturaBloqueada(ip) {
  const reg = capturasPorIp.get(ip);
  const agora = Date.now();
  if (!reg || agora >= reg.ate) {
    capturasPorIp.set(ip, { count: 1, ate: agora + CAPTURA_JANELA_MS });
    return false;
  }
  reg.count += 1;
  return reg.count > CAPTURA_MAX;
}
async function avancarLeadAuto(leadId, chaveDestino, motivo) {
  try {
    const lead = await prisma.lead.findUnique({
      where: { id: leadId },
      include: { pipelineStage: { select: { ordem: true, nome: true } } }
    });
    if (!lead || lead.deletedAt || lead.convertidoEmClienteId) return;
    const destino = await prisma.pipelineStage.findFirst({ where: { chaveAuto: chaveDestino } });
    if (!destino || destino.id === lead.pipelineStageId || destino.ordem <= lead.pipelineStage.ordem) return;
    const max = await prisma.lead.aggregate({
      where: { pipelineStageId: destino.id, deletedAt: null, convertidoEmClienteId: null },
      _max: { ordem: true }
    });
    await prisma.lead.update({
      where: { id: leadId },
      data: { pipelineStageId: destino.id, ordem: (max._max.ordem ?? -1) + 1 }
    });
    await prisma.activityLog.create({
      data: {
        acao: "lead.auto_avancou",
        entidadeTipo: "lead",
        entidadeId: leadId,
        dados: { de: lead.pipelineStage.nome, para: destino.nome, motivo }
      }
    });
  } catch {
  }
}
async function avancarLeadPorClienteAuto(clienteId, chaveDestino, motivo) {
  const lead = await prisma.lead.findFirst({
    where: { clienteId, deletedAt: null, convertidoEmClienteId: null },
    orderBy: { createdAt: "desc" },
    select: { id: true }
  });
  if (lead) await avancarLeadAuto(lead.id, chaveDestino, motivo);
}
var PLAYBOOK = {
  novo: [
    { titulo: "Fazer o primeiro contato", obrigatorio: true },
    { titulo: "Confirmar os servi\xE7os de interesse", obrigatorio: true, autoRegra: "servicos" },
    { titulo: "Descobrir quem decide, o or\xE7amento e o prazo", obrigatorio: true }
  ],
  qualificacao: [
    { titulo: "Entender a necessidade e os requisitos", obrigatorio: false },
    { titulo: "Registrar o valor estimado da oportunidade", obrigatorio: true, autoRegra: "valor" }
  ],
  proposta: [
    { titulo: "Elaborar e enviar a proposta", obrigatorio: true, acaoDoc: "proposta", autoRegra: "proposta_enviada" },
    { titulo: "Confirmar o aceite do cliente", obrigatorio: true, autoRegra: "proposta_assinada" }
  ],
  negociacao: [
    { titulo: "Alinhar ajustes finais", obrigatorio: false },
    { titulo: "Elaborar e enviar o contrato", obrigatorio: true, acaoDoc: "contrato", autoRegra: "contrato_enviado" },
    { titulo: "Confirmar a assinatura do contrato", obrigatorio: true, autoRegra: "contrato_assinado" }
  ],
  fechado: [{ titulo: "Converter em cliente", obrigatorio: true }]
};
async function seedPassosSeVazio(leadId, stageId, chaveAuto) {
  if (!chaveAuto) return;
  const existe = await prisma.leadPasso.count({ where: { leadId, stageId } });
  if (existe > 0) return;
  const dados = [];
  const modelo = PLAYBOOK[chaveAuto];
  if (modelo)
    modelo.forEach(
      (m, i) => dados.push({ leadId, stageId, servicoId: null, titulo: m.titulo, obrigatorio: m.obrigatorio, acaoDoc: m.acaoDoc ?? null, autoRegra: m.autoRegra ?? null, ordem: i })
    );
  const servicos = await prisma.servico.findMany({
    where: { leads: { some: { id: leadId } } },
    orderBy: { ordem: "asc" },
    include: { passos: { where: { etapaChave: chaveAuto }, orderBy: { ordem: "asc" } } }
  });
  let ordem = dados.length;
  for (const s of servicos) {
    for (const sp of s.passos) {
      dados.push({ leadId, stageId, servicoId: s.id, titulo: sp.titulo, obrigatorio: sp.obrigatorio, acaoDoc: null, autoRegra: null, ordem: ordem++ });
    }
  }
  if (dados.length) await prisma.leadPasso.createMany({ data: dados });
}
async function sincronizarPassosServicos(leadId, stageId, chaveAuto) {
  if (!chaveAuto) return;
  const servicos = await prisma.servico.findMany({
    where: { leads: { some: { id: leadId } } },
    orderBy: { ordem: "asc" },
    include: { passos: { where: { etapaChave: chaveAuto }, orderBy: { ordem: "asc" } } }
  });
  const servicoIds = new Set(servicos.map((s) => s.id));
  const existentes = await prisma.leadPasso.findMany({
    where: { leadId, stageId, NOT: { servicoId: null } }
  });
  const orfaos = existentes.filter((p) => p.servicoId && !servicoIds.has(p.servicoId) && !p.concluido);
  if (orfaos.length) {
    await prisma.leadPasso.deleteMany({ where: { id: { in: orfaos.map((o) => o.id) } } });
  }
  const jaTem = new Set(existentes.map((p) => `${p.servicoId}::${p.titulo}`));
  const agg = await prisma.leadPasso.aggregate({ where: { leadId, stageId }, _max: { ordem: true } });
  let ordem = (agg._max.ordem ?? -1) + 1;
  const novos = [];
  for (const s of servicos) {
    for (const sp of s.passos) {
      if (jaTem.has(`${s.id}::${sp.titulo}`)) continue;
      novos.push({ leadId, stageId, servicoId: s.id, titulo: sp.titulo, obrigatorio: sp.obrigatorio, acaoDoc: null, ordem: ordem++ });
    }
  }
  if (novos.length) await prisma.leadPasso.createMany({ data: novos });
}
var REGRAS_DERIVADAS = /* @__PURE__ */ new Set(["servicos", "valor"]);
var REGRAS_EVENTO = /* @__PURE__ */ new Set(["proposta_enviada", "proposta_assinada", "contrato_enviado", "contrato_assinado"]);
async function reconciliarPassosAuto(leadId) {
  try {
    const lead = await prisma.lead.findUnique({
      where: { id: leadId },
      select: { valorEstimado: true, _count: { select: { servicos: true } } }
    });
    if (!lead) return;
    const docSteps = await prisma.leadPasso.findMany({
      where: { leadId, acaoDoc: { in: ["proposta", "contrato"] }, NOT: { documentoId: null } },
      select: { acaoDoc: true, documentoId: true }
    });
    const docIds = docSteps.map((d) => d.documentoId).filter((x) => !!x);
    const docs = docIds.length ? await prisma.documento.findMany({
      where: { id: { in: docIds }, deletedAt: null },
      select: { id: true, assinaturaSolicitadaEm: true, assinadoEm: true }
    }) : [];
    const docById = new Map(docs.map((d) => [d.id, d]));
    const marco = { proposta_enviada: false, proposta_assinada: false, contrato_enviado: false, contrato_assinado: false };
    for (const ds of docSteps) {
      const d = ds.documentoId ? docById.get(ds.documentoId) : void 0;
      if (!d) continue;
      if (ds.acaoDoc === "proposta") {
        if (d.assinaturaSolicitadaEm) marco.proposta_enviada = true;
        if (d.assinadoEm) marco.proposta_assinada = true;
      } else if (ds.acaoDoc === "contrato") {
        if (d.assinaturaSolicitadaEm) marco.contrato_enviado = true;
        if (d.assinadoEm) marco.contrato_assinado = true;
      }
    }
    const cumprida = {
      servicos: lead._count.servicos > 0,
      valor: lead.valorEstimado != null && lead.valorEstimado > 0,
      ...marco
    };
    const autos = await prisma.leadPasso.findMany({
      where: { leadId, NOT: { autoRegra: null } },
      select: { id: true, autoRegra: true, concluido: true }
    });
    for (const p of autos) {
      const regra = p.autoRegra ?? "";
      const alvo = cumprida[regra] ?? false;
      if (REGRAS_DERIVADAS.has(regra)) {
        if (p.concluido !== alvo) {
          await prisma.leadPasso.update({
            where: { id: p.id },
            data: { concluido: alvo, concluidoEm: alvo ? /* @__PURE__ */ new Date() : null, concluidoPorId: null }
          });
        }
      } else if (REGRAS_EVENTO.has(regra)) {
        if (alvo && !p.concluido) {
          await prisma.leadPasso.update({
            where: { id: p.id },
            data: { concluido: true, concluidoEm: /* @__PURE__ */ new Date(), concluidoPorId: null }
          });
        }
      }
    }
  } catch {
  }
}
async function getLeadDetalhe(id) {
  const lead = await prisma.lead.findUnique({
    where: { id },
    include: {
      servicos: { select: { id: true, nome: true }, orderBy: { ordem: "asc" } },
      responsavel: { select: { nome: true } },
      pipelineStage: true
    }
  });
  if (!lead || lead.deletedAt) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  await seedPassosSeVazio(lead.id, lead.pipelineStageId, lead.pipelineStage.chaveAuto);
  await reconciliarPassosAuto(lead.id);
  const passos = await prisma.leadPasso.findMany({
    where: { leadId: id, stageId: lead.pipelineStageId },
    orderBy: [{ ordem: "asc" }]
  });
  const servIds = [...new Set(passos.map((p) => p.servicoId).filter((x) => !!x))];
  const servMap = new Map(
    servIds.length ? (await prisma.servico.findMany({ where: { id: { in: servIds } }, select: { id: true, nome: true } })).map((s) => [s.id, s.nome]) : []
  );
  const docIds = [...new Set(passos.map((p) => p.documentoId).filter((x) => !!x))];
  const docMap = new Map(
    docIds.length ? (await prisma.documento.findMany({
      where: { id: { in: docIds } },
      select: {
        id: true,
        status: true,
        propostaStatus: true,
        assinaturaSolicitadaEm: true,
        assinadoEm: true,
        deletedAt: true
      }
    })).map((d) => [d.id, d]) : []
  );
  const docSituacao = (docId) => {
    if (!docId) return null;
    const d = docMap.get(docId);
    if (!d || d.deletedAt) return null;
    const s = situacaoDocumento(d);
    return { key: s.key, label: s.label, variant: s.variant };
  };
  const stages = await prisma.pipelineStage.findMany({ orderBy: { ordem: "asc" } });
  const idx = stages.findIndex((s) => s.id === lead.pipelineStageId);
  const proxima = idx >= 0 && idx < stages.length - 1 ? stages[idx + 1] : null;
  const faltamObrig = passos.filter((p) => p.obrigatorio && !p.concluido).length;
  const timeline = await prisma.activityLog.findMany({
    where: { entidadeTipo: "lead", entidadeId: id },
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { user: { select: { nome: true } } }
  });
  let deOndeVeio = lead.rastreio;
  if (!deOndeVeio) {
    const criacao = await prisma.activityLog.findFirst({
      where: { entidadeTipo: "lead", entidadeId: id, acao: { in: ["lead.capturado", "lead.criado"] } },
      orderBy: { createdAt: "asc" },
      include: { user: { select: { nome: true } } }
    });
    deOndeVeio = criacao?.acao === "lead.capturado" ? "Recebido pelo formul\xE1rio de capta\xE7\xE3o do site." : `Cadastrado manualmente no sistema${criacao?.user?.nome ? ` por ${criacao.user.nome}` : ""}.`;
  }
  return {
    id: lead.id,
    nome: lead.nome,
    empresa: lead.empresa,
    email: lead.email,
    telefone: lead.telefone,
    origem: lead.origem,
    valorEstimado: lead.valorEstimado,
    observacoes: lead.observacoes,
    rastreio: deOndeVeio,
    clienteId: lead.clienteId,
    responsavel: lead.responsavel,
    stage: { id: lead.pipelineStage.id, nome: lead.pipelineStage.nome, cor: lead.pipelineStage.cor },
    servicos: lead.servicos,
    passos: passos.map((p) => ({
      id: p.id,
      titulo: p.titulo,
      obrigatorio: p.obrigatorio,
      concluido: p.concluido,
      grupo: p.servicoId ? servMap.get(p.servicoId) ?? "Servi\xE7o" : "Geral",
      acaoDoc: p.acaoDoc,
      documentoId: p.documentoId,
      docSituacao: docSituacao(p.documentoId),
      // Passo derivado do estado (servicos/valor): a UI mostra selo e trava o toque.
      // Passos de evento (documento) continuam ticáveis na mão, então não travam.
      auto: p.autoRegra != null && REGRAS_DERIVADAS.has(p.autoRegra)
    })),
    proxima: proxima ? { id: proxima.id, nome: proxima.nome } : null,
    faltamObrig,
    prontoParaAvancar: !!proxima && faltamObrig === 0 && passos.length > 0,
    timeline: timeline.map((a) => ({
      id: a.id,
      acao: a.acao,
      createdAt: a.createdAt,
      usuario: a.user?.nome ?? null,
      dados: a.dados
    }))
  };
}
async function avancarSeChecklistCompleto(leadId, userId) {
  let destino = null;
  for (let i = 0; i < 6; i++) {
    const lead = await prisma.lead.findUnique({ where: { id: leadId }, include: { pipelineStage: true } });
    if (!lead || lead.deletedAt || lead.convertidoEmClienteId || lead.perdidoEm) break;
    const faltam = await prisma.leadPasso.count({
      where: { leadId, stageId: lead.pipelineStageId, obrigatorio: true, concluido: false }
    });
    if (faltam > 0) break;
    const stages = await prisma.pipelineStage.findMany({ orderBy: { ordem: "asc" } });
    const idx = stages.findIndex((s) => s.id === lead.pipelineStageId);
    const proxima = idx >= 0 && idx < stages.length - 1 ? stages[idx + 1] : null;
    if (!proxima) break;
    const max = await prisma.lead.aggregate({
      where: { pipelineStageId: proxima.id, deletedAt: null, convertidoEmClienteId: null },
      _max: { ordem: true }
    });
    await prisma.lead.update({ where: { id: leadId }, data: { pipelineStageId: proxima.id, ordem: (max._max.ordem ?? -1) + 1 } });
    await prisma.activityLog.create({
      data: { userId: userId ?? void 0, acao: "lead.auto_avancou_checklist", entidadeTipo: "lead", entidadeId: leadId, dados: { de: lead.pipelineStage.nome, para: proxima.nome } }
    });
    await seedPassosSeVazio(leadId, proxima.id, proxima.chaveAuto);
    if (userId) await docsAoEntrarEtapa(leadId, proxima.chaveAuto, userId);
    await reconciliarPassosAuto(leadId);
    await reconciliarSituacaoCliente(lead.clienteId);
    destino = { id: proxima.id, nome: proxima.nome };
  }
  return destino;
}
async function togglePasso(passoId, userId) {
  const p = await prisma.leadPasso.findUnique({ where: { id: passoId } });
  if (!p) throw new TRPCError2({ code: "NOT_FOUND", message: "Passo n\xE3o encontrado" });
  if (p.autoRegra && REGRAS_DERIVADAS.has(p.autoRegra)) {
    throw new TRPCError2({
      code: "BAD_REQUEST",
      message: "Este passo \xE9 autom\xE1tico \u2014 ele conclui sozinho quando a condi\xE7\xE3o \xE9 atendida."
    });
  }
  const concluido = !p.concluido;
  await prisma.leadPasso.update({
    where: { id: passoId },
    data: { concluido, concluidoEm: concluido ? /* @__PURE__ */ new Date() : null, concluidoPorId: concluido ? userId : null }
  });
  const avancou = concluido ? await avancarSeChecklistCompleto(p.leadId, userId) : null;
  return { ok: true, avancou };
}
async function addPasso(leadId, titulo) {
  const lead = await prisma.lead.findUnique({ where: { id: leadId }, select: { pipelineStageId: true } });
  if (!lead) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  const max = await prisma.leadPasso.aggregate({
    where: { leadId, stageId: lead.pipelineStageId },
    _max: { ordem: true }
  });
  await prisma.leadPasso.create({
    data: { leadId, stageId: lead.pipelineStageId, titulo: titulo.trim(), ordem: (max._max.ordem ?? -1) + 1 }
  });
  return { ok: true };
}
async function removePasso(passoId) {
  const p = await prisma.leadPasso.findUnique({ where: { id: passoId }, select: { obrigatorio: true } });
  if (p?.obrigatorio) {
    throw new TRPCError2({
      code: "BAD_REQUEST",
      message: "Esta tarefa \xE9 obrigat\xF3ria e n\xE3o pode ser removida. Conclua-a para avan\xE7ar."
    });
  }
  await prisma.leadPasso.deleteMany({ where: { id: passoId } });
  return { ok: true };
}
async function docsAoEntrarEtapa(leadId, chaveAuto, userId) {
  if (chaveAuto !== "proposta" && chaveAuto !== "negociacao") return;
  try {
    const m = await import("./documentos.service-Q3JFFZKK.js");
    if (chaveAuto === "proposta") await m.gerarPropostaAutoParaLead(leadId, userId);
    else if (chaveAuto === "negociacao") await m.gerarContratoAutoParaLead(leadId, userId);
  } catch {
  }
}
async function avancarEtapa(leadId, userId) {
  const lead = await prisma.lead.findUnique({ where: { id: leadId }, include: { pipelineStage: true } });
  if (!lead || lead.deletedAt) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  const faltam = await prisma.leadPasso.count({
    where: { leadId, stageId: lead.pipelineStageId, obrigatorio: true, concluido: false }
  });
  if (faltam > 0) {
    throw new TRPCError2({ code: "BAD_REQUEST", message: "Conclua os passos obrigat\xF3rios antes de avan\xE7ar." });
  }
  const stages = await prisma.pipelineStage.findMany({ orderBy: { ordem: "asc" } });
  const idx = stages.findIndex((s) => s.id === lead.pipelineStageId);
  const proxima = idx >= 0 && idx < stages.length - 1 ? stages[idx + 1] : null;
  if (!proxima) throw new TRPCError2({ code: "BAD_REQUEST", message: "Este lead j\xE1 est\xE1 na \xFAltima etapa." });
  const max = await prisma.lead.aggregate({
    where: { pipelineStageId: proxima.id, deletedAt: null, convertidoEmClienteId: null },
    _max: { ordem: true }
  });
  await prisma.lead.update({
    where: { id: leadId },
    data: { pipelineStageId: proxima.id, ordem: (max._max.ordem ?? -1) + 1 }
  });
  await prisma.activityLog.create({
    data: {
      userId,
      acao: "lead.avancou_etapa",
      entidadeTipo: "lead",
      entidadeId: leadId,
      dados: { de: lead.pipelineStage.nome, para: proxima.nome }
    }
  });
  await seedPassosSeVazio(leadId, proxima.id, proxima.chaveAuto);
  await docsAoEntrarEtapa(leadId, proxima.chaveAuto, userId);
  await reconciliarSituacaoCliente(lead.clienteId);
  return { ok: true, para: { id: proxima.id, nome: proxima.nome } };
}
async function listLeads() {
  const leads = await prisma.lead.findMany({
    where: { deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    orderBy: [{ pipelineStageId: "asc" }, { ordem: "asc" }],
    include: {
      responsavel: { select: { nome: true } },
      servicos: { select: { id: true, nome: true }, orderBy: { ordem: "asc" } },
      // "Portal ativo" fiel = tem usuário de Portal que consegue entrar (senha definida) —
      // mesmo critério da lista de clientes. Evita o falso-positivo de só ter clienteId.
      clientePortal: {
        select: { _count: { select: { usuariosPortal: { where: { role: "CLIENTE", ativo: true, passwordHash: { not: null } } } } } }
      }
    }
  });
  return leads.map(({ clientePortal, ...l }) => ({
    ...l,
    portalAtivo: (clientePortal?._count.usuariosPortal ?? 0) > 0
  }));
}
function listPerdidos() {
  return prisma.lead.findMany({
    where: { deletedAt: null, NOT: { perdidoEm: null } },
    orderBy: { perdidoEm: "desc" },
    take: 50,
    include: {
      responsavel: { select: { nome: true } },
      pipelineStage: { select: { nome: true, cor: true } }
    }
  });
}
async function funilResumo() {
  const [ganhos, perdidos] = await Promise.all([
    prisma.lead.count({ where: { deletedAt: null, NOT: { convertidoEmClienteId: null } } }),
    prisma.lead.count({ where: { deletedAt: null, NOT: { perdidoEm: null } } })
  ]);
  const fechados = ganhos + perdidos;
  return { ganhos, perdidos, taxaConversao: fechados ? ganhos / fechados : 0 };
}
async function marcarPerdido(id, motivo, userId) {
  const lead = await prisma.lead.findUnique({ where: { id }, select: { convertidoEmClienteId: true, perdidoEm: true, clienteId: true } });
  if (!lead) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  if (lead.convertidoEmClienteId) throw new TRPCError2({ code: "BAD_REQUEST", message: "Este lead j\xE1 foi convertido \u2014 n\xE3o pode ser marcado como perdido." });
  if (lead.perdidoEm) throw new TRPCError2({ code: "BAD_REQUEST", message: "Este lead j\xE1 est\xE1 marcado como perdido." });
  await prisma.lead.update({ where: { id }, data: { perdidoEm: /* @__PURE__ */ new Date(), motivoPerda: motivo.trim() } });
  await prisma.activityLog.create({
    data: { userId, acao: "lead.perdido", entidadeTipo: "lead", entidadeId: id, dados: { motivo: motivo.trim() } }
  });
  await reconciliarSituacaoCliente(lead.clienteId);
  return { ok: true };
}
async function reabrirLead(id, userId) {
  const lead = await prisma.lead.findUnique({ where: { id }, select: { perdidoEm: true, pipelineStageId: true, clienteId: true } });
  if (!lead) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  if (!lead.perdidoEm) throw new TRPCError2({ code: "BAD_REQUEST", message: "Este lead n\xE3o est\xE1 perdido." });
  const max = await prisma.lead.aggregate({
    where: { pipelineStageId: lead.pipelineStageId, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    _max: { ordem: true }
  });
  await prisma.lead.update({
    where: { id },
    data: { perdidoEm: null, motivoPerda: null, ordem: (max._max.ordem ?? -1) + 1 }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "lead.reaberto", entidadeTipo: "lead", entidadeId: id }
  });
  await reconciliarSituacaoCliente(lead.clienteId);
  return { ok: true };
}
async function avisarEquipeSobreLead(tipo, lead) {
  const contato = lead.empresa ? `${lead.nome} \xB7 ${lead.empresa}` : lead.nome;
  const gestao = await prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
    select: { id: true }
  });
  const avisar = new Set(gestao.map((g) => g.id));
  if (lead.responsavelId) avisar.add(lead.responsavelId);
  for (const uid of avisar) {
    await notificar(uid, tipo, { contato }, { entidadeTipo: "lead", entidadeId: lead.id });
  }
}
async function desistenciaPeloCliente(clienteId, motivoCliente) {
  const lead = await prisma.lead.findFirst({
    where: { clienteId, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    orderBy: { createdAt: "desc" },
    select: { id: true, nome: true, empresa: true, responsavelId: true }
  });
  if (!lead) throw new TRPCError2({ code: "BAD_REQUEST", message: "N\xE3o h\xE1 atendimento em andamento para encerrar." });
  const motivo = ["Desist\xEAncia pelo Portal", motivoCliente?.trim() || null].filter(Boolean).join(" \u2014 ");
  await prisma.lead.update({ where: { id: lead.id }, data: { perdidoEm: /* @__PURE__ */ new Date(), motivoPerda: motivo } });
  await prisma.activityLog.create({
    data: { acao: "lead.perdido", entidadeTipo: "lead", entidadeId: lead.id, dados: { motivo, origem: "portal" } }
  });
  await reconciliarSituacaoCliente(clienteId);
  await avisarEquipeSobreLead("lead_desistiu", lead);
  return { ok: true };
}
async function retomarPeloCliente(clienteId) {
  const lead = await prisma.lead.findFirst({
    where: { clienteId, deletedAt: null, convertidoEmClienteId: null, NOT: { perdidoEm: null } },
    orderBy: { perdidoEm: "desc" },
    select: { id: true, nome: true, empresa: true, responsavelId: true, pipelineStageId: true }
  });
  if (!lead) throw new TRPCError2({ code: "BAD_REQUEST", message: "N\xE3o h\xE1 atendimento para retomar." });
  const max = await prisma.lead.aggregate({
    where: { pipelineStageId: lead.pipelineStageId, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    _max: { ordem: true }
  });
  await prisma.lead.update({
    where: { id: lead.id },
    data: { perdidoEm: null, motivoPerda: null, ordem: (max._max.ordem ?? -1) + 1 }
  });
  await prisma.activityLog.create({
    data: { acao: "lead.reaberto", entidadeTipo: "lead", entidadeId: lead.id, dados: { origem: "portal" } }
  });
  await reconciliarSituacaoCliente(clienteId);
  await avisarEquipeSobreLead("lead_retomou", lead);
  return { ok: true };
}
async function solicitarServicosPeloCliente(clienteId, servicoIds, mensagem) {
  const servicos = await prisma.servico.findMany({ where: { id: { in: servicoIds }, ativo: true }, select: { id: true, nome: true } });
  if (servicos.length === 0) throw new TRPCError2({ code: "BAD_REQUEST", message: "Selecione ao menos um servi\xE7o v\xE1lido." });
  const nomes = servicos.map((s) => s.nome).join(", ");
  const msg = clean(mensagem ?? null);
  const nota = [msg && `Pedido pelo Portal: ${msg}`, `Servi\xE7os pedidos pelo Portal: ${nomes}`].filter(Boolean).join("\n");
  const existente = await prisma.lead.findFirst({
    where: { clienteId, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    orderBy: { createdAt: "desc" },
    include: { pipelineStage: { select: { id: true, chaveAuto: true } } }
  });
  let alvo;
  if (existente) {
    await prisma.lead.update({
      where: { id: existente.id },
      data: {
        servicos: { connect: servicos.map((s) => ({ id: s.id })) },
        observacoes: [existente.observacoes, nota].filter(Boolean).join("\n\n") || existente.observacoes
      }
    });
    await sincronizarPassosServicos(existente.id, existente.pipelineStage.id, existente.pipelineStage.chaveAuto);
    await reconciliarPassosAuto(existente.id);
    alvo = { id: existente.id, nome: existente.nome, empresa: existente.empresa, responsavelId: existente.responsavelId };
  } else {
    const cliente = await prisma.cliente.findFirst({
      where: { id: clienteId, deletedAt: null },
      select: { nome: true, tipo: true, email: true, telefone: true, responsavelId: true }
    });
    if (!cliente) throw new TRPCError2({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado" });
    const stages = await listStages();
    const stage = stages[0];
    if (!stage) throw new TRPCError2({ code: "INTERNAL_SERVER_ERROR", message: "Pipeline n\xE3o configurado" });
    const max = await prisma.lead.aggregate({
      where: { pipelineStageId: stage.id, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
      _max: { ordem: true }
    });
    const criado = await prisma.lead.create({
      data: {
        nome: cliente.nome,
        empresa: cliente.tipo === "PJ" ? cliente.nome : null,
        email: cliente.email,
        telefone: cliente.telefone,
        origem: "Portal do cliente",
        rastreio: "Servi\xE7os solicitados pelo pr\xF3prio cliente no Portal.",
        observacoes: nota,
        pipelineStageId: stage.id,
        ordem: (max._max.ordem ?? -1) + 1,
        responsavelId: cliente.responsavelId,
        clienteId,
        servicos: { connect: servicos.map((s) => ({ id: s.id })) }
      }
    });
    await seedPassosSeVazio(criado.id, stage.id, stage.chaveAuto);
    await reconciliarPassosAuto(criado.id);
    alvo = { id: criado.id, nome: criado.nome, empresa: criado.empresa, responsavelId: criado.responsavelId };
  }
  await prisma.activityLog.create({
    data: { acao: "lead.servicos_portal", entidadeTipo: "lead", entidadeId: alvo.id, dados: { origem: "portal", servicos: nomes } }
  });
  await reconciliarSituacaoCliente(clienteId);
  const contato = alvo.empresa ? `${alvo.nome} \xB7 ${alvo.empresa}` : alvo.nome;
  const gestao = await prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
    select: { id: true }
  });
  const avisar = new Set(gestao.map((g) => g.id));
  if (alvo.responsavelId) avisar.add(alvo.responsavelId);
  for (const uid of avisar) {
    await notificar(uid, "servico_solicitado", { contato, servicos: nomes }, { entidadeTipo: "lead", entidadeId: alvo.id });
  }
  return { ok: true };
}
async function reconciliarSituacaoCliente(clienteId) {
  if (!clienteId) return;
  try {
    const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { situacaoComercial: true } });
    if (!cliente) return;
    const leads = await prisma.lead.findMany({
      where: { clienteId, deletedAt: null },
      select: { convertidoEmClienteId: true, perdidoEm: true, pipelineStage: { select: { chaveAuto: true } } }
    });
    const ganhou = leads.some((l) => l.convertidoEmClienteId);
    if (ganhou) {
      if (cliente.situacaoComercial !== "ATIVO") {
        await prisma.cliente.update({ where: { id: clienteId }, data: { situacaoComercial: "ATIVO" } });
      }
      return;
    }
    if (cliente.situacaoComercial === "ATIVO" || cliente.situacaoComercial === "INATIVO") return;
    if (leads.length === 0) return;
    const abertos = leads.filter((l) => !l.perdidoEm);
    const nova = abertos.length ? abertos.some((l) => l.pipelineStage.chaveAuto === "negociacao") ? "NEGOCIACAO" : "PROSPECT" : "PERDIDO";
    await prisma.cliente.updateMany({ where: { id: clienteId, NOT: { situacaoComercial: nova } }, data: { situacaoComercial: nova } });
  } catch {
  }
}
async function criarOportunidadeParaCliente(clienteId, ator, opts) {
  const cliente = await prisma.cliente.findFirst({
    where: { id: clienteId, deletedAt: null },
    select: { id: true, nome: true, tipo: true, email: true, telefone: true, responsavelId: true }
  });
  if (!cliente) throw new TRPCError2({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado" });
  const stages = await listStages();
  const stage = stages[0];
  if (!stage) throw new TRPCError2({ code: "INTERNAL_SERVER_ERROR", message: "Pipeline n\xE3o configurado" });
  const max = await prisma.lead.aggregate({
    where: { pipelineStageId: stage.id, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    _max: { ordem: true }
  });
  const servicoIds = opts?.servicoIds ?? [];
  const lead = await prisma.lead.create({
    data: {
      nome: cliente.nome,
      empresa: cliente.tipo === "PJ" ? cliente.nome : null,
      email: cliente.email,
      telefone: cliente.telefone,
      origem: "Cliente existente",
      rastreio: "Nova oportunidade aberta a partir da ficha de um cliente existente.",
      valorEstimado: opts?.valorEstimado ?? null,
      observacoes: clean(opts?.observacoes ?? null),
      pipelineStageId: stage.id,
      ordem: (max._max.ordem ?? -1) + 1,
      responsavelId: cliente.responsavelId ?? ator,
      clienteId: cliente.id,
      servicos: servicoIds.length ? { connect: servicoIds.map((id) => ({ id })) } : void 0
    }
  });
  await prisma.activityLog.create({
    data: { userId: ator, acao: "lead.criado", entidadeTipo: "lead", entidadeId: lead.id, dados: { origem: "cliente_existente" } }
  });
  await seedPassosSeVazio(lead.id, stage.id, stage.chaveAuto);
  await reconciliarPassosAuto(lead.id);
  await reconciliarSituacaoCliente(clienteId);
  return { leadId: lead.id };
}
async function createLead(input, userId) {
  let stageId = input.pipelineStageId;
  if (!stageId) {
    const stages = await listStages();
    stageId = stages[0]?.id;
  }
  if (!stageId) {
    throw new TRPCError2({ code: "INTERNAL_SERVER_ERROR", message: "Pipeline n\xE3o configurado" });
  }
  const max = await prisma.lead.aggregate({
    where: { pipelineStageId: stageId, deletedAt: null, convertidoEmClienteId: null },
    _max: { ordem: true }
  });
  const ordem = (max._max.ordem ?? -1) + 1;
  const origemManual = clean(input.origem);
  const criador = await nomeUsuario(userId);
  const rastreioManual = [
    `Cadastrado manualmente no sistema${criador ? ` por ${criador}` : ""}.`,
    origemManual ? `Origem informada: ${origemManual}.` : null
  ].filter(Boolean).join("\n");
  const lead = await prisma.lead.create({
    data: {
      nome: input.nome.trim(),
      empresa: clean(input.empresa),
      email: clean(input.email),
      telefone: clean(input.telefone),
      origem: origemManual,
      rastreio: rastreioManual,
      valorEstimado: input.valorEstimado ?? null,
      observacoes: clean(input.observacoes),
      pipelineStageId: stageId,
      ordem,
      responsavelId: input.responsavelId || userId,
      servicos: input.servicoIds?.length ? { connect: input.servicoIds.map((id) => ({ id })) } : void 0
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "lead.criado", entidadeTipo: "lead", entidadeId: lead.id }
  });
  if (lead.responsavelId && lead.responsavelId !== userId) {
    const contato = lead.empresa ? `${lead.nome} \xB7 ${lead.empresa}` : lead.nome;
    void notificar(lead.responsavelId, "lead_atribuido", { contato }, { entidadeTipo: "lead", entidadeId: lead.id }).catch(() => {
    });
  }
  return lead;
}
async function updateLead(input, userId) {
  const { id, pipelineStageId, ...rest } = input;
  const data = {};
  if (rest.nome !== void 0) data.nome = rest.nome.trim();
  if (rest.empresa !== void 0) data.empresa = clean(rest.empresa);
  if (rest.email !== void 0) data.email = clean(rest.email);
  if (rest.telefone !== void 0) data.telefone = clean(rest.telefone);
  if (rest.origem !== void 0) data.origem = clean(rest.origem);
  if (rest.valorEstimado !== void 0) data.valorEstimado = rest.valorEstimado ?? null;
  if (rest.observacoes !== void 0) data.observacoes = clean(rest.observacoes);
  if (rest.responsavelId !== void 0) data.responsavelId = rest.responsavelId || null;
  if (pipelineStageId !== void 0) data.pipelineStageId = pipelineStageId;
  if (rest.servicoIds !== void 0) data.servicos = { set: rest.servicoIds.map((sid) => ({ id: sid })) };
  let novoResponsavel = null;
  if (rest.responsavelId !== void 0) {
    const antes = await prisma.lead.findUnique({ where: { id }, select: { responsavelId: true } });
    const novo = rest.responsavelId || null;
    if (novo && novo !== antes?.responsavelId && novo !== userId) novoResponsavel = novo;
  }
  const lead = await prisma.lead.update({ where: { id }, data, include: { pipelineStage: true } });
  if (novoResponsavel) {
    const contato = lead.empresa ? `${lead.nome} \xB7 ${lead.empresa}` : lead.nome;
    void notificar(novoResponsavel, "lead_atribuido", { contato }, { entidadeTipo: "lead", entidadeId: lead.id }).catch(() => {
    });
  }
  if (rest.servicoIds !== void 0) {
    await seedPassosSeVazio(lead.id, lead.pipelineStageId, lead.pipelineStage.chaveAuto);
    await sincronizarPassosServicos(lead.id, lead.pipelineStageId, lead.pipelineStage.chaveAuto);
  }
  if (rest.servicoIds !== void 0 || rest.valorEstimado !== void 0) {
    await reconciliarPassosAuto(lead.id);
  }
  return lead;
}
async function moveLead(input, userId) {
  const lead = await prisma.lead.findUnique({
    where: { id: input.id },
    include: { pipelineStage: { select: { nome: true } } }
  });
  if (!lead) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  const mudouEtapa = lead.pipelineStageId !== input.pipelineStageId;
  const destino = await prisma.lead.findMany({
    where: {
      pipelineStageId: input.pipelineStageId,
      deletedAt: null,
      convertidoEmClienteId: null,
      id: { not: input.id }
    },
    orderBy: { ordem: "asc" },
    select: { id: true }
  });
  const idsOrdenados = destino.map((l) => l.id);
  const alvo = Math.max(0, Math.min(input.ordem, idsOrdenados.length));
  idsOrdenados.splice(alvo, 0, input.id);
  await prisma.$transaction(
    idsOrdenados.map(
      (leadId, i) => prisma.lead.update({
        where: { id: leadId },
        data: { ordem: i, pipelineStageId: input.pipelineStageId }
      })
    )
  );
  if (mudouEtapa) {
    const stage = await prisma.pipelineStage.findUnique({
      where: { id: input.pipelineStageId },
      select: { nome: true, chaveAuto: true }
    });
    await prisma.activityLog.create({
      data: {
        userId,
        acao: "lead.moveu_etapa",
        entidadeTipo: "lead",
        entidadeId: input.id,
        dados: { de: lead.pipelineStage.nome, para: stage?.nome ?? null }
      }
    });
    await seedPassosSeVazio(input.id, input.pipelineStageId, stage?.chaveAuto ?? null);
    await reconciliarPassosAuto(input.id);
    await docsAoEntrarEtapa(input.id, stage?.chaveAuto ?? null, userId);
    await reconciliarSituacaoCliente(lead.clienteId);
  }
  return { ok: true };
}
async function convertLead(id, userId, enviarEmail = true) {
  const lead = await prisma.lead.findUnique({
    where: { id },
    include: {
      servicos: {
        select: { id: true, nome: true, valor: true, valorRecorrencia: true, percentual: true, percentualRecorrencia: true },
        orderBy: { ordem: "asc" }
      }
    }
  });
  if (!lead || lead.deletedAt) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  if (lead.convertidoEmClienteId) {
    throw new TRPCError2({ code: "BAD_REQUEST", message: "Este lead j\xE1 foi convertido" });
  }
  const nomeCliente = lead.empresa?.trim() || lead.nome.trim();
  const clienteId = lead.clienteId ?? await garantirClienteDoLead(lead, userId);
  await prisma.cliente.update({ where: { id: clienteId }, data: { situacaoComercial: "ATIVO" } });
  await prisma.lead.update({
    where: { id },
    data: { convertidoEmClienteId: clienteId, clienteId, convertidoEm: /* @__PURE__ */ new Date() }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "lead.convertido", entidadeTipo: "cliente", entidadeId: clienteId, dados: { leadId: id } }
  });
  for (const s of lead.servicos) {
    await prisma.clienteServico.upsert({
      where: { clienteId_servicoId: { clienteId, servicoId: s.id } },
      update: { status: "ATIVO", canceladoEm: null, canceladoPorTipo: null },
      create: {
        clienteId,
        servicoId: s.id,
        status: "ATIVO",
        origem: "FUNIL",
        valor: s.valor ?? null,
        valorRecorrencia: s.valorRecorrencia,
        percentual: s.percentual ?? null,
        percentualRecorrencia: s.percentualRecorrencia
      }
    });
  }
  const resp = lead.responsavelId ?? userId;
  let projetoId = null;
  for (const s of lead.servicos) {
    const pid = await garantirCardDoServicoContratado(clienteId, s.id, s.nome, resp).catch(() => null);
    if (pid && !projetoId) projetoId = pid;
  }
  if (!projetoId) {
    const geral = await prisma.projeto.create({ data: { clienteId, nome: `Projeto \u2014 ${nomeCliente}`, responsavelId: resp }, select: { id: true } });
    await prisma.activityLog.create({ data: { userId, acao: "projeto.criado", entidadeTipo: "projeto", entidadeId: geral.id } });
    projetoId = geral.id;
  }
  try {
    const vencimento = /* @__PURE__ */ new Date();
    vencimento.setDate(vencimento.getDate() + 30);
    vencimento.setHours(12, 0, 0, 0);
    let avulso = 0;
    let mensal = 0;
    const percentuais = [];
    for (const s of lead.servicos) {
      if (s.valor && s.valor > 0) {
        if (s.valorRecorrencia === "MENSAL") mensal += s.valor;
        else avulso += s.valor;
      }
      if (s.percentual && s.percentual > 0) percentuais.push(`${s.percentual}% do faturamento (${s.nome})`);
    }
    const obsPct = percentuais.length ? ` Cobran\xE7as por % (variam com o faturamento do m\xEAs): ${percentuais.join("; ")}.` : "";
    const criarConta = (valor, recorrencia, descricao, obs) => prisma.conta.create({ data: { tipo: "RECEBER", descricao, valor, vencimento, clienteId, recorrencia, observacoes: obs } });
    if (avulso > 0 || mensal > 0) {
      if (avulso > 0) {
        await criarConta(avulso, "NENHUMA", `Contrato (servi\xE7os avulsos) \u2014 ${nomeCliente}`, `Provisionado na convers\xE3o do lead.${obsPct} Revise o valor e o vencimento.`);
      }
      if (mensal > 0) {
        await criarConta(mensal, "MENSAL", `Mensalidade \u2014 ${nomeCliente}`, `Mensalidade dos servi\xE7os recorrentes, provisionada na convers\xE3o.${avulso > 0 ? "" : obsPct} Revise o valor e o vencimento.`);
      }
      await prisma.activityLog.create({
        data: { userId, acao: "conta.criada", entidadeTipo: "cliente", entidadeId: clienteId, dados: { origem: "conversao_lead", avulso, mensal } }
      });
    } else if (lead.valorEstimado && lead.valorEstimado > 0) {
      await criarConta(lead.valorEstimado, "NENHUMA", `Contrato \u2014 ${nomeCliente}`, `Provisionado na convers\xE3o do lead a partir da estimativa do funil.${obsPct} Revise o valor e o vencimento.`);
      await prisma.activityLog.create({
        data: { userId, acao: "conta.criada", entidadeTipo: "cliente", entidadeId: clienteId, dados: { origem: "conversao_lead" } }
      });
    }
  } catch {
  }
  try {
    const inicio = proximoDiaUtil(3, 10);
    await prisma.evento.create({
      data: {
        titulo: `Reuni\xE3o de kickoff \u2014 ${nomeCliente}`,
        descricao: "Alinhamento inicial do onboarding ap\xF3s o fechamento. Ajuste a data/hora conforme a agenda do cliente.",
        tipo: "REUNIAO",
        escopo: "EMPRESA",
        inicio,
        fim: new Date(inicio.getTime() + 60 * 60 * 1e3),
        donoId: resp,
        clienteId,
        projetoId
      }
    });
  } catch {
  }
  const gestao = await prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
    select: { id: true }
  });
  const avisar = new Set(gestao.map((g) => g.id));
  if (lead.responsavelId) avisar.add(lead.responsavelId);
  avisar.delete(userId);
  for (const uid of avisar) {
    await notificar(uid, "lead_convertido", { cliente: nomeCliente }, { entidadeTipo: "cliente", entidadeId: clienteId });
  }
  if (enviarEmail) {
    try {
      const acesso = await garantirAcessoPortal(clienteId, nomeCliente, lead.email);
      if (acesso.jaTinhaAcesso && lead.email) {
        void enviarEmailTemplate("cliente_boas_vindas", lead.email, { nome: nomeCliente, link: config.WEB_ORIGIN }).catch(() => {
        });
      }
    } catch {
    }
  }
  try {
    const m = await import("./documentos.service-Q3JFFZKK.js");
    await m.gerarContratoAutoParaLead(id, userId);
  } catch {
  }
  return { clienteId, projetoId };
}
async function capturarLead(input, ip) {
  if (input.website && input.website.trim()) return { ok: true };
  if (capturaBloqueada(ip ?? "?")) {
    throw new TRPCError2({
      code: "TOO_MANY_REQUESTS",
      message: "Muitos envios. Tente novamente mais tarde."
    });
  }
  const stages = await listStages();
  const stageId = stages[0]?.id;
  if (!stageId) throw new TRPCError2({ code: "INTERNAL_SERVER_ERROR", message: "Pipeline n\xE3o configurado" });
  const max = await prisma.lead.aggregate({
    where: { pipelineStageId: stageId, deletedAt: null, convertidoEmClienteId: null },
    _max: { ordem: true }
  });
  const emailLimpo = clean(input.email);
  if (emailLimpo) {
    const existente = await prisma.lead.findFirst({
      where: { email: emailLimpo, deletedAt: null, convertidoEmClienteId: null },
      orderBy: { createdAt: "desc" },
      include: { pipelineStage: { select: { id: true, chaveAuto: true } } }
    });
    if (existente) {
      const msg = clean(input.mensagem);
      await prisma.lead.update({
        where: { id: existente.id },
        data: {
          observacoes: [existente.observacoes, msg && `Novo contato pelo site: ${msg}`].filter(Boolean).join("\n\n") || existente.observacoes,
          servicos: input.servicoIds?.length ? { connect: input.servicoIds.map((sid) => ({ id: sid })) } : void 0
        }
      });
      await sincronizarPassosServicos(existente.id, existente.pipelineStage.id, existente.pipelineStage.chaveAuto);
      await reconciliarPassosAuto(existente.id);
      await prisma.activityLog.create({ data: { acao: "lead.recapturado", entidadeTipo: "lead", entidadeId: existente.id } });
      const contato2 = existente.empresa ? `${existente.nome} \xB7 ${existente.empresa}` : existente.nome;
      const equipe2 = await prisma.user.findMany({
        where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
        select: { id: true }
      });
      for (const u of equipe2) {
        await notificar(u.id, "lead_novo", { contato: contato2 }, { entidadeTipo: "lead", entidadeId: existente.id });
      }
      return { ok: true };
    }
  }
  const { origem, rastreio } = derivarRastreioOrigem(input);
  const lead = await prisma.lead.create({
    data: {
      nome: input.nome.trim(),
      empresa: clean(input.empresa),
      email: clean(input.email),
      telefone: clean(input.telefone),
      origem,
      rastreio: rastreio || null,
      observacoes: clean(input.mensagem),
      pipelineStageId: stageId,
      ordem: (max._max.ordem ?? -1) + 1,
      responsavelId: null,
      servicos: input.servicoIds?.length ? { connect: input.servicoIds.map((id) => ({ id })) } : void 0
    }
  });
  await prisma.activityLog.create({
    data: { acao: "lead.capturado", entidadeTipo: "lead", entidadeId: lead.id }
  });
  try {
    const clienteId = await garantirClienteDoLead(lead, null);
    const acesso = await garantirAcessoPortal(clienteId, lead.nome, lead.email);
    if (!acesso.criou && lead.email) {
      void enviarEmailTemplate("lead_confirmacao", lead.email, { nome: input.nome.trim() }).catch(() => {
      });
    }
  } catch {
  }
  const contato = lead.empresa ? `${lead.nome} \xB7 ${lead.empresa}` : lead.nome;
  const equipe = await prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
    select: { id: true }
  });
  for (const u of equipe) {
    await notificar(u.id, "lead_novo", { contato }, { entidadeTipo: "lead", entidadeId: lead.id });
  }
  return { ok: true };
}
async function garantirClienteDoLead(lead, atorId) {
  if (lead.clienteId) {
    const atual = await prisma.cliente.findFirst({ where: { id: lead.clienteId, deletedAt: null }, select: { id: true } });
    if (atual) return atual.id;
  }
  if (lead.email) {
    const existente = await prisma.cliente.findFirst({ where: { email: lead.email, deletedAt: null }, select: { id: true } });
    if (existente) {
      await prisma.lead.update({ where: { id: lead.id }, data: { clienteId: existente.id } });
      return existente.id;
    }
  }
  const temEmpresa = !!lead.empresa?.trim();
  const cliente = await prisma.cliente.create({
    data: {
      // Com empresa, a CONTA é a empresa (PJ); a pessoa do lead vira o contato principal
      // logo abaixo (não se perde). Sem empresa, o cliente é a própria pessoa (PF).
      nome: temEmpresa ? lead.empresa.trim() : lead.nome.trim(),
      tipo: temEmpresa ? "PJ" : "PF",
      email: lead.email,
      telefone: lead.telefone,
      observacoes: lead.observacoes,
      responsavelId: lead.responsavelId ?? atorId ?? null,
      situacaoComercial: "PROSPECT"
    }
  });
  if (temEmpresa && lead.nome.trim()) {
    await prisma.contato.create({
      data: { clienteId: cliente.id, nome: lead.nome.trim(), email: lead.email, telefone: lead.telefone, principal: true }
    });
  }
  await prisma.lead.update({ where: { id: lead.id }, data: { clienteId: cliente.id } });
  return cliente.id;
}
async function convidarPortal(leadId, ator) {
  const lead = await prisma.lead.findUnique({ where: { id: leadId } });
  if (!lead || lead.deletedAt) throw new TRPCError2({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado" });
  if (!lead.email) {
    throw new TRPCError2({
      code: "BAD_REQUEST",
      message: "Cadastre um e-mail no lead para convid\xE1-lo ao Portal."
    });
  }
  const clienteId = await garantirClienteDoLead(lead, ator.id);
  const jaTem = await prisma.user.findFirst({
    where: { clienteId, role: "CLIENTE", deletedAt: null }
  });
  if (jaTem) {
    if (jaTem.passwordHash === null) {
      const r = await reenviarConvite(ator.role, jaTem.id);
      await avancarLeadAuto(leadId, "qualificacao", "Convite ao Portal enviado");
      return { clienteId, conviteUrl: r.conviteUrl, emailEnviado: r.emailEnviado, email: r.email };
    }
    throw new TRPCError2({ code: "CONFLICT", message: "Este cliente j\xE1 tem acesso ativo ao Portal." });
  }
  const { usuario, conviteUrl, emailEnviado } = await convidarUsuario(ator.role, {
    nome: lead.nome,
    email: lead.email,
    role: "CLIENTE",
    clienteId
  });
  await avancarLeadAuto(leadId, "qualificacao", "Convite ao Portal enviado");
  return { clienteId, conviteUrl, emailEnviado, email: usuario.email };
}
async function removeLead(id, userId) {
  const lead = await prisma.lead.findUnique({ where: { id }, select: { clienteId: true } });
  await prisma.lead.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  await prisma.activityLog.create({
    data: { userId, acao: "lead.removido", entidadeTipo: "lead", entidadeId: id }
  });
  await reconciliarSituacaoCliente(lead?.clienteId ?? null);
  return { ok: true };
}

// src/modules/documentos/modelos.service.ts
import { TRPCError as TRPCError3 } from "@trpc/server";
var DEFAULTS2 = [
  {
    // O marcador {{servicos}} é onde o construtor injeta a tabela de serviços + investimento
    // (com prazo/condições). O resto do corpo é livre e editável.
    nome: "Proposta comercial",
    tipo: "PROPOSTA",
    corpo: `Prezado(a) {{cliente.nome}},

{{apresentacao}}

{{servicos}}

Ficamos \xE0 disposi\xE7\xE3o para qualquer d\xFAvida e seguimos juntos no que voc\xEA decidir. Ser\xE1 um prazer cuidar disso por voc\xEA.

Atenciosamente,
**Equipe MedConsultoria**`
  },
  {
    nome: "Proposta de credenciamento",
    tipo: "PROPOSTA",
    corpo: `Prezado(a) {{cliente.nome}},

Sabemos que **se credenciar junto \xE0s operadoras e conv\xEAnios** costuma ser burocr\xE1tico, demorado e cheio de exig\xEAncias. Esta proposta mostra como a **MedConsultoria assume esse processo por inteiro** \u2014 da organiza\xE7\xE3o dos documentos \xE0 aprova\xE7\xE3o final em cada plano \u2014, para que voc\xEA se dedique ao que faz de melhor: cuidar dos seus pacientes.

## O que \xE9 o credenciamento

Credenciar \xE9 habilitar voc\xEA (ou a sua cl\xEDnica) a **atender pelos planos de sa\xFAde e conv\xEAnios** \u2014 passando a receber os pacientes dessas operadoras e a faturar por elas. \xC9 um processo cheio de exig\xEAncias e documentos; n\xF3s conduzimos tudo por voc\xEA, do come\xE7o ao fim.

## Como funciona \u2014 passo a passo

1. **Levantamento e organiza\xE7\xE3o** dos seus documentos e informa\xE7\xF5es.
2. **Cadastro e protocolo** junto a cada operadora / conv\xEAnio.
3. **Acompanhamento** de cada processo e **negocia\xE7\xE3o da tabela** de honor\xE1rios.
4. **Conclus\xE3o**: credenciamento aprovado e voc\xEA liberado para atender.

## O que vamos precisar de voc\xEA

Para come\xE7ar, pediremos alguns documentos \u2014 de forma simples, pelo seu Portal do Cliente:

- Documentos pessoais e profissionais (RG, CPF, registro no conselho, t\xEDtulo de especialista, diploma);
- Comprovante de endere\xE7o e dados banc\xE1rios;
- Se for cl\xEDnica / PJ: CNPJ, contrato social, alvar\xE1 e licen\xE7a sanit\xE1ria.

_A lista exata \xE9 confirmada conforme as operadoras escolhidas._

## Operadoras e conv\xEAnios

Conduzimos o seu credenciamento junto \xE0s operadoras selecionadas para o seu perfil e a sua regi\xE3o:

{{operadoras}}

_Podemos incluir ou ajustar operadoras conforme a sua especialidade e a sua pra\xE7a._

{{servicos}}

Assim que voc\xEA aprovar esta proposta, j\xE1 iniciamos o levantamento da documenta\xE7\xE3o pelo seu Portal do Cliente.

Atenciosamente,
**Equipe MedConsultoria**`
  },
  {
    nome: "Contrato de presta\xE7\xE3o de servi\xE7os",
    tipo: "CONTRATO",
    corpo: `**CONTRATO DE PRESTA\xC7\xC3O DE SERVI\xC7OS**

Pelo presente instrumento particular, de um lado {{contratada}}, doravante denominada **CONTRATADA**; e de outro **{{cliente.nome}}**, inscrita(o) sob o documento {{cliente.documento}}, e-mail {{cliente.email}}, doravante denominada(o) **CONTRATANTE**; t\xEAm entre si justo e contratado o quanto segue.

## 1. Objeto
A CONTRATADA prestar\xE1 \xE0 CONTRATANTE os seguintes servi\xE7os:

{{objeto}}

As condi\xE7\xF5es espec\xEDficas de **cada servi\xE7o contratado** est\xE3o detalhadas na Cl\xE1usula 9 (Condi\xE7\xF5es espec\xEDficas dos servi\xE7os).

## 2. Obriga\xE7\xF5es da CONTRATADA
- Executar os servi\xE7os com zelo, t\xE9cnica e \xE9tica profissional;
- Manter a CONTRATANTE informada sobre o andamento dos trabalhos;
- Guardar sigilo sobre todas as informa\xE7\xF5es a que tiver acesso.

## 3. Obriga\xE7\xF5es da CONTRATANTE
- Fornecer, em tempo h\xE1bil, os documentos e as informa\xE7\xF5es necess\xE1rios;
- Efetuar os pagamentos nas condi\xE7\xF5es acordadas;
- Indicar um respons\xE1vel para o contato com a CONTRATADA.

## 4. Valor e forma de pagamento
{{valor}}

Os valores ser\xE3o reajustados a cada 12 (doze) meses pela varia\xE7\xE3o acumulada do IPCA/IBGE (ou \xEDndice que venha a substitu\xED-lo).

## 5. Prazo e vig\xEAncia
{{prazo}}

## 6. Confidencialidade e prote\xE7\xE3o de dados (LGPD)
As partes manter\xE3o sigilo sobre as informa\xE7\xF5es trocadas. A CONTRATADA tratar\xE1 eventuais dados pessoais e dados de pacientes estritamente para a execu\xE7\xE3o deste contrato, conforme a Lei n\xBA 13.709/2018 (LGPD), adotando as medidas de seguran\xE7a adequadas.

## 7. Rescis\xE3o
Este contrato pode ser rescindido por qualquer das partes mediante aviso pr\xE9vio de 30 (trinta) dias, sem preju\xEDzo dos valores devidos at\xE9 a data da rescis\xE3o. Na rescis\xE3o imotivada antes do t\xE9rmino da vig\xEAncia, a parte que der causa pagar\xE1 multa compensat\xF3ria equivalente a 1 (uma) mensalidade dos servi\xE7os.

## 8. Disposi\xE7\xF5es gerais
Fica eleito o foro de {{foro}} para dirimir eventuais d\xFAvidas. As partes assinam este contrato **eletronicamente**, com validade jur\xEDdica (Lei n\xBA 14.063/2020), declarando concord\xE2ncia com todas as condi\xE7\xF5es aqui estabelecidas.

## 9. Condi\xE7\xF5es espec\xEDficas dos servi\xE7os
As condi\xE7\xF5es abaixo se aplicam a cada servi\xE7o efetivamente contratado pela CONTRATANTE e integram o objeto deste contrato.

{{clausulas_servicos}}

---

**MedConsultoria** (CONTRATADA) &nbsp;\xB7&nbsp; **{{cliente.nome}}** (CONTRATANTE)`
  },
  {
    nome: "Escopo de trabalho",
    tipo: "ESCOPO",
    corpo: `**ESCOPO DE TRABALHO**

**Cliente:** {{cliente.nome}}
**Servi\xE7o:** {{servico}}

## Objetivo
{{objetivo}}

## O que est\xE1 inclu\xEDdo
{{atividades}}

## Entreg\xE1veis
{{entregaveis}}

## O que N\xC3O est\xE1 inclu\xEDdo
{{fora_escopo}}

## Prazos e marcos
{{prazos}}

## Responsabilidades
- **MedConsultoria:** execu\xE7\xE3o do servi\xE7o, acompanhamento e relat\xF3rios de andamento.
- **Cliente:** envio dos documentos e informa\xE7\xF5es em tempo h\xE1bil, e um respons\xE1vel para contato.

## Observa\xE7\xF5es
{{observacoes}}`
  },
  {
    nome: "Ata de reuni\xE3o",
    tipo: "ATA",
    corpo: `**Data da reuni\xE3o:** {{data_reuniao}} &nbsp;\xB7&nbsp; **Local:** {{local}}
**Participantes:** {{participantes}}

## Pauta
{{pauta}}

## Discuss\xF5es e decis\xF5es
{{decisoes}}

## Pr\xF3ximos passos (o qu\xEA \xB7 quem \xB7 quando)
{{proximos_passos}}`
  },
  {
    nome: "Pauta de reuni\xE3o",
    tipo: "PAUTA_REUNIAO",
    corpo: `**Data e hora:** {{data_hora}} &nbsp;\xB7&nbsp; **Participantes:** {{participantes}}

## Objetivo da reuni\xE3o
{{objetivo}}

## T\xF3picos a tratar
{{topicos}}

## Decis\xF5es que precisamos tomar
{{decisoes_necessarias}}

## Pontos que n\xE3o podemos esquecer
{{pontos_chave}}

## Materiais de apoio
{{materiais}}`
  },
  {
    nome: "Checklist de onboarding do cliente",
    tipo: "ONBOARDING",
    corpo: `## Onboarding de {{cliente.nome}}

**Boas-vindas e alinhamento**
- [ ] Proposta aceita e contrato assinado
- [ ] Reuni\xE3o de kickoff realizada
- [ ] Respons\xE1vel e equipe definidos

**Acessos e informa\xE7\xF5es**
- [ ] Documentos e acessos recebidos
- [ ] Ferramentas e relat\xF3rios configurados

**Plano de trabalho**
- [ ] Cronograma e metas acordados
- [ ] Primeiro alinhamento de resultados agendado

**Observa\xE7\xF5es:** {{observacoes}}`
  },
  {
    nome: "Checklist de documentos \u2014 Credenciamento",
    tipo: "CHECKLIST",
    corpo: `Lista dos documentos necess\xE1rios para o credenciamento. Marque conforme for enviando \u2014 voc\xEA pode enviar tudo de forma simples pelo seu **Portal do Cliente**.

## Do profissional
- [ ] RG e CPF
- [ ] Registro no conselho (CRM / CRO)
- [ ] Diploma de gradua\xE7\xE3o
- [ ] T\xEDtulo de especialista / RQE (se houver)
- [ ] Comprovante de endere\xE7o
- [ ] Dados banc\xE1rios
- [ ] Foto 3x4 (se solicitada pela operadora)

## Da cl\xEDnica / PJ (quando aplic\xE1vel)
- [ ] CNPJ e contrato social
- [ ] Alvar\xE1 de funcionamento
- [ ] Licen\xE7a sanit\xE1ria (vigil\xE2ncia)
- [ ] Respons\xE1vel t\xE9cnico
- [ ] Comprovante de endere\xE7o da cl\xEDnica

_A lista pode variar conforme a operadora / conv\xEAnio._

**Observa\xE7\xF5es:** {{observacoes}}`
  },
  {
    nome: "Pauta de postagem (calend\xE1rio editorial)",
    tipo: "PAUTA_POSTAGEM",
    corpo: `**Per\xEDodo:** {{periodo}}

## Calend\xE1rio de conte\xFAdo

{{postagens}}

## Diretrizes
- Sempre dentro das normas do CFM (sem promessas de resultado, sem antes/depois indevido).
- Tom acolhedor e informativo.

**Observa\xE7\xF5es:** {{observacoes}}`
  },
  {
    nome: "Relat\xF3rio de faturamento e glosas",
    tipo: "RELATORIO",
    corpo: `**Per\xEDodo:** {{periodo}}

## Resumo do faturamento

| Indicador | Valor |
| --- | --- |
| Total faturado | {{total_faturado}} |
| Total glosado | {{total_glosado}} |
| Glosas recuperadas | {{glosas_recuperadas}} |
| % de glosa | {{percentual_glosa}} |

## Principais motivos de glosa
{{motivos_glosa}}

## A\xE7\xF5es realizadas
{{acoes}}

## Recomenda\xE7\xF5es
{{recomendacoes}}`
  },
  {
    nome: "Relat\xF3rio gerencial mensal",
    tipo: "RELATORIO",
    corpo: `**Per\xEDodo:** {{periodo}}

## Indicadores do m\xEAs
{{indicadores}}

## Destaques e conquistas
{{destaques}}

## Pontos de aten\xE7\xE3o
{{atencao}}

## Pr\xF3ximos passos
{{proximos_passos}}

**Equipe MedConsultoria**`
  },
  {
    nome: "Relat\xF3rio de desempenho de marketing",
    tipo: "RELATORIO",
    corpo: `**Per\xEDodo:** {{periodo}}

## Resultados

| M\xE9trica | Resultado | Varia\xE7\xE3o |
| --- | --- | --- |
| Alcance | {{alcance}} | {{var_alcance}} |
| Seguidores | {{seguidores}} | {{var_seguidores}} |
| Engajamento | {{engajamento}} | {{var_engajamento}} |
| Agendamentos/leads | {{leads}} | {{var_leads}} |

## Destaques do per\xEDodo
{{destaques}}

## Pr\xF3ximas a\xE7\xF5es
{{proximas_acoes}}`
  },
  {
    nome: "Diagn\xF3stico inicial",
    tipo: "DIAGNOSTICO",
    corpo: `**Cliente:** {{cliente.nome}} &nbsp;\xB7&nbsp; **Data:** {{data}}

## Situa\xE7\xE3o atual
{{situacao}}

## Pontos fortes
{{pontos_fortes}}

## Oportunidades de melhoria
{{oportunidades}}

## Recomenda\xE7\xF5es da MedConsultoria
{{recomendacoes}}`
  },
  {
    nome: "Plano de a\xE7\xE3o",
    tipo: "PLANO_ACAO",
    corpo: `**Cliente:** {{cliente.nome}}
**Objetivo:** {{objetivo}}

## A\xE7\xF5es

{{acoes}}

## Como mediremos o sucesso
{{indicadores}}`
  },
  {
    nome: "Recibo",
    tipo: "RECIBO",
    corpo: `**RECIBO**

Recebemos de **{{cliente.nome}}** a import\xE2ncia de **{{valor}}** ({{valor_extenso}}), referente a **{{referente}}**.

**Forma de pagamento:** {{forma_pagamento}} &nbsp;\xB7&nbsp; **Data:** {{data}}

Para clareza, firmamos o presente recibo, dando plena quita\xE7\xE3o do valor acima.

---

**MedConsultoria**`
  }
];
async function listModelos() {
  const existentes = await prisma.modeloDocumento.findMany({
    select: { id: true, nome: true, corpo: true, tipo: true, editadoManualmente: true }
  });
  const porNome = new Map(existentes.map((m) => [m.nome, m]));
  for (const d of DEFAULTS2) {
    const ex = porNome.get(d.nome);
    if (!ex) {
      await prisma.modeloDocumento.create({ data: d });
    } else if (!ex.editadoManualmente && (ex.corpo !== d.corpo || ex.tipo !== d.tipo)) {
      await prisma.modeloDocumento.update({ where: { id: ex.id }, data: { corpo: d.corpo, tipo: d.tipo } });
    }
  }
  await prisma.modeloDocumento.updateMany({
    where: { tipo: "BRIEFING", ativo: true, editadoManualmente: false },
    data: { ativo: false }
  });
  return prisma.modeloDocumento.findMany({ where: { ativo: true }, orderBy: [{ tipo: "asc" }, { nome: "asc" }] });
}
async function getModelo(id) {
  const m = await prisma.modeloDocumento.findUnique({ where: { id } });
  if (!m) throw new TRPCError3({ code: "NOT_FOUND", message: "Modelo n\xE3o encontrado." });
  return m;
}
function createModelo(input) {
  return prisma.modeloDocumento.create({
    data: { nome: input.nome.trim(), tipo: input.tipo, corpo: input.corpo }
  });
}
function updateModelo(input) {
  const { id, ...rest } = input;
  const data = { editadoManualmente: true };
  if (rest.nome !== void 0) data.nome = rest.nome.trim();
  if (rest.tipo !== void 0) data.tipo = rest.tipo;
  if (rest.corpo !== void 0) data.corpo = rest.corpo;
  return prisma.modeloDocumento.update({ where: { id }, data });
}
async function removeModelo(id) {
  await prisma.modeloDocumento.update({ where: { id }, data: { ativo: false } });
  return { ok: true };
}

// src/modules/documentos/documentos.service.ts
function render(corpo, variaveis, cliente) {
  const ctx = { ...variaveis };
  if (cliente) {
    ctx["cliente.nome"] = cliente.nome;
    ctx["cliente.email"] = cliente.email ?? "";
    ctx["cliente.documento"] = cliente.documento ?? "";
    ctx["cliente.telefone"] = cliente.telefone ?? "";
  }
  ctx["data"] = (/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR");
  const escVal = (v) => v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return corpo.replace(
    /\{\{\s*([\w.]+)\s*\}\}/g,
    (_, k) => ctx[k] != null ? escVal(ctx[k]) : "*(a preencher)*"
  );
}
function listDocumentos(status) {
  return prisma.documento.findMany({
    where: { deletedAt: null, ...status ? { status } : {} },
    orderBy: { updatedAt: "desc" },
    select: {
      id: true,
      titulo: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      // Sinais para a faixa "Precisa de atenção" no arquivo.
      propostaStatus: true,
      assinaturaSolicitadaEm: true,
      assinadoEm: true,
      modelo: { select: { nome: true, tipo: true } },
      cliente: { select: { nome: true } },
      criadoPor: { select: { nome: true } }
    }
  });
}
async function getDocumento(id) {
  const doc = await prisma.documento.findFirst({
    where: { id, deletedAt: null },
    include: {
      modelo: { select: { nome: true, tipo: true } },
      cliente: { select: { id: true, nome: true } },
      criadoPor: { select: { nome: true } },
      aprovadoPor: { select: { nome: true } },
      versoes: { orderBy: { createdAt: "desc" }, include: { autor: { select: { nome: true } } } }
    }
  });
  if (!doc) throw new TRPCError4({ code: "NOT_FOUND", message: "Documento n\xE3o encontrado" });
  return doc;
}
async function createDocumento(input, userId) {
  const modelo = await prisma.modeloDocumento.findUnique({ where: { id: input.modeloId } });
  if (!modelo) throw new TRPCError4({ code: "NOT_FOUND", message: "Modelo n\xE3o encontrado" });
  const clienteId = input.clienteId?.trim() || null;
  const cliente = clienteId ? await prisma.cliente.findUnique({
    where: { id: clienteId },
    select: { nome: true, email: true, documento: true, telefone: true }
  }) : null;
  const conteudo = render(modelo.corpo, input.variaveis ?? {}, cliente);
  const titulo = input.titulo?.trim() || `${modelo.nome}${cliente ? " - " + cliente.nome : ""}`;
  return prisma.documento.create({
    data: {
      modeloId: modelo.id,
      clienteId,
      titulo,
      conteudo,
      status: "RASCUNHO",
      criadoPorId: userId,
      versoes: { create: { conteudo, autorId: userId, origem: "MANUAL" } }
    }
  });
}
var brl = (n) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
var fmtPct = (v) => `${v.toLocaleString("pt-BR", { maximumFractionDigits: 2 })}%`;
function montarServicos(itens, servicos) {
  const sufixo = (r) => r === "MENSAL" ? "/m\xEAs" : "";
  let totalAvulso = 0;
  let totalMensal = 0;
  const percentuais = [];
  const linhasTabela = itens.map((it) => {
    const s = servicos.find((x) => x.id === it.servicoId);
    const qtd = it.quantidade ?? 1;
    const sub = (it.valor ?? 0) * qtd;
    if (it.recorrencia === "MENSAL") totalMensal += sub;
    else totalAvulso += sub;
    const partes = [];
    if (sub > 0) {
      const base = qtd > 1 ? `${qtd} \xD7 ${brl(it.valor ?? 0)} = ${brl(sub)}` : brl(sub);
      partes.push(base + sufixo(it.recorrencia));
    }
    if (it.percentual != null && it.percentual > 0) {
      partes.push(`${fmtPct(it.percentual)} do faturamento/m\xEAs`);
      percentuais.push(`${fmtPct(it.percentual)} do faturamento (${s?.nome ?? "servi\xE7o"})`);
    }
    const preco = partes.length ? partes.join(" + ") : "a combinar";
    const nome = s?.nome ?? "Servi\xE7o";
    const desc = s?.descricao ? ` \u2014 ${s.descricao}` : "";
    return `| **${nome}**${desc} | ${preco} |`;
  });
  const investimento = [];
  if (totalAvulso > 0) investimento.push(`- **\xC0 vista (1x):** ${brl(totalAvulso)}`);
  if (totalMensal > 0) investimento.push(`- **Mensal:** ${brl(totalMensal)}/m\xEAs`);
  for (const p of percentuais) investimento.push(`- **${p}** \u2014 por m\xEAs`);
  if (investimento.length === 0) investimento.push("- A combinar");
  return {
    tabela: `| Servi\xE7o | Investimento |
| --- | --- |
${linhasTabela.join("\n")}`,
    investimento: investimento.join("\n"),
    nomes: itens.map((it) => servicos.find((x) => x.id === it.servicoId)?.nome ?? "Servi\xE7o")
  };
}
async function criarProposta(input, userId) {
  const clienteId = input.clienteId?.trim() || null;
  const cliente = clienteId ? await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true, email: true, documento: true, telefone: true } }) : null;
  const extras = [
    input.prazo?.trim() ? `**Prazo estimado:** ${input.prazo.trim()}` : "",
    input.condicoes?.trim() ? `**Condi\xE7\xF5es de pagamento:** ${input.condicoes.trim()}` : ""
  ].filter(Boolean);
  const ehCredenciamento = (input.operadoras?.length ?? 0) > 0;
  let servicosNomes = [];
  let blocoServicos;
  if (ehCredenciamento) {
    const ops = input.operadoras ?? [];
    const fee = input.valorPorOperadora ?? 0;
    const total = fee * ops.length;
    const investeTxt = fee > 0 ? `**${brl(total)}** para o credenciamento em **${ops.length} operadora(s)** \u2014 ${brl(fee)} por operadora.` : "Investimento a combinar conforme as operadoras selecionadas.";
    const bloco = [`## Investimento

${investeTxt}`];
    if (extras.length) bloco.push(extras.join("  \n"));
    if (input.observacoes?.trim()) bloco.push(input.observacoes.trim());
    blocoServicos = bloco.join("\n\n");
  } else {
    const servicos = await prisma.servico.findMany({
      where: { id: { in: input.itens.map((i) => i.servicoId) } },
      select: { id: true, nome: true, descricao: true }
    });
    const r = montarServicos(input.itens, servicos);
    servicosNomes = r.nomes;
    const bloco = [
      `## Servi\xE7os propostos

${r.tabela}`,
      `## Investimento

${r.investimento}`
    ];
    if (extras.length) bloco.push(extras.join("  \n"));
    if (input.observacoes?.trim()) bloco.push(input.observacoes.trim());
    blocoServicos = bloco.join("\n\n");
  }
  const operadorasBloco = (input.operadoras?.length ?? 0) > 0 ? (input.operadoras ?? []).map((o) => `- **${o}**`).join("\n") : "_(a definir com voc\xEA)_";
  const modelo = input.modeloId ? await prisma.modeloDocumento.findUnique({ where: { id: input.modeloId } }) : await prisma.modeloDocumento.findFirst({ where: { tipo: "PROPOSTA", ativo: true }, orderBy: { createdAt: "asc" } });
  const usaApresentacao = modelo?.corpo?.includes("{{apresentacao}}") ?? false;
  const nomeCliente = cliente?.nome ?? "cliente";
  let apresentacao = `A MedConsultoria cuida de todos os processos da sua cl\xEDnica para lhe dar mais tempo e tranquilidade para fazer o que mais importa: cuidar de vidas. Apresentamos a seguir a proposta pensada para as suas necessidades.`;
  if (usaApresentacao && input.usarIA && isAiEnabled) {
    try {
      const user = [
        `Escreva um par\xE1grafo de APRESENTA\xC7\xC3O (2-4 frases) para uma proposta comercial da MedConsultoria ao cliente "${nomeCliente}".`,
        `Servi\xE7os propostos: ${servicosNomes.join(", ")}.`,
        "Tom profissional e acolhedor, foco em sa\xFAde/cl\xEDnicas. Responda apenas com o par\xE1grafo, sem t\xEDtulo."
      ].join("\n");
      apresentacao = (await aiService.gerarRascunho(SYSTEM_IA, user)).trim() || apresentacao;
    } catch {
    }
  }
  let conteudo;
  if (modelo?.corpo?.includes("{{servicos}}")) {
    const comMarcadores = modelo.corpo.replace(/\{\{\s*servicos\s*\}\}/g, blocoServicos).replace(/\{\{\s*operadoras\s*\}\}/g, operadorasBloco).replace(/\{\{\s*apresentacao\s*\}\}/g, apresentacao);
    conteudo = render(comMarcadores, {}, cliente);
  } else {
    const secoes = [
      `Prezado(a) ${cliente?.nome ?? ""},`.trim(),
      apresentacao,
      blocoServicos,
      "Ficamos \xE0 disposi\xE7\xE3o para esclarecimentos.",
      "Atenciosamente,  \n**Equipe MedConsultoria**"
    ];
    conteudo = secoes.join("\n\n");
  }
  const titulo = input.titulo?.trim() || `${modelo?.nome ?? "Proposta"}${cliente ? " - " + cliente.nome : ""}`;
  const doc = await prisma.documento.create({
    data: {
      modeloId: modelo?.id ?? null,
      clienteId,
      titulo,
      conteudo,
      status: "RASCUNHO",
      criadoPorId: userId,
      // Itens estruturados (só na proposta comercial) — o aceite os sincroniza com os serviços
      // contratados do cliente. Credenciamento (operadoras) não mapeia para o catálogo.
      itens: ehCredenciamento ? void 0 : input.itens,
      versoes: { create: { conteudo, autorId: userId, origem: input.usarIA ? "IA" : "MANUAL" } }
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "documento.proposta_gerada", entidadeTipo: "documento", entidadeId: doc.id }
  });
  return doc;
}
async function itensDoCliente(clienteId) {
  const contratados = await prisma.clienteServico.findMany({
    where: { clienteId, status: "ATIVO" },
    select: {
      valor: true,
      valorRecorrencia: true,
      percentual: true,
      servico: { select: { id: true, nome: true, categoria: true } }
    },
    orderBy: { contratadoEm: "asc" }
  });
  if (contratados.length) {
    return {
      origem: "CONTRATADO",
      itens: contratados.map((c) => ({
        servicoId: c.servico.id,
        nome: c.servico.nome,
        categoria: c.servico.categoria,
        valor: c.valor ?? 0,
        quantidade: 1,
        recorrencia: c.valorRecorrencia ?? "AVULSO",
        percentual: c.servico.categoria === "Faturamento" ? c.percentual ?? null : null
      }))
    };
  }
  const lead = await prisma.lead.findFirst({
    where: { clienteId, deletedAt: null, convertidoEmClienteId: null },
    orderBy: { createdAt: "desc" },
    select: { servicos: { select: { id: true, nome: true, valor: true, valorRecorrencia: true, percentual: true, categoria: true } } }
  });
  if (lead?.servicos.length) {
    return {
      origem: "LEAD",
      itens: lead.servicos.map((s) => ({
        servicoId: s.id,
        nome: s.nome,
        categoria: s.categoria,
        valor: s.valor ?? 0,
        quantidade: 1,
        recorrencia: s.valorRecorrencia ?? "AVULSO",
        percentual: s.categoria === "Faturamento" ? s.percentual ?? null : null
      }))
    };
  }
  return { origem: "VAZIO", itens: [] };
}
async function contextoClienteDoc(input) {
  const cliente = await prisma.cliente.findUnique({
    where: { id: input.clienteId },
    select: { nome: true, tipo: true, documento: true, email: true, telefone: true }
  });
  if (!cliente) throw new TRPCError4({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado." });
  const { itens, origem } = await itensDoCliente(input.clienteId);
  let totalAvulso = 0;
  let totalMensal = 0;
  for (const it of itens) {
    const sub = (it.valor ?? 0) * (it.quantidade ?? 1);
    if (it.recorrencia === "MENSAL") totalMensal += sub;
    else totalAvulso += sub;
  }
  const nomes = itens.map((i) => i.nome);
  const propostaAceita = await prisma.documento.findFirst({
    where: { clienteId: input.clienteId, deletedAt: null, propostaStatus: "ACEITA" },
    orderBy: { propostaRespondidaEm: "desc" },
    select: { id: true, titulo: true, propostaRespondidaEm: true }
  });
  const sugestoes = {
    // "objeto"/"escopo"/"servicos": lista dos serviços.
    servicos: nomes.length ? nomes.map((n) => `- ${n}`).join("\n") : "",
    // "referente": nomes em linha (recibo).
    referente: nomes.join(", "),
    // "valor"/"mensalidade": prioriza o mensal; senão o à vista.
    valor: totalMensal > 0 ? totalMensal : totalAvulso
  };
  return {
    cliente,
    itens,
    origem,
    // CONTRATADO | LEAD | VAZIO — o dialog explica de onde veio
    investimento: { avulso: totalAvulso, mensal: totalMensal },
    propostaAceita: propostaAceita ? { id: propostaAceita.id, titulo: propostaAceita.titulo, em: propostaAceita.propostaRespondidaEm } : null,
    vigenciaSugerida: 12,
    sugestoes
  };
}
function textoVigencia(meses) {
  const extenso = { 6: "seis", 12: "doze", 24: "vinte e quatro", 36: "trinta e seis" };
  const porExtenso = extenso[meses] ? ` (${extenso[meses]})` : "";
  return `Vig\xEAncia de ${meses}${porExtenso} ${meses === 1 ? "m\xEAs" : "meses"} a contar da assinatura, renov\xE1vel automaticamente por iguais per\xEDodos, salvo manifesta\xE7\xE3o em contr\xE1rio com 30 (trinta) dias de anteced\xEAncia.`;
}
async function criarContrato(input, userId) {
  const cliente = await prisma.cliente.findUnique({
    where: { id: input.clienteId },
    select: { nome: true, email: true, documento: true, telefone: true }
  });
  if (!cliente) throw new TRPCError4({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado." });
  const servicos = await prisma.servico.findMany({
    where: { id: { in: input.itens.map((i) => i.servicoId) } },
    select: { id: true, nome: true, descricao: true, clausulasContrato: true }
  });
  const sufixo = (rec) => rec === "MENSAL" ? "/m\xEAs" : "";
  const precoDoItem = (it) => {
    const sub = (it.valor ?? 0) * (it.quantidade ?? 1);
    const partes = [];
    if (sub > 0) partes.push(brl(sub) + sufixo(it.recorrencia));
    if (it.percentual != null && it.percentual > 0) partes.push(`${fmtPct(it.percentual)} do faturamento/m\xEAs`);
    return partes.join(" + ");
  };
  const objeto = input.itens.map((it) => {
    const s = servicos.find((x) => x.id === it.servicoId);
    const preco = precoDoItem(it);
    return `- **${s?.nome ?? "Servi\xE7o"}**${preco ? ` \u2014 ${preco}` : ""}`;
  }).join("\n");
  const clausulasServicos = input.itens.map((it) => {
    const s = servicos.find((x) => x.id === it.servicoId);
    const cl = s?.clausulasContrato?.trim();
    return `### ${s?.nome ?? "Servi\xE7o"}

${cl || "Servi\xE7o prestado conforme a proposta comercial e o escopo de trabalho aprovados pela CONTRATANTE."}`;
  }).join("\n\n");
  const r = montarServicos(input.itens, servicos);
  const valorBloco = [r.investimento, input.observacoes?.trim() ? `
${input.observacoes.trim()}` : ""].filter(Boolean).join("");
  const prazoTxt = textoVigencia(input.vigenciaMeses);
  const foroTxt = "da comarca do domic\xEDlio da CONTRATANTE";
  const modelo = input.modeloId ? await prisma.modeloDocumento.findUnique({ where: { id: input.modeloId } }) : await prisma.modeloDocumento.findFirst({ where: { tipo: "CONTRATO", ativo: true }, orderBy: { createdAt: "asc" } });
  if (!modelo) throw new TRPCError4({ code: "NOT_FOUND", message: "Nenhum modelo de contrato cadastrado." });
  const comMarcadores = modelo.corpo.replace(/\{\{\s*objeto\s*\}\}/g, objeto).replace(/\{\{\s*clausulas_servicos\s*\}\}/g, clausulasServicos).replace(/\{\{\s*valor\s*\}\}/g, valorBloco).replace(/\{\{\s*prazo\s*\}\}/g, prazoTxt).replace(/\{\{\s*foro\s*\}\}/g, foroTxt).replace(/\{\{\s*contratada\s*\}\}/g, qualificacaoContratada());
  const conteudo = render(comMarcadores, {}, cliente);
  const titulo = input.titulo?.trim() || `${modelo.nome} \u2014 ${cliente.nome}`;
  const doc = await prisma.documento.create({
    data: {
      modeloId: modelo.id,
      clienteId: input.clienteId,
      titulo,
      conteudo,
      status: "RASCUNHO",
      criadoPorId: userId,
      itens: input.itens,
      versoes: { create: { conteudo, autorId: userId, origem: "MANUAL" } }
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "documento.contrato_gerado", entidadeTipo: "documento", entidadeId: doc.id }
  });
  return doc;
}
async function gerarPropostaAutoParaLead(leadId, userId) {
  const jaTem = await prisma.leadPasso.findFirst({
    where: { leadId, acaoDoc: "proposta", documentoId: { not: null } },
    select: { id: true }
  });
  if (jaTem) return;
  const lead = await prisma.lead.findFirst({
    where: { id: leadId, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    select: {
      id: true,
      nome: true,
      empresa: true,
      email: true,
      telefone: true,
      observacoes: true,
      responsavelId: true,
      clienteId: true,
      servicos: { select: { id: true, valor: true, valorRecorrencia: true, percentual: true, categoria: true } }
    }
  });
  if (!lead || lead.servicos.length === 0) return;
  const clienteId = await garantirClienteDoLead(lead, userId);
  const itens = lead.servicos.map((s) => ({
    servicoId: s.id,
    valor: s.valor ?? 0,
    quantidade: 1,
    recorrencia: s.valorRecorrencia ?? "AVULSO",
    percentual: s.categoria === "Faturamento" ? s.percentual ?? null : null
  }));
  const doc = await criarProposta({ clienteId, itens, usarIA: false }, userId);
  await prisma.documento.update({ where: { id: doc.id }, data: { status: "EM_REVISAO" } });
  await prisma.leadPasso.updateMany({
    where: { leadId, acaoDoc: "proposta", documentoId: null },
    data: { documentoId: doc.id }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "documento.proposta_auto", entidadeTipo: "documento", entidadeId: doc.id }
  });
  void notificar(
    lead.responsavelId ?? userId,
    "documento_revisao",
    { documento: doc.titulo },
    { entidadeTipo: "documento", entidadeId: doc.id }
  ).catch(() => {
  });
  return doc;
}
async function gerarContratoAutoParaCliente(clienteId, userId, opts) {
  const jaTem = await prisma.documento.findFirst({
    where: { clienteId, deletedAt: null, modelo: { tipo: "CONTRATO" } },
    select: { id: true }
  });
  if (jaTem) return;
  const { itens } = await itensDoCliente(clienteId);
  let documentoId;
  if (itens.length) {
    const doc = await criarContrato(
      {
        clienteId,
        vigenciaMeses: 12,
        itens: itens.map(({ servicoId, valor, quantidade, recorrencia, percentual }) => ({ servicoId, valor, quantidade, recorrencia, percentual }))
      },
      userId
    );
    documentoId = doc.id;
    if (opts?.leadId) await prisma.leadPasso.updateMany({ where: { leadId: opts.leadId, acaoDoc: "contrato", documentoId: null }, data: { documentoId } });
  } else if (opts?.leadId) {
    ({ documentoId } = await gerarParaLead(opts.leadId, "contrato", { id: userId }));
  } else {
    return;
  }
  await prisma.documento.update({ where: { id: documentoId }, data: { status: "EM_REVISAO" } });
  await prisma.activityLog.create({
    data: { userId, acao: "documento.contrato_auto", entidadeTipo: "documento", entidadeId: documentoId }
  });
  const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { responsavelId: true } });
  void notificar(
    cliente?.responsavelId ?? userId,
    "documento_revisao",
    { documento: "Contrato" },
    { entidadeTipo: "documento", entidadeId: documentoId }
  ).catch(() => {
  });
  return { documentoId };
}
async function gerarContratoAutoParaLead(leadId, userId) {
  const lead = await prisma.lead.findFirst({
    where: { id: leadId, deletedAt: null, perdidoEm: null },
    select: { id: true, nome: true, empresa: true, email: true, telefone: true, observacoes: true, responsavelId: true, clienteId: true }
  });
  if (!lead) return;
  const clienteId = lead.clienteId ?? await garantirClienteDoLead(lead, userId);
  return gerarContratoAutoParaCliente(clienteId, userId, { leadId });
}
var TIPO_ACAO_DOC = {
  briefing: "BRIEFING",
  proposta: "PROPOSTA",
  contrato: "CONTRATO"
};
async function gerarParaLead(leadId, tipo, ator) {
  const tipoModelo = TIPO_ACAO_DOC[tipo];
  if (!tipoModelo) throw new TRPCError4({ code: "BAD_REQUEST", message: "Tipo de documento inv\xE1lido." });
  const lead = await prisma.lead.findFirst({
    where: { id: leadId, deletedAt: null },
    select: {
      id: true,
      nome: true,
      empresa: true,
      email: true,
      telefone: true,
      observacoes: true,
      responsavelId: true,
      clienteId: true,
      servicos: { select: { id: true, nome: true, valor: true, valorRecorrencia: true, percentual: true, categoria: true, clausulasContrato: true } }
    }
  });
  if (!lead) throw new TRPCError4({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado." });
  const clienteId = await garantirClienteDoLead(lead, ator.id);
  if (tipo === "proposta") {
    const itens = lead.servicos.map((s) => ({
      servicoId: s.id,
      valor: s.valor ?? 0,
      quantidade: 1,
      recorrencia: s.valorRecorrencia ?? "AVULSO",
      percentual: s.categoria === "Faturamento" ? s.percentual ?? null : null
    }));
    const doc2 = await criarProposta({ clienteId, itens, usarIA: false }, ator.id);
    await prisma.leadPasso.updateMany({ where: { leadId, acaoDoc: "proposta", documentoId: null }, data: { documentoId: doc2.id } });
    return { documentoId: doc2.id };
  }
  await listModelos();
  const modelo = await prisma.modeloDocumento.findFirst({ where: { tipo: tipoModelo, ativo: true }, orderBy: { createdAt: "asc" } });
  if (!modelo) throw new TRPCError4({ code: "NOT_FOUND", message: `Nenhum modelo de ${tipo} cadastrado.` });
  const cliente = await prisma.cliente.findUnique({
    where: { id: clienteId },
    select: { nome: true, email: true, documento: true, telefone: true }
  });
  const variaveis = {};
  if (tipo === "contrato") {
    variaveis.objeto = lead.servicos.length ? lead.servicos.map((s) => `- **${s.nome}**`).join("\n") : "Servi\xE7os de consultoria conforme a proposta comercial aprovada pela CONTRATANTE.";
    variaveis.clausulas_servicos = lead.servicos.length ? lead.servicos.map((s) => {
      const cl = s.clausulasContrato?.trim();
      return `### ${s.nome}

${cl || "Servi\xE7o prestado conforme a proposta comercial e o escopo de trabalho aprovados pela CONTRATANTE."}`;
    }).join("\n\n") : "Condi\xE7\xF5es conforme a proposta comercial e o escopo de trabalho aprovados pela CONTRATANTE.";
    variaveis.valor = "Conforme os valores da proposta comercial aprovada pela CONTRATANTE.";
    variaveis.prazo = textoVigencia(12);
    variaveis.foro = "da comarca do domic\xEDlio da CONTRATANTE";
    variaveis.contratada = qualificacaoContratada();
  }
  const conteudo = render(modelo.corpo, variaveis, cliente);
  const titulo = `${modelo.nome} \u2014 ${cliente?.nome ?? lead.nome}`;
  const doc = await prisma.documento.create({
    data: {
      modeloId: modelo.id,
      clienteId,
      titulo,
      conteudo,
      status: "RASCUNHO",
      criadoPorId: ator.id,
      versoes: { create: { conteudo, autorId: ator.id, origem: "MANUAL" } }
    }
  });
  await prisma.leadPasso.updateMany({ where: { leadId, acaoDoc: tipo, documentoId: null }, data: { documentoId: doc.id } });
  await prisma.activityLog.create({
    data: { userId: ator.id, acao: `documento.${tipoModelo.toLowerCase()}_gerado`, entidadeTipo: "documento", entidadeId: doc.id }
  });
  return { documentoId: doc.id };
}
async function updateConteudo(id, conteudo, userId) {
  const doc = await prisma.documento.findUnique({ where: { id } });
  if (!doc || doc.deletedAt) throw new TRPCError4({ code: "NOT_FOUND" });
  if (doc.status === "ENVIADO") {
    throw new TRPCError4({ code: "BAD_REQUEST", message: "Documento j\xE1 enviado n\xE3o pode ser editado" });
  }
  await prisma.$transaction([
    prisma.documento.update({ where: { id }, data: { conteudo } }),
    prisma.documentoVersao.create({
      data: { documentoId: id, conteudo, autorId: userId, origem: "MANUAL" }
    })
  ]);
  return { ok: true };
}
var ETAPA_POR_TIPO_DOC = {
  PROPOSTA: "proposta",
  CONTRATO: "negociacao"
};
async function setStatus(id, status, userId) {
  const doc = await prisma.documento.findUnique({ where: { id }, include: { modelo: { select: { tipo: true } } } });
  if (!doc || doc.deletedAt) throw new TRPCError4({ code: "NOT_FOUND" });
  if (status === "ENVIADO" && doc.status !== "APROVADO") {
    throw new TRPCError4({ code: "BAD_REQUEST", message: "Aprove o documento antes de enviar" });
  }
  const data = { status };
  if (status === "APROVADO") data.aprovadoPorId = userId;
  if (status === "ENVIADO") data.enviadoEm = /* @__PURE__ */ new Date();
  if (status === "RASCUNHO") {
    data.aprovadoPorId = null;
    data.enviadoEm = null;
  }
  await prisma.documento.update({ where: { id }, data });
  await prisma.activityLog.create({
    data: {
      userId,
      acao: `documento.${status.toLowerCase()}`,
      entidadeTipo: "documento",
      entidadeId: id
    }
  });
  const etapa = doc.modelo ? ETAPA_POR_TIPO_DOC[doc.modelo.tipo] : void 0;
  if (status === "ENVIADO" && doc.clienteId && etapa) {
    const motivo = doc.modelo?.tipo === "CONTRATO" ? "Contrato enviado ao cliente" : "Proposta enviada ao cliente";
    void avancarLeadPorClienteAuto(doc.clienteId, etapa, motivo).catch(() => {
    });
  }
  return { ok: true };
}
async function removeDocumento(id) {
  await prisma.documento.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  await prisma.leadPasso.updateMany({ where: { documentoId: id }, data: { documentoId: null } });
  return { ok: true };
}
var SYSTEM_IA = "Voc\xEA \xE9 um assistente da consultoria MedConsultoria. Redija documentos profissionais, claros e objetivos em portugu\xEAs do Brasil. Responda APENAS com o texto final do documento \u2014 sem coment\xE1rios, sem markdown, sem cercas de c\xF3digo.";
function exigirIA() {
  if (!isAiEnabled) {
    throw new TRPCError4({ code: "PRECONDITION_FAILED", message: "IA n\xE3o configurada (OPENAI_API_KEY)." });
  }
}
async function gerarComIA(input, userId) {
  exigirIA();
  const modelo = await prisma.modeloDocumento.findUnique({ where: { id: input.modeloId } });
  if (!modelo) throw new TRPCError4({ code: "NOT_FOUND", message: "Modelo n\xE3o encontrado" });
  const clienteId = input.clienteId?.trim() || null;
  const cliente = clienteId ? await prisma.cliente.findUnique({
    where: { id: clienteId },
    select: { nome: true, email: true, documento: true, telefone: true }
  }) : null;
  const user = [
    `Tipo de documento: ${modelo.nome}.`,
    `Modelo de refer\xEAncia (use como base de estrutura; substitua qualquer {{campo}} por conte\xFAdo real):`,
    modelo.corpo,
    "",
    cliente ? `Cliente: ${cliente.nome}${cliente.email ? ` (${cliente.email})` : ""}${cliente.documento ? ` \u2014 ${cliente.documento}` : ""}.` : "Cliente: n\xE3o informado.",
    `Data de hoje: ${(/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR")}.`,
    "",
    `Instru\xE7\xF5es: ${input.instrucoes}`,
    "",
    "Gere o documento completo e pronto para revis\xE3o humana."
  ].join("\n");
  const conteudo = await aiService.gerarRascunho(SYSTEM_IA, user);
  const titulo = input.titulo?.trim() || `${modelo.nome}${cliente ? " - " + cliente.nome : ""}`;
  const doc = await prisma.documento.create({
    data: {
      modeloId: modelo.id,
      clienteId,
      titulo,
      conteudo,
      status: "RASCUNHO",
      criadoPorId: userId,
      versoes: { create: { conteudo, autorId: userId, origem: "IA" } }
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "documento.ia_gerado", entidadeTipo: "documento", entidadeId: doc.id }
  });
  return doc;
}
async function melhorarComIA(id, instrucao, userId) {
  exigirIA();
  const doc = await prisma.documento.findUnique({ where: { id } });
  if (!doc || doc.deletedAt) throw new TRPCError4({ code: "NOT_FOUND" });
  if (doc.status === "ENVIADO") {
    throw new TRPCError4({ code: "BAD_REQUEST", message: "Documento j\xE1 enviado n\xE3o pode ser editado" });
  }
  const user = [
    "Aprimore/edite o documento abaixo conforme a instru\xE7\xE3o. Mantenha o tom profissional.",
    `Instru\xE7\xE3o: ${instrucao}`,
    "",
    "Documento atual:",
    doc.conteudo
  ].join("\n");
  const conteudo = await aiService.gerarRascunho(SYSTEM_IA, user);
  await prisma.$transaction([
    prisma.documento.update({ where: { id }, data: { conteudo } }),
    prisma.documentoVersao.create({
      data: { documentoId: id, conteudo, autorId: userId, origem: "IA" }
    })
  ]);
  return { ok: true };
}
async function resumirReuniao(input, userId) {
  exigirIA();
  const clienteId = input.clienteId?.trim() || null;
  const cliente = clienteId ? await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true } }) : null;
  const system = "Voc\xEA \xE9 um assistente da consultoria MedConsultoria. A partir de anota\xE7\xF5es de reuni\xE3o, produza uma ATA clara e estruturada em portugu\xEAs do Brasil, com as se\xE7\xF5es: PARTICIPANTES (se houver), PAUTA, DECIS\xD5ES e PR\xD3XIMOS PASSOS (com respons\xE1veis e prazos quando mencionados). Responda APENAS com o texto da ata \u2014 sem markdown, sem coment\xE1rios.";
  const user = [
    `T\xEDtulo da reuni\xE3o: ${input.titulo?.trim() || "Reuni\xE3o"}`,
    `Cliente: ${cliente?.nome ?? "n\xE3o informado"}`,
    `Data: ${(/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR")}`,
    "",
    "Anota\xE7\xF5es da reuni\xE3o:",
    input.anotacoes
  ].join("\n");
  const conteudo = await aiService.gerarRascunho(system, user);
  const titulo = input.titulo?.trim() ? `Ata - ${input.titulo.trim()}` : `Ata de reuni\xE3o${cliente ? " - " + cliente.nome : ""}`;
  const modeloAta = await prisma.modeloDocumento.findFirst({ where: { tipo: "ATA", ativo: true }, orderBy: { createdAt: "asc" } });
  const doc = await prisma.documento.create({
    data: {
      modeloId: modeloAta?.id ?? null,
      clienteId,
      titulo,
      conteudo,
      status: "RASCUNHO",
      criadoPorId: userId,
      versoes: { create: { conteudo, autorId: userId, origem: "IA" } }
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "documento.ia_ata", entidadeTipo: "documento", entidadeId: doc.id }
  });
  return doc;
}
async function gerarPautaReuniao(input, userId) {
  exigirIA();
  const clienteId = input.clienteId?.trim() || null;
  let clienteNome = null;
  let contexto = "Cliente: n\xE3o informado.";
  if (clienteId) {
    const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true } });
    if (cliente) {
      clienteNome = cliente.nome;
      const [servs, lead] = await Promise.all([
        prisma.clienteServico.findMany({
          where: { clienteId, status: "ATIVO" },
          select: { servico: { select: { nome: true } } }
        }),
        prisma.lead.findFirst({
          where: { clienteId, deletedAt: null, convertidoEmClienteId: null },
          orderBy: { createdAt: "desc" },
          select: { pipelineStage: { select: { nome: true } } }
        })
      ]);
      contexto = [
        `Cliente: ${cliente.nome}.`,
        servs.length ? `Servi\xE7os contratados: ${servs.map((s) => s.servico.nome).join(", ")}.` : "Ainda sem servi\xE7os contratados.",
        lead ? `Etapa no funil de vendas: ${lead.pipelineStage.nome}.` : ""
      ].filter(Boolean).join("\n");
    }
  }
  const system = "Voc\xEA \xE9 um assistente da consultoria MedConsultoria. Prepare uma PAUTA DE REUNI\xC3O clara e objetiva em portugu\xEAs do Brasil, com as se\xE7\xF5es: OBJETIVO, T\xD3PICOS A TRATAR, PONTOS QUE N\xC3O PODEMOS ESQUECER e PR\xD3XIMOS PASSOS SUGERIDOS. Seja pr\xE1tico e espec\xEDfico ao contexto. Responda APENAS com o texto da pauta \u2014 sem cercas de c\xF3digo, sem coment\xE1rios.";
  const user = [
    `Contexto:
${contexto}`,
    `Data de hoje: ${(/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR")}.`,
    "",
    `O que se quer tratar / objetivo da reuni\xE3o:
${input.topicos}`,
    "",
    "Gere a pauta pronta para conduzir a reuni\xE3o."
  ].join("\n");
  const conteudo = await aiService.gerarRascunho(system, user);
  const titulo = input.titulo?.trim() || `Pauta de reuni\xE3o${clienteNome ? " - " + clienteNome : ""}`;
  const modeloPauta = await prisma.modeloDocumento.findFirst({ where: { tipo: "PAUTA_REUNIAO", ativo: true }, orderBy: { createdAt: "asc" } });
  const doc = await prisma.documento.create({
    data: {
      modeloId: modeloPauta?.id ?? null,
      clienteId,
      titulo,
      conteudo,
      status: "RASCUNHO",
      criadoPorId: userId,
      versoes: { create: { conteudo, autorId: userId, origem: "IA" } }
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "documento.ia_pauta", entidadeTipo: "documento", entidadeId: doc.id }
  });
  return doc;
}

export {
  hashPassword,
  verifyPassword,
  precisaRehash,
  gerarTokenPublico,
  criarToken,
  inspecionarToken,
  consumirToken,
  listStages,
  garantirAcessoPortal,
  listUsuarios,
  listEquipe,
  createUsuario,
  convidarUsuario,
  reenviarConvite,
  updateUsuario,
  resumoResponsabilidades,
  deleteUsuario,
  aiService,
  listModelos,
  getModelo,
  createModelo,
  updateModelo,
  removeModelo,
  listDocumentos,
  getDocumento,
  createDocumento,
  criarProposta,
  contextoClienteDoc,
  criarContrato,
  gerarPropostaAutoParaLead,
  gerarContratoAutoParaCliente,
  gerarContratoAutoParaLead,
  gerarParaLead,
  updateConteudo,
  setStatus,
  removeDocumento,
  gerarComIA,
  melhorarComIA,
  resumirReuniao,
  gerarPautaReuniao,
  avancarLeadPorClienteAuto,
  reconciliarPassosAuto,
  getLeadDetalhe,
  avancarSeChecklistCompleto,
  togglePasso,
  addPasso,
  removePasso,
  avancarEtapa,
  listLeads,
  listPerdidos,
  funilResumo,
  marcarPerdido,
  reabrirLead,
  desistenciaPeloCliente,
  retomarPeloCliente,
  solicitarServicosPeloCliente,
  criarOportunidadeParaCliente,
  createLead,
  updateLead,
  moveLead,
  convertLead,
  capturarLead,
  convidarPortal,
  removeLead
};
//# sourceMappingURL=chunk-YSR2MJZI.js.map