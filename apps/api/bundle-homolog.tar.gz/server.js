import {
  addPasso,
  aiService,
  avancarEtapa,
  avancarLeadPorClienteAuto,
  avancarSeChecklistCompleto,
  capturarLead,
  consumirToken,
  contextoClienteDoc,
  convertLead,
  convidarPortal,
  convidarUsuario,
  createDocumento,
  createLead,
  createModelo,
  createUsuario,
  criarContrato,
  criarOportunidadeParaCliente,
  criarProposta,
  criarToken,
  deleteUsuario,
  desistenciaPeloCliente,
  funilResumo,
  garantirAcessoPortal,
  gerarComIA,
  gerarParaLead,
  gerarPautaReuniao,
  gerarTokenPublico,
  getDocumento,
  getLeadDetalhe,
  getModelo,
  hashPassword,
  inspecionarToken,
  listDocumentos,
  listEquipe,
  listLeads,
  listModelos,
  listPerdidos,
  listStages,
  listUsuarios,
  marcarPerdido,
  melhorarComIA,
  moveLead,
  precisaRehash,
  reabrirLead,
  reconciliarPassosAuto,
  reenviarConvite,
  removeDocumento,
  removeLead,
  removeModelo,
  removePasso,
  resumirReuniao,
  resumoResponsabilidades,
  retomarPeloCliente,
  setStatus,
  solicitarServicosPeloCliente,
  togglePasso,
  updateConteudo,
  updateLead,
  updateModelo,
  updateUsuario,
  verifyPassword
} from "./chunk-YSR2MJZI.js";
import {
  AVATAR_MAX,
  MIMETYPES_ACEITOS,
  MIMETYPES_IMAGEM,
  TAMANHO_MAX,
  addRequisito,
  addServicoPasso,
  ativarServicoCliente,
  atualizarContratacaoCliente,
  atualizarRequisito,
  atualizarServico,
  atualizarServicoPasso,
  caminhoAbsoluto,
  cancelarServicoCliente,
  criarServico,
  equipeDoCliente,
  getArquivo,
  listPassosDoServico,
  listRequisitos,
  listServicos,
  listServicosAtivos,
  listarArquivos,
  registrarUpload,
  removerArquivo,
  removerArquivo2,
  removerRequisito,
  removerServico,
  removerServicoPasso,
  reordenarRequisitos,
  reordenarServicoPassos,
  reordenarServicos,
  salvarArquivo,
  salvarAvatar,
  servicosDoCliente,
  servicosDoClientePortal,
  setRoteiro,
  validarPastaUploads
} from "./chunk-UT3JPKGF.js";
import {
  createProjeto,
  getProjeto,
  listProjetos,
  reconciliarCardsDoServico,
  reconciliarStatusCard,
  reconciliarStatusProjeto,
  removeProjeto,
  setParticipantes,
  updateProjeto
} from "./chunk-RC5JM4L5.js";
import {
  agendaFinanceira,
  atencao,
  atividade,
  banco,
  configInfo,
  createConta,
  desempenho,
  diagnostico,
  erros,
  getProcessoAgora,
  getResumoTrafego,
  historicoUptime,
  ignorarErro,
  incidentes,
  limparSessoesExpiradas,
  listContas,
  marcarPaga,
  metricas,
  migracoes,
  porCategoria,
  reconhecerIncidente,
  recordCall,
  reexibirErro,
  registrarErro,
  removeConta,
  resolverErro,
  resolverIncidente,
  resolverTodosErros,
  resolverTodosIncidentes,
  resumo,
  revogarSessao,
  rodarVarredura,
  saude,
  sessoes,
  startMonitor,
  startReminderLoop,
  statusJobs,
  updateConta
} from "./chunk-FWRXEZ6P.js";
import {
  OPERADORAS_COMUNS,
  SESSION_COOKIE,
  SESSION_TTL_SECONDS,
  SITUACOES_CLIENTE,
  aceitarConviteSchema,
  addCampoSchema,
  addChecklistSchema,
  addParticipantesSchema,
  addRequisitoSchema,
  addServicoPassoSchema,
  assinarSchema,
  ativarServicoClienteSchema,
  atualizarContratacaoClienteSchema,
  atualizarTemplate,
  cancelarServicoClienteSchema,
  capturaLeadSchema,
  carteiraInputSchema,
  changePasswordSchema,
  config,
  conflitoEventoSchema,
  contextoClienteDocSchema,
  conversaIdSchema,
  createCardSchema,
  createCategoriaSchema,
  createClienteSchema,
  createContaSchema,
  createContatoSchema,
  createDocumentoSchema,
  createEventoSchema,
  createFormularioSchema,
  createGrupoSchema,
  createLeadSchema,
  createModeloSchema,
  createNotaSchema,
  createOrigemSchema,
  createProjetoSchema,
  createServicoSchema,
  createSession,
  createUsuarioSchema,
  criarContratoSchema,
  criarPropostaSchema,
  deleteUsuarioSchema,
  destroySession,
  editarMensagemSchema,
  enviarEmailTemplate,
  enviarTeste,
  gerarComIASchema,
  gerarPautaSchema,
  gerarPreview,
  gerirParticipanteSchema,
  getUserFromSession,
  hasRoleLevel,
  iniciarChamadoSchema,
  initRealtime,
  inviteUsuarioSchema,
  isAiEnabled,
  isProd,
  listCategoriasSchema,
  listContasSchema,
  listEventosSchema,
  listMeus,
  listNotificacoes,
  listPorCliente,
  listPorLead,
  listTodos,
  listarPreferenciasEmail,
  listarTemplates,
  loginSchema,
  marcarPagaSchema,
  markAllRead,
  markRead,
  melhorarComIASchema,
  mensagemIdSchema,
  moveCardSchema,
  moveLeadSchema,
  notificar,
  notificationService,
  novaOportunidadeSchema,
  portalAbrirChamadoSchema,
  portalEnviarChamadoSchema,
  portalMeusDadosSchema,
  prisma,
  redefinirSenhaSchema,
  renomearGrupoSchema,
  resetarTemplate,
  responderPropostaSchema,
  resumirReuniaoSchema,
  resumoAgendaSchema,
  resumoEnviados,
  salvarRespostaSchema,
  sendMensagemSchema,
  setAtivoClienteSchema,
  setChamadoAssuntoSchema,
  setChamadoPrioridadeSchema,
  setChamadoResponsavelSchema,
  setChamadoStatusSchema,
  setParticipantesSchema,
  setPreferenciaEmail,
  setRoteiroSchema,
  setStatusDocumentoSchema,
  solicitarResetSchema,
  solicitarServicosSchema,
  src_exports,
  startIndividualSchema,
  statusDocumentoEnum,
  togglePreferenciaSchema,
  updateCampoSchema,
  updateCardSchema,
  updateCategoriaSchema,
  updateClienteSchema,
  updateContaSchema,
  updateConteudoSchema,
  updateEventoSchema,
  updateFormularioSchema,
  updateLeadSchema,
  updateModeloSchema,
  updateOrigemSchema,
  updateProfileSchema,
  updateProjetoSchema,
  updateRequisitoSchema,
  updateServicoPassoSchema,
  updateServicoSchema,
  updateUsuarioSchema
} from "./chunk-RQVINKOG.js";

// src/env.ts
import { config as loadEnv } from "dotenv";
import { resolve } from "path";
loadEnv({ path: resolve(process.cwd(), ".env") });
loadEnv({ path: resolve(process.cwd(), "../../.env") });

// src/server.ts
import Fastify from "fastify";
import cookie from "@fastify/cookie";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import fastifyStatic from "@fastify/static";
import { fastifyTRPCPlugin } from "@trpc/server/adapters/fastify";
import { resolve as resolve2, dirname } from "path";
import { fileURLToPath } from "url";
import { existsSync } from "fs";

// src/trpc/trpc.ts
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({ transformer: superjson });
var router = t.router;
var middleware = t.middleware;
var timed = t.procedure.use(async ({ path, next }) => {
  const start = Date.now();
  const result = await next();
  recordCall(path, result.ok, Date.now() - start);
  return result;
});
var publicProcedure = timed;
var isAuthed = middleware(({ ctx, next }) => {
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: "N\xE3o autenticado" });
  return next({ ctx: { user: ctx.user } });
});
var protectedProcedure = timed.use(isAuthed);
function requireRole(min) {
  return middleware(({ ctx, next }) => {
    if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: "N\xE3o autenticado" });
    if (!hasRoleLevel(ctx.user.role, min)) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Sem permiss\xE3o" });
    }
    return next({ ctx: { user: ctx.user } });
  });
}
var funcionarioProcedure = timed.use(requireRole("FUNCIONARIO"));
var adminProcedure = timed.use(requireRole("ADMIN"));
var rootProcedure = timed.use(requireRole("ROOT"));
var portalProcedure = timed.use(
  middleware(({ ctx, next }) => {
    if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: "N\xE3o autenticado" });
    if (ctx.user.role !== "CLIENTE" || !ctx.user.clienteId) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito ao Portal do Cliente" });
    }
    return next({ ctx: { user: ctx.user, clienteId: ctx.user.clienteId } });
  })
);

// src/modules/auth/auth.router.ts
import { z } from "zod";

// src/modules/auth/auth.service.ts
import { TRPCError as TRPCError2 } from "@trpc/server";
var RESET_TTL_MS = 60 * 60 * 1e3;
function toSessionUser(u) {
  return {
    id: u.id,
    nome: u.nome,
    email: u.email,
    role: u.role,
    avatarUrl: u.avatarUrl,
    clienteId: u.clienteId
  };
}
var CREDENCIAIS_INVALIDAS = new TRPCError2({
  code: "UNAUTHORIZED",
  message: "E-mail ou senha incorretos"
});
var MUITAS_TENTATIVAS = new TRPCError2({
  code: "TOO_MANY_REQUESTS",
  message: "Muitas tentativas de login. Aguarde alguns minutos e tente novamente."
});
var MAX_TENTATIVAS = 8;
var JANELA_MS = 15 * 60 * 1e3;
var tentativas = /* @__PURE__ */ new Map();
function chaveLogin(ip, email) {
  return `${ip ?? "?"}:${email.trim().toLowerCase()}`;
}
function loginBloqueado(chave) {
  const reg = tentativas.get(chave);
  if (!reg) return false;
  if (Date.now() >= reg.ate) {
    tentativas.delete(chave);
    return false;
  }
  return reg.count >= MAX_TENTATIVAS;
}
function registrarFalha(chave) {
  const agora = Date.now();
  const reg = tentativas.get(chave);
  if (!reg || agora >= reg.ate) tentativas.set(chave, { count: 1, ate: agora + JANELA_MS });
  else reg.count += 1;
}
async function registrarTentativaFalha(email, motivo, userAgent) {
  try {
    await prisma.activityLog.create({
      data: {
        acao: "login.falhou",
        entidadeTipo: "auth",
        dados: { email, motivo, navegador: userAgent?.slice(0, 160) ?? null }
      }
    });
  } catch {
  }
}
async function registrarBloqueioCliente(email, motivo, userAgent) {
  try {
    await prisma.activityLog.create({
      data: {
        acao: "login.bloqueado_no_navegador",
        entidadeTipo: "auth",
        dados: { email, motivo, navegador: userAgent?.slice(0, 160) ?? null }
      }
    });
  } catch {
  }
}
async function login(input, userAgent, ip) {
  const chave = chaveLogin(ip, input.email);
  if (loginBloqueado(chave)) throw MUITAS_TENTATIVAS;
  const user = await prisma.user.findUnique({ where: { email: input.email } });
  if (!user || !user.ativo || user.deletedAt || !user.passwordHash) {
    registrarFalha(chave);
    await registrarTentativaFalha(
      input.email,
      !user ? "conta inexistente" : !user.ativo ? "conta inativa" : user.deletedAt ? "conta removida" : "convite n\xE3o aceito (sem senha)",
      userAgent
    );
    throw CREDENCIAIS_INVALIDAS;
  }
  const ok = await verifyPassword(user.passwordHash, input.password);
  if (!ok) {
    registrarFalha(chave);
    await registrarTentativaFalha(input.email, "senha n\xE3o confere", userAgent);
    throw CREDENCIAIS_INVALIDAS;
  }
  tentativas.delete(chave);
  if (await precisaRehash(user.passwordHash)) {
    const novo = await hashPassword(input.password);
    await prisma.user.update({ where: { id: user.id }, data: { passwordHash: novo } }).catch(() => {
    });
  }
  const sid = await createSession(user.id, userAgent, ip);
  await prisma.activityLog.create({ data: { userId: user.id, acao: "login" } });
  return { sid, user: toSessionUser(user) };
}
async function updateProfile(userId, nome) {
  const user = await prisma.user.update({ where: { id: userId }, data: { nome: nome.trim() } });
  return toSessionUser(user);
}
async function removerAvatar(userId) {
  const atual = await prisma.user.findUnique({ where: { id: userId }, select: { avatarUrl: true } });
  if (atual?.avatarUrl) await removerArquivo(atual.avatarUrl);
  const user = await prisma.user.update({ where: { id: userId }, data: { avatarUrl: null } });
  return toSessionUser(user);
}
async function changePassword(userId, senhaAtual, novaSenha, currentSid) {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (!user.passwordHash) {
    throw new TRPCError2({ code: "BAD_REQUEST", message: "Conta sem senha definida." });
  }
  const ok = await verifyPassword(user.passwordHash, senhaAtual);
  if (!ok) throw new TRPCError2({ code: "BAD_REQUEST", message: "A senha atual est\xE1 incorreta." });
  await prisma.user.update({
    where: { id: userId },
    data: { passwordHash: await hashPassword(novaSenha) }
  });
  await prisma.session.deleteMany({
    where: { userId, ...currentSid ? { NOT: { id: currentSid } } : {} }
  });
  return { ok: true };
}
async function validarConvite(token) {
  const info = await inspecionarToken(token, "CONVITE");
  return info ? { valido: true, nome: info.nome, email: info.email } : { valido: false };
}
async function aceitarConvite(token, novaSenha, userAgent, ip) {
  const userId = await consumirToken(token, "CONVITE");
  if (!userId) {
    throw new TRPCError2({ code: "BAD_REQUEST", message: "Convite inv\xE1lido ou expirado." });
  }
  const user = await prisma.user.update({
    where: { id: userId },
    data: { passwordHash: await hashPassword(novaSenha), ativo: true }
  });
  const sid = await createSession(user.id, userAgent, ip);
  await prisma.activityLog.create({ data: { userId: user.id, acao: "convite_aceito" } });
  void enviarBoasVindas(user.nome, user.email).catch(() => {
  });
  if (user.role === "CLIENTE" && user.clienteId) {
    void avancarLeadPorClienteAuto(user.clienteId, "qualificacao", "Lead ativou o acesso ao Portal").catch(() => {
    });
  }
  return { sid, user: toSessionUser(user) };
}
async function enviarBoasVindas(nome, email) {
  await enviarEmailTemplate("boas_vindas", email, { nome, link: config.WEB_ORIGIN });
}
async function solicitarReset(email) {
  const user = await prisma.user.findFirst({
    where: { email: email.trim().toLowerCase(), ativo: true, deletedAt: null, passwordHash: { not: null } },
    select: { id: true, nome: true, email: true }
  });
  if (user) {
    const token = await criarToken(user.id, "RESET", RESET_TTL_MS);
    const url = `${config.WEB_ORIGIN}/redefinir-senha?token=${token}`;
    const { enviado } = await enviarEmailTemplate("reset_senha", user.email, { nome: user.nome, link: url });
    if (!enviado) console.info(`[reset:dev] link para ${user.email}: ${url}`);
  }
  return { ok: true };
}
async function validarReset(token) {
  const info = await inspecionarToken(token, "RESET");
  return info ? { valido: true, nome: info.nome, email: info.email } : { valido: false };
}
async function redefinirSenha(token, novaSenha, userAgent, ip) {
  const userId = await consumirToken(token, "RESET");
  if (!userId) {
    throw new TRPCError2({ code: "BAD_REQUEST", message: "Link inv\xE1lido ou expirado." });
  }
  const user = await prisma.user.update({
    where: { id: userId },
    data: { passwordHash: await hashPassword(novaSenha), ativo: true }
  });
  await prisma.session.deleteMany({ where: { userId } });
  const sid = await createSession(user.id, userAgent, ip);
  await prisma.activityLog.create({ data: { userId: user.id, acao: "senha_redefinida" } });
  return { sid, user: toSessionUser(user) };
}

// src/modules/auth/auth.router.ts
var cookieOptions = {
  httpOnly: true,
  secure: isProd,
  sameSite: "lax",
  path: "/",
  signed: true,
  maxAge: SESSION_TTL_SECONDS
};
var authRouter = router({
  /** Login por e-mail/senha. Define o cookie de sessão httpOnly. */
  login: publicProcedure.input(loginSchema).mutation(async ({ ctx, input }) => {
    const userAgent = ctx.req.headers["user-agent"];
    const { sid, user } = await login(input, userAgent, ctx.req.ip);
    ctx.res.setCookie(SESSION_COOKIE, sid, cookieOptions);
    return user;
  }),
  /**
   * Registra um login que o NAVEGADOR barrou antes de sair (validação do formulário).
   *
   * Ponto cego que custou dois diagnósticos errados: quando o campo não passa na validação do
   * cliente, nenhuma requisição chega ao servidor — logo, não havia registro nenhum e "não
   * consigo entrar" ficava indepurável. Agora fica.
   *
   * Só grava e-mail e motivo; NUNCA a senha. Protegido pelo rate-limit global do servidor.
   */
  registrarBloqueioNoNavegador: publicProcedure.input(z.object({ email: z.string().max(200), motivo: z.string().max(200) })).mutation(async ({ ctx, input }) => {
    await registrarBloqueioCliente(input.email, input.motivo, ctx.req.headers["user-agent"]);
    return { ok: true };
  }),
  /** Encerra a sessão atual. */
  logout: publicProcedure.mutation(async ({ ctx }) => {
    const raw = ctx.req.cookies[SESSION_COOKIE];
    const unsigned = raw ? ctx.req.unsignCookie(raw) : null;
    await destroySession(unsigned?.valid ? unsigned.value ?? void 0 : void 0);
    ctx.res.clearCookie(SESSION_COOKIE, { path: "/" });
    return { ok: true };
  }),
  /** Usuário autenticado atual (ou null). Base do "estou logado?" no front. */
  me: publicProcedure.query(({ ctx }) => ctx.user),
  /** Verifica um token de convite (para a tela de definir senha). Público. */
  validarConvite: publicProcedure.input(z.object({ token: z.string().min(1) })).query(({ input }) => validarConvite(input.token)),
  /** Aceita o convite: define a senha e já autentica (cria o cookie de sessão). Público. */
  aceitarConvite: publicProcedure.input(aceitarConviteSchema).mutation(async ({ ctx, input }) => {
    const userAgent = ctx.req.headers["user-agent"];
    const { sid, user } = await aceitarConvite(input.token, input.novaSenha, userAgent, ctx.req.ip);
    ctx.res.setCookie(SESSION_COOKIE, sid, cookieOptions);
    return user;
  }),
  /** Solicita redefinição de senha. Sempre responde ok (anti-enumeração). Público. */
  solicitarReset: publicProcedure.input(solicitarResetSchema).mutation(({ input }) => solicitarReset(input.email)),
  /** Verifica um token de redefinição (para a tela). Público. */
  validarReset: publicProcedure.input(z.object({ token: z.string().min(1) })).query(({ input }) => validarReset(input.token)),
  /** Redefine a senha via token e já autentica (cria o cookie). Público. */
  redefinirSenha: publicProcedure.input(redefinirSenhaSchema).mutation(async ({ ctx, input }) => {
    const userAgent = ctx.req.headers["user-agent"];
    const { sid, user } = await redefinirSenha(input.token, input.novaSenha, userAgent, ctx.req.ip);
    ctx.res.setCookie(SESSION_COOKIE, sid, cookieOptions);
    return user;
  }),
  /** Edita o próprio perfil (nome). */
  updateProfile: protectedProcedure.input(updateProfileSchema).mutation(({ ctx, input }) => updateProfile(ctx.user.id, input.nome)),
  /** Remove a própria foto de perfil. */
  removerAvatar: protectedProcedure.mutation(({ ctx }) => removerAvatar(ctx.user.id)),
  /** Troca a própria senha (mantém a sessão atual, revoga as demais). */
  changePassword: protectedProcedure.input(changePasswordSchema).mutation(({ ctx, input }) => {
    const raw = ctx.req.cookies[SESSION_COOKIE];
    const unsigned = raw ? ctx.req.unsignCookie(raw) : null;
    const currentSid = unsigned?.valid ? unsigned.value ?? void 0 : void 0;
    return changePassword(ctx.user.id, input.senhaAtual, input.novaSenha, currentSid);
  })
});

// src/modules/clientes/clientes.router.ts
import { z as z2 } from "zod";

// src/modules/clientes/clientes.service.ts
import { TRPCError as TRPCError3 } from "@trpc/server";
var clean = (v) => {
  const t2 = v?.trim();
  return t2 ? t2 : null;
};
async function listClientes(search) {
  const s = search?.trim();
  const clientes = await prisma.cliente.findMany({
    where: {
      deletedAt: null,
      // A página Clientes lista só CLIENTES de verdade (ativos/inativos). Prospects,
      // negociação e perdidos são leads — vivem no Funil de vendas, não aqui.
      situacaoComercial: { in: [...SITUACOES_CLIENTE] },
      ...s ? {
        OR: [
          { nome: { contains: s } },
          { email: { contains: s } },
          { documento: { contains: s } }
        ]
      } : {}
    },
    orderBy: { nome: "asc" },
    select: {
      id: true,
      nome: true,
      tipo: true,
      situacaoComercial: true,
      email: true,
      telefone: true,
      documento: true,
      responsavelId: true,
      createdAt: true,
      responsavel: { select: { nome: true } },
      _count: {
        select: {
          contatos: true,
          projetos: { where: { deletedAt: null } },
          // "Portal ativo" = já existe um acesso de cliente que consegue entrar (senha definida).
          usuariosPortal: { where: { role: "CLIENTE", ativo: true, passwordHash: { not: null } } },
          // "No funil" = tem oportunidade aberta (upsell em andamento) ligada a este cliente.
          leadsPortal: { where: { deletedAt: null, convertidoEmClienteId: null, perdidoEm: null } },
          // Serviços contratados ativos (o que o cliente tem hoje).
          servicosContratados: { where: { status: "ATIVO" } }
        }
      }
    }
  });
  if (clientes.length === 0) return [];
  const ids = clientes.map((c) => c.id);
  const reunioes = await prisma.evento.groupBy({
    by: ["clienteId"],
    where: {
      clienteId: { in: ids },
      deletedAt: null,
      inicio: { gte: /* @__PURE__ */ new Date() },
      escopo: "EMPRESA",
      tipo: { in: ["REUNIAO", "COMPROMISSO"] }
    },
    _min: { inicio: true }
  });
  const proxMap = new Map(reunioes.map((r) => [r.clienteId, r._min.inicio]));
  return clientes.map((c) => ({
    ...c,
    proximaReuniao: proxMap.get(c.id) ?? null,
    emFunil: c._count.leadsPortal > 0
  }));
}
async function resumoClientes() {
  const [ativos, inativos, portaisAtivos] = await Promise.all([
    prisma.cliente.count({ where: { deletedAt: null, situacaoComercial: "ATIVO" } }),
    prisma.cliente.count({ where: { deletedAt: null, situacaoComercial: "INATIVO" } }),
    prisma.user.count({ where: { role: "CLIENTE", ativo: true, deletedAt: null, passwordHash: { not: null } } })
  ]);
  return { total: ativos + inativos, ativos, inativos, portaisAtivos };
}
async function convidarPortalCliente(ator, clienteId) {
  const cliente = await prisma.cliente.findFirst({ where: { id: clienteId, deletedAt: null }, select: { id: true, nome: true, email: true } });
  if (!cliente) throw new TRPCError3({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado" });
  if (!cliente.email) {
    throw new TRPCError3({ code: "BAD_REQUEST", message: "Cadastre um e-mail no cliente para enviar o acesso ao Portal." });
  }
  const jaTem = await prisma.user.findFirst({ where: { clienteId, role: "CLIENTE", deletedAt: null } });
  if (jaTem) {
    if (jaTem.passwordHash === null) {
      const r = await reenviarConvite(ator.role, jaTem.id);
      return { email: r.email, conviteUrl: r.conviteUrl, emailEnviado: r.emailEnviado };
    }
    throw new TRPCError3({ code: "CONFLICT", message: "Este cliente j\xE1 tem acesso ativo ao Portal." });
  }
  const { usuario, conviteUrl, emailEnviado } = await convidarUsuario(ator.role, {
    nome: cliente.nome,
    email: cliente.email,
    role: "CLIENTE",
    clienteId
  });
  return { email: usuario.email, conviteUrl, emailEnviado };
}
async function setAtivoCliente(id, ativo, userId) {
  const cliente = await prisma.cliente.findFirst({ where: { id, deletedAt: null }, select: { situacaoComercial: true } });
  if (!cliente) throw new TRPCError3({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado" });
  if (!SITUACOES_CLIENTE.includes(cliente.situacaoComercial)) {
    throw new TRPCError3({ code: "BAD_REQUEST", message: "S\xF3 \xE9 poss\xEDvel ativar/desativar um cliente. Prospects s\xE3o geridos no Funil." });
  }
  await prisma.cliente.update({ where: { id }, data: { situacaoComercial: ativo ? "ATIVO" : "INATIVO" } });
  await prisma.activityLog.create({
    data: { userId, acao: ativo ? "cliente.ativado" : "cliente.desativado", entidadeTipo: "cliente", entidadeId: id }
  });
  return { ok: true };
}
async function relacionadosCliente(clienteId, isAdmin) {
  const agora = /* @__PURE__ */ new Date();
  const [projetos, documentos, eventos, contas, leadsOrigem] = await Promise.all([
    prisma.projeto.findMany({
      where: { clienteId, deletedAt: null },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        nome: true,
        status: true,
        // Status dos cartões para calcular o progresso do projeto na ficha.
        cards: { where: { deletedAt: null }, select: { status: true } },
        _count: { select: { cards: { where: { deletedAt: null } } } }
      }
    }),
    prisma.documento.findMany({
      where: { clienteId, deletedAt: null },
      orderBy: { updatedAt: "desc" },
      take: 8,
      // Campos para a situação coerente (fluxo + aceite + assinatura) na ficha.
      select: {
        id: true,
        titulo: true,
        status: true,
        propostaStatus: true,
        assinaturaSolicitadaEm: true,
        assinadoEm: true,
        modelo: { select: { tipo: true } }
      }
    }),
    prisma.evento.findMany({
      where: { clienteId, deletedAt: null, inicio: { gte: agora } },
      orderBy: { inicio: "asc" },
      take: 5,
      select: { id: true, titulo: true, inicio: true, tipo: true, linkReuniao: true }
    }),
    isAdmin ? prisma.conta.findMany({
      where: { clienteId, deletedAt: null },
      orderBy: { vencimento: "asc" },
      take: 10,
      select: {
        id: true,
        descricao: true,
        tipo: true,
        valor: true,
        vencimento: true,
        pago: true,
        recorrencia: true
      }
    }) : Promise.resolve(null),
    // Origem comercial: o(s) lead(s) que originaram este cliente (convertido ou ligado ao
    // Portal) — mostra de onde veio, o que pediu e o histórico comercial.
    prisma.lead.findMany({
      where: { deletedAt: null, OR: [{ convertidoEmClienteId: clienteId }, { clienteId }] },
      orderBy: { createdAt: "asc" },
      select: {
        id: true,
        origem: true,
        rastreio: true,
        valorEstimado: true,
        createdAt: true,
        convertidoEmClienteId: true,
        convertidoEm: true,
        perdidoEm: true,
        motivoPerda: true,
        pipelineStage: { select: { nome: true } },
        servicos: { select: { id: true, nome: true }, orderBy: { ordem: "asc" } }
      }
    })
  ]);
  return {
    projetos,
    documentos,
    eventos,
    contas: contas ? contas.map((c) => ({ ...c, valor: c.valor.toNumber() })) : null,
    origem: leadsOrigem.map((l) => ({
      id: l.id,
      origem: l.origem,
      rastreio: l.rastreio,
      valorEstimado: l.valorEstimado,
      createdAt: l.createdAt,
      convertidoEm: l.convertidoEm,
      servicos: l.servicos,
      etapa: l.pipelineStage.nome,
      status: l.convertidoEmClienteId ? "convertido" : l.perdidoEm ? "perdido" : "em_andamento",
      motivoPerda: l.motivoPerda
    }))
  };
}
async function getCliente(id) {
  const cliente = await prisma.cliente.findFirst({
    where: { id, deletedAt: null },
    include: {
      contatos: { orderBy: [{ principal: "desc" }, { nome: "asc" }] },
      responsavel: { select: { nome: true } },
      _count: {
        select: {
          // acesso de Portal já ativo (senha definida) x convite pendente (sem senha).
          usuariosPortal: { where: { role: "CLIENTE", ativo: true, passwordHash: { not: null } } }
        }
      }
    }
  });
  if (!cliente) throw new TRPCError3({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado" });
  const notas = await prisma.nota.findMany({
    where: { entidadeTipo: "cliente", entidadeId: id },
    include: { autor: { select: { nome: true } } },
    orderBy: { createdAt: "desc" }
  });
  return { ...cliente, notas, portalAtivo: cliente._count.usuariosPortal > 0 };
}
async function createCliente(input, userId, enviarAcessoPortal = false) {
  const cliente = await prisma.cliente.create({
    data: {
      nome: input.nome.trim(),
      tipo: input.tipo,
      documento: clean(input.documento),
      email: clean(input.email),
      telefone: clean(input.telefone),
      observacoes: clean(input.observacoes),
      responsavelId: input.responsavelId || userId
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "cliente.criado", entidadeTipo: "cliente", entidadeId: cliente.id }
  });
  if (enviarAcessoPortal && cliente.email) {
    await garantirAcessoPortal(cliente.id, cliente.nome, cliente.email).catch(() => {
    });
  }
  return cliente;
}
async function updateCliente(input) {
  const { id, ...rest } = input;
  const data = {};
  if (rest.nome !== void 0) data.nome = rest.nome.trim();
  if (rest.tipo !== void 0) data.tipo = rest.tipo;
  if (rest.documento !== void 0) data.documento = clean(rest.documento);
  if (rest.email !== void 0) data.email = clean(rest.email);
  if (rest.telefone !== void 0) data.telefone = clean(rest.telefone);
  if (rest.observacoes !== void 0) data.observacoes = clean(rest.observacoes);
  if (rest.responsavelId !== void 0) data.responsavelId = rest.responsavelId || null;
  return prisma.cliente.update({ where: { id }, data });
}
async function removeCliente(id, userId) {
  await prisma.cliente.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  await prisma.lead.updateMany({
    where: { clienteId: id, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
    data: { deletedAt: /* @__PURE__ */ new Date() }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "cliente.removido", entidadeTipo: "cliente", entidadeId: id }
  });
  return { ok: true };
}
async function excluirDefinitivoCliente(id, userId) {
  const cliente = await prisma.cliente.findUnique({ where: { id }, select: { id: true, nome: true } });
  if (!cliente) throw new TRPCError3({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado" });
  const [projetos, documentos, contas, servicos, eventos, acessos, arquivosCli, conversas, respostas, leads] = await Promise.all([
    prisma.projeto.count({ where: { clienteId: id } }),
    prisma.documento.count({ where: { clienteId: id } }),
    prisma.conta.count({ where: { clienteId: id } }),
    prisma.clienteServico.count({ where: { clienteId: id } }),
    prisma.evento.count({ where: { clienteId: id } }),
    prisma.user.count({ where: { clienteId: id } }),
    prisma.arquivo.count({ where: { clienteId: id } }),
    prisma.conversa.count({ where: { clienteId: id } }),
    prisma.formularioResposta.count({ where: { clienteId: id } }),
    prisma.lead.count({ where: { OR: [{ clienteId: id }, { convertidoEmClienteId: id }] } })
  ]);
  const vinculos = {
    projetos,
    documentos,
    financeiro: contas,
    servi\u00E7os: servicos,
    agenda: eventos,
    "acessos ao Portal": acessos,
    arquivos: arquivosCli,
    conversas,
    "respostas de formul\xE1rio": respostas,
    leads
  };
  const bloqueios = Object.entries(vinculos).filter(([, n]) => n > 0);
  if (bloqueios.length) {
    const detalhe = bloqueios.map(([k, n]) => `${k}: ${n}`).join(", ");
    throw new TRPCError3({
      code: "BAD_REQUEST",
      message: `Exclus\xE3o definitiva bloqueada \u2014 o cliente tem v\xEDnculos (${detalhe}). Arquive o cliente para preservar o hist\xF3rico.`
    });
  }
  await prisma.$transaction([
    prisma.contato.deleteMany({ where: { clienteId: id } }),
    prisma.cliente.delete({ where: { id } })
  ]);
  await prisma.activityLog.create({
    data: { userId, acao: "cliente.excluido_definitivo", entidadeTipo: "cliente", entidadeId: id }
  });
  return { ok: true };
}
function addContato(input) {
  return prisma.contato.create({
    data: {
      clienteId: input.clienteId,
      nome: input.nome.trim(),
      cargo: clean(input.cargo),
      email: clean(input.email),
      telefone: clean(input.telefone),
      principal: input.principal
    }
  });
}
async function removeContato(id) {
  await prisma.contato.delete({ where: { id } });
  return { ok: true };
}
function addNota(input, userId) {
  return prisma.nota.create({
    data: {
      autorId: userId,
      entidadeTipo: input.entidadeTipo,
      entidadeId: input.entidadeId,
      conteudo: input.conteudo.trim()
    },
    include: { autor: { select: { nome: true } } }
  });
}
function arquivarNota(notaId, userId, arquivar2) {
  return prisma.nota.update({
    where: { id: notaId },
    data: arquivar2 ? { arquivadaEm: /* @__PURE__ */ new Date(), arquivadaPorId: userId } : { arquivadaEm: null, arquivadaPorId: null },
    include: { autor: { select: { nome: true } } }
  });
}

// src/modules/mensagens/mensagens.service.ts
import { TRPCError as TRPCError4 } from "@trpc/server";
async function ensureParticipant(conversaId, userId) {
  const p = await prisma.conversaParticipante.findUnique({ where: { conversaId_userId: { conversaId, userId } } });
  if (!p) throw new TRPCError4({ code: "FORBIDDEN", message: "Voc\xEA n\xE3o participa desta conversa" });
  return p;
}
async function ehAdmin(userId) {
  const u = await prisma.user.findUnique({ where: { id: userId }, select: { role: true } });
  return u?.role === "ADMIN" || u?.role === "ROOT";
}
function listUsuarios2(userId) {
  return prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { not: "CLIENTE" }, id: { not: userId } },
    select: { id: true, nome: true, role: true, avatarUrl: true },
    orderBy: { nome: "asc" }
  });
}
function listClientesParaChamado(busca) {
  const q = busca?.trim();
  return prisma.cliente.findMany({
    where: { deletedAt: null, ...q ? { nome: { contains: q } } : {} },
    select: { id: true, nome: true, situacaoComercial: true },
    orderBy: { nome: "asc" },
    take: 50
  });
}
async function contarNaoLidas(conversaId, userId, ultimaLeituraEm) {
  return prisma.mensagem.count({
    where: { conversaId, deletedAt: null, autorId: { not: userId }, ...ultimaLeituraEm ? { createdAt: { gt: ultimaLeituraEm } } : {} }
  });
}
async function listConversas(userId, arquivadas = false) {
  const parts = await prisma.conversaParticipante.findMany({
    where: {
      userId,
      ocultoEm: null,
      ...arquivadas ? { NOT: { arquivadoEm: null } } : { arquivadoEm: null },
      conversa: { deletedAt: null }
    },
    include: {
      conversa: {
        include: {
          participantes: { include: { user: { select: { id: true, nome: true, role: true, avatarUrl: true } } } },
          mensagens: { where: { deletedAt: null }, orderBy: { createdAt: "desc" }, take: 1 },
          cliente: { select: { id: true, nome: true } },
          responsavel: { select: { id: true, nome: true } }
        }
      }
    }
  });
  const clienteIds = parts.map((p) => p.conversa.clienteId).filter((x) => !!x);
  const leadsAtivos = clienteIds.length ? await prisma.lead.findMany({ where: { clienteId: { in: clienteIds }, convertidoEmClienteId: null, perdidoEm: null, deletedAt: null }, select: { clienteId: true } }) : [];
  const ehLead = new Set(leadsAtivos.map((l) => l.clienteId));
  const result = [];
  for (const p of parts) {
    const conv = p.conversa;
    let categoria;
    let nome;
    if (conv.tipo === "GRUPO") {
      categoria = "grupo";
      nome = conv.nome ?? "Grupo";
    } else if (conv.tipo === "CLIENTE") {
      categoria = conv.clienteId && ehLead.has(conv.clienteId) ? "lead" : "cliente";
      nome = conv.cliente?.nome ?? "Cliente";
    } else {
      categoria = "direta";
      nome = conv.participantes.find((pp) => pp.userId !== userId)?.user.nome ?? "Conversa";
    }
    let avatarUserId = null;
    let avatarUrl = null;
    if (conv.tipo === "INDIVIDUAL") {
      const o = conv.participantes.find((pp) => pp.userId !== userId)?.user;
      if (o?.avatarUrl) {
        avatarUserId = o.id;
        avatarUrl = o.avatarUrl;
      }
    } else if (conv.tipo === "CLIENTE") {
      const cli = conv.participantes.find((pp) => pp.user.role === "CLIENTE" && pp.user.avatarUrl)?.user;
      if (cli) {
        avatarUserId = cli.id;
        avatarUrl = cli.avatarUrl;
      }
    }
    const ultima = conv.mensagens[0] ?? null;
    result.push({
      id: conv.id,
      tipo: conv.tipo,
      categoria,
      nome,
      numero: conv.numero,
      assunto: conv.assunto,
      status: conv.status,
      prioridade: conv.prioridade,
      resolvidoEm: conv.resolvidoEm,
      clienteId: conv.clienteId,
      responsavel: conv.responsavel,
      avatarUserId,
      avatarUrl,
      membros: conv.participantes.length,
      updatedAt: conv.updatedAt,
      ultimaMensagem: ultima ? { conteudo: ultima.conteudo, createdAt: ultima.createdAt } : null,
      naoLidas: await contarNaoLidas(conv.id, userId, p.ultimaLeituraEm),
      fixado: !!p.fixadoEm,
      silenciado: !!p.silenciadoEm,
      arquivado: !!p.arquivadoEm
    });
  }
  result.sort((a, b) => Number(b.fixado) - Number(a.fixado) || +new Date(b.updatedAt) - +new Date(a.updatedAt));
  return result;
}
async function getConversaInfo(conversaId, userId) {
  await ensureParticipant(conversaId, userId);
  const conv = await prisma.conversa.findUnique({
    where: { id: conversaId },
    include: {
      participantes: { include: { user: { select: { id: true, nome: true, role: true, avatarUrl: true } } } },
      cliente: { select: { id: true, nome: true } },
      responsavel: { select: { id: true, nome: true } }
    }
  });
  if (!conv) throw new TRPCError4({ code: "NOT_FOUND", message: "Conversa n\xE3o encontrada" });
  const admin = await ehAdmin(userId);
  return {
    id: conv.id,
    tipo: conv.tipo,
    nome: conv.nome,
    numero: conv.numero,
    assunto: conv.assunto,
    status: conv.status,
    prioridade: conv.prioridade,
    resolvidoEm: conv.resolvidoEm,
    clienteId: conv.clienteId,
    cliente: conv.cliente,
    responsavel: conv.responsavel,
    criadoPorId: conv.criadoPorId,
    podeGerir: conv.tipo === "GRUPO" && (conv.criadoPorId === userId || admin) || conv.tipo === "CLIENTE",
    ehAdmin: admin,
    participantes: conv.participantes.map((p) => ({ id: p.user.id, nome: p.user.nome, role: p.user.role, avatarUrl: p.user.avatarUrl })).sort((a, b) => a.nome.localeCompare(b.nome))
  };
}
async function startIndividual(userId, outroUserId) {
  if (outroUserId === userId) throw new TRPCError4({ code: "BAD_REQUEST", message: "N\xE3o \xE9 poss\xEDvel conversar consigo mesmo" });
  const existente = await prisma.conversa.findFirst({
    where: { tipo: "INDIVIDUAL", deletedAt: null, AND: [{ participantes: { some: { userId } } }, { participantes: { some: { userId: outroUserId } } }] }
  });
  if (existente) {
    await prisma.conversaParticipante.updateMany({ where: { conversaId: existente.id, userId }, data: { ocultoEm: null } });
    return existente;
  }
  return prisma.conversa.create({ data: { tipo: "INDIVIDUAL", participantes: { create: [{ userId }, { userId: outroUserId }] } } });
}
function createGrupo(userId, nome, participantIds) {
  const ids = Array.from(/* @__PURE__ */ new Set([userId, ...participantIds]));
  return prisma.conversa.create({ data: { tipo: "GRUPO", nome: nome.trim(), criadoPorId: userId, participantes: { create: ids.map((id) => ({ userId: id })) } } });
}
async function ensureGrupoGerivel(conversaId, userId) {
  const conv = await prisma.conversa.findUnique({ where: { id: conversaId }, select: { tipo: true, criadoPorId: true } });
  if (!conv || conv.tipo !== "GRUPO") throw new TRPCError4({ code: "BAD_REQUEST", message: "N\xE3o \xE9 um grupo" });
  await ensureParticipant(conversaId, userId);
  if (conv.criadoPorId !== userId && !await ehAdmin(userId)) {
    throw new TRPCError4({ code: "FORBIDDEN", message: "S\xF3 o criador do grupo ou um administrador pode gerenci\xE1-lo" });
  }
}
async function renomearGrupo(conversaId, userId, nome) {
  await ensureGrupoGerivel(conversaId, userId);
  return prisma.conversa.update({ where: { id: conversaId }, data: { nome: nome.trim() } });
}
async function addParticipantes(conversaId, userId, userIds) {
  await ensureGrupoGerivel(conversaId, userId);
  await prisma.conversaParticipante.createMany({ data: userIds.map((uid) => ({ conversaId, userId: uid })), skipDuplicates: true });
  await prisma.conversa.update({ where: { id: conversaId }, data: { updatedAt: /* @__PURE__ */ new Date() } });
  return { ok: true };
}
async function removerParticipante(conversaId, userId, alvoId) {
  await ensureGrupoGerivel(conversaId, userId);
  await prisma.conversaParticipante.deleteMany({ where: { conversaId, userId: alvoId } });
  return { ok: true };
}
async function sairDaConversa(conversaId, userId) {
  await ensureParticipant(conversaId, userId);
  await prisma.conversaParticipante.deleteMany({ where: { conversaId, userId } });
  return { ok: true };
}
async function apagarConversa(conversaId, userId) {
  await ensureParticipant(conversaId, userId);
  const conv = await prisma.conversa.findUnique({ where: { id: conversaId }, select: { tipo: true, criadoPorId: true } });
  if (!conv) throw new TRPCError4({ code: "NOT_FOUND", message: "Conversa n\xE3o encontrada" });
  const admin = await ehAdmin(userId);
  if (conv.tipo === "GRUPO" && (conv.criadoPorId === userId || admin)) {
    await prisma.conversa.update({ where: { id: conversaId }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  } else if (conv.tipo === "CLIENTE" && admin) {
    await prisma.conversa.update({ where: { id: conversaId }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  } else if (conv.tipo === "INDIVIDUAL") {
    await prisma.conversaParticipante.updateMany({ where: { conversaId, userId }, data: { ocultoEm: /* @__PURE__ */ new Date() } });
  } else {
    throw new TRPCError4({ code: "FORBIDDEN", message: "Voc\xEA n\xE3o pode apagar esta conversa" });
  }
  return { ok: true };
}
async function setPreferencia(conversaId, userId, campo, ligar) {
  await ensureParticipant(conversaId, userId);
  await prisma.conversaParticipante.updateMany({ where: { conversaId, userId }, data: { [campo]: ligar ? /* @__PURE__ */ new Date() : null } });
  return { ok: true };
}
var fixar = (c, u, l) => setPreferencia(c, u, "fixadoEm", l);
var silenciar = (c, u, l) => setPreferencia(c, u, "silenciadoEm", l);
var arquivar = (c, u, l) => setPreferencia(c, u, "arquivadoEm", l);
async function participantesDoCliente(clienteId, atorId) {
  const [cliente, portalUsers, admins] = await Promise.all([
    prisma.cliente.findUnique({ where: { id: clienteId }, select: { responsavelId: true } }),
    prisma.user.findMany({ where: { clienteId, role: "CLIENTE", ativo: true, deletedAt: null }, select: { id: true } }),
    prisma.user.findMany({ where: { role: { in: ["ADMIN", "ROOT"] }, ativo: true, deletedAt: null }, select: { id: true } })
  ]);
  const ids = /* @__PURE__ */ new Set([...portalUsers.map((u) => u.id), ...admins.map((a) => a.id)]);
  if (cliente?.responsavelId) ids.add(cliente.responsavelId);
  if (atorId) ids.add(atorId);
  return [...ids];
}
async function criarChamado(atorId, clienteId, assunto, prioridade = "NORMAL") {
  const ids = await participantesDoCliente(clienteId, atorId);
  const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { responsavelId: true } });
  const agg = await prisma.conversa.aggregate({ _max: { numero: true } });
  const numero = (agg._max.numero ?? 1002) + 1;
  return prisma.conversa.create({
    data: {
      tipo: "CLIENTE",
      clienteId,
      numero,
      assunto: assunto.trim(),
      prioridade,
      status: "ABERTO",
      responsavelId: cliente?.responsavelId ?? null,
      criadoPorId: atorId ?? null,
      participantes: { create: ids.map((id) => ({ userId: id })) }
    },
    select: { id: true, numero: true }
  });
}
async function iniciarChamado(atorId, clienteId, assunto, prioridade) {
  return criarChamado(atorId, clienteId, assunto, prioridade ?? "NORMAL");
}
async function listChamadosDoCliente(clienteId, userId) {
  const chamados = await prisma.conversa.findMany({
    where: { tipo: "CLIENTE", clienteId, deletedAt: null },
    include: { mensagens: { where: { deletedAt: null }, orderBy: { createdAt: "desc" }, take: 1 }, responsavel: { select: { id: true, nome: true } } },
    orderBy: [{ status: "asc" }, { updatedAt: "desc" }]
  });
  const out = [];
  for (const c of chamados) {
    let naoLidas = 0;
    if (userId) {
      const part = await prisma.conversaParticipante.findUnique({ where: { conversaId_userId: { conversaId: c.id, userId } }, select: { ultimaLeituraEm: true } });
      naoLidas = part ? await contarNaoLidas(c.id, userId, part.ultimaLeituraEm) : 0;
    }
    out.push({
      id: c.id,
      numero: c.numero,
      assunto: c.assunto,
      status: c.status,
      prioridade: c.prioridade,
      resolvidoEm: c.resolvidoEm,
      updatedAt: c.updatedAt,
      responsavel: c.responsavel,
      ultimaMensagem: c.mensagens[0] ? { conteudo: c.mensagens[0].conteudo, createdAt: c.mensagens[0].createdAt } : null,
      naoLidas
    });
  }
  return out;
}
async function ensureChamado(conversaId, userId) {
  await ensureParticipant(conversaId, userId);
  const conv = await prisma.conversa.findUnique({ where: { id: conversaId }, select: { tipo: true } });
  if (conv?.tipo !== "CLIENTE") throw new TRPCError4({ code: "BAD_REQUEST", message: "N\xE3o \xE9 um chamado" });
}
async function setChamadoStatus(conversaId, userId, status) {
  await ensureChamado(conversaId, userId);
  const conv = await prisma.conversa.update({ where: { id: conversaId }, data: { status, resolvidoEm: status === "RESOLVIDO" ? /* @__PURE__ */ new Date() : null } });
  await pushParaParticipantes(conversaId, "mensagem", { conversaId });
  return conv;
}
var resolverChamado = (c, u) => setChamadoStatus(c, u, "RESOLVIDO");
var reabrirChamado = (c, u) => setChamadoStatus(c, u, "ABERTO");
async function setChamadoResponsavel(conversaId, userId, responsavelId) {
  await ensureChamado(conversaId, userId);
  if (responsavelId) await prisma.conversaParticipante.createMany({ data: [{ conversaId, userId: responsavelId }], skipDuplicates: true });
  return prisma.conversa.update({ where: { id: conversaId }, data: { responsavelId } });
}
async function setChamadoAssunto(conversaId, userId, assunto) {
  await ensureChamado(conversaId, userId);
  return prisma.conversa.update({ where: { id: conversaId }, data: { assunto: assunto.trim() } });
}
async function setChamadoPrioridade(conversaId, userId, prioridade) {
  await ensureChamado(conversaId, userId);
  return prisma.conversa.update({ where: { id: conversaId }, data: { prioridade } });
}
async function listMensagens(conversaId, userId) {
  await ensureParticipant(conversaId, userId);
  const msgs = await prisma.mensagem.findMany({
    where: { conversaId },
    orderBy: { createdAt: "asc" },
    take: 400,
    include: { autor: { select: { id: true, nome: true, role: true, avatarUrl: true } } }
  });
  return msgs.map((m) => ({ ...m, conteudo: m.deletedAt ? "" : m.conteudo }));
}
async function pushParaParticipantes(conversaId, evento, payload, exceto) {
  const parts = await prisma.conversaParticipante.findMany({ where: { conversaId }, select: { userId: true, user: { select: { role: true } } } });
  for (const p of parts) if (p.userId !== exceto) notificationService.emitToUser(p.userId, evento, payload);
  return parts;
}
async function sendMensagem(conversaId, conteudo, userId) {
  await ensureParticipant(conversaId, userId);
  const conv = await prisma.conversa.findUnique({ where: { id: conversaId }, select: { tipo: true, clienteId: true } });
  const msg = await prisma.mensagem.create({ data: { conversaId, autorId: userId, conteudo: conteudo.trim() }, include: { autor: { select: { id: true, nome: true, role: true, avatarUrl: true } } } });
  await prisma.conversa.update({ where: { id: conversaId }, data: { updatedAt: /* @__PURE__ */ new Date() } });
  await prisma.conversaParticipante.update({ where: { conversaId_userId: { conversaId, userId } }, data: { ultimaLeituraEm: /* @__PURE__ */ new Date() } });
  await prisma.conversaParticipante.updateMany({ where: { conversaId, NOT: { ocultoEm: null } }, data: { ocultoEm: null } });
  const parts = await pushParaParticipantes(conversaId, "mensagem", { conversaId, mensagem: msg }, userId);
  if (conv?.tipo === "CLIENTE" && msg.autor.role === "CLIENTE") {
    const cliente = conv.clienteId ? await prisma.cliente.findUnique({ where: { id: conv.clienteId }, select: { nome: true } }) : null;
    for (const p of parts) {
      if (p.userId !== userId && p.user.role !== "CLIENTE") {
        await notificar(p.userId, "suporte", { cliente: cliente?.nome ?? "cliente", mensagem: conteudo.trim().slice(0, 120) }, { entidadeTipo: "cliente", entidadeId: conv.clienteId ?? void 0 });
      }
    }
  }
  return msg;
}
async function editarMensagem(mensagemId, userId, conteudo) {
  const m = await prisma.mensagem.findUnique({ where: { id: mensagemId }, select: { autorId: true, conversaId: true, deletedAt: true } });
  if (!m || m.deletedAt) throw new TRPCError4({ code: "NOT_FOUND", message: "Mensagem n\xE3o encontrada" });
  if (m.autorId !== userId) throw new TRPCError4({ code: "FORBIDDEN", message: "Voc\xEA s\xF3 pode editar suas mensagens" });
  const msg = await prisma.mensagem.update({ where: { id: mensagemId }, data: { conteudo: conteudo.trim(), editadoEm: /* @__PURE__ */ new Date() }, include: { autor: { select: { id: true, nome: true, role: true, avatarUrl: true } } } });
  await pushParaParticipantes(m.conversaId, "mensagem", { conversaId: m.conversaId, mensagem: msg });
  return msg;
}
async function apagarMensagem(mensagemId, userId) {
  const m = await prisma.mensagem.findUnique({ where: { id: mensagemId }, select: { autorId: true, conversaId: true } });
  if (!m) throw new TRPCError4({ code: "NOT_FOUND", message: "Mensagem n\xE3o encontrada" });
  if (m.autorId !== userId && !await ehAdmin(userId)) throw new TRPCError4({ code: "FORBIDDEN", message: "Voc\xEA s\xF3 pode apagar suas mensagens" });
  await prisma.mensagem.update({ where: { id: mensagemId }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  await pushParaParticipantes(m.conversaId, "mensagem", { conversaId: m.conversaId });
  return { ok: true };
}
async function markRead2(conversaId, userId) {
  await ensureParticipant(conversaId, userId);
  await prisma.conversaParticipante.update({ where: { conversaId_userId: { conversaId, userId } }, data: { ultimaLeituraEm: /* @__PURE__ */ new Date() } });
  return { ok: true };
}
async function ensureChamadoDoCliente(conversaId, clienteId) {
  const conv = await prisma.conversa.findFirst({ where: { id: conversaId, tipo: "CLIENTE", clienteId, deletedAt: null }, select: { id: true, status: true } });
  if (!conv) throw new TRPCError4({ code: "FORBIDDEN", message: "Chamado indispon\xEDvel" });
  return conv;
}
function portalListChamados(clienteId, portalUserId) {
  return listChamadosDoCliente(clienteId, portalUserId);
}
async function portalAbrirChamado(clienteId, portalUserId, assunto, mensagem) {
  const conv = await criarChamado(portalUserId, clienteId, assunto, "NORMAL");
  if (mensagem?.trim()) {
    await sendMensagem(conv.id, mensagem, portalUserId);
  } else {
    const cli = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true } });
    const parts = await prisma.conversaParticipante.findMany({ where: { conversaId: conv.id }, select: { userId: true, user: { select: { role: true } } } });
    for (const p of parts) {
      if (p.user.role !== "CLIENTE") await notificar(p.userId, "suporte", { cliente: cli?.nome ?? "cliente", mensagem: `Novo chamado: ${assunto}` }, { entidadeTipo: "cliente", entidadeId: clienteId });
    }
  }
  return conv;
}
async function portalMensagens(clienteId, portalUserId, conversaId) {
  await ensureChamadoDoCliente(conversaId, clienteId);
  const info = await prisma.conversa.findUnique({ where: { id: conversaId }, select: { numero: true, assunto: true, status: true } });
  const mensagens = await listMensagens(conversaId, portalUserId);
  return { conversaId, numero: info?.numero ?? null, assunto: info?.assunto ?? null, status: info?.status ?? "ABERTO", mensagens };
}
async function portalEnviar(clienteId, portalUserId, conversaId, corpo) {
  const conv = await ensureChamadoDoCliente(conversaId, clienteId);
  if (conv.status === "RESOLVIDO") await prisma.conversa.update({ where: { id: conversaId }, data: { status: "ABERTO", resolvidoEm: null } });
  return sendMensagem(conversaId, corpo, portalUserId);
}

// src/modules/clientes/clientes.router.ts
var clientesRouter = router({
  // Chamados de suporte do cliente (lista na ficha; a conversa fica em Mensagens).
  chamados: funcionarioProcedure.input(z2.object({ clienteId: z2.string() })).query(({ input, ctx }) => listChamadosDoCliente(input.clienteId, ctx.user.id)),
  list: funcionarioProcedure.input(z2.object({ search: z2.string().optional() }).optional()).query(({ input }) => listClientes(input?.search)),
  // KPIs da base (topo da lista de clientes).
  resumo: funcionarioProcedure.query(() => resumoClientes()),
  get: funcionarioProcedure.input(z2.object({ id: z2.string() })).query(({ input }) => getCliente(input.id)),
  // Projetos, documentos, reuniões e (p/ admin) contas do cliente — o hub da ficha.
  relacionados: funcionarioProcedure.input(z2.object({ id: z2.string() })).query(
    ({ input, ctx }) => relacionadosCliente(input.id, hasRoleLevel(ctx.user.role, "ADMIN"))
  ),
  create: funcionarioProcedure.input(createClienteSchema.extend({ enviarAcessoPortal: z2.boolean().optional() })).mutation(({ input, ctx }) => {
    const { enviarAcessoPortal, ...dados } = input;
    return createCliente(dados, ctx.user.id, enviarAcessoPortal ?? false);
  }),
  update: funcionarioProcedure.input(updateClienteSchema).mutation(({ input }) => updateCliente(input)),
  // Ativar/desativar cliente (toggle manual na ficha) — só ADMIN+ (RBAC).
  setAtivo: adminProcedure.input(setAtivoClienteSchema).mutation(({ input, ctx }) => setAtivoCliente(input.id, input.ativo, ctx.user.id)),
  // Enviar/reenviar o acesso ao Portal do Cliente (igual ao convite do Funil).
  convidarPortal: funcionarioProcedure.input(z2.object({ id: z2.string() })).mutation(({ input, ctx }) => convidarPortalCliente(ctx.user, input.id)),
  // Arquivar cliente (exclusão LÓGICA: some das listas, preserva histórico) — só ADMIN+.
  remove: adminProcedure.input(z2.object({ id: z2.string() })).mutation(({ input, ctx }) => removeCliente(input.id, ctx.user.id)),
  // Exclusão DEFINITIVA (física) — só ROOT e apenas se não houver vínculos que a tornem
  // insegura (projetos, documentos, financeiro, serviços, agenda, acessos, arquivos…).
  excluirDefinitivo: rootProcedure.input(z2.object({ id: z2.string() })).mutation(({ input, ctx }) => excluirDefinitivoCliente(input.id, ctx.user.id)),
  addContato: funcionarioProcedure.input(createContatoSchema).mutation(({ input }) => addContato(input)),
  removeContato: funcionarioProcedure.input(z2.object({ id: z2.string() })).mutation(({ input }) => removeContato(input.id)),
  addNota: funcionarioProcedure.input(createNotaSchema).mutation(({ input, ctx }) => addNota(input, ctx.user.id)),
  /** Arquiva/desarquiva uma nota (histórico imutável — nunca edita/apaga o conteúdo). */
  arquivarNota: funcionarioProcedure.input(z2.object({ notaId: z2.string().min(1), arquivar: z2.boolean() })).mutation(({ input, ctx }) => arquivarNota(input.notaId, ctx.user.id, input.arquivar)),
  // ── Serviços contratados do cliente (ficha) ──
  servicos: funcionarioProcedure.input(z2.object({ id: z2.string() })).query(({ input }) => servicosDoCliente(input.id)),
  ativarServico: funcionarioProcedure.input(ativarServicoClienteSchema).mutation(
    ({ input, ctx }) => ativarServicoCliente(
      input.clienteId,
      input.servicoId,
      { valor: input.valor ?? null, observacao: input.observacao || null, avisarCliente: input.avisarCliente },
      { id: ctx.user.id }
    )
  ),
  cancelarServico: funcionarioProcedure.input(cancelarServicoClienteSchema).mutation(
    ({ input, ctx }) => cancelarServicoCliente(input.clienteId, input.servicoId, "EQUIPE", input.motivo || void 0, ctx.user.id)
  ),
  atualizarContratacao: funcionarioProcedure.input(atualizarContratacaoClienteSchema).mutation(({ input }) => {
    const { clienteId, servicoId, ...dados } = input;
    return atualizarContratacaoCliente(clienteId, servicoId, dados);
  }),
  // ── Arquivos do cliente (upload chega pelo endpoint /upload) ──
  arquivos: funcionarioProcedure.input(z2.object({ id: z2.string(), servicoId: z2.string().optional() })).query(({ input }) => listarArquivos(input.id, input.servicoId)),
  // Remover arquivo (lixeira/soft-delete) — só ADMIN+ (FUNCIONARIO envia/atualiza, não exclui).
  removerArquivo: adminProcedure.input(z2.object({ id: z2.string() })).mutation(({ input, ctx }) => removerArquivo2(input.id, void 0, ctx.user.id))
});

// src/modules/pipeline/pipeline.router.ts
var pipelineRouter = router({
  stages: funcionarioProcedure.query(() => listStages())
});

// src/modules/servicos/servicos.router.ts
import { z as z3 } from "zod";
var servicosRouter = router({
  // Público: usado pelo formulário de captação do site.
  publicos: publicProcedure.query(() => listServicosAtivos()),
  // Interno: lista para o cadastro de leads.
  ativos: funcionarioProcedure.query(() => listServicosAtivos()),
  // Gestão (ADMIN/ROOT): catálogo completo + CRUD.
  list: adminProcedure.query(() => listServicos()),
  criar: adminProcedure.input(createServicoSchema).mutation(({ input }) => criarServico(input)),
  atualizar: adminProcedure.input(updateServicoSchema).mutation(({ input }) => {
    const { id, ...dados } = input;
    return atualizarServico(id, dados);
  }),
  remover: adminProcedure.input(z3.object({ id: z3.string().min(1) })).mutation(({ input }) => removerServico(input.id)),
  setRoteiro: adminProcedure.input(setRoteiroSchema).mutation(({ input }) => setRoteiro(input.servicoId, input.roteiro)),
  reordenar: adminProcedure.input(z3.object({ ids: z3.array(z3.string()) })).mutation(({ input }) => reordenarServicos(input.ids)),
  // Passos padrão de um serviço (por etapa).
  passos: adminProcedure.input(z3.object({ servicoId: z3.string().min(1) })).query(({ input }) => listPassosDoServico(input.servicoId)),
  addPasso: adminProcedure.input(addServicoPassoSchema).mutation(({ input }) => addServicoPasso(input.servicoId, input.titulo, input.etapaChave, input.obrigatorio)),
  atualizarPasso: adminProcedure.input(updateServicoPassoSchema).mutation(({ input }) => {
    const { id, ...dados } = input;
    return atualizarServicoPasso(id, dados);
  }),
  removerPasso: adminProcedure.input(z3.object({ id: z3.string().min(1) })).mutation(({ input }) => removerServicoPasso(input.id)),
  reordenarPassos: adminProcedure.input(z3.object({ ids: z3.array(z3.string()) })).mutation(({ input }) => reordenarServicoPassos(input.ids)),
  // Exigências (checklist de documentos/briefings) de um serviço.
  requisitos: adminProcedure.input(z3.object({ servicoId: z3.string().min(1) })).query(({ input }) => listRequisitos(input.servicoId)),
  addRequisito: adminProcedure.input(addRequisitoSchema).mutation(({ input }) => addRequisito(input)),
  atualizarRequisito: adminProcedure.input(updateRequisitoSchema).mutation(({ input }) => {
    const { id, ...dados } = input;
    return atualizarRequisito(id, dados);
  }),
  removerRequisito: adminProcedure.input(z3.object({ id: z3.string().min(1) })).mutation(({ input }) => removerRequisito(input.id)),
  reordenarRequisitos: adminProcedure.input(z3.object({ ids: z3.array(z3.string()) })).mutation(({ input }) => reordenarRequisitos(input.ids))
});

// src/modules/origens/origens.router.ts
import { z as z4 } from "zod";

// src/modules/origens/origens.service.ts
import { TRPCError as TRPCError5 } from "@trpc/server";
var DEFAULTS = [
  "P\xE1gina de Captura",
  "Site",
  "Indica\xE7\xE3o",
  "Evento",
  "WhatsApp",
  "Google",
  "Facebook/Instagram",
  "LinkedIn",
  "YouTube",
  "Twitter/X",
  "Outro"
];
async function seedIfEmpty() {
  if (await prisma.origem.count() === 0) {
    await prisma.origem.createMany({ data: DEFAULTS.map((nome, ordem) => ({ nome, ordem })) });
  }
}
async function listOrigens() {
  await seedIfEmpty();
  return prisma.origem.findMany({ orderBy: { ordem: "asc" } });
}
async function listOrigensAtivas() {
  await seedIfEmpty();
  return prisma.origem.findMany({ where: { ativo: true }, orderBy: { ordem: "asc" }, select: { id: true, nome: true } });
}
async function criarOrigem(nome) {
  const max = await prisma.origem.aggregate({ _max: { ordem: true } });
  return prisma.origem.create({ data: { nome: nome.trim(), ordem: (max._max.ordem ?? -1) + 1 } });
}
async function atualizarOrigem(id, dados) {
  const data = {};
  if (dados.nome !== void 0) data.nome = dados.nome.trim();
  if (dados.ativo !== void 0) data.ativo = dados.ativo;
  return prisma.origem.update({ where: { id }, data }).catch(() => {
    throw new TRPCError5({ code: "NOT_FOUND", message: "Origem n\xE3o encontrada." });
  });
}
async function removerOrigem(id) {
  await prisma.origem.deleteMany({ where: { id } });
  return { ok: true };
}
async function reordenarOrigens(ids) {
  await prisma.$transaction(
    ids.map((id, ordem) => prisma.origem.update({ where: { id }, data: { ordem } }))
  );
  return { ok: true };
}

// src/modules/origens/origens.router.ts
var origensRouter = router({
  ativas: funcionarioProcedure.query(() => listOrigensAtivas()),
  list: adminProcedure.query(() => listOrigens()),
  criar: adminProcedure.input(createOrigemSchema).mutation(({ input }) => criarOrigem(input.nome)),
  atualizar: adminProcedure.input(updateOrigemSchema).mutation(({ input }) => {
    const { id, ...dados } = input;
    return atualizarOrigem(id, dados);
  }),
  remover: adminProcedure.input(z4.object({ id: z4.string().min(1) })).mutation(({ input }) => removerOrigem(input.id)),
  reordenar: adminProcedure.input(z4.object({ ids: z4.array(z4.string().min(1)).min(1) })).mutation(({ input }) => reordenarOrigens(input.ids))
});

// src/modules/leads/leads.router.ts
import { z as z5 } from "zod";
var leadsRouter = router({
  list: funcionarioProcedure.query(() => listLeads()),
  /** Formulário público do site — cria o lead no funil. Sem autenticação. */
  capturar: publicProcedure.input(capturaLeadSchema).mutation(({ input, ctx }) => capturarLead(input, ctx.req.ip)),
  create: funcionarioProcedure.input(createLeadSchema).mutation(({ input, ctx }) => createLead(input, ctx.user.id)),
  update: funcionarioProcedure.input(updateLeadSchema).mutation(({ input, ctx }) => updateLead(input, ctx.user.id)),
  move: funcionarioProcedure.input(moveLeadSchema).mutation(({ input, ctx }) => moveLead(input, ctx.user.id)),
  convert: funcionarioProcedure.input(z5.object({ id: z5.string(), enviarEmail: z5.boolean().optional() })).mutation(({ input, ctx }) => convertLead(input.id, ctx.user.id, input.enviarEmail ?? true)),
  /** Abre uma nova oportunidade no funil para um cliente que já existe (com serviços). */
  novaOportunidade: funcionarioProcedure.input(novaOportunidadeSchema).mutation(
    ({ input, ctx }) => criarOportunidadeParaCliente(input.clienteId, ctx.user.id, {
      servicoIds: input.servicoIds,
      valorEstimado: input.valorEstimado,
      observacoes: input.observacoes
    })
  ),
  /** Indicadores de ganho/perda do funil. */
  resumo: funcionarioProcedure.query(() => funilResumo()),
  /** Leads perdidos (relatório + reabertura). */
  perdidos: funcionarioProcedure.query(() => listPerdidos()),
  marcarPerdido: funcionarioProcedure.input(z5.object({ id: z5.string(), motivo: z5.string().trim().min(1, "Diga o motivo da perda").max(500) })).mutation(({ input, ctx }) => marcarPerdido(input.id, input.motivo, ctx.user.id)),
  reabrir: funcionarioProcedure.input(z5.object({ id: z5.string() })).mutation(({ input, ctx }) => reabrirLead(input.id, ctx.user.id)),
  /** Convida o lead para o Portal (cria conta Cliente Prospect + convite). */
  convidarPortal: funcionarioProcedure.input(z5.object({ id: z5.string() })).mutation(({ input, ctx }) => convidarPortal(input.id, ctx.user)),
  remove: funcionarioProcedure.input(z5.object({ id: z5.string() })).mutation(({ input, ctx }) => removeLead(input.id, ctx.user.id)),
  // ── Painel do lead + checklist por etapa (Fase 2) ──
  detalhe: funcionarioProcedure.input(z5.object({ id: z5.string() })).query(({ input }) => getLeadDetalhe(input.id)),
  togglePasso: funcionarioProcedure.input(z5.object({ passoId: z5.string() })).mutation(({ input, ctx }) => togglePasso(input.passoId, ctx.user.id)),
  addPasso: funcionarioProcedure.input(z5.object({ leadId: z5.string(), titulo: z5.string().trim().min(1, "Escreva o passo").max(200) })).mutation(({ input }) => addPasso(input.leadId, input.titulo)),
  removePasso: funcionarioProcedure.input(z5.object({ passoId: z5.string() })).mutation(({ input }) => removePasso(input.passoId)),
  avancarEtapa: funcionarioProcedure.input(z5.object({ id: z5.string() })).mutation(({ input, ctx }) => avancarEtapa(input.id, ctx.user.id))
});

// src/modules/projetos/projetos.router.ts
import { z as z6 } from "zod";
var projetosRouter = router({
  setParticipantes: funcionarioProcedure.input(setParticipantesSchema).mutation(({ input, ctx }) => setParticipantes(input.projetoId, input.userIds, ctx.user.id)),
  list: funcionarioProcedure.input(z6.object({ clienteId: z6.string().optional() }).optional()).query(({ input }) => listProjetos(input?.clienteId)),
  get: funcionarioProcedure.input(z6.object({ id: z6.string() })).query(({ input }) => getProjeto(input.id)),
  create: funcionarioProcedure.input(createProjetoSchema).mutation(({ input, ctx }) => createProjeto(input, ctx.user.id)),
  update: funcionarioProcedure.input(updateProjetoSchema).mutation(({ input }) => updateProjeto(input)),
  remove: funcionarioProcedure.input(z6.object({ id: z6.string() })).mutation(({ input, ctx }) => removeProjeto(input.id, ctx.user.id))
});

// src/modules/cards/cards.router.ts
import { z as z7 } from "zod";

// src/modules/cards/cards.service.ts
import { TRPCError as TRPCError6 } from "@trpc/server";
var clean2 = (v) => {
  const t2 = v?.trim();
  return t2 ? t2 : null;
};
async function notificarAtribuicao(card, atribuidoPor) {
  if (!card.responsavelId || card.responsavelId === atribuidoPor) return;
  const projeto = await prisma.projeto.findUnique({
    where: { id: card.projetoId },
    select: { nome: true }
  });
  await notificar(
    card.responsavelId,
    "tarefa_atribuida",
    { tarefa: card.titulo, projeto: projeto?.nome ?? "" },
    { entidadeTipo: "projeto", entidadeId: card.projetoId }
  );
}
async function listCards(projetoId, userId) {
  const cards = await prisma.card.findMany({
    where: { projetoId, deletedAt: null },
    orderBy: [{ status: "asc" }, { ordem: "asc" }],
    include: {
      responsavel: { select: { nome: true } },
      servico: { select: { nome: true } },
      checklist: { orderBy: { ordem: "asc" } },
      timeEntries: true
    }
  });
  return cards.map((c) => {
    const tempoTotalSeg = c.timeEntries.reduce((s, e) => s + (e.duracaoSeg ?? 0), 0);
    const rodando = c.timeEntries.find((e) => e.userId === userId && e.fim === null);
    const { timeEntries: _te, ...rest } = c;
    return { ...rest, tempoTotalSeg, timerInicio: rodando?.inicio ?? null };
  });
}
async function createCard(input, userId) {
  const status = input.status ?? "A_FAZER";
  const max = await prisma.card.aggregate({
    where: { projetoId: input.projetoId, status, deletedAt: null },
    _max: { ordem: true }
  });
  const card = await prisma.card.create({
    data: {
      projetoId: input.projetoId,
      titulo: input.titulo.trim(),
      descricao: clean2(input.descricao),
      status,
      prioridade: input.prioridade,
      prazo: input.prazo ?? null,
      ordem: (max._max.ordem ?? -1) + 1,
      // Vazio = o criador vira responsável.
      responsavelId: input.responsavelId || userId
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "card.criado", entidadeTipo: "card", entidadeId: card.id }
  });
  await notificarAtribuicao(card, userId);
  return card;
}
async function updateCard(input, userId) {
  const { id, ...rest } = input;
  const atual = await prisma.card.findUnique({ where: { id }, select: { responsavelId: true } });
  const data = {};
  if (rest.titulo !== void 0) data.titulo = rest.titulo.trim();
  if (rest.descricao !== void 0) data.descricao = clean2(rest.descricao);
  if (rest.prioridade !== void 0) data.prioridade = rest.prioridade;
  if (rest.prazo !== void 0) data.prazo = rest.prazo ?? null;
  if (rest.responsavelId !== void 0) data.responsavelId = rest.responsavelId || null;
  const card = await prisma.card.update({ where: { id }, data });
  const novoResp = rest.responsavelId !== void 0 ? rest.responsavelId || null : void 0;
  if (novoResp !== void 0 && novoResp !== atual?.responsavelId) {
    await notificarAtribuicao(card, userId);
  }
  return card;
}
async function moveCard(input) {
  const card = await prisma.card.findUnique({ where: { id: input.id } });
  if (!card) throw new TRPCError6({ code: "NOT_FOUND", message: "Cart\xE3o n\xE3o encontrado" });
  const destino = await prisma.card.findMany({
    where: { projetoId: card.projetoId, status: input.status, deletedAt: null, id: { not: input.id } },
    orderBy: { ordem: "asc" },
    select: { id: true }
  });
  const ids = destino.map((d) => d.id);
  const alvo = Math.max(0, Math.min(input.ordem, ids.length));
  ids.splice(alvo, 0, input.id);
  await prisma.$transaction(
    ids.map(
      (id, i) => prisma.card.update({ where: { id }, data: { ordem: i, status: input.status } })
    )
  );
  if (input.status === "CONCLUIDO" && card.status !== "CONCLUIDO") {
    const abertas = await prisma.timeEntry.findMany({ where: { cardId: input.id, fim: null }, select: { id: true, inicio: true } });
    const fim = /* @__PURE__ */ new Date();
    for (const t2 of abertas) {
      await prisma.timeEntry.update({
        where: { id: t2.id },
        data: { fim, duracaoSeg: Math.max(0, Math.round((fim.getTime() - t2.inicio.getTime()) / 1e3)) }
      });
    }
  }
  await reconciliarStatusProjeto(card.projetoId);
  return { ok: true };
}
async function removeCard(id) {
  await prisma.card.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  return { ok: true };
}
async function getCard(id, userId) {
  const card = await prisma.card.findFirst({
    where: { id, deletedAt: null },
    include: {
      responsavel: { select: { nome: true } },
      checklist: { orderBy: { ordem: "asc" } },
      timeEntries: { orderBy: { inicio: "desc" }, include: { user: { select: { nome: true } } } }
    }
  });
  if (!card) throw new TRPCError6({ code: "NOT_FOUND", message: "Cart\xE3o n\xE3o encontrado" });
  const comentarios = await prisma.nota.findMany({
    where: { entidadeTipo: "card", entidadeId: id },
    include: { autor: { select: { nome: true } } },
    orderBy: { createdAt: "desc" }
  });
  const tempoTotalSeg = card.timeEntries.reduce((s, e) => s + (e.duracaoSeg ?? 0), 0);
  const rodando = card.timeEntries.find((e) => e.userId === userId && e.fim === null);
  return { ...card, comentarios, tempoTotalSeg, timerInicio: rodando?.inicio ?? null };
}
async function addChecklist(input) {
  const max = await prisma.checklistItem.aggregate({
    where: { cardId: input.cardId },
    _max: { ordem: true }
  });
  return prisma.checklistItem.create({
    data: { cardId: input.cardId, texto: input.texto.trim(), ordem: (max._max.ordem ?? -1) + 1 }
  });
}
async function toggleChecklist(id, concluido) {
  const item = await prisma.checklistItem.findUnique({ where: { id }, select: { cardId: true, requisitoId: true } });
  if (!item) throw new TRPCError6({ code: "NOT_FOUND", message: "Item n\xE3o encontrado" });
  if (item.requisitoId) return { movidoPara: null };
  await prisma.checklistItem.update({ where: { id }, data: { concluido } });
  const movidoPara = await reconciliarStatusCard(item.cardId);
  return { movidoPara };
}
async function removeChecklist(id) {
  const item = await prisma.checklistItem.findUnique({ where: { id }, select: { cardId: true } });
  await prisma.checklistItem.delete({ where: { id } });
  if (item) await reconciliarStatusCard(item.cardId);
  return { ok: true };
}
function addComentario(cardId, conteudo, userId) {
  return prisma.nota.create({
    data: { autorId: userId, entidadeTipo: "card", entidadeId: cardId, conteudo: conteudo.trim() },
    include: { autor: { select: { nome: true } } }
  });
}
async function editComentario(id, conteudo, userId) {
  const nota = await prisma.nota.findUnique({ where: { id }, select: { autorId: true, entidadeTipo: true } });
  if (!nota || nota.entidadeTipo !== "card") throw new TRPCError6({ code: "NOT_FOUND", message: "Coment\xE1rio n\xE3o encontrado" });
  if (nota.autorId !== userId) throw new TRPCError6({ code: "FORBIDDEN", message: "Voc\xEA s\xF3 pode editar seus pr\xF3prios coment\xE1rios." });
  return prisma.nota.update({
    where: { id },
    data: { conteudo: conteudo.trim() },
    include: { autor: { select: { nome: true } } }
  });
}
async function removeComentario(id, userId, isGestor) {
  const nota = await prisma.nota.findUnique({ where: { id }, select: { autorId: true, entidadeTipo: true } });
  if (!nota || nota.entidadeTipo !== "card") throw new TRPCError6({ code: "NOT_FOUND", message: "Coment\xE1rio n\xE3o encontrado" });
  if (nota.autorId !== userId && !isGestor) throw new TRPCError6({ code: "FORBIDDEN", message: "Voc\xEA n\xE3o pode apagar este coment\xE1rio." });
  await prisma.nota.delete({ where: { id } });
  return { ok: true };
}
async function startTimer(cardId, userId) {
  const rodando = await prisma.timeEntry.findFirst({ where: { cardId, userId, fim: null } });
  if (rodando) return rodando;
  return prisma.timeEntry.create({ data: { cardId, userId } });
}
async function stopTimer(cardId, userId) {
  const abertas = await prisma.timeEntry.findMany({ where: { cardId, userId, fim: null } });
  if (abertas.length === 0) return { ok: true };
  const fim = /* @__PURE__ */ new Date();
  await prisma.$transaction(
    abertas.map(
      (e) => prisma.timeEntry.update({
        where: { id: e.id },
        data: { fim, duracaoSeg: Math.max(0, Math.round((fim.getTime() - e.inicio.getTime()) / 1e3)) }
      })
    )
  );
  return { ok: true };
}

// src/modules/cards/cards.router.ts
var cardsRouter = router({
  list: funcionarioProcedure.input(z7.object({ projetoId: z7.string() })).query(({ input, ctx }) => listCards(input.projetoId, ctx.user.id)),
  get: funcionarioProcedure.input(z7.object({ id: z7.string() })).query(({ input, ctx }) => getCard(input.id, ctx.user.id)),
  create: funcionarioProcedure.input(createCardSchema).mutation(({ input, ctx }) => createCard(input, ctx.user.id)),
  update: funcionarioProcedure.input(updateCardSchema).mutation(({ input, ctx }) => updateCard(input, ctx.user.id)),
  move: funcionarioProcedure.input(moveCardSchema).mutation(({ input }) => moveCard(input)),
  remove: funcionarioProcedure.input(z7.object({ id: z7.string() })).mutation(({ input }) => removeCard(input.id)),
  addChecklist: funcionarioProcedure.input(addChecklistSchema).mutation(({ input }) => addChecklist(input)),
  toggleChecklist: funcionarioProcedure.input(z7.object({ id: z7.string(), concluido: z7.boolean() })).mutation(({ input }) => toggleChecklist(input.id, input.concluido)),
  removeChecklist: funcionarioProcedure.input(z7.object({ id: z7.string() })).mutation(({ input }) => removeChecklist(input.id)),
  addComentario: funcionarioProcedure.input(z7.object({ cardId: z7.string(), conteudo: z7.string().trim().min(1) })).mutation(({ input, ctx }) => addComentario(input.cardId, input.conteudo, ctx.user.id)),
  editComentario: funcionarioProcedure.input(z7.object({ id: z7.string(), conteudo: z7.string().trim().min(1) })).mutation(({ input, ctx }) => editComentario(input.id, input.conteudo, ctx.user.id)),
  removeComentario: funcionarioProcedure.input(z7.object({ id: z7.string() })).mutation(({ input, ctx }) => removeComentario(input.id, ctx.user.id, hasRoleLevel(ctx.user.role, "ADMIN"))),
  startTimer: funcionarioProcedure.input(z7.object({ cardId: z7.string() })).mutation(({ input, ctx }) => startTimer(input.cardId, ctx.user.id)),
  stopTimer: funcionarioProcedure.input(z7.object({ cardId: z7.string() })).mutation(({ input, ctx }) => stopTimer(input.cardId, ctx.user.id))
});

// src/modules/agenda/agenda.router.ts
import { z as z8 } from "zod";

// src/modules/agenda/agenda.service.ts
var clean3 = (v) => {
  const t2 = v?.trim();
  return t2 ? t2 : null;
};
var startOfDay = (d) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
var endOfDay = (d) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};
function quandoTexto(inicio, diaInteiro) {
  const tz = "America/Sao_Paulo";
  if (diaInteiro) {
    return `${new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeZone: tz }).format(inicio)} (dia inteiro)`;
  }
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: tz }).format(inicio);
}
function proximo(data, recorrencia) {
  const d = new Date(data);
  if (recorrencia === "DIARIA") d.setDate(d.getDate() + 1);
  else if (recorrencia === "SEMANAL") d.setDate(d.getDate() + 7);
  else if (recorrencia === "MENSAL") d.setMonth(d.getMonth() + 1);
  return d;
}
async function listEventos(rangeInicio, rangeFim, userId) {
  const base = await prisma.evento.findMany({
    where: {
      deletedAt: null,
      inicio: { lte: rangeFim },
      OR: [{ escopo: "EMPRESA" }, { donoId: userId }, { participantes: { some: { userId } } }]
    },
    include: {
      cliente: { select: { id: true, nome: true } },
      projeto: { select: { id: true, nome: true } },
      dono: { select: { id: true, nome: true } },
      participantes: { select: { user: { select: { id: true, nome: true } } } }
    },
    orderBy: { inicio: "asc" }
  });
  const duracao = (ev) => ev.fim ? ev.fim.getTime() - ev.inicio.getTime() : 0;
  const ocorrencia = (ev, inicio) => ({
    occurrenceId: `${ev.id}:${inicio.toISOString()}`,
    eventoId: ev.id,
    titulo: ev.titulo,
    descricao: ev.descricao,
    tipo: ev.tipo,
    escopo: ev.escopo,
    inicio,
    fim: ev.fim ? new Date(inicio.getTime() + duracao(ev)) : null,
    diaInteiro: ev.diaInteiro,
    local: ev.local,
    linkReuniao: ev.linkReuniao,
    recorrencia: ev.recorrencia,
    cliente: ev.cliente,
    projeto: ev.projeto,
    dono: ev.dono,
    participantes: ev.participantes.map((p) => p.user),
    clienteConfirmadoEm: ev.clienteConfirmadoEm,
    // Campos da série base (para edição — editar afeta a série toda).
    clienteId: ev.clienteId,
    projetoId: ev.projetoId,
    recorrenciaAte: ev.recorrenciaAte,
    baseInicio: ev.inicio,
    baseFim: ev.fim
  });
  const out = [];
  for (const ev of base) {
    if (ev.recorrencia === "NENHUMA") {
      const fimEv = ev.fim ?? ev.inicio;
      if (ev.inicio <= rangeFim && fimEv >= rangeInicio) out.push(ocorrencia(ev, ev.inicio));
      continue;
    }
    const ate = ev.recorrenciaAte ?? rangeFim;
    let cur = new Date(ev.inicio);
    let guard = 0;
    while (cur <= rangeFim && cur <= ate && guard < 500) {
      if (cur >= rangeInicio) out.push(ocorrencia(ev, new Date(cur)));
      cur = proximo(cur, ev.recorrencia);
      guard++;
    }
  }
  out.sort((a, b) => a.inicio.getTime() - b.inicio.getTime());
  return out;
}
async function avisarClienteReuniao(clienteId, titulo, inicio, diaInteiro, link) {
  if (!clienteId) return;
  try {
    const cli = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true, email: true } });
    if (cli?.email) {
      void enviarEmailTemplate("reuniao_agendada", cli.email, {
        nome: cli.nome,
        titulo,
        quando: quandoTexto(inicio, diaInteiro),
        link: link ?? ""
      }).catch(() => {
      });
    }
  } catch {
  }
}
async function createEvento(input, userId, avisarCliente = false) {
  const participanteIds = (input.participanteIds ?? []).filter((id) => id && id !== userId);
  const evento = await prisma.evento.create({
    data: {
      titulo: input.titulo.trim(),
      descricao: clean3(input.descricao),
      tipo: input.tipo,
      escopo: input.escopo,
      inicio: input.inicio,
      fim: input.fim ?? null,
      diaInteiro: input.diaInteiro,
      local: clean3(input.local),
      linkReuniao: clean3(input.linkReuniao),
      recorrencia: input.recorrencia,
      recorrenciaAte: input.recorrenciaAte ?? null,
      clienteId: clean3(input.clienteId),
      projetoId: clean3(input.projetoId),
      donoId: userId,
      participantes: participanteIds.length ? { create: participanteIds.map((uid) => ({ userId: uid })) } : void 0
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "evento.criado", entidadeTipo: "evento", entidadeId: evento.id }
  });
  if (avisarCliente) {
    await avisarClienteReuniao(evento.clienteId, evento.titulo, evento.inicio, evento.diaInteiro, evento.linkReuniao);
  }
  return evento;
}
async function updateEvento(input, avisarCliente = false) {
  const { id, participanteIds, ...rest } = input;
  const atual = await prisma.evento.findUnique({ where: { id }, select: { inicio: true } });
  const data = {};
  if (rest.titulo !== void 0) data.titulo = rest.titulo.trim();
  if (rest.descricao !== void 0) data.descricao = clean3(rest.descricao);
  if (rest.tipo !== void 0) data.tipo = rest.tipo;
  if (rest.escopo !== void 0) data.escopo = rest.escopo;
  let remarcou = false;
  if (rest.inicio !== void 0) {
    data.inicio = rest.inicio;
    remarcou = !atual || atual.inicio.getTime() !== rest.inicio.getTime();
    if (remarcou) {
      data.lembreteEnviado = false;
      data.lembreteClienteEnviado = false;
      data.clienteConfirmadoEm = null;
    }
  }
  if (rest.fim !== void 0) data.fim = rest.fim ?? null;
  if (rest.diaInteiro !== void 0) data.diaInteiro = rest.diaInteiro;
  if (rest.local !== void 0) data.local = clean3(rest.local);
  if (rest.linkReuniao !== void 0) data.linkReuniao = clean3(rest.linkReuniao);
  if (rest.recorrencia !== void 0) data.recorrencia = rest.recorrencia;
  if (rest.recorrenciaAte !== void 0) data.recorrenciaAte = rest.recorrenciaAte ?? null;
  if (rest.clienteId !== void 0) data.clienteId = clean3(rest.clienteId);
  if (rest.projetoId !== void 0) data.projetoId = clean3(rest.projetoId);
  if (participanteIds !== void 0) {
    const donoRow = await prisma.evento.findUnique({ where: { id }, select: { donoId: true } });
    const ids = participanteIds.filter((uid) => uid && uid !== donoRow?.donoId);
    await prisma.eventoParticipante.deleteMany({ where: { eventoId: id } });
    if (ids.length) {
      await prisma.eventoParticipante.createMany({ data: ids.map((uid) => ({ eventoId: id, userId: uid })) });
    }
  }
  const evento = await prisma.evento.update({ where: { id }, data });
  if (avisarCliente && remarcou) {
    await avisarClienteReuniao(evento.clienteId, evento.titulo, evento.inicio, evento.diaInteiro, evento.linkReuniao);
  }
  return evento;
}
async function removeEvento(id, userId) {
  await prisma.evento.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  await prisma.activityLog.create({
    data: { userId, acao: "evento.removido", entidadeTipo: "evento", entidadeId: id }
  });
  return { ok: true };
}
async function verificarConflitos(input, userId) {
  const inicio = input.inicio;
  const fim = input.fim ?? new Date(inicio.getTime() + 30 * 60 * 1e3);
  const novoIni = inicio.getTime();
  const novoFim = fim.getTime();
  const participanteIds = (input.participanteIds ?? []).filter((id) => id !== userId);
  const nomes = participanteIds.length ? new Map(
    (await prisma.user.findMany({ where: { id: { in: participanteIds } }, select: { id: true, nome: true } })).map(
      (u) => [u.id, u.nome]
    )
  ) : /* @__PURE__ */ new Map();
  const pessoas = [
    { id: userId, nome: null },
    ...participanteIds.map((id) => ({ id, nome: nomes.get(id) ?? "Participante" }))
  ];
  const vistos = /* @__PURE__ */ new Set();
  const conflitos = [];
  for (const p of pessoas) {
    const ocorrencias = await listEventos(startOfDay(inicio), endOfDay(fim), p.id);
    for (const o of ocorrencias) {
      if (o.eventoId === input.ignorarId || o.diaInteiro || vistos.has(o.occurrenceId)) continue;
      const oi = new Date(o.inicio).getTime();
      const of = o.fim ? new Date(o.fim).getTime() : oi + 30 * 60 * 1e3;
      if (oi < novoFim && novoIni < of) {
        vistos.add(o.occurrenceId);
        conflitos.push({ titulo: o.titulo, inicio: o.inicio, fim: o.fim, dono: o.dono?.nome ?? null, participante: p.nome });
      }
    }
  }
  return conflitos;
}
async function confirmarPresencaCliente(eventoId, clienteId) {
  const ev = await prisma.evento.findFirst({
    where: { id: eventoId, clienteId, deletedAt: null, escopo: "EMPRESA" },
    select: { id: true, titulo: true, donoId: true, clienteConfirmadoEm: true, cliente: { select: { nome: true } } }
  });
  if (!ev) return { ok: false };
  if (!ev.clienteConfirmadoEm) {
    await prisma.evento.update({ where: { id: ev.id }, data: { clienteConfirmadoEm: /* @__PURE__ */ new Date() } });
    try {
      const { notificar: notificar2 } = await import("./notificacoes.service-FYOXIC3Z.js");
      await notificar2(
        ev.donoId,
        "presenca_confirmada",
        { cliente: ev.cliente?.nome ?? "O cliente", evento: ev.titulo },
        { entidadeTipo: "evento", entidadeId: ev.id }
      );
    } catch {
    }
  }
  return { ok: true };
}

// src/modules/agenda/agenda.router.ts
var agendaRouter = router({
  list: funcionarioProcedure.input(listEventosSchema).query(({ input, ctx }) => listEventos(input.inicio, input.fim, ctx.user.id)),
  create: funcionarioProcedure.input(createEventoSchema.and(z8.object({ avisarCliente: z8.boolean().optional() }))).mutation(({ input, ctx }) => {
    const { avisarCliente, ...dados } = input;
    return createEvento(dados, ctx.user.id, avisarCliente ?? false);
  }),
  update: funcionarioProcedure.input(updateEventoSchema.and(z8.object({ avisarCliente: z8.boolean().optional() }))).mutation(({ input }) => {
    const { avisarCliente, ...dados } = input;
    return updateEvento(dados, avisarCliente ?? false);
  }),
  remove: funcionarioProcedure.input(z8.object({ id: z8.string() })).mutation(({ input, ctx }) => removeEvento(input.id, ctx.user.id)),
  // Conflitos de horário na agenda do usuário (para avisar ao criar/editar).
  conflitos: funcionarioProcedure.input(conflitoEventoSchema).query(({ input, ctx }) => verificarConflitos(input, ctx.user.id))
});

// src/modules/notificacoes/notificacoes.router.ts
import { z as z9 } from "zod";
var notificacoesRouter = router({
  list: protectedProcedure.query(({ ctx }) => listNotificacoes(ctx.user.id)),
  markAllRead: protectedProcedure.mutation(({ ctx }) => markAllRead(ctx.user.id)),
  markRead: protectedProcedure.input(z9.object({ id: z9.string() })).mutation(({ ctx, input }) => markRead(ctx.user.id, input.id)),
  /** Preferências de e-mail do usuário (categorias com estado ligado/desligado). */
  preferenciasEmail: protectedProcedure.query(
    ({ ctx }) => listarPreferenciasEmail(ctx.user.id, ctx.user.role)
  ),
  setPreferenciaEmail: protectedProcedure.input(z9.object({ tipo: z9.string().min(1), ativo: z9.boolean() })).mutation(({ ctx, input }) => setPreferenciaEmail(ctx.user.id, input.tipo, input.ativo))
});

// src/modules/financeiro/financeiro.router.ts
import { z as z10 } from "zod";

// src/modules/financeiro/categorias.service.ts
import { TRPCError as TRPCError7 } from "@trpc/server";
var DEFAULTS_EMPRESA = [
  { nome: "Honor\xE1rios", tipo: "RECEITA", cor: "#30AD73" },
  { nome: "Consultoria", tipo: "RECEITA", cor: "#2DA8E1" },
  { nome: "Outras receitas", tipo: "RECEITA", cor: "#003591" },
  { nome: "Aluguel", tipo: "DESPESA", cor: "#E5484D" },
  { nome: "Sal\xE1rios", tipo: "DESPESA", cor: "#F59E0B" },
  { nome: "Impostos", tipo: "DESPESA", cor: "#002463" },
  { nome: "Fornecedores", tipo: "DESPESA", cor: "#8b5cf6" },
  { nome: "Outras despesas", tipo: "DESPESA", cor: "#64748b" }
];
var DEFAULTS_PESSOAL = [
  { nome: "Sal\xE1rio / Renda", tipo: "RECEITA", cor: "#30AD73" },
  { nome: "Outras receitas", tipo: "RECEITA", cor: "#2DA8E1" },
  { nome: "Casa / Aluguel", tipo: "DESPESA", cor: "#E5484D" },
  { nome: "Mercado", tipo: "DESPESA", cor: "#F59E0B" },
  { nome: "Contas (\xE1gua/luz/net)", tipo: "DESPESA", cor: "#0ea5e9" },
  { nome: "Cart\xE3o de cr\xE9dito", tipo: "DESPESA", cor: "#8b5cf6" },
  { nome: "Transporte", tipo: "DESPESA", cor: "#002463" },
  { nome: "Sa\xFAde", tipo: "DESPESA", cor: "#ec4899" },
  { nome: "Educa\xE7\xE3o", tipo: "DESPESA", cor: "#14b8a6" },
  { nome: "Lazer", tipo: "DESPESA", cor: "#f97316" },
  { nome: "Outras despesas", tipo: "DESPESA", cor: "#64748b" }
];
async function listCategorias(escopo, ctx) {
  const filtro = escopo === "PESSOAL" ? { escopo, donoId: ctx.userId } : { escopo: "EMPRESA" };
  const count = await prisma.categoria.count({ where: filtro });
  if (count === 0) {
    const sementes = escopo === "PESSOAL" ? DEFAULTS_PESSOAL : DEFAULTS_EMPRESA;
    await prisma.categoria.createMany({
      data: sementes.map((s) => ({ ...s, escopo, donoId: escopo === "PESSOAL" ? ctx.userId : null }))
    });
  }
  return prisma.categoria.findMany({ where: filtro, orderBy: [{ tipo: "asc" }, { nome: "asc" }] });
}
async function categoriaComPosse(id, ctx) {
  const cat = await prisma.categoria.findUnique({ where: { id } });
  if (!cat) throw new TRPCError7({ code: "NOT_FOUND", message: "Categoria n\xE3o encontrada" });
  if (cat.escopo === "PESSOAL" && cat.donoId !== ctx.userId)
    throw new TRPCError7({ code: "FORBIDDEN", message: "Esta \xE9 uma categoria pessoal de outra pessoa." });
  return cat;
}
function createCategoria(input, ctx) {
  const escopo = input.escopo ?? "EMPRESA";
  return prisma.categoria.create({
    data: {
      nome: input.nome.trim(),
      tipo: input.tipo,
      escopo,
      donoId: escopo === "PESSOAL" ? ctx.userId : null,
      cor: input.cor?.trim() || null
    }
  });
}
async function updateCategoria(input, ctx) {
  await categoriaComPosse(input.id, ctx);
  return prisma.categoria.update({
    where: { id: input.id },
    data: {
      ...input.nome !== void 0 ? { nome: input.nome.trim() } : {},
      ...input.tipo !== void 0 ? { tipo: input.tipo } : {},
      ...input.cor !== void 0 ? { cor: input.cor?.trim() || null } : {}
    }
  });
}
async function removeCategoria(id, ctx) {
  await categoriaComPosse(id, ctx);
  return prisma.categoria.delete({ where: { id } });
}

// src/modules/financeiro/financeiro.router.ts
var ctxDe = (ctx) => ({ userId: ctx.user.id, role: ctx.user.role });
var financeiroRouter = router({
  categorias: router({
    list: adminProcedure.input(listCategoriasSchema).query(({ input, ctx }) => listCategorias(input.escopo, ctxDe(ctx))),
    create: adminProcedure.input(createCategoriaSchema).mutation(({ input, ctx }) => createCategoria(input, ctxDe(ctx))),
    update: adminProcedure.input(updateCategoriaSchema).mutation(({ input, ctx }) => updateCategoria(input, ctxDe(ctx))),
    remove: adminProcedure.input(z10.object({ id: z10.string() })).mutation(({ input, ctx }) => removeCategoria(input.id, ctxDe(ctx)))
  }),
  contas: router({
    resumo: adminProcedure.input(carteiraInputSchema).query(({ input, ctx }) => resumo(input.carteira, ctxDe(ctx))),
    porCategoria: adminProcedure.input(carteiraInputSchema).query(({ input, ctx }) => porCategoria(input.carteira, ctxDe(ctx))),
    agenda: adminProcedure.input(carteiraInputSchema).query(({ input, ctx }) => agendaFinanceira(input.carteira, ctxDe(ctx))),
    list: adminProcedure.input(listContasSchema).query(({ input, ctx }) => listContas(input, ctxDe(ctx))),
    create: adminProcedure.input(createContaSchema).mutation(({ input, ctx }) => createConta(input, ctxDe(ctx))),
    update: adminProcedure.input(updateContaSchema).mutation(({ input, ctx }) => updateConta(input, ctxDe(ctx))),
    remove: adminProcedure.input(z10.object({ id: z10.string() })).mutation(({ input, ctx }) => removeConta(input.id, ctxDe(ctx))),
    marcarPaga: adminProcedure.input(marcarPagaSchema).mutation(({ input, ctx }) => marcarPaga(input.id, input.pago, ctxDe(ctx)))
  })
});

// src/modules/dashboard/dashboard.service.ts
var DIA = 864e5;
function contarConflitos(occ) {
  const timed2 = occ.filter((e) => !e.diaInteiro);
  const byDay = /* @__PURE__ */ new Map();
  for (const e of timed2) {
    const k = new Date(e.inicio).toDateString();
    const arr = byDay.get(k) ?? [];
    arr.push(e);
    byDay.set(k, arr);
  }
  let count = 0;
  for (const arr of byDay.values()) {
    for (let i = 0; i < arr.length; i++) {
      const a = arr[i];
      const ai = +new Date(a.inicio);
      const af = a.fim ? +new Date(a.fim) : ai + 30 * 6e4;
      for (let j = 0; j < arr.length; j++) {
        if (i === j) continue;
        const b = arr[j];
        const bi = +new Date(b.inicio);
        const bf = b.fim ? +new Date(b.fim) : bi + 30 * 6e4;
        if (ai < bf && bi < af) {
          count++;
          break;
        }
      }
    }
  }
  return count;
}
async function dashboard(userId, role) {
  const isAdmin = hasRoleLevel(role, "ADMIN");
  const isRoot = role === "ROOT";
  const hojeInicio = /* @__PURE__ */ new Date();
  hojeInicio.setHours(0, 0, 0, 0);
  const hojeFim = /* @__PURE__ */ new Date();
  hojeFim.setHours(23, 59, 59, 999);
  const amanhaInicio = new Date(hojeInicio.getTime() + DIA);
  const em7 = new Date(hojeInicio.getTime() + 7 * DIA);
  const d7 = new Date(Date.now() - 7 * DIA);
  const d14 = new Date(Date.now() - 14 * DIA);
  const d30 = new Date(Date.now() - 30 * DIA);
  const [
    eventosHoje,
    proximosEventos,
    minhasTarefasHoje,
    minhasTarefasCount,
    minhasTarefasAtrasadasCount,
    minhasTarefasConcluidas7,
    minhasTarefasCards
  ] = await Promise.all([
    listEventos(hojeInicio, hojeFim, userId),
    listEventos(amanhaInicio, em7, userId),
    prisma.card.count({
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: userId, prazo: { gte: hojeInicio, lte: hojeFim } }
    }),
    prisma.card.count({
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: userId }
    }),
    prisma.card.count({
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: userId, prazo: { lt: hojeInicio } }
    }),
    prisma.card.count({
      where: { deletedAt: null, status: "CONCLUIDO", responsavelId: userId, updatedAt: { gte: d7 } }
    }),
    prisma.card.findMany({
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: userId },
      include: { projeto: { select: { id: true, nome: true } } },
      orderBy: { prazo: "asc" },
      take: 30
    })
  ]);
  const minhasTarefasLista = [...minhasTarefasCards].sort((a, b) => {
    if (a.prazo && b.prazo) return a.prazo.getTime() - b.prazo.getTime();
    if (a.prazo) return -1;
    if (b.prazo) return 1;
    return b.createdAt.getTime() - a.createdAt.getTime();
  }).slice(0, 7).map((c) => ({ id: c.id, titulo: c.titulo, prazo: c.prazo, prioridade: c.prioridade, status: c.status, projeto: c.projeto }));
  const conflitosAgendaCount = contarConflitos([...eventosHoje, ...proximosEventos]);
  const gestao = isAdmin ? await montarGestao(hojeInicio, em7, d7, d14, d30, { userId, role }) : null;
  const sistema = isRoot ? await montarSistema() : null;
  return {
    role,
    eventosHoje,
    proximosEventos: proximosEventos.slice(0, 6),
    minhasTarefas: minhasTarefasCount,
    minhasTarefasHoje,
    minhasTarefasAtrasadasCount,
    minhasTarefasConcluidas7,
    minhasTarefasLista,
    conflitosAgendaCount,
    gestao,
    sistema
  };
}
async function montarGestao(hojeInicio, em7, d7, d14, d30, ctx) {
  const d5 = new Date(Date.now() - 5 * DIA);
  const [
    fin,
    aVencerAgg,
    aVencerCount,
    stages,
    leadsPorEtapa,
    novosLeads7,
    leadsConvertidos30,
    leadsParados,
    projetosPorStatus,
    projetosSemResp,
    projetosParados,
    aguardandoClienteCards,
    abertasPorResp,
    atrasadasPorResp,
    clientesTotal,
    clientesNovos30,
    clientesProspect,
    clientesQuerendoMais,
    tarefasAtrasadasEquipe,
    docsPendentes,
    docsPendentesCount,
    docsAguardandoClienteCount,
    atividadeRecente
  ] = await Promise.all([
    resumo("EMPRESA", ctx),
    prisma.conta.aggregate({
      _sum: { valor: true },
      where: { deletedAt: null, pago: false, tipo: "PAGAR", vencimento: { gte: hojeInicio, lte: em7 } }
    }),
    prisma.conta.count({
      where: { deletedAt: null, pago: false, tipo: "PAGAR", vencimento: { gte: hojeInicio, lte: em7 } }
    }),
    listStages(),
    prisma.lead.groupBy({
      by: ["pipelineStageId"],
      where: { deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
      _count: { _all: true },
      _sum: { valorEstimado: true }
    }),
    prisma.lead.count({ where: { deletedAt: null, createdAt: { gte: d7 } } }),
    prisma.lead.count({ where: { convertidoEmClienteId: { not: null }, updatedAt: { gte: d30 } } }),
    prisma.lead.count({ where: { deletedAt: null, convertidoEmClienteId: null, perdidoEm: null, updatedAt: { lt: d14 } } }),
    prisma.projeto.groupBy({ by: ["status"], where: { deletedAt: null }, _count: { _all: true } }),
    prisma.projeto.count({ where: { deletedAt: null, responsavelId: null } }),
    prisma.projeto.count({ where: { deletedAt: null, status: "ATIVO", updatedAt: { lt: d14 } } }),
    prisma.card.findMany({
      where: { deletedAt: null, status: "AGUARDANDO_CLIENTE" },
      select: { projetoId: true },
      distinct: ["projetoId"]
    }),
    prisma.card.groupBy({
      by: ["responsavelId"],
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: { not: null } },
      _count: { _all: true }
    }),
    prisma.card.groupBy({
      by: ["responsavelId"],
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: { not: null }, prazo: { lt: hojeInicio } },
      _count: { _all: true }
    }),
    prisma.cliente.count({ where: { deletedAt: null } }),
    prisma.cliente.count({ where: { deletedAt: null, createdAt: { gte: d30 } } }),
    prisma.cliente.count({ where: { deletedAt: null, situacaoComercial: "PROSPECT" } }),
    // Clientes (ativos/inativos) com oportunidade aberta no funil = upsell em andamento.
    prisma.cliente.count({
      where: {
        deletedAt: null,
        situacaoComercial: { in: ["ATIVO", "INATIVO"] },
        leadsPortal: { some: { deletedAt: null, convertidoEmClienteId: null, perdidoEm: null } }
      }
    }),
    prisma.card.count({ where: { deletedAt: null, status: { not: "CONCLUIDO" }, prazo: { lt: hojeInicio } } }),
    prisma.documento.findMany({
      where: { deletedAt: null, status: { in: ["RASCUNHO", "EM_REVISAO"] } },
      include: { cliente: { select: { nome: true } } },
      orderBy: { updatedAt: "desc" },
      take: 6
    }),
    prisma.documento.count({ where: { deletedAt: null, status: { in: ["RASCUNHO", "EM_REVISAO"] } } }),
    // Documentos enviados esperando o CLIENTE (aceite de proposta / assinatura) há +5 dias.
    prisma.documento.count({
      where: {
        deletedAt: null,
        OR: [
          { propostaStatus: "PENDENTE", propostaRespondidaEm: null, propostaSolicitadaEm: { lt: d5 } },
          { assinaturaSolicitadaEm: { lt: d5 }, assinadoEm: null }
        ]
      }
    }),
    prisma.activityLog.findMany({
      where: { NOT: { acao: "login" } },
      orderBy: { createdAt: "desc" },
      take: 8,
      include: { user: { select: { nome: true } } }
    })
  ]);
  const etapaMap = new Map(leadsPorEtapa.map((e) => [e.pipelineStageId, e]));
  const funilEtapas = stages.map((s) => {
    const e = etapaMap.get(s.id);
    return { nome: s.nome, count: e?._count._all ?? 0, valor: e?._sum.valorEstimado ?? 0 };
  });
  const funilTotal = funilEtapas.reduce((acc, e) => acc + e.count, 0);
  const funilValor = funilEtapas.reduce((acc, e) => acc + e.valor, 0);
  const projStatus = { ATIVO: 0, PAUSADO: 0, CONCLUIDO: 0 };
  for (const p of projetosPorStatus) projStatus[p.status] = p._count._all;
  const respIds = abertasPorResp.map((r) => r.responsavelId).filter((x) => !!x);
  const usuarios = respIds.length ? await prisma.user.findMany({ where: { id: { in: respIds } }, select: { id: true, nome: true } }) : [];
  const nomeById = new Map(usuarios.map((u) => [u.id, u.nome]));
  const atrasadasById = new Map(atrasadasPorResp.map((r) => [r.responsavelId, r._count._all]));
  const equipe = abertasPorResp.filter((r) => r.responsavelId).map((r) => ({
    nome: nomeById.get(r.responsavelId) ?? "\u2014",
    abertas: r._count._all,
    atrasadas: atrasadasById.get(r.responsavelId) ?? 0
  })).sort((a, b) => b.atrasadas - a.atrasadas || b.abertas - a.abertas).slice(0, 6);
  const equipeMaxAbertas = Math.max(1, ...equipe.map((e) => e.abertas));
  return {
    financeiro: { ...fin, aVencer7: { total: aVencerAgg._sum.valor?.toNumber() ?? 0, count: aVencerCount } },
    funil: {
      etapas: funilEtapas,
      total: funilTotal,
      valor: funilValor,
      novos7: novosLeads7,
      convertidos30: leadsConvertidos30,
      parados: leadsParados
    },
    projetos: {
      ativos: projStatus.ATIVO ?? 0,
      pausados: projStatus.PAUSADO ?? 0,
      concluidos: projStatus.CONCLUIDO ?? 0,
      aguardandoCliente: aguardandoClienteCards.length,
      semResponsavel: projetosSemResp,
      parados: projetosParados
    },
    equipe,
    equipeMaxAbertas,
    clientes: { total: clientesTotal, novos30: clientesNovos30, prospects: clientesProspect, querendoMais: clientesQuerendoMais },
    tarefasAtrasadasEquipeCount: tarefasAtrasadasEquipe,
    docsPendentes: docsPendentes.map((d) => ({ id: d.id, titulo: d.titulo, status: d.status, updatedAt: d.updatedAt, cliente: d.cliente })),
    docsPendentesCount,
    docsAguardandoClienteCount,
    atividadeRecente: atividadeRecente.map((a) => ({ id: a.id, acao: a.acao, createdAt: a.createdAt, usuario: a.user?.nome ?? null }))
  };
}
async function montarSistema() {
  const [s, errosAbertos, incidentesAbertos, sessoesAtivas] = await Promise.all([
    saude(),
    prisma.errorLog.count({ where: { resolvido: false, ignorado: false } }),
    prisma.incidente.count({ where: { status: { in: ["ABERTO", "RECONHECIDO"] } } }),
    prisma.session.count({ where: { expiresAt: { gt: /* @__PURE__ */ new Date() } } })
  ]);
  const idadeMin = (d) => d ? Math.round((Date.now() - new Date(d).getTime()) / 6e4) : null;
  return {
    statusGeral: s.statusGeral,
    heapUsoPct: s.memoria.heapUsoPct,
    loopP99: s.memoria.loopP99,
    db: s.db,
    errosAbertos,
    incidentesAbertos,
    sessoesAtivas,
    conexoesSocket: s.conexoesSocket,
    uptimeSeg: s.uptimeSeg,
    ambiente: s.ambiente,
    nodeVersao: s.nodeVersao,
    idadeLembreteMin: idadeMin(s.jobs.ultimoLembreteEm),
    idadeScanMin: idadeMin(s.jobs.ultimoScanEm)
  };
}

// src/modules/dashboard/dashboard.router.ts
var dashboardRouter = router({
  resumo: funcionarioProcedure.query(({ ctx }) => dashboard(ctx.user.id, ctx.user.role))
});

// src/modules/mensagens/mensagens.router.ts
import { z as z11 } from "zod";
var mensagensRouter = router({
  listConversas: funcionarioProcedure.input(z11.object({ arquivadas: z11.boolean().optional() }).optional()).query(({ input, ctx }) => listConversas(ctx.user.id, input?.arquivadas ?? false)),
  usuarios: funcionarioProcedure.query(({ ctx }) => listUsuarios2(ctx.user.id)),
  clientes: funcionarioProcedure.input(z11.object({ busca: z11.string().optional() }).optional()).query(({ input }) => listClientesParaChamado(input?.busca)),
  chamadosDoCliente: funcionarioProcedure.input(z11.object({ clienteId: z11.string() })).query(({ input, ctx }) => listChamadosDoCliente(input.clienteId, ctx.user.id)),
  info: funcionarioProcedure.input(conversaIdSchema).query(({ input, ctx }) => getConversaInfo(input.conversaId, ctx.user.id)),
  startIndividual: funcionarioProcedure.input(startIndividualSchema).mutation(({ input, ctx }) => startIndividual(ctx.user.id, input.outroUserId)),
  createGrupo: funcionarioProcedure.input(createGrupoSchema).mutation(({ input, ctx }) => createGrupo(ctx.user.id, input.nome, input.participantIds)),
  // Gestão de grupo / conversa.
  renomearGrupo: funcionarioProcedure.input(renomearGrupoSchema).mutation(({ input, ctx }) => renomearGrupo(input.conversaId, ctx.user.id, input.nome)),
  addParticipantes: funcionarioProcedure.input(addParticipantesSchema).mutation(({ input, ctx }) => addParticipantes(input.conversaId, ctx.user.id, input.userIds)),
  removerParticipante: funcionarioProcedure.input(gerirParticipanteSchema).mutation(({ input, ctx }) => removerParticipante(input.conversaId, ctx.user.id, input.userId)),
  sair: funcionarioProcedure.input(conversaIdSchema).mutation(({ input, ctx }) => sairDaConversa(input.conversaId, ctx.user.id)),
  apagar: funcionarioProcedure.input(conversaIdSchema).mutation(({ input, ctx }) => apagarConversa(input.conversaId, ctx.user.id)),
  // Preferências por usuário.
  fixar: funcionarioProcedure.input(togglePreferenciaSchema).mutation(({ input, ctx }) => fixar(input.conversaId, ctx.user.id, input.ligar)),
  silenciar: funcionarioProcedure.input(togglePreferenciaSchema).mutation(({ input, ctx }) => silenciar(input.conversaId, ctx.user.id, input.ligar)),
  arquivar: funcionarioProcedure.input(togglePreferenciaSchema).mutation(({ input, ctx }) => arquivar(input.conversaId, ctx.user.id, input.ligar)),
  // Chamados/tickets.
  iniciarChamado: funcionarioProcedure.input(iniciarChamadoSchema).mutation(({ input, ctx }) => iniciarChamado(ctx.user.id, input.clienteId, input.assunto, input.prioridade)),
  setStatus: funcionarioProcedure.input(setChamadoStatusSchema).mutation(({ input, ctx }) => setChamadoStatus(input.conversaId, ctx.user.id, input.status)),
  resolver: funcionarioProcedure.input(conversaIdSchema).mutation(({ input, ctx }) => resolverChamado(input.conversaId, ctx.user.id)),
  reabrir: funcionarioProcedure.input(conversaIdSchema).mutation(({ input, ctx }) => reabrirChamado(input.conversaId, ctx.user.id)),
  setResponsavel: funcionarioProcedure.input(setChamadoResponsavelSchema).mutation(({ input, ctx }) => setChamadoResponsavel(input.conversaId, ctx.user.id, input.responsavelId)),
  setAssunto: funcionarioProcedure.input(setChamadoAssuntoSchema).mutation(({ input, ctx }) => setChamadoAssunto(input.conversaId, ctx.user.id, input.assunto)),
  setPrioridade: funcionarioProcedure.input(setChamadoPrioridadeSchema).mutation(({ input, ctx }) => setChamadoPrioridade(input.conversaId, ctx.user.id, input.prioridade)),
  // Mensagens.
  listMensagens: funcionarioProcedure.input(conversaIdSchema).query(({ input, ctx }) => listMensagens(input.conversaId, ctx.user.id)),
  send: funcionarioProcedure.input(sendMensagemSchema).mutation(({ input, ctx }) => sendMensagem(input.conversaId, input.conteudo, ctx.user.id)),
  editar: funcionarioProcedure.input(editarMensagemSchema).mutation(({ input, ctx }) => editarMensagem(input.mensagemId, ctx.user.id, input.conteudo)),
  apagarMensagem: funcionarioProcedure.input(mensagemIdSchema).mutation(({ input, ctx }) => apagarMensagem(input.mensagemId, ctx.user.id)),
  markRead: funcionarioProcedure.input(conversaIdSchema).mutation(({ input, ctx }) => markRead2(input.conversaId, ctx.user.id))
});

// src/modules/documentos/documentos.router.ts
import { z as z12 } from "zod";

// src/modules/documentos/operadoras.service.ts
import { TRPCError as TRPCError8 } from "@trpc/server";
async function seedIfEmpty2() {
  if (await prisma.operadora.count() === 0) {
    await prisma.operadora.createMany({ data: OPERADORAS_COMUNS.map((nome, ordem) => ({ nome, ordem })) });
  }
}
async function listOperadoras() {
  await seedIfEmpty2();
  return prisma.operadora.findMany({ orderBy: [{ ordem: "asc" }, { nome: "asc" }], select: { id: true, nome: true } });
}
async function criarOperadora(nome) {
  const max = await prisma.operadora.aggregate({ _max: { ordem: true } });
  return prisma.operadora.create({ data: { nome: nome.trim(), ordem: (max._max.ordem ?? -1) + 1 } });
}
async function renomearOperadora(id, nome) {
  return prisma.operadora.update({ where: { id }, data: { nome: nome.trim() } }).catch(() => {
    throw new TRPCError8({ code: "NOT_FOUND", message: "Operadora n\xE3o encontrada." });
  });
}
async function removerOperadora(id) {
  await prisma.operadora.deleteMany({ where: { id } });
  return { ok: true };
}

// src/modules/documentos/documentos.router.ts
var nomeOperadora = z12.string().trim().min(1, "Informe o nome").max(80);
var documentosRouter = router({
  // Catálogo de modelos: FUNCIONARIO usa (list/get); administrar (criar/editar/remover) é ADMIN+.
  modelos: router({
    list: funcionarioProcedure.query(() => listModelos()),
    get: funcionarioProcedure.input(z12.object({ id: z12.string() })).query(({ input }) => getModelo(input.id)),
    create: adminProcedure.input(createModeloSchema).mutation(({ input }) => createModelo(input)),
    update: adminProcedure.input(updateModeloSchema).mutation(({ input }) => updateModelo(input)),
    remove: adminProcedure.input(z12.object({ id: z12.string() })).mutation(({ input }) => removeModelo(input.id))
  }),
  // Catálogo de operadoras: FUNCIONARIO consulta (list); administrar é ADMIN+.
  operadoras: router({
    list: funcionarioProcedure.query(() => listOperadoras()),
    criar: adminProcedure.input(z12.object({ nome: nomeOperadora })).mutation(({ input }) => criarOperadora(input.nome)),
    renomear: adminProcedure.input(z12.object({ id: z12.string().min(1), nome: nomeOperadora })).mutation(({ input }) => renomearOperadora(input.id, input.nome)),
    remover: adminProcedure.input(z12.object({ id: z12.string().min(1) })).mutation(({ input }) => removerOperadora(input.id))
  }),
  list: funcionarioProcedure.input(z12.object({ status: statusDocumentoEnum.optional() }).optional()).query(({ input }) => listDocumentos(input?.status)),
  get: funcionarioProcedure.input(z12.object({ id: z12.string() })).query(({ input }) => getDocumento(input.id)),
  create: funcionarioProcedure.input(createDocumentoSchema).mutation(({ input, ctx }) => createDocumento(input, ctx.user.id)),
  /** Proposta inteligente: monta a proposta a partir dos serviços (com preços) do catálogo. */
  criarProposta: funcionarioProcedure.input(criarPropostaSchema).mutation(({ input, ctx }) => criarProposta(input, ctx.user.id)),
  /** Contrato inteligente: monta o contrato a partir dos serviços contratados + vigência. */
  criarContrato: funcionarioProcedure.input(criarContratoSchema).mutation(({ input, ctx }) => criarContrato(input, ctx.user.id)),
  /** Contexto do cliente (serviços contratados, investimento, proposta aceita) p/ auto-preencher. */
  contextoCliente: funcionarioProcedure.input(contextoClienteDocSchema).query(({ input }) => contextoClienteDoc(input)),
  /** Gera um documento (briefing/proposta/contrato) do modelo com os dados do lead. */
  gerarParaLead: funcionarioProcedure.input(z12.object({ leadId: z12.string(), tipo: z12.enum(["briefing", "proposta", "contrato"]) })).mutation(({ input, ctx }) => gerarParaLead(input.leadId, input.tipo, { id: ctx.user.id })),
  updateConteudo: funcionarioProcedure.input(updateConteudoSchema).mutation(({ input, ctx }) => updateConteudo(input.id, input.conteudo, ctx.user.id)),
  setStatus: funcionarioProcedure.input(setStatusDocumentoSchema).mutation(({ input, ctx }) => setStatus(input.id, input.status, ctx.user.id)),
  remove: funcionarioProcedure.input(z12.object({ id: z12.string() })).mutation(({ input }) => removeDocumento(input.id)),
  // ── IA (OpenAI) — a disponibilidade é consultada via `ia.disponivel` ──
  gerarComIA: funcionarioProcedure.input(gerarComIASchema).mutation(({ input, ctx }) => gerarComIA(input, ctx.user.id)),
  melhorarComIA: funcionarioProcedure.input(melhorarComIASchema).mutation(({ input, ctx }) => melhorarComIA(input.id, input.instrucao, ctx.user.id)),
  resumirReuniao: funcionarioProcedure.input(resumirReuniaoSchema).mutation(({ input, ctx }) => resumirReuniao(input, ctx.user.id)),
  gerarPauta: funcionarioProcedure.input(gerarPautaSchema).mutation(({ input, ctx }) => gerarPautaReuniao(input, ctx.user.id))
});

// src/modules/assinaturas/assinaturas.router.ts
import { z as z13 } from "zod";

// src/modules/assinaturas/assinaturas.service.ts
import { TRPCError as TRPCError9 } from "@trpc/server";

// src/lib/hash.ts
import { createHash } from "crypto";
function hashConteudo(conteudo) {
  return createHash("sha256").update(conteudo, "utf8").digest("hex");
}

// src/modules/assinaturas/assinaturas.service.ts
var linkAssinatura = (token) => `${config.WEB_ORIGIN}/assinar/${token}`;
async function reconciliarLeadDoDocumento(documentoId) {
  const passo = await prisma.leadPasso.findFirst({ where: { documentoId }, select: { leadId: true } });
  if (passo) {
    await reconciliarPassosAuto(passo.leadId);
    await avancarSeChecklistCompleto(passo.leadId, null).catch(() => {
    });
  }
}
async function solicitar(documentoId, ator, avisarPorEmail = true) {
  const doc = await prisma.documento.findFirst({
    where: { id: documentoId, deletedAt: null },
    include: { cliente: { select: { nome: true, email: true } } }
  });
  if (!doc) throw new TRPCError9({ code: "NOT_FOUND", message: "Documento n\xE3o encontrado." });
  if (!doc.cliente) {
    throw new TRPCError9({ code: "BAD_REQUEST", message: "Vincule um cliente ao documento antes de solicitar assinatura." });
  }
  if (!doc.cliente.email) {
    throw new TRPCError9({ code: "BAD_REQUEST", message: "O cliente precisa ter um e-mail cadastrado para assinar." });
  }
  const hash = hashConteudo(doc.conteudo);
  await prisma.assinatura.deleteMany({ where: { documentoId } });
  await prisma.$transaction([
    prisma.assinatura.create({
      data: { documentoId, papel: "CLIENTE", nome: doc.cliente.nome, email: doc.cliente.email, ordem: 0, hashDocumento: hash, token: gerarTokenPublico() }
    }),
    prisma.assinatura.create({
      data: { documentoId, papel: "MEDCONSULTORIA", nome: ator.nome, email: ator.email, ordem: 1, hashDocumento: hash, token: gerarTokenPublico() }
    }),
    prisma.documento.update({ where: { id: documentoId }, data: { assinaturaSolicitadaEm: /* @__PURE__ */ new Date(), assinadoEm: null } })
  ]);
  const assinaturas = await prisma.assinatura.findMany({ where: { documentoId }, orderBy: { ordem: "asc" } });
  if (avisarPorEmail) {
    for (const a of assinaturas) {
      if (!a.email) continue;
      void enviarEmailTemplate("assinatura_solicitada", a.email, {
        nome: a.nome,
        documento: doc.titulo,
        link: linkAssinatura(a.token)
      }).catch(() => {
      });
    }
  }
  await prisma.activityLog.create({
    data: { userId: ator.id, acao: "documento.assinatura_solicitada", entidadeTipo: "documento", entidadeId: documentoId }
  });
  await reconciliarLeadDoDocumento(documentoId);
  return assinaturas.map((a) => ({ id: a.id, papel: a.papel, nome: a.nome, token: a.token, status: a.status }));
}
async function listarDoDocumento(documentoId) {
  const doc = await prisma.documento.findUnique({ where: { id: documentoId }, select: { conteudo: true } });
  const hashAtual = doc ? hashConteudo(doc.conteudo) : null;
  const assinaturas = await prisma.assinatura.findMany({ where: { documentoId }, orderBy: { ordem: "asc" } });
  return assinaturas.map((a) => ({
    id: a.id,
    papel: a.papel,
    nome: a.nome,
    email: a.email,
    status: a.status,
    metodo: a.metodo,
    assinadoEm: a.assinadoEm,
    ip: a.ip,
    token: a.token,
    hashDocumento: a.hashDocumento,
    integro: a.status === "ASSINADO" ? a.hashDocumento === hashAtual : true
  }));
}
async function getPorToken(token) {
  const a = await prisma.assinatura.findUnique({
    where: { token },
    include: { documento: { select: { titulo: true, conteudo: true } } }
  });
  if (!a) throw new TRPCError9({ code: "NOT_FOUND", message: "Link de assinatura inv\xE1lido." });
  const hashAtual = hashConteudo(a.documento.conteudo);
  const outras = await prisma.assinatura.findMany({
    where: { documentoId: a.documentoId },
    orderBy: { ordem: "asc" },
    select: { papel: true, nome: true, status: true, assinadoEm: true }
  });
  return {
    documento: { titulo: a.documento.titulo, conteudo: a.documento.conteudo },
    signatario: { nome: a.nome, papel: a.papel },
    status: a.status,
    assinadoEm: a.assinadoEm,
    metodo: a.metodo,
    nomeDigitado: a.nomeDigitado,
    imagem: a.imagem,
    // Se o conteúdo mudou depois do envio, bloqueia a assinatura (integridade).
    conteudoAlterado: a.hashDocumento !== hashAtual,
    todas: outras
  };
}
async function assinar(input, ip, userAgent) {
  const a = await prisma.assinatura.findUnique({
    where: { token: input.token },
    include: { documento: { select: { id: true, titulo: true, conteudo: true, criadoPorId: true } } }
  });
  if (!a) throw new TRPCError9({ code: "NOT_FOUND", message: "Link de assinatura inv\xE1lido." });
  if (a.status === "ASSINADO") return { ok: true, concluido: false, jaAssinado: true };
  if (a.hashDocumento !== hashConteudo(a.documento.conteudo)) {
    throw new TRPCError9({
      code: "BAD_REQUEST",
      message: "O documento foi alterado ap\xF3s o envio. Pe\xE7a um novo link de assinatura."
    });
  }
  await prisma.assinatura.update({
    where: { id: a.id },
    data: {
      status: "ASSINADO",
      metodo: input.metodo,
      imagem: input.metodo === "DESENHO" ? input.imagem ?? null : null,
      nomeDigitado: input.metodo === "DIGITADO" ? input.nomeDigitado?.trim() ?? null : null,
      ip: ip ?? null,
      userAgent: userAgent ?? null,
      assinadoEm: /* @__PURE__ */ new Date()
    }
  });
  const pendentes = await prisma.assinatura.count({ where: { documentoId: a.documentoId, status: { not: "ASSINADO" } } });
  const concluido = pendentes === 0;
  if (concluido) {
    await prisma.documento.update({ where: { id: a.documentoId }, data: { assinadoEm: /* @__PURE__ */ new Date() } });
    await prisma.activityLog.create({
      data: { acao: "documento.assinado", entidadeTipo: "documento", entidadeId: a.documentoId }
    });
    await reconciliarLeadDoDocumento(a.documentoId);
    if (a.documento.criadoPorId) {
      void notificar(
        a.documento.criadoPorId,
        "documento_revisao",
        { documento: `${a.documento.titulo} (assinado por todos)` },
        { entidadeTipo: "documento", entidadeId: a.documentoId }
      ).catch(() => {
      });
    }
  }
  return { ok: true, concluido };
}

// src/modules/assinaturas/assinaturas.router.ts
var assinaturasRouter = router({
  // Interno (equipe): solicita e acompanha as assinaturas do documento.
  solicitar: funcionarioProcedure.input(z13.object({ documentoId: z13.string(), avisarPorEmail: z13.boolean().optional() })).mutation(
    ({ input, ctx }) => solicitar(
      input.documentoId,
      { id: ctx.user.id, nome: ctx.user.nome, email: ctx.user.email },
      input.avisarPorEmail ?? true
    )
  ),
  doDocumento: funcionarioProcedure.input(z13.object({ documentoId: z13.string() })).query(({ input }) => listarDoDocumento(input.documentoId)),
  // Público (por token, sem login) — página de assinatura.
  porToken: publicProcedure.input(z13.object({ token: z13.string().min(1) })).query(({ input }) => getPorToken(input.token)),
  assinar: publicProcedure.input(assinarSchema).mutation(
    ({ input, ctx }) => assinar(input, ctx.req.ip, ctx.req.headers["user-agent"])
  )
});

// src/modules/propostas/propostas.router.ts
import { z as z14 } from "zod";

// src/modules/propostas/propostas.service.ts
import { randomUUID } from "crypto";
import { TRPCError as TRPCError10 } from "@trpc/server";
var linkProposta = (token) => `${config.WEB_ORIGIN}/proposta/${token}`;
async function alvosDaEquipe(clienteId) {
  const [cliente, admins] = await Promise.all([
    prisma.cliente.findUnique({ where: { id: clienteId }, select: { responsavelId: true } }),
    prisma.user.findMany({
      where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
      select: { id: true }
    })
  ]);
  const alvos = new Set(admins.map((a) => a.id));
  if (cliente?.responsavelId) alvos.add(cliente.responsavelId);
  return [...alvos];
}
async function habilitarAceite(documentoId, ator, avisarPorEmail = true) {
  const doc = await prisma.documento.findFirst({
    where: { id: documentoId, deletedAt: null },
    include: { cliente: { select: { id: true, nome: true, email: true } } }
  });
  if (!doc) throw new TRPCError10({ code: "NOT_FOUND", message: "Documento n\xE3o encontrado." });
  if (!doc.cliente) {
    throw new TRPCError10({ code: "BAD_REQUEST", message: "Vincule um cliente \xE0 proposta antes de habilitar o aceite." });
  }
  const token = randomUUID();
  await prisma.documento.update({
    where: { id: documentoId },
    data: {
      propostaToken: token,
      propostaStatus: "PENDENTE",
      propostaHash: hashConteudo(doc.conteudo),
      propostaSolicitadaEm: /* @__PURE__ */ new Date(),
      propostaRespondidaEm: null,
      propostaRespIp: null,
      propostaMotivoRecusa: null
    }
  });
  if (avisarPorEmail && doc.cliente.email) {
    void enviarEmailTemplate("proposta_para_aceite", doc.cliente.email, {
      nome: doc.cliente.nome,
      documento: doc.titulo,
      link: linkProposta(token)
    }).catch(() => {
    });
  }
  await prisma.activityLog.create({
    data: { userId: ator.id, acao: "proposta.aceite_habilitado", entidadeTipo: "documento", entidadeId: documentoId }
  });
  void avancarLeadPorClienteAuto(doc.cliente.id, "proposta", "Proposta enviada ao cliente para aceite").catch(() => {
  });
  return { token, link: linkProposta(token) };
}
async function statusDoDocumento(documentoId) {
  const doc = await prisma.documento.findUnique({
    where: { id: documentoId },
    select: {
      conteudo: true,
      propostaToken: true,
      propostaStatus: true,
      propostaHash: true,
      propostaSolicitadaEm: true,
      propostaRespondidaEm: true,
      propostaMotivoRecusa: true,
      propostaRespIp: true
    }
  });
  if (!doc || !doc.propostaToken) return null;
  return {
    token: doc.propostaToken,
    link: linkProposta(doc.propostaToken),
    status: doc.propostaStatus,
    solicitadaEm: doc.propostaSolicitadaEm,
    respondidaEm: doc.propostaRespondidaEm,
    motivoRecusa: doc.propostaMotivoRecusa,
    ip: doc.propostaRespIp,
    // Se o conteúdo mudou depois de habilitar, o cliente não consegue aceitar (integridade).
    conteudoAlterado: doc.propostaStatus === "PENDENTE" && doc.propostaHash !== hashConteudo(doc.conteudo)
  };
}
async function getPorToken2(token) {
  const doc = await prisma.documento.findUnique({
    where: { propostaToken: token },
    select: {
      titulo: true,
      conteudo: true,
      propostaStatus: true,
      propostaHash: true,
      propostaRespondidaEm: true,
      propostaMotivoRecusa: true,
      cliente: { select: { nome: true } },
      modelo: { select: { tipo: true } }
    }
  });
  if (!doc) throw new TRPCError10({ code: "NOT_FOUND", message: "Link de proposta inv\xE1lido." });
  return {
    documento: { titulo: doc.titulo, conteudo: doc.conteudo },
    clienteNome: doc.cliente?.nome ?? null,
    tipo: doc.modelo?.tipo ?? "PROPOSTA",
    status: doc.propostaStatus,
    respondidaEm: doc.propostaRespondidaEm,
    motivoRecusa: doc.propostaMotivoRecusa,
    conteudoAlterado: doc.propostaStatus === "PENDENTE" && doc.propostaHash !== hashConteudo(doc.conteudo)
  };
}
async function responder(input, ip) {
  const doc = await prisma.documento.findUnique({
    where: { propostaToken: input.token },
    select: { id: true, titulo: true, conteudo: true, propostaStatus: true, propostaHash: true, clienteId: true, criadoPorId: true, itens: true, cliente: { select: { nome: true } } }
  });
  if (!doc) throw new TRPCError10({ code: "NOT_FOUND", message: "Link de proposta inv\xE1lido." });
  if (doc.propostaStatus !== "PENDENTE") {
    return { ok: true, jaRespondida: true, decisao: doc.propostaStatus };
  }
  if (doc.propostaHash !== hashConteudo(doc.conteudo)) {
    throw new TRPCError10({
      code: "BAD_REQUEST",
      message: "A proposta foi alterada ap\xF3s o envio. Pe\xE7a um novo link \xE0 MedConsultoria."
    });
  }
  const aceita = input.decisao === "ACEITA";
  await prisma.documento.update({
    where: { id: doc.id },
    data: {
      propostaStatus: aceita ? "ACEITA" : "RECUSADA",
      propostaRespondidaEm: /* @__PURE__ */ new Date(),
      propostaRespIp: ip ?? null,
      propostaMotivoRecusa: aceita ? null : input.motivo?.trim() || null
    }
  });
  await prisma.activityLog.create({
    data: {
      acao: aceita ? "proposta.aceita" : "proposta.recusada",
      entidadeTipo: "documento",
      entidadeId: doc.id,
      dados: aceita ? void 0 : { motivo: input.motivo?.trim() ?? "" }
    }
  });
  const nomeCliente = doc.cliente?.nome ?? "O cliente";
  if (doc.clienteId) {
    if (aceita) {
      void avancarLeadPorClienteAuto(doc.clienteId, "negociacao", "Proposta aceita pelo cliente").catch(() => {
      });
      const clienteId = doc.clienteId;
      const criadoPorId = doc.criadoPorId;
      const itensAceitos = Array.isArray(doc.itens) ? doc.itens : [];
      void (async () => {
        const atorId = criadoPorId ?? (await prisma.cliente.findUnique({ where: { id: clienteId }, select: { responsavelId: true } }))?.responsavelId ?? (await prisma.user.findFirst({ where: { role: { in: ["ADMIN", "ROOT"] }, ativo: true, deletedAt: null }, select: { id: true } }))?.id ?? null;
        if (!atorId) return;
        if (itensAceitos.length) {
          const { sincronizarServicosContratados } = await import("./servicos-cliente.service-SNG7TMAE.js");
          await sincronizarServicosContratados(clienteId, itensAceitos, { id: atorId });
        }
        const lead = await prisma.lead.findFirst({
          where: { clienteId, deletedAt: null, convertidoEmClienteId: null },
          orderBy: { createdAt: "desc" },
          select: { id: true }
        });
        const { gerarContratoAutoParaCliente } = await import("./documentos.service-Q3JFFZKK.js");
        await gerarContratoAutoParaCliente(clienteId, atorId, { leadId: lead?.id });
      })().catch(() => {
      });
    }
    for (const userId of await alvosDaEquipe(doc.clienteId)) {
      void notificar(
        userId,
        aceita ? "proposta_aceita" : "proposta_recusada",
        aceita ? { cliente: nomeCliente, documento: doc.titulo } : { cliente: nomeCliente, documento: doc.titulo, motivo: input.motivo?.trim() || "(n\xE3o informado)" },
        { entidadeTipo: "documento", entidadeId: doc.id }
      ).catch(() => {
      });
    }
  }
  return { ok: true, decisao: aceita ? "ACEITA" : "RECUSADA" };
}

// src/modules/propostas/propostas.router.ts
var propostasRouter = router({
  // Interno (equipe): habilita o aceite e acompanha o estado da proposta.
  habilitar: funcionarioProcedure.input(z14.object({ documentoId: z14.string(), avisarPorEmail: z14.boolean().optional() })).mutation(
    ({ input, ctx }) => habilitarAceite(input.documentoId, { id: ctx.user.id, nome: ctx.user.nome }, input.avisarPorEmail ?? true)
  ),
  doDocumento: funcionarioProcedure.input(z14.object({ documentoId: z14.string() })).query(({ input }) => statusDoDocumento(input.documentoId)),
  // Público (por token, sem login) — página de aceite/recusa da proposta.
  porToken: publicProcedure.input(z14.object({ token: z14.string().min(1) })).query(({ input }) => getPorToken2(input.token)),
  responder: publicProcedure.input(responderPropostaSchema).mutation(({ input, ctx }) => responder(input, ctx.req.ip))
});

// src/modules/portal/portal.router.ts
import { z as z15 } from "zod";

// src/modules/portal/portal.service.ts
import { TRPCError as TRPCError11 } from "@trpc/server";
async function meusDados(clienteId) {
  const c = await prisma.cliente.findUnique({
    where: { id: clienteId },
    select: { nome: true, tipo: true, documento: true, email: true, telefone: true }
  });
  if (!c) throw new TRPCError11({ code: "NOT_FOUND", message: "Cadastro n\xE3o encontrado." });
  return c;
}
async function atualizarMeusDados(clienteId, userId, dados) {
  const nome = dados.nome.trim();
  await prisma.cliente.update({
    where: { id: clienteId },
    data: {
      nome,
      tipo: dados.tipo,
      documento: dados.documento?.trim() || null,
      email: dados.email?.trim() || null,
      telefone: dados.telefone?.trim() || null
    }
  });
  await prisma.user.update({ where: { id: userId }, data: { nome } }).catch(() => {
  });
  await prisma.activityLog.create({ data: { userId, acao: "cliente.dados_atualizados_portal", entidadeTipo: "cliente", entidadeId: clienteId } }).catch(() => {
  });
  return { ok: true, nome };
}
async function resumo2(clienteId) {
  const agora = /* @__PURE__ */ new Date();
  const [cliente, projetos, documentos, reunioes, leadAtivo, totalEtapas, paraAssinar, leadPerdido, cardsAguardando, propostasPendentes] = await Promise.all([
    prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true } }),
    prisma.projeto.findMany({
      where: { clienteId, deletedAt: null },
      select: {
        id: true,
        nome: true,
        status: true,
        previsaoFim: true,
        // Só o status dos cartões (para calcular progresso) — nada interno vaza.
        cards: { where: { deletedAt: null }, select: { status: true } },
        // Próxima reunião do projeto (mesmo filtro seguro dos eventos do Portal).
        eventos: {
          where: { inicio: { gte: agora }, escopo: "EMPRESA", tipo: { in: ["REUNIAO", "COMPROMISSO"] } },
          orderBy: { inicio: "asc" },
          take: 1,
          select: { titulo: true, inicio: true }
        }
      },
      orderBy: { createdAt: "desc" }
    }),
    prisma.documento.findMany({
      where: { clienteId, deletedAt: null, status: "ENVIADO" },
      // Campos p/ a situação coerente (o cliente vê "Aceita"/"Assinado"/"Disponível"…).
      select: {
        id: true,
        titulo: true,
        updatedAt: true,
        status: true,
        propostaStatus: true,
        assinaturaSolicitadaEm: true,
        assinadoEm: true,
        modelo: { select: { tipo: true } }
      },
      orderBy: { updatedAt: "desc" }
    }),
    prisma.evento.findMany({
      // Só eventos voltados ao cliente: escopo EMPRESA e tipos de encontro
      // (reunião/compromisso). Lembretes/eventos pessoais internos NUNCA vazam.
      where: {
        clienteId,
        deletedAt: null,
        inicio: { gte: agora },
        escopo: "EMPRESA",
        tipo: { in: ["REUNIAO", "COMPROMISSO"] }
      },
      select: {
        id: true,
        titulo: true,
        inicio: true,
        fim: true,
        linkReuniao: true,
        tipo: true,
        local: true,
        descricao: true,
        clienteConfirmadoEm: true
      },
      orderBy: { inicio: "asc" },
      take: 10
    }),
    // Lead ativo ligado a este cliente (prospect ainda no funil, não desistido) → andamento.
    prisma.lead.findFirst({
      where: { clienteId, deletedAt: null, convertidoEmClienteId: null, perdidoEm: null },
      orderBy: { createdAt: "desc" },
      select: {
        pipelineStage: { select: { nome: true, chaveAuto: true, ordem: true } },
        servicos: { select: { id: true, nome: true }, orderBy: { ordem: "asc" } }
      }
    }),
    prisma.pipelineStage.count(),
    // Documentos aguardando a assinatura DESTE cliente — CTA "Assinar" direto no Portal.
    prisma.assinatura.findMany({
      where: { status: "PENDENTE", papel: "CLIENTE", documento: { clienteId, deletedAt: null } },
      select: { token: true, documento: { select: { titulo: true } } },
      orderBy: { criadoEm: "desc" }
    }),
    // Lead perdido ligado a este cliente (desistência/perda) → oferece retomar no Portal.
    prisma.lead.findFirst({
      where: { clienteId, deletedAt: null, convertidoEmClienteId: null, NOT: { perdidoEm: null } },
      select: { id: true }
    }),
    // "O que depende de você": cartões em AGUARDANDO_CLIENTE nos projetos do cliente.
    prisma.card.findMany({
      where: { status: "AGUARDANDO_CLIENTE", deletedAt: null, projeto: { clienteId, deletedAt: null } },
      select: { id: true, titulo: true, prazo: true, projeto: { select: { nome: true } } },
      orderBy: [{ prazo: "asc" }, { createdAt: "asc" }]
    }),
    // Propostas aguardando o aceite/recusa DESTE cliente — CTA direto no Portal.
    prisma.documento.findMany({
      where: { clienteId, deletedAt: null, propostaStatus: "PENDENTE", propostaToken: { not: null } },
      select: { titulo: true, propostaToken: true },
      orderBy: { propostaSolicitadaEm: "desc" }
    })
  ]);
  const projetosView = projetos.map((p) => {
    const total = p.cards.length;
    const concluidos = p.cards.filter((c) => c.status === "CONCLUIDO").length;
    return {
      id: p.id,
      nome: p.nome,
      status: p.status,
      previsaoFim: p.previsaoFim,
      total,
      concluidos,
      progresso: total ? Math.round(concluidos / total * 100) : 0,
      proximaReuniao: p.eventos[0] ?? null
    };
  });
  const aguardandoVoce = cardsAguardando.map((c) => ({ id: c.id, titulo: c.titulo, prazo: c.prazo, projeto: c.projeto.nome }));
  const atendimento = leadAtivo ? {
    etapa: leadAtivo.pipelineStage.nome,
    chave: leadAtivo.pipelineStage.chaveAuto,
    passo: leadAtivo.pipelineStage.ordem + 1,
    total: totalEtapas
  } : null;
  return {
    clienteNome: cliente?.nome ?? "Cliente",
    projetos: projetosView,
    aguardandoVoce,
    documentos,
    reunioes,
    atendimento,
    // O prospect pode desistir enquanto há atendimento ativo; se já desistiu (e não há
    // atendimento ativo), pode retomar. Cliente pleno (sem lead no funil) não vê nada disso.
    podeDesistir: !!leadAtivo,
    atendimentoEncerrado: !leadAtivo && !!leadPerdido,
    // Serviços que o cliente já pediu (pré-marca no autosserviço e mostra no atendimento).
    servicosAtuais: leadAtivo?.servicos ?? [],
    paraAssinar: paraAssinar.map((a) => ({ token: a.token, titulo: a.documento.titulo })),
    propostas: propostasPendentes.map((p) => ({ token: p.propostaToken, titulo: p.titulo }))
  };
}
async function getDocumento2(id, clienteId) {
  const doc = await prisma.documento.findFirst({
    where: { id, clienteId, status: "ENVIADO", deletedAt: null },
    select: { id: true, titulo: true, conteudo: true }
  });
  if (!doc) throw new TRPCError11({ code: "NOT_FOUND", message: "Documento n\xE3o encontrado" });
  return doc;
}

// src/modules/formularios/formularios.service.ts
import { TRPCError as TRPCError12 } from "@trpc/server";
var SEED = [
  {
    servico: "Desenvolvimento de site",
    titulo: "Briefing de site",
    descricao: "Conte pra gente sobre o site que voc\xEA precisa \u2014 quanto mais detalhes, melhor.",
    campos: [
      { rotulo: "Sobre o seu trabalho (o que faz, especialidades)", tipo: "TEXTO_LONGO", obrigatorio: true },
      { rotulo: "Qual o principal objetivo do site?", tipo: "TEXTO_LONGO", obrigatorio: true, ajuda: "Ex.: conseguir mais agendamentos, passar credibilidade\u2026" },
      { rotulo: "Quem \xE9 o seu p\xFAblico-alvo?", tipo: "TEXTO_CURTO", obrigatorio: true },
      { rotulo: "Quais p\xE1ginas voc\xEA quer?", tipo: "MULTIPLA", opcoes: ["In\xEDcio", "Sobre", "Servi\xE7os", "Blog", "Contato", "Agendamento"] },
      { rotulo: "J\xE1 tem dom\xEDnio (www)?", tipo: "SIM_NAO" },
      { rotulo: "J\xE1 tem logotipo / identidade visual?", tipo: "SIM_NAO" },
      { rotulo: "Sites de refer\xEAncia que voc\xEA gosta", tipo: "TEXTO_LONGO", ajuda: "Cole os links e diga o que gostou em cada um." },
      { rotulo: "Prazo desejado", tipo: "TEXTO_CURTO", ajuda: "Ex.: em 30 dias, sem pressa\u2026" },
      { rotulo: "Algo mais que devemos saber?", tipo: "TEXTO_LONGO" }
    ]
  },
  {
    servico: "Identidade visual (Branding)",
    titulo: "Briefing de identidade visual",
    descricao: "Vamos criar a cara da sua marca. Responda com calma \u2014 n\xE3o existe resposta errada.",
    campos: [
      { rotulo: "Nome da marca / como quer ser chamado(a)", tipo: "TEXTO_CURTO", obrigatorio: true },
      { rotulo: "O que a sua marca representa (valores, personalidade)", tipo: "TEXTO_LONGO", obrigatorio: true },
      { rotulo: "Cores de prefer\xEAncia", tipo: "TEXTO_CURTO" },
      { rotulo: "O que voc\xEA N\xC3O quer (cores/estilos a evitar)", tipo: "TEXTO_CURTO" },
      { rotulo: "Refer\xEAncias visuais que voc\xEA admira", tipo: "TEXTO_LONGO" },
      { rotulo: "Onde a marca ser\xE1 usada?", tipo: "MULTIPLA", opcoes: ["Site", "Redes sociais", "Fachada", "Jaleco/uniforme", "Papelaria", "Materiais impressos"] },
      { rotulo: "J\xE1 tem algum material atual (logo, cores)? Descreva.", tipo: "TEXTO_LONGO" },
      { rotulo: "Algo mais que devemos saber?", tipo: "TEXTO_LONGO" }
    ]
  },
  {
    servico: "Gest\xE3o de redes sociais",
    titulo: "Briefing de redes sociais",
    descricao: "Para cuidarmos das suas redes do jeito certo (e dentro das normas do CFM).",
    campos: [
      { rotulo: "Perfis atuais (@)", tipo: "TEXTO_CURTO" },
      { rotulo: "Qual o principal objetivo?", tipo: "ESCOLHA", opcoes: ["Autoridade/credibilidade", "Mais agendamentos", "Alcance/seguidores"], obrigatorio: true },
      { rotulo: "Quem \xE9 o seu p\xFAblico-alvo?", tipo: "TEXTO_CURTO", obrigatorio: true },
      { rotulo: "Tom de voz desejado", tipo: "TEXTO_CURTO", ajuda: "Ex.: acolhedor, t\xE9cnico, pr\xF3ximo\u2026" },
      { rotulo: "Frequ\xEAncia de postagem desejada", tipo: "ESCOLHA", opcoes: ["3x por semana", "Di\xE1rio", "A definir com a equipe"] },
      { rotulo: "Perfis de refer\xEAncia / concorrentes que voc\xEA acompanha", tipo: "TEXTO_LONGO" },
      { rotulo: "As fotos e v\xEDdeos: voc\xEA fornece ou a gente produz?", tipo: "ESCOLHA", opcoes: ["Eu forne\xE7o", "Voc\xEAs produzem", "Um pouco de cada"] },
      { rotulo: "Algo mais que devemos saber?", tipo: "TEXTO_LONGO" }
    ]
  }
];
async function seedSeVazio() {
  if (await prisma.formulario.count() > 0) return;
  for (const f of SEED) {
    const form = await prisma.formulario.create({
      data: {
        titulo: f.titulo,
        descricao: f.descricao,
        campos: {
          create: f.campos.map((c, i) => ({
            rotulo: c.rotulo,
            tipo: c.tipo,
            obrigatorio: c.obrigatorio ?? false,
            opcoes: c.opcoes ? JSON.stringify(c.opcoes) : null,
            ajuda: c.ajuda ?? null,
            ordem: i
          }))
        }
      }
    });
    const servico = await prisma.servico.findFirst({ where: { nome: f.servico }, select: { id: true } });
    if (servico) {
      const jaTem = await prisma.servicoRequisito.findFirst({ where: { servicoId: servico.id, formularioId: form.id } });
      if (!jaTem) {
        const max = await prisma.servicoRequisito.aggregate({ where: { servicoId: servico.id }, _max: { ordem: true } });
        await prisma.servicoRequisito.create({
          data: { servicoId: servico.id, titulo: f.titulo, tipo: "BRIEFING", obrigatorio: true, formularioId: form.id, ordem: (max._max.ordem ?? -1) + 1 }
        });
      }
    }
  }
}
async function listFormularios() {
  await seedSeVazio();
  return prisma.formulario.findMany({
    where: { ativo: true, interno: false },
    // internos (informação de 1 pergunta) são geridos pelo requisito
    orderBy: { titulo: "asc" },
    include: { _count: { select: { campos: true } } }
  });
}
function parseCampo(c) {
  return { ...c, opcoes: c.opcoes ? JSON.parse(c.opcoes) : [] };
}
async function getFormulario(id) {
  const form = await prisma.formulario.findUnique({
    where: { id },
    include: { campos: { orderBy: { ordem: "asc" } } }
  });
  if (!form) throw new TRPCError12({ code: "NOT_FOUND", message: "Formul\xE1rio n\xE3o encontrado." });
  return { ...form, campos: form.campos.map(parseCampo) };
}
function criarFormulario(input) {
  return prisma.formulario.create({ data: { titulo: input.titulo.trim(), descricao: input.descricao?.trim() || null } });
}
function atualizarFormulario(id, dados) {
  const data = {};
  if (dados.titulo !== void 0) data.titulo = dados.titulo.trim();
  if (dados.descricao !== void 0) data.descricao = dados.descricao?.trim() || null;
  if (dados.ativo !== void 0) data.ativo = dados.ativo;
  return prisma.formulario.update({ where: { id }, data });
}
async function removerFormulario(id) {
  await prisma.formulario.update({ where: { id }, data: { ativo: false } });
  return { ok: true };
}
async function addCampo(input) {
  const max = await prisma.formularioCampo.aggregate({ where: { formularioId: input.formularioId }, _max: { ordem: true } });
  return prisma.formularioCampo.create({
    data: {
      formularioId: input.formularioId,
      rotulo: input.rotulo.trim(),
      tipo: input.tipo,
      obrigatorio: input.obrigatorio,
      opcoes: input.opcoes?.length ? JSON.stringify(input.opcoes) : null,
      ajuda: input.ajuda?.trim() || null,
      ordem: (max._max.ordem ?? -1) + 1
    }
  });
}
function atualizarCampo(id, dados) {
  const data = {};
  if (dados.rotulo !== void 0) data.rotulo = dados.rotulo.trim();
  if (dados.tipo !== void 0) data.tipo = dados.tipo;
  if (dados.obrigatorio !== void 0) data.obrigatorio = dados.obrigatorio;
  if (dados.opcoes !== void 0) data.opcoes = dados.opcoes.length ? JSON.stringify(dados.opcoes) : null;
  if (dados.ajuda !== void 0) data.ajuda = dados.ajuda?.trim() || null;
  return prisma.formularioCampo.update({ where: { id }, data });
}
async function removerCampo(id) {
  await prisma.formularioCampo.delete({ where: { id } });
  return { ok: true };
}
async function reordenarCampos(ids) {
  await prisma.$transaction(ids.map((id, ordem) => prisma.formularioCampo.update({ where: { id }, data: { ordem } })));
  return { ok: true };
}
async function getFormularioDoRequisito(clienteId, requisitoId) {
  const req = await prisma.servicoRequisito.findUnique({
    where: { id: requisitoId },
    include: { formulario: { include: { campos: { orderBy: { ordem: "asc" } } } } }
  });
  if (!req?.formulario) throw new TRPCError12({ code: "NOT_FOUND", message: "Formul\xE1rio n\xE3o encontrado." });
  const resposta = await prisma.formularioResposta.findFirst({ where: { clienteId, requisitoId } });
  return {
    requisitoId,
    titulo: req.formulario.titulo,
    descricao: req.formulario.descricao,
    campos: req.formulario.campos.map(parseCampo),
    resposta: resposta ? { id: resposta.id, respostas: JSON.parse(resposta.respostas), status: resposta.status } : null
  };
}
async function salvarResposta(clienteId, requisitoId, respostas, enviar) {
  const req = await prisma.servicoRequisito.findUnique({
    where: { id: requisitoId },
    select: { formularioId: true, servicoId: true, titulo: true }
  });
  if (!req?.formularioId) throw new TRPCError12({ code: "BAD_REQUEST", message: "Este item n\xE3o tem formul\xE1rio." });
  const existente = await prisma.formularioResposta.findFirst({ where: { clienteId, requisitoId } });
  const data = {
    respostas: JSON.stringify(respostas),
    status: enviar ? "ENVIADO" : "RASCUNHO",
    enviadoEm: enviar ? /* @__PURE__ */ new Date() : existente?.enviadoEm ?? null
  };
  const resp = existente ? await prisma.formularioResposta.update({ where: { id: existente.id }, data }) : await prisma.formularioResposta.create({
    data: { ...data, formularioId: req.formularioId, clienteId, requisitoId, servicoId: req.servicoId }
  });
  if (enviar) {
    const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true } });
    const destinos = await equipeDoCliente(clienteId);
    for (const uid of destinos) {
      await notificar(
        uid,
        "documento_cliente_enviado",
        { cliente: cliente?.nome ?? "Cliente", documento: req.titulo },
        { entidadeTipo: "cliente", entidadeId: clienteId }
      ).catch(() => {
      });
    }
  }
  if (req.servicoId) await reconciliarCardsDoServico(clienteId, req.servicoId).catch(() => {
  });
  return resp;
}
async function getResposta(id, clienteScope) {
  const resp = await prisma.formularioResposta.findUnique({
    where: { id },
    include: { formulario: { include: { campos: { orderBy: { ordem: "asc" } } } }, cliente: { select: { nome: true } } }
  });
  if (!resp) throw new TRPCError12({ code: "NOT_FOUND", message: "Resposta n\xE3o encontrada." });
  if (clienteScope && resp.clienteId !== clienteScope) throw new TRPCError12({ code: "FORBIDDEN", message: "Sem acesso." });
  return {
    id: resp.id,
    titulo: resp.formulario.titulo,
    clienteNome: resp.cliente.nome,
    status: resp.status,
    enviadoEm: resp.enviadoEm,
    campos: resp.formulario.campos.map(parseCampo),
    respostas: JSON.parse(resp.respostas)
  };
}

// src/modules/portal/portal.router.ts
var portalRouter = router({
  resumo: portalProcedure.query(({ ctx }) => resumo2(ctx.clienteId)),
  // Dados cadastrais do próprio cliente (LGPD: acesso + retificação dos próprios dados).
  meusDados: portalProcedure.query(({ ctx }) => meusDados(ctx.clienteId)),
  atualizarMeusDados: portalProcedure.input(portalMeusDadosSchema).mutation(({ input, ctx }) => atualizarMeusDados(ctx.clienteId, ctx.user.id, input)),
  // E-mails que o cliente recebeu — para ele acompanhar tudo pelo Portal.
  emails: portalProcedure.query(({ ctx }) => listPorCliente(ctx.clienteId)),
  // Confirmar presença numa reunião (escopado ao clienteId da sessão).
  confirmarReuniao: portalProcedure.input(z15.object({ eventoId: z15.string() })).mutation(({ input, ctx }) => confirmarPresencaCliente(input.eventoId, ctx.clienteId)),
  // Livre-arbítrio do prospect: desistir do atendimento (vira lead perdido) ou retomar.
  // Sempre escopado ao clienteId da sessão — nunca recebe id de lead do cliente.
  desistir: portalProcedure.input(z15.object({ motivo: z15.string().trim().max(500).optional() })).mutation(({ input, ctx }) => desistenciaPeloCliente(ctx.clienteId, input.motivo)),
  retomar: portalProcedure.mutation(({ ctx }) => retomarPeloCliente(ctx.clienteId)),
  // Autosserviço: catálogo de serviços + solicitar (vira oportunidade no funil).
  servicosDisponiveis: portalProcedure.query(() => listServicosAtivos()),
  solicitarServicos: portalProcedure.input(solicitarServicosSchema).mutation(({ input, ctx }) => solicitarServicosPeloCliente(ctx.clienteId, input.servicoIds, input.mensagem)),
  documento: portalProcedure.input(z15.object({ id: z15.string() })).query(({ input, ctx }) => getDocumento2(input.id, ctx.clienteId)),
  // Serviços contratados do próprio cliente + exigências de documentos (o que falta enviar).
  meusServicos: portalProcedure.query(({ ctx }) => servicosDoClientePortal(ctx.clienteId)),
  cancelarServico: portalProcedure.input(z15.object({ servicoId: z15.string(), motivo: z15.string().trim().max(500).optional() })).mutation(({ input, ctx }) => cancelarServicoCliente(ctx.clienteId, input.servicoId, "CLIENTE", input.motivo, ctx.user.id)),
  // Briefings/formulários online: o cliente preenche na tela (rascunho ou envia).
  briefing: router({
    get: portalProcedure.input(z15.object({ requisitoId: z15.string() })).query(({ input, ctx }) => getFormularioDoRequisito(ctx.clienteId, input.requisitoId)),
    salvar: portalProcedure.input(salvarRespostaSchema).mutation(({ input, ctx }) => salvarResposta(ctx.clienteId, input.requisitoId, input.respostas, input.enviar))
  }),
  // Documentos que o cliente enviou (o upload em si chega pelo endpoint /upload).
  arquivos: portalProcedure.query(({ ctx }) => listarArquivos(ctx.clienteId)),
  removerArquivo: portalProcedure.input(z15.object({ id: z15.string() })).mutation(({ input, ctx }) => removerArquivo2(input.id, ctx.clienteId)),
  // Suporte = helpdesk de chamados/tickets. Sempre escopado ao clienteId da sessão.
  suporte: router({
    listChamados: portalProcedure.query(({ ctx }) => portalListChamados(ctx.clienteId, ctx.user.id)),
    abrir: portalProcedure.input(portalAbrirChamadoSchema).mutation(({ input, ctx }) => portalAbrirChamado(ctx.clienteId, ctx.user.id, input.assunto, input.mensagem)),
    mensagens: portalProcedure.input(z15.object({ conversaId: z15.string() })).query(({ input, ctx }) => portalMensagens(ctx.clienteId, ctx.user.id, input.conversaId)),
    enviar: portalProcedure.input(portalEnviarChamadoSchema).mutation(({ input, ctx }) => portalEnviar(ctx.clienteId, ctx.user.id, input.conversaId, input.corpo))
  })
});

// src/modules/usuarios/usuarios.router.ts
import { z as z16 } from "zod";
var usuariosRouter = router({
  list: adminProcedure.query(() => listUsuarios()),
  // Lista simples da equipe (id+nome) para atribuir responsáveis — acesso interno.
  equipe: funcionarioProcedure.query(() => listEquipe()),
  create: adminProcedure.input(createUsuarioSchema).mutation(({ ctx, input }) => createUsuario(ctx.user.role, input)),
  // Convite por e-mail (onboarding padrão) — cria pendente e devolve o link em modo dev.
  convidar: adminProcedure.input(inviteUsuarioSchema).mutation(({ ctx, input }) => convidarUsuario(ctx.user.role, input)),
  reenviarConvite: adminProcedure.input(z16.object({ id: z16.string().min(1) })).mutation(({ ctx, input }) => reenviarConvite(ctx.user.role, input.id)),
  update: adminProcedure.input(updateUsuarioSchema).mutation(({ ctx, input }) => updateUsuario(ctx.user.id, ctx.user.role, input)),
  // Resumo do que o usuário é responsável — alimenta o diálogo de exclusão.
  resumoResponsabilidades: adminProcedure.input(z16.object({ id: z16.string().min(1) })).query(({ input }) => resumoResponsabilidades(input.id)),
  remove: adminProcedure.input(deleteUsuarioSchema).mutation(
    ({ ctx, input }) => deleteUsuario(ctx.user.id, ctx.user.role, input.id, input.transferirParaId)
  )
});

// src/modules/emails/emails.router.ts
import { z as z17 } from "zod";
var camposSchema = z17.object({
  chave: z17.string().min(1),
  assunto: z17.string().trim().min(1, "Informe o assunto"),
  titulo: z17.string().trim().min(1, "Informe o t\xEDtulo"),
  corpo: z17.string().trim().min(1, "Escreva o corpo"),
  ctaTexto: z17.string().trim().optional().or(z17.literal("")),
  nota: z17.string().trim().optional().or(z17.literal(""))
});
var emailsRouter = router({
  list: adminProcedure.query(() => listarTemplates()),
  update: adminProcedure.input(camposSchema).mutation(({ ctx, input }) => {
    const { chave, ...dados } = input;
    return atualizarTemplate(chave, dados, ctx.user.nome);
  }),
  resetar: adminProcedure.input(z17.object({ chave: z17.string().min(1) })).mutation(({ input }) => resetarTemplate(input.chave)),
  // Prévia como mutation (POST) — o corpo pode ser longo (evita limite de URL).
  preview: adminProcedure.input(camposSchema).mutation(({ input }) => {
    const { chave, ...campos } = input;
    return gerarPreview(chave, campos);
  }),
  enviarTeste: adminProcedure.input(z17.object({ chave: z17.string().min(1), email: z17.string().trim().email("E-mail inv\xE1lido") })).mutation(({ input }) => enviarTeste(input.chave, input.email))
});

// src/modules/emails/enviados.router.ts
import { z as z18 } from "zod";
var emailsEnviadosRouter = router({
  // Os meus (qualquer usuário logado vê os e-mails que recebeu — em Configurações).
  meus: protectedProcedure.query(({ ctx }) => listMeus(ctx.user.id, ctx.user.email)),
  // Enviados a um lead / cliente (equipe interna, na ficha do lead/cliente).
  doLead: funcionarioProcedure.input(z18.object({ leadId: z18.string().min(1) })).query(({ input }) => listPorLead(input.leadId)),
  doCliente: funcionarioProcedure.input(z18.object({ clienteId: z18.string().min(1) })).query(({ input }) => listPorCliente(input.clienteId)),
  // ── Monitor global (só ADMIN/ROOT): indicadores + lista completa filtrável ──
  resumo: adminProcedure.query(() => resumoEnviados()),
  todos: adminProcedure.input(
    z18.object({
      status: z18.enum(["ENVIADO", "FALHOU"]).optional(),
      template: z18.string().optional(),
      busca: z18.string().optional(),
      dias: z18.number().int().optional(),
      limite: z18.number().int().min(1).max(500).optional()
    })
  ).query(({ input }) => listTodos(input))
});

// src/modules/busca/busca.router.ts
import { z as z19 } from "zod";

// src/modules/busca/busca.service.ts
async function buscaGlobal(termo) {
  const s = termo.trim();
  if (s.length < 2) return [];
  const [clientes, leads, projetos, documentos] = await Promise.all([
    prisma.cliente.findMany({
      where: {
        deletedAt: null,
        OR: [{ nome: { contains: s } }, { email: { contains: s } }, { documento: { contains: s } }]
      },
      take: 5,
      orderBy: { nome: "asc" },
      select: { id: true, nome: true, email: true }
    }),
    prisma.lead.findMany({
      where: {
        deletedAt: null,
        OR: [{ nome: { contains: s } }, { empresa: { contains: s } }, { email: { contains: s } }]
      },
      take: 5,
      orderBy: { updatedAt: "desc" },
      select: { id: true, nome: true, empresa: true }
    }),
    prisma.projeto.findMany({
      where: { deletedAt: null, nome: { contains: s } },
      take: 5,
      orderBy: { updatedAt: "desc" },
      select: { id: true, nome: true, cliente: { select: { nome: true } } }
    }),
    prisma.documento.findMany({
      where: { deletedAt: null, titulo: { contains: s } },
      take: 5,
      orderBy: { updatedAt: "desc" },
      select: { id: true, titulo: true, cliente: { select: { nome: true } } }
    })
  ]);
  return [
    ...clientes.map((c) => ({ tipo: "cliente", id: c.id, titulo: c.nome, subtitulo: c.email })),
    ...leads.map((l) => ({ tipo: "lead", id: l.id, titulo: l.nome, subtitulo: l.empresa })),
    ...projetos.map((p) => ({ tipo: "projeto", id: p.id, titulo: p.nome, subtitulo: p.cliente?.nome ?? null })),
    ...documentos.map((d) => ({ tipo: "documento", id: d.id, titulo: d.titulo, subtitulo: d.cliente?.nome ?? null }))
  ];
}

// src/modules/busca/busca.router.ts
var buscaRouter = router({
  global: funcionarioProcedure.input(z19.object({ termo: z19.string() })).query(({ input }) => buscaGlobal(input.termo))
});

// src/modules/formularios/formularios.router.ts
import { z as z20 } from "zod";
var formulariosRouter = router({
  // Catálogo de formulários (para ligar a um requisito e para a gestão).
  list: funcionarioProcedure.query(() => listFormularios()),
  get: funcionarioProcedure.input(z20.object({ id: z20.string() })).query(({ input }) => getFormulario(input.id)),
  // Gestão (admin): criar/editar/remover formulários e campos.
  criar: adminProcedure.input(createFormularioSchema).mutation(({ input }) => criarFormulario(input)),
  atualizar: adminProcedure.input(updateFormularioSchema).mutation(({ input }) => {
    const { id, ...dados } = input;
    return atualizarFormulario(id, dados);
  }),
  remover: adminProcedure.input(z20.object({ id: z20.string() })).mutation(({ input }) => removerFormulario(input.id)),
  addCampo: adminProcedure.input(addCampoSchema).mutation(({ input }) => addCampo(input)),
  atualizarCampo: adminProcedure.input(updateCampoSchema).mutation(({ input }) => {
    const { id, ...dados } = input;
    return atualizarCampo(id, dados);
  }),
  removerCampo: adminProcedure.input(z20.object({ id: z20.string() })).mutation(({ input }) => removerCampo(input.id)),
  reordenarCampos: adminProcedure.input(z20.object({ ids: z20.array(z20.string()) })).mutation(({ input }) => reordenarCampos(input.ids)),
  // Resposta preenchida (equipe vê na ficha).
  resposta: funcionarioProcedure.input(z20.object({ id: z20.string() })).query(({ input }) => getResposta(input.id))
});

// src/modules/ia/ia.router.ts
import { z as z21 } from "zod";

// src/modules/ia/ia.service.ts
import { TRPCError as TRPCError13 } from "@trpc/server";
var SYSTEM = `Voc\xEA \xE9 a assistente virtual do "Workspace MedConsultoria", o sistema operacional interno da consultoria MedConsultoria (n\xE3o \xE9 um SaaS).
Responda SEMPRE em portugu\xEAs do Brasil, de forma breve, pr\xE1tica e cordial.

O sistema tem estas \xE1reas: Dashboard (vis\xE3o do dia), Funil de vendas (leads em kanban), Clientes, Projetos (kanban com tarefas, checklist, prioridade e cron\xF4metro), Agenda (compromissos, retornos e reuni\xF5es por link), Mensagens (chat interno), Documentos (gerados de modelos com vari\xE1veis ou com IA; fluxo rascunho \u2192 em revis\xE3o \u2192 aprovado \u2192 enviado; export PDF/Word), Financeiro (contas a pagar/receber, categorias \u2014 s\xF3 administradores), Configura\xE7\xF5es (perfil e senha) e Usu\xE1rios (equipe e cria\xE7\xE3o de acessos ao Portal do Cliente).

Ajude a pessoa a usar o sistema (onde clicar, como fazer) e responda d\xFAvidas gerais de gest\xE3o/consultoria.
Nunca invente dados espec\xEDficos de clientes, valores ou registros que voc\xEA n\xE3o recebeu \u2014 se n\xE3o souber um dado concreto do sistema, oriente onde encontr\xE1-lo na tela.`;
function perguntar(pergunta) {
  return aiService.gerarRascunho(SYSTEM, pergunta.trim());
}
function exigirIA() {
  if (!isAiEnabled) throw new TRPCError13({ code: "PRECONDITION_FAILED", message: "IA n\xE3o configurada (OPENAI_API_KEY)." });
}
var SYSTEM_SUGESTAO = "Voc\xEA \xE9 uma assistente da consultoria MedConsultoria (setor de sa\xFAde: cl\xEDnicas, consult\xF3rios, m\xE9dicos). Seja pr\xE1tica, objetiva e em portugu\xEAs do Brasil. Quando pedirem JSON, responda APENAS com o JSON v\xE1lido \u2014 sem markdown, sem coment\xE1rios, sem cercas de c\xF3digo.";
var dataBR = () => (/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR");
function extrairJson(texto) {
  const limpo = texto.replace(/```json/gi, "").replace(/```/g, "").trim();
  const ini = Math.min(...["[", "{"].map((c) => limpo.indexOf(c) < 0 ? Infinity : limpo.indexOf(c)));
  const fim = Math.max(limpo.lastIndexOf("]"), limpo.lastIndexOf("}"));
  const slice = ini !== Infinity && fim >= 0 ? limpo.slice(ini, fim + 1) : limpo;
  return JSON.parse(slice);
}
async function resumoDoDia(userId, role) {
  exigirIA();
  const isAdmin = hasRoleLevel(role, "ADMIN");
  const hoje0 = /* @__PURE__ */ new Date();
  hoje0.setHours(0, 0, 0, 0);
  const hojeFim = /* @__PURE__ */ new Date();
  hojeFim.setHours(23, 59, 59, 999);
  const [atrasadas, tarefasHoje, eventosHoje, docsRevisao, contasVencidas] = await Promise.all([
    prisma.card.findMany({
      where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: userId, prazo: { lt: hoje0 } },
      select: { titulo: true, projeto: { select: { nome: true } } },
      orderBy: { prazo: "asc" },
      take: 8
    }),
    prisma.card.count({ where: { deletedAt: null, status: { not: "CONCLUIDO" }, responsavelId: userId, prazo: { gte: hoje0, lte: hojeFim } } }),
    listEventos(hoje0, hojeFim, userId),
    isAdmin ? prisma.documento.count({ where: { deletedAt: null, status: "EM_REVISAO" } }) : Promise.resolve(0),
    isAdmin ? prisma.conta.count({ where: { pago: false, vencimento: { lt: hoje0 } } }) : Promise.resolve(0)
  ]);
  const horaEv = (d) => new Date(d).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  const ctx = [
    `Tarefas atrasadas (${atrasadas.length}): ${atrasadas.map((t2) => `${t2.titulo} [${t2.projeto.nome}]`).join("; ") || "nenhuma"}.`,
    `Tarefas que vencem hoje: ${tarefasHoje}.`,
    `Compromissos de hoje (${eventosHoje.length}): ${eventosHoje.map((e) => `${e.diaInteiro ? "" : horaEv(e.inicio) + " "}${e.titulo}`).join("; ") || "nenhum"}.`,
    isAdmin ? `Gest\xE3o \u2014 documentos aguardando revis\xE3o: ${docsRevisao}; contas vencidas: ${contasVencidas}.` : ""
  ].filter(Boolean).join("\n");
  const user = `Data de hoje: ${dataBR()}. Ajude a pessoa a saber o que fazer HOJE.
Com base nos dados, escreva um "plano do dia" curto e priorizado (comece pelo mais urgente), em at\xE9 6 t\xF3picos objetivos e motivadores. Se estiver tudo em dia, diga isso e sugira 1-2 a\xE7\xF5es proativas. N\xE3o invente dados nem tarefas que n\xE3o est\xE3o aqui.

${ctx}`;
  return aiService.gerarRascunho(SYSTEM_SUGESTAO, user);
}
async function resumoAgenda(userId, inicio, fim, rotulo) {
  exigirIA();
  const eventos = await listEventos(inicio, fim, userId);
  const tz = "America/Sao_Paulo";
  const quando = (d) => new Intl.DateTimeFormat("pt-BR", { weekday: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: tz }).format(d);
  const linhas = eventos.map((e) => {
    const partes = [
      e.diaInteiro ? `${new Intl.DateTimeFormat("pt-BR", { weekday: "short", day: "2-digit", timeZone: tz }).format(e.inicio)} (dia inteiro)` : quando(e.inicio),
      e.titulo,
      e.cliente ? `cliente: ${e.cliente.nome}` : "",
      e.local ? `local: ${e.local}` : "",
      e.linkReuniao ? "online" : ""
    ].filter(Boolean);
    return `- ${partes.join(" \xB7 ")}`;
  });
  const ctx = eventos.length ? `Compromissos do per\xEDodo (${eventos.length}):
${linhas.join("\n")}` : "Nenhum compromisso no per\xEDodo.";
  const user = `Data de hoje: ${dataBR()}. Per\xEDodo: ${rotulo ?? "selecionado"}.
Com base na agenda abaixo, escreva um resumo curto e pr\xE1tico para a pessoa se preparar: quantos compromissos, os hor\xE1rios de pico, o que exige prepara\xE7\xE3o (reuni\xF5es com cliente/link), e 1-2 dicas objetivas. Se estiver vazia, sugira 1-2 a\xE7\xF5es proativas. M\xE1ximo 6 t\xF3picos. N\xE3o invente compromissos que n\xE3o est\xE3o aqui.

${ctx}`;
  return aiService.gerarRascunho(SYSTEM_SUGESTAO, user);
}
var SYSTEM_TECNICO = "Voc\xEA \xE9 um engenheiro de software/SRE s\xEAnior respons\xE1vel por manter o Workspace MedConsultoria 100% saud\xE1vel e seguro. Stack: Node 20 + Fastify + tRPC + Prisma/MySQL + Socket.IO no back; React + Vite + TanStack no front; app de UM processo (sem cluster). Responda SEMPRE em portugu\xEAs do Brasil, t\xE9cnico, direto e ACION\xC1VEL (diga o que verificar/rodar/corrigir). N\xE3o invente dados nem arquivos que n\xE3o foram informados.";
async function diagnosticoSistema() {
  exigirIA();
  const { saude: saude2, erros: erros2, incidentes: incidentes2, metricas: metricas2, banco: banco2 } = await import("./sistema.service-AIWQ67FF.js");
  const [s, errs, incs, m, db] = await Promise.all([saude2(), erros2(), incidentes2(), metricas2(), banco2()]);
  const errosAbertos = errs.filter((e) => !e.resolvido);
  const incAbertos = incs.filter((i) => i.status !== "RESOLVIDO");
  const ctx = [
    `SA\xDADE: ${JSON.stringify(s).slice(0, 1500)}`,
    `ERROS ABERTOS (${errosAbertos.length}): ${errosAbertos.slice(0, 12).map((e) => `[${e.ocorrencias}x] ${e.mensagem}${e.rota ? ` @${e.rota}` : ""}`).join(" | ") || "nenhum"}`,
    `INCIDENTES ABERTOS (${incAbertos.length}): ${incAbertos.map((i) => `${i.titulo} [${i.severidade}] ${i.componente}: ${i.detalhe}`).join(" | ") || "nenhum"}`,
    `BANCO: ${JSON.stringify(db).slice(0, 800)}`,
    `M\xC9TRICAS: ${JSON.stringify(m).slice(0, 600)}`
  ].join("\n");
  const user = `Data/hora: ${(/* @__PURE__ */ new Date()).toLocaleString("pt-BR")}. Fa\xE7a um DIAGN\xD3STICO t\xE9cnico do sistema a partir do estado abaixo:
1) Avalia\xE7\xE3o geral \u2014 est\xE1 saud\xE1vel? O que preocupa? (1-2 frases)
2) Os problemas mais prov\xE1veis, com a causa-raiz de cada um.
3) Corre\xE7\xF5es recomendadas, passo a passo (o que investigar/rodar/corrigir, e quais bot\xF5es deste painel usar: Resolver erro/incidente, Revogar sess\xE3o, Limpar sess\xF5es, Rodar varredura).
Se estiver tudo saud\xE1vel, diga isso e sugira 1-2 verifica\xE7\xF5es preventivas. M\xE1ximo ~8 t\xF3picos.

${ctx}`;
  return aiService.gerarRascunho(SYSTEM_TECNICO, user);
}
async function explicarErro(id) {
  exigirIA();
  const e = await prisma.errorLog.findUnique({ where: { id } });
  if (!e) throw new TRPCError13({ code: "NOT_FOUND", message: "Erro n\xE3o encontrado." });
  const user = `Erro registrado na aplica\xE7\xE3o (agrupado por fingerprint):
Mensagem: ${e.mensagem}
Rota: ${e.rota ?? "\u2014"}
Ocorr\xEAncias: ${e.ocorrencias}${e.regrediu ? " (REGREDIU \u2014 j\xE1 tinha sido resolvido)" : ""}
Stack:
${(e.stack ?? "sem stack").slice(0, 2500)}

Explique de forma direta: (1) a causa mais prov\xE1vel, (2) como corrigir (passos concretos no c\xF3digo/config), (3) \xE9 cr\xEDtico ou \xE9 ru\xEDdo que pode ser ignorado?`;
  return aiService.gerarRascunho(SYSTEM_TECNICO, user);
}
async function explicarIncidente(id) {
  exigirIA();
  const i = await prisma.incidente.findUnique({ where: { id } });
  if (!i) throw new TRPCError13({ code: "NOT_FOUND", message: "Incidente n\xE3o encontrado." });
  const user = `Incidente aberto pelo motor de alertas:
Regra: ${i.regra}
T\xEDtulo: ${i.titulo}
Severidade: ${i.severidade}
Componente: ${i.componente}
Detalhe: ${i.detalhe}${i.valorPico != null ? `
Valor de pico: ${i.valorPico}` : ""}

Explique: (1) o que este alerta significa, (2) a causa mais prov\xE1vel, (3) como mitigar/corrigir passo a passo, (4) como prevenir a recorr\xEAncia.`;
  return aiService.gerarRascunho(SYSTEM_TECNICO, user);
}
async function sugerirRequisitos(servicoId) {
  exigirIA();
  const s = await prisma.servico.findUnique({ where: { id: servicoId }, select: { nome: true, descricao: true } });
  if (!s) throw new TRPCError13({ code: "NOT_FOUND", message: "Servi\xE7o n\xE3o encontrado." });
  const user = `Servi\xE7o da MedConsultoria: "${s.nome}"${s.descricao ? ` \u2014 ${s.descricao}` : ""}.
Liste de 3 a 6 DOCUMENTOS ou INFORMA\xC7\xD5ES que o cliente precisa enviar para executarmos esse servi\xE7o.
Responda APENAS um array JSON: [{"titulo":"...","descricao":"breve explica\xE7\xE3o para o cliente","obrigatorio":true}].`;
  const txt = await aiService.gerarRascunho(SYSTEM_SUGESTAO, user);
  const arr = extrairJson(txt);
  return Array.isArray(arr) ? arr.filter((x) => x?.titulo).slice(0, 8) : [];
}
async function sugerirCampos(titulo, descricao) {
  exigirIA();
  const user = `Crie as perguntas de um formul\xE1rio/briefing chamado "${titulo}"${descricao ? ` (${descricao})` : ""}, que um cliente de uma consultoria de sa\xFAde vai responder.
De 4 a 8 perguntas. Cada item: "rotulo" (a pergunta), "tipo" (um de: TEXTO_CURTO, TEXTO_LONGO, ESCOLHA, MULTIPLA, NUMERO, SIM_NAO, DATA), "obrigatorio" (boolean) e, s\xF3 para ESCOLHA/MULTIPLA, "opcoes" (array de strings).
Responda APENAS o array JSON.`;
  const txt = await aiService.gerarRascunho(SYSTEM_SUGESTAO, user);
  const tipos = ["TEXTO_CURTO", "TEXTO_LONGO", "ESCOLHA", "MULTIPLA", "NUMERO", "SIM_NAO", "DATA"];
  const arr = extrairJson(txt);
  return (Array.isArray(arr) ? arr : []).filter((c) => c?.rotulo).map((c) => ({
    rotulo: c.rotulo,
    tipo: tipos.includes(c.tipo) ? c.tipo : "TEXTO_CURTO",
    obrigatorio: !!c.obrigatorio,
    opcoes: Array.isArray(c.opcoes) ? c.opcoes.filter((o) => typeof o === "string") : []
  })).slice(0, 10);
}
async function resumirCliente(clienteId) {
  exigirIA();
  const cliente = await prisma.cliente.findUnique({
    where: { id: clienteId },
    select: { nome: true, situacaoComercial: true, observacoes: true, createdAt: true }
  });
  if (!cliente) throw new TRPCError13({ code: "NOT_FOUND", message: "Cliente n\xE3o encontrado." });
  const [servicos, projetos, proxReuniao, oportunidades] = await Promise.all([
    prisma.clienteServico.findMany({ where: { clienteId, status: "ATIVO" }, select: { servico: { select: { nome: true } } } }),
    prisma.projeto.findMany({ where: { clienteId, deletedAt: null }, select: { nome: true, status: true } }),
    prisma.evento.findFirst({ where: { clienteId, inicio: { gte: /* @__PURE__ */ new Date() } }, orderBy: { inicio: "asc" }, select: { titulo: true, inicio: true } }),
    prisma.lead.findMany({ where: { clienteId, convertidoEmClienteId: null, perdidoEm: null, deletedAt: null }, select: { servicos: { select: { nome: true } } } })
  ]);
  const ctx = [
    `Cliente: ${cliente.nome} (situa\xE7\xE3o: ${cliente.situacaoComercial}). Cliente desde ${cliente.createdAt.toLocaleDateString("pt-BR")}.`,
    `Servi\xE7os contratados: ${servicos.map((s) => s.servico.nome).join(", ") || "nenhum"}.`,
    `Projetos: ${projetos.map((p) => `${p.nome} (${p.status})`).join("; ") || "nenhum"}.`,
    proxReuniao ? `Pr\xF3xima reuni\xE3o: ${proxReuniao.titulo} em ${proxReuniao.inicio.toLocaleDateString("pt-BR")}.` : "Sem reuni\xE3o futura agendada.",
    oportunidades.length ? `Oportunidades abertas no funil (quer mais): ${oportunidades.flatMap((o) => o.servicos.map((s) => s.nome)).join(", ") || "sem servi\xE7os definidos"}.` : "Sem oportunidade aberta no funil.",
    cliente.observacoes ? `Observa\xE7\xF5es: ${cliente.observacoes}` : ""
  ].filter(Boolean).join("\n");
  const user = `Data de hoje: ${dataBR()}.
Com base nos dados abaixo, escreva um RESUMO curto do cliente (3-5 frases) e, em seguida, uma lista de 3 PR\xD3XIMOS PASSOS pr\xE1ticos para a equipe. N\xE3o invente dados que n\xE3o est\xE3o aqui.

${ctx}`;
  return aiService.gerarRascunho(SYSTEM_SUGESTAO, user);
}
async function sugerirProximoPassoLead(leadId) {
  exigirIA();
  const lead = await prisma.lead.findUnique({
    where: { id: leadId },
    include: {
      pipelineStage: { select: { nome: true } },
      servicos: { select: { nome: true } },
      passos: { where: { concluido: false }, select: { titulo: true }, take: 10 }
    }
  });
  if (!lead) throw new TRPCError13({ code: "NOT_FOUND", message: "Lead n\xE3o encontrado." });
  const ctx = [
    `Lead: ${lead.nome}${lead.empresa ? ` (${lead.empresa})` : ""}. Etapa atual: ${lead.pipelineStage.nome}.`,
    `Servi\xE7os de interesse: ${lead.servicos.map((s) => s.nome).join(", ") || "n\xE3o definidos"}.`,
    lead.valorEstimado ? `Valor estimado: R$ ${lead.valorEstimado.toLocaleString("pt-BR")}.` : "Sem valor estimado.",
    lead.passos.length ? `Passos pendentes: ${lead.passos.map((p) => p.titulo).join("; ")}.` : "Sem passos pendentes registrados.",
    lead.observacoes ? `Observa\xE7\xF5es: ${lead.observacoes}` : ""
  ].filter(Boolean).join("\n");
  const user = `Data de hoje: ${dataBR()}.
Sugira o PR\xD3XIMO PASSO mais eficaz para avan\xE7ar este lead no funil (1-3 a\xE7\xF5es concretas e objetivas, em t\xF3picos). N\xE3o invente dados.

${ctx}`;
  return aiService.gerarRascunho(SYSTEM_SUGESTAO, user);
}
async function escreverMensagem(input) {
  exigirIA();
  let nome = "cliente";
  let contexto = "";
  if (input.leadId) {
    const l = await prisma.lead.findUnique({ where: { id: input.leadId }, include: { pipelineStage: { select: { nome: true } }, servicos: { select: { nome: true } } } });
    if (l) {
      nome = l.nome;
      contexto = `Lead na etapa "${l.pipelineStage.nome}", interessado em: ${l.servicos.map((s) => s.nome).join(", ") || "n\xE3o definido"}.`;
    }
  } else if (input.clienteId) {
    const c = await prisma.cliente.findUnique({ where: { id: input.clienteId }, select: { nome: true } });
    const servicos = await prisma.clienteServico.findMany({ where: { clienteId: input.clienteId, status: "ATIVO" }, select: { servico: { select: { nome: true } } } });
    if (c) {
      nome = c.nome;
      contexto = `Cliente com os servi\xE7os: ${servicos.map((s) => s.servico.nome).join(", ") || "nenhum"}.`;
    }
  }
  const user = `Escreva um e-mail profissional e cordial da MedConsultoria para "${nome}".
${contexto}
Objetivo do e-mail: ${input.objetivo?.trim() || "dar sequ\xEAncia ao atendimento de forma proativa"}.
Responda APENAS um JSON: {"assunto":"...","corpo":"..."}. O corpo em texto simples, com sauda\xE7\xE3o e assinatura "Equipe MedConsultoria".`;
  const txt = await aiService.gerarRascunho(SYSTEM_SUGESTAO, user);
  try {
    const o = extrairJson(txt);
    return { assunto: o.assunto ?? "Contato \u2014 MedConsultoria", corpo: o.corpo ?? txt };
  } catch {
    return { assunto: "Contato \u2014 MedConsultoria", corpo: txt };
  }
}

// src/modules/ia/ia.router.ts
var iaRouter = router({
  disponivel: funcionarioProcedure.query(() => ({ disponivel: isAiEnabled })),
  perguntar: funcionarioProcedure.input(z21.object({ pergunta: z21.string().min(1, "Escreva sua pergunta").max(1e3) })).mutation(({ input }) => perguntar(input.pergunta)),
  resumoDoDia: funcionarioProcedure.mutation(({ ctx }) => resumoDoDia(ctx.user.id, ctx.user.role)),
  resumoAgenda: funcionarioProcedure.input(resumoAgendaSchema).mutation(({ input, ctx }) => resumoAgenda(ctx.user.id, input.inicio, input.fim, input.rotulo)),
  sugerirRequisitos: funcionarioProcedure.input(z21.object({ servicoId: z21.string() })).mutation(({ input }) => sugerirRequisitos(input.servicoId)),
  sugerirCampos: funcionarioProcedure.input(z21.object({ titulo: z21.string().min(1), descricao: z21.string().optional() })).mutation(({ input }) => sugerirCampos(input.titulo, input.descricao)),
  resumirCliente: funcionarioProcedure.input(z21.object({ clienteId: z21.string() })).mutation(({ input }) => resumirCliente(input.clienteId)),
  sugerirProximoPassoLead: funcionarioProcedure.input(z21.object({ leadId: z21.string() })).mutation(({ input }) => sugerirProximoPassoLead(input.leadId)),
  escreverMensagem: funcionarioProcedure.input(z21.object({ leadId: z21.string().optional(), clienteId: z21.string().optional(), objetivo: z21.string().max(500).optional() })).mutation(({ input }) => escreverMensagem(input)),
  // IA do painel SISTEMA (só ROOT/devs): diagnóstico geral + explicar erro/incidente.
  diagnosticoSistema: rootProcedure.mutation(() => diagnosticoSistema()),
  explicarErro: rootProcedure.input(z21.object({ id: z21.string() })).mutation(({ input }) => explicarErro(input.id)),
  explicarIncidente: rootProcedure.input(z21.object({ id: z21.string() })).mutation(({ input }) => explicarIncidente(input.id))
});

// src/modules/sistema/sistema.router.ts
import { z as z22 } from "zod";
var sistemaRouter = router({
  saude: rootProcedure.query(() => saude()),
  desempenho: rootProcedure.query(() => desempenho()),
  banco: rootProcedure.query(() => banco()),
  diagnostico: rootProcedure.query(() => diagnostico()),
  metricas: rootProcedure.query(() => metricas()),
  atencao: rootProcedure.query(() => atencao()),
  sessoes: rootProcedure.query(() => sessoes()),
  atividade: rootProcedure.query(() => atividade()),
  erros: rootProcedure.input(z22.object({ ocultos: z22.boolean().optional() }).optional()).query(({ input }) => erros(input?.ocultos)),
  incidentes: rootProcedure.query(() => incidentes()),
  historicoUptime: rootProcedure.query(() => historicoUptime()),
  migracoes: rootProcedure.query(() => migracoes()),
  config: rootProcedure.query(() => configInfo()),
  revogarSessao: rootProcedure.input(z22.object({ id: z22.string() })).mutation(({ input }) => revogarSessao(input.id)),
  resolverErro: rootProcedure.input(z22.object({ id: z22.string() })).mutation(({ input }) => resolverErro(input.id)),
  ignorarErro: rootProcedure.input(z22.object({ id: z22.string() })).mutation(({ input }) => ignorarErro(input.id)),
  reexibirErro: rootProcedure.input(z22.object({ id: z22.string() })).mutation(({ input }) => reexibirErro(input.id)),
  reconhecerIncidente: rootProcedure.input(z22.object({ id: z22.string() })).mutation(({ input }) => reconhecerIncidente(input.id)),
  resolverIncidente: rootProcedure.input(z22.object({ id: z22.string() })).mutation(({ input }) => resolverIncidente(input.id)),
  limparSessoesExpiradas: rootProcedure.mutation(() => limparSessoesExpiradas()),
  // Ações em massa + varredura sob demanda.
  resolverTodosErros: rootProcedure.mutation(() => resolverTodosErros()),
  resolverTodosIncidentes: rootProcedure.mutation(() => resolverTodosIncidentes()),
  rodarVarredura: rootProcedure.mutation(() => rodarVarredura())
});

// src/trpc/router.ts
var appRouter = router({
  auth: authRouter,
  dashboard: dashboardRouter,
  mensagens: mensagensRouter,
  documentos: documentosRouter,
  assinaturas: assinaturasRouter,
  propostas: propostasRouter,
  portal: portalRouter,
  clientes: clientesRouter,
  pipeline: pipelineRouter,
  servicos: servicosRouter,
  origens: origensRouter,
  leads: leadsRouter,
  projetos: projetosRouter,
  cards: cardsRouter,
  agenda: agendaRouter,
  notificacoes: notificacoesRouter,
  financeiro: financeiroRouter,
  usuarios: usuariosRouter,
  emails: emailsRouter,
  emailsEnviados: emailsEnviadosRouter,
  busca: buscaRouter,
  formularios: formulariosRouter,
  ia: iaRouter,
  sistema: sistemaRouter
});

// src/trpc/context.ts
async function createContext({ req, res }) {
  const raw = req.cookies[SESSION_COOKIE];
  const unsigned = raw ? req.unsignCookie(raw) : null;
  const sid = unsigned?.valid ? unsigned.value ?? void 0 : void 0;
  const user = await getUserFromSession(sid);
  return { req, res, user };
}

// src/http/uploads.ts
import multipart from "@fastify/multipart";
import { createReadStream } from "fs";
import { extname } from "path";
var CONTENT_TYPE_POR_EXT = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp" };
async function usuarioDaRequest(req) {
  const raw = req.cookies[SESSION_COOKIE];
  const unsigned = raw ? req.unsignCookie(raw) : null;
  const sid = unsigned?.valid ? unsigned.value ?? void 0 : void 0;
  return getUserFromSession(sid);
}
async function registrarRotasArquivos(app2) {
  await app2.register(multipart, { limits: { fileSize: TAMANHO_MAX, files: 1 } });
  app2.post("/upload", async (req, reply) => {
    const user = await usuarioDaRequest(req);
    if (!user) return reply.code(401).send({ error: "N\xE3o autenticado." });
    const isCliente = user.role === "CLIENTE";
    const campos = {};
    let salvo = null;
    for await (const part of req.parts()) {
      if (part.type === "field") {
        campos[part.fieldname] = String(part.value);
        continue;
      }
      if (part.fieldname !== "arquivo") {
        part.file.resume();
        continue;
      }
      if (!MIMETYPES_ACEITOS.has(part.mimetype)) {
        part.file.resume();
        return reply.code(415).send({ error: "Tipo de arquivo n\xE3o permitido. Envie PDF, imagem, Word ou Excel." });
      }
      const clienteId = isCliente ? user.clienteId : campos.clienteId;
      if (!clienteId) {
        part.file.resume();
        return reply.code(400).send({ error: "Cliente n\xE3o informado." });
      }
      const { caminho, tamanho } = await salvarArquivo(clienteId, part.filename, part.file);
      if (part.file.truncated) {
        await removerArquivo(caminho);
        return reply.code(413).send({ error: "Arquivo excede o limite de 20 MB." });
      }
      salvo = { caminho, tamanho, nome: part.filename, mimetype: part.mimetype, clienteId };
    }
    if (!salvo) return reply.code(400).send({ error: "Nenhum arquivo enviado." });
    const arquivo = await registrarUpload({
      clienteId: salvo.clienteId,
      servicoId: campos.servicoId || null,
      requisitoId: campos.requisitoId || null,
      nome: salvo.nome,
      mimetype: salvo.mimetype,
      tamanho: salvo.tamanho,
      caminho: salvo.caminho,
      enviadoPorTipo: isCliente ? "CLIENTE" : "EQUIPE",
      enviadoPorId: user.id
    });
    return reply.send({ id: arquivo.id, nome: arquivo.nome, tamanho: arquivo.tamanho });
  });
  app2.post("/transcrever", async (req, reply) => {
    const user = await usuarioDaRequest(req);
    if (!user || user.role === "CLIENTE") return reply.code(401).send({ error: "N\xE3o autenticado." });
    if (!isAiEnabled) return reply.code(412).send({ error: "IA n\xE3o configurada (OPENAI_API_KEY)." });
    let buffer = null;
    let filename = "audio.webm";
    for await (const part of req.parts()) {
      if (part.type === "field") continue;
      if (part.fieldname !== "audio") {
        part.file.resume();
        continue;
      }
      if (!/^(audio|video)\//.test(part.mimetype)) {
        part.file.resume();
        return reply.code(415).send({ error: "Envie um arquivo de \xE1udio." });
      }
      filename = part.filename || "audio.webm";
      const chunks = [];
      for await (const c of part.file) chunks.push(c);
      if (part.file.truncated) return reply.code(413).send({ error: "\xC1udio muito grande (m\xE1x. 20 MB)." });
      buffer = Buffer.concat(chunks);
    }
    if (!buffer || buffer.length === 0) return reply.code(400).send({ error: "Nenhum \xE1udio enviado." });
    try {
      const texto = await aiService.transcrever(buffer, filename);
      return reply.send({ texto });
    } catch {
      return reply.code(500).send({ error: "N\xE3o consegui transcrever o \xE1udio. Tente de novo." });
    }
  });
  app2.post("/avatar", async (req, reply) => {
    const user = await usuarioDaRequest(req);
    if (!user) return reply.code(401).send({ error: "N\xE3o autenticado." });
    let salvo = null;
    for await (const part of req.parts()) {
      if (part.type === "field") continue;
      if (part.fieldname !== "arquivo") {
        part.file.resume();
        continue;
      }
      if (!MIMETYPES_IMAGEM.has(part.mimetype)) {
        part.file.resume();
        return reply.code(415).send({ error: "Envie uma imagem JPG, PNG ou WebP." });
      }
      salvo = await salvarAvatar(user.id, part.filename, part.file);
      if (part.file.truncated || salvo.tamanho > AVATAR_MAX) {
        await removerArquivo(salvo.caminho);
        return reply.code(413).send({ error: "Imagem muito grande (m\xE1x. 5 MB)." });
      }
    }
    if (!salvo) return reply.code(400).send({ error: "Nenhuma imagem enviada." });
    const anterior = await prisma.user.findUnique({ where: { id: user.id }, select: { avatarUrl: true } });
    await prisma.user.update({ where: { id: user.id }, data: { avatarUrl: salvo.caminho } });
    if (anterior?.avatarUrl && anterior.avatarUrl !== salvo.caminho) await removerArquivo(anterior.avatarUrl);
    return reply.send({ avatarUrl: salvo.caminho });
  });
  app2.get("/avatar/:userId", async (req, reply) => {
    const user = await usuarioDaRequest(req);
    if (!user) return reply.code(401).send({ error: "N\xE3o autenticado." });
    const alvo = await prisma.user.findUnique({ where: { id: req.params.userId }, select: { avatarUrl: true } });
    if (!alvo?.avatarUrl) return reply.code(404).send({ error: "Sem foto." });
    let stream;
    try {
      stream = createReadStream(caminhoAbsoluto(alvo.avatarUrl));
    } catch {
      return reply.code(404).send({ error: "Foto n\xE3o encontrada." });
    }
    reply.header("Content-Type", CONTENT_TYPE_POR_EXT[extname(alvo.avatarUrl).toLowerCase()] ?? "image/png");
    reply.header("Cache-Control", "private, max-age=300");
    return reply.send(stream);
  });
  app2.get("/arquivos/:id", async (req, reply) => {
    const user = await usuarioDaRequest(req);
    if (!user) return reply.code(401).send({ error: "N\xE3o autenticado." });
    const arquivo = await getArquivo(req.params.id);
    if (user.role === "CLIENTE" && arquivo.clienteId !== user.clienteId) {
      return reply.code(403).send({ error: "Sem acesso a este arquivo." });
    }
    let stream;
    try {
      stream = createReadStream(caminhoAbsoluto(arquivo.caminho));
    } catch {
      return reply.code(404).send({ error: "Arquivo n\xE3o encontrado." });
    }
    reply.header("Content-Type", arquivo.mimetype);
    reply.header(
      "Content-Disposition",
      `attachment; filename*=UTF-8''${encodeURIComponent(arquivo.nome)}`
    );
    return reply.send(stream);
  });
}

// src/observability/alertas.ts
var INTERVALO_MS = 3e4;
var PENDENTES_PADRAO = 2;
var REGRAS = [
  {
    chave: "event_loop",
    componente: "Processo",
    titulo: "Event loop lento",
    unidade: "ms",
    ler: async () => getProcessoAgora().loopP99,
    dispara: 100,
    recupera: 60,
    severidade: (v) => v >= 250 ? "critico" : "degradado"
  },
  {
    chave: "heap",
    componente: "Processo",
    titulo: "Uso de mem\xF3ria alto",
    unidade: "%",
    ler: async () => getProcessoAgora().heapUsoPct,
    dispara: 85,
    recupera: 75,
    severidade: (v) => v >= 92 ? "critico" : "degradado"
  },
  {
    chave: "taxa_erro",
    componente: "API",
    titulo: "Taxa de erro elevada",
    unidade: "%",
    ler: async () => {
      const t2 = getResumoTrafego();
      return t2.reqUltimoMin >= 5 ? t2.taxaErroUltimoMin : null;
    },
    dispara: 5,
    recupera: 2,
    severidade: (v) => v >= 20 ? "critico" : "degradado"
  },
  {
    chave: "db_latencia",
    componente: "Banco de dados",
    titulo: "Banco lento",
    unidade: "ms",
    ler: async () => {
      const t0 = Date.now();
      try {
        await prisma.$queryRaw`SELECT 1`;
      } catch {
        return 99999;
      }
      return Date.now() - t0;
    },
    dispara: 500,
    recupera: 250,
    severidade: (v) => v >= 2e3 ? "critico" : "degradado"
  },
  {
    chave: "conexoes_db",
    componente: "Banco de dados",
    titulo: "Conex\xF5es do banco no limite",
    unidade: "%",
    ler: async () => {
      try {
        const conn = await prisma.$queryRawUnsafe(
          "SHOW STATUS LIKE 'Threads_connected'"
        );
        const max = await prisma.$queryRawUnsafe(
          "SHOW VARIABLES LIKE 'max_connections'"
        );
        const c = Number(conn[0]?.Value ?? 0);
        const m = Number(max[0]?.Value ?? 0);
        return m ? Math.round(c / m * 100) : null;
      } catch {
        return null;
      }
    },
    dispara: 80,
    recupera: 65,
    severidade: (v) => v >= 90 ? "critico" : "degradado"
  },
  {
    chave: "jobs_parados",
    componente: "Jobs",
    titulo: "Jobs em segundo plano parados",
    unidade: "min",
    ler: async () => {
      const j = statusJobs();
      if (!j.ultimoScanEm) return null;
      return (Date.now() - new Date(j.ultimoScanEm).getTime()) / 6e4;
    },
    dispara: 25,
    recupera: 15,
    severidade: (v) => v >= 40 ? "critico" : "degradado"
  }
];
var estados = /* @__PURE__ */ new Map();
async function notificarRoot(titulo, detalhe, incidenteId) {
  const roots = await prisma.user.findMany({
    where: { role: "ROOT", ativo: true, deletedAt: null },
    select: { id: true }
  });
  for (const r of roots) {
    await notificar(r.id, "incidente", { titulo, detalhe }, { entidadeTipo: "incidente", entidadeId: incidenteId });
  }
}
async function avaliar() {
  for (const regra of REGRAS) {
    let valor;
    try {
      valor = await regra.ler();
    } catch {
      continue;
    }
    if (valor == null) continue;
    const est = estados.get(regra.chave) ?? { disparado: false, excedeuVezes: 0, pico: 0 };
    if (!est.disparado) {
      if (valor >= regra.dispara) {
        est.excedeuVezes++;
        est.pico = Math.max(est.pico, valor);
        if (est.excedeuVezes >= (regra.pendentes ?? PENDENTES_PADRAO)) {
          const sev = regra.severidade(est.pico);
          const detalhe = `${regra.titulo}: chegou a ${est.pico}${regra.unidade} (limite ${regra.dispara}${regra.unidade}).`;
          const existente = await prisma.incidente.findFirst({
            where: { regra: regra.chave, status: { in: ["ABERTO", "RECONHECIDO"] } },
            orderBy: { createdAt: "desc" }
          });
          const inc = existente ?? await prisma.incidente.create({
            data: {
              regra: regra.chave,
              titulo: regra.titulo,
              severidade: sev,
              componente: regra.componente,
              detalhe,
              valorPico: est.pico
            }
          });
          est.disparado = true;
          est.incidenteId = inc.id;
          est.excedeuVezes = 0;
          if (!existente) {
            await notificarRoot(`\u{1F6A8} ${regra.titulo}`, detalhe, inc.id);
          }
        }
      } else {
        est.excedeuVezes = 0;
        est.pico = 0;
      }
    } else {
      est.pico = Math.max(est.pico, valor);
      if (est.incidenteId) {
        await prisma.incidente.update({ where: { id: est.incidenteId }, data: { valorPico: est.pico } }).catch(() => {
        });
      }
      if (valor < regra.recupera) {
        if (est.incidenteId) {
          const inc = await prisma.incidente.update({
            where: { id: est.incidenteId },
            data: { status: "RESOLVIDO", resolvidoEm: /* @__PURE__ */ new Date() }
          }).catch(() => null);
          if (inc) {
            const durMin = Math.round((Date.now() - new Date(inc.createdAt).getTime()) / 6e4);
            await notificarRoot(
              `\u2705 Resolvido: ${regra.titulo}`,
              `Voltou ao normal (${valor}${regra.unidade}) ap\xF3s ${durMin}min.`,
              inc.id
            );
          }
        }
        est.disparado = false;
        est.excedeuVezes = 0;
        est.pico = 0;
        est.incidenteId = void 0;
      }
    }
    estados.set(regra.chave, est);
  }
}
var intervalo = null;
function startAlertas() {
  if (intervalo) return;
  intervalo = setInterval(() => void avaliar().catch(() => {
  }), INTERVALO_MS);
  intervalo.unref();
}

// src/server.ts
var app = Fastify({ logger: true, trustProxy: true, maxParamLength: 5e3 });
await app.register(cookie, { secret: config.SESSION_SECRET });
await app.register(cors, { origin: config.WEB_ORIGIN, credentials: true });
var wsOrigin = config.WEB_ORIGIN.replace(/^http/i, "ws");
await app.register(helmet, {
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'self'"],
      formAction: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "blob:"],
      fontSrc: ["'self'", "data:"],
      connectSrc: ["'self'", wsOrigin],
      workerSrc: ["'self'", "blob:"],
      ...isProd ? { upgradeInsecureRequests: [] } : {}
    }
  },
  // Permite abrir recursos próprios (ex.: download de arquivo/PDF) sem bloquear cross-origin legítimo.
  crossOriginResourcePolicy: { policy: "same-origin" },
  crossOriginEmbedderPolicy: false
});
await app.register(rateLimit, { max: 300, timeWindow: "1 minute" });
await app.register(fastifyTRPCPlugin, {
  prefix: "/trpc",
  trpcOptions: {
    router: appRouter,
    createContext,
    onError({
      path,
      error,
      ctx
    }) {
      app.log.error({ path, err: error }, "tRPC error");
      if (error.code === "INTERNAL_SERVER_ERROR") {
        void registrarErro({
          rota: path ?? null,
          mensagem: error.message,
          stack: error.stack ?? null,
          userId: ctx?.user?.id ?? null
        }).catch(() => {
        });
      }
    }
  }
});
app.get("/health", async () => ({ status: "ok", ts: (/* @__PURE__ */ new Date()).toISOString() }));
var upl = await validarPastaUploads();
app.log.info({ uploads: upl }, `[uploads] base=${upl.base} escrita=${upl.escrita}`);
await registrarRotasArquivos(app);
var here = dirname(fileURLToPath(import.meta.url));
var webDist = resolve2(here, "public");
if (isProd && existsSync(webDist)) {
  await app.register(fastifyStatic, { root: webDist, wildcard: false });
  app.setNotFoundHandler((req, reply) => {
    if (req.url.startsWith("/trpc") || req.url.startsWith("/socket.io")) {
      return reply.code(404).send({ error: "Not found" });
    }
    return reply.sendFile("index.html");
  });
}
initRealtime(app);
startReminderLoop();
startMonitor();
startAlertas();
await app.listen({ port: config.API_PORT, host: "0.0.0.0" });
app.log.info(`API ouvindo na porta ${config.API_PORT}`);
//# sourceMappingURL=server.js.map