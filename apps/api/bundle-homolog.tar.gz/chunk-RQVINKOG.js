var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));

// ../../packages/db/src/index.ts
var src_exports = {};
__export(src_exports, {
  EQUIPE_REAL: () => EQUIPE_REAL,
  STAGE_DEFAULTS: () => STAGE_DEFAULTS,
  getSlowQueries: () => getSlowQueries,
  podeRodarDemoSeed: () => podeRodarDemoSeed,
  prisma: () => prisma
});
__reExport(src_exports, client_star);
import { PrismaClient } from "@prisma/client";
import { performance } from "perf_hooks";
import * as client_star from "@prisma/client";

// ../../packages/db/src/seed-guard.ts
var HOSTS_LOCAIS = /* @__PURE__ */ new Set(["localhost", "127.0.0.1", "::1", "mysql", "host.docker.internal"]);
function hostDaUrl(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return null;
  }
}
function podeRodarDemoSeed(env) {
  if (env.NODE_ENV === "production") {
    return { permitido: false, motivo: "NODE_ENV=production \u2014 dados de exemplo nunca v\xE3o para produ\xE7\xE3o." };
  }
  const url = env.DATABASE_URL;
  if (!url) {
    return { permitido: false, motivo: "DATABASE_URL ausente \u2014 imposs\xEDvel confirmar que o banco \xE9 local." };
  }
  const host = hostDaUrl(url);
  if (!host) {
    return { permitido: false, motivo: "DATABASE_URL inv\xE1lida \u2014 imposs\xEDvel confirmar que o banco \xE9 local." };
  }
  if (HOSTS_LOCAIS.has(host)) {
    return { permitido: true, motivo: `banco local (${host})` };
  }
  if (env.DEMO_SEED_CONFIRMO === "1") {
    return { permitido: true, motivo: `host remoto (${host}) liberado por DEMO_SEED_CONFIRMO=1` };
  }
  return {
    permitido: false,
    motivo: `banco remoto (${host}) \u2014 o demo-seed insere dados fict\xEDcios e usu\xE1rios com senha padr\xE3o. Se for MESMO isso que voc\xEA quer, rode com DEMO_SEED_CONFIRMO=1.`
  };
}

// ../../packages/db/src/seed-config.ts
var STAGE_DEFAULTS = [
  { nome: "Novo", ordem: 0, cor: "#2DA8E1" },
  { nome: "Qualifica\xE7\xE3o", ordem: 1, cor: "#003591" },
  { nome: "Proposta", ordem: 2, cor: "#30AD73" },
  { nome: "Negocia\xE7\xE3o", ordem: 3, cor: "#F59E0B" },
  { nome: "Fechado", ordem: 4, cor: "#30AD73" }
];
var EQUIPE_REAL = [
  { chaveEmail: "SEED_ROOT_EMAIL", emailPadrao: "root@medconsultoria.com.br", nome: "Root", role: "ROOT" },
  {
    chaveEmail: "SEED_ADMIN_EMAIL",
    emailPadrao: "thais.garcia@medconsultoria.com.br",
    nome: "Tha\xEDs Garcia",
    role: "ADMIN"
  }
];

// ../../packages/db/src/index.ts
var SLOW_QUERY_MS = 300;
var SLOW_MAX = 100;
var slowBuf = [];
function getSlowQueries() {
  return [...slowBuf].reverse();
}
function createClient() {
  return new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"]
  }).$extends({
    query: {
      $allModels: {
        async $allOperations({ model, operation, args, query }) {
          const start = performance.now();
          const result = await query(args);
          const ms = performance.now() - start;
          if (ms > SLOW_QUERY_MS) {
            slowBuf.push({ op: `${model}.${operation}`, ms: Math.round(ms), ts: Date.now() });
            if (slowBuf.length > SLOW_MAX) slowBuf.shift();
          }
          return result;
        }
      }
    }
  });
}
var globalForPrisma = globalThis;
var prisma = globalForPrisma.prisma ?? createClient();
if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}

// ../../packages/shared/src/constants/roles.ts
var ROLES = ["CLIENTE", "FUNCIONARIO", "ADMIN", "ROOT"];
var ROLE_LEVEL = {
  CLIENTE: 0,
  FUNCIONARIO: 1,
  ADMIN: 2,
  ROOT: 3
};
function hasRoleLevel(role, required) {
  return ROLE_LEVEL[role] >= ROLE_LEVEL[required];
}

// ../../packages/shared/src/constants/email.ts
var EMAIL_CATEGORIAS = [
  { tipo: "lembrete", label: "Lembretes de compromisso", descricao: "Aviso antes de um evento ou reuni\xE3o come\xE7ar." },
  { tipo: "presenca_confirmada", label: "Presen\xE7a confirmada", descricao: "Quando um cliente confirma presen\xE7a numa reuni\xE3o pelo Portal." },
  { tipo: "tarefa_atribuida", label: "Tarefa atribu\xEDda a voc\xEA", descricao: "Quando algu\xE9m atribui um cart\xE3o/tarefa a voc\xEA." },
  { tipo: "tarefa_atrasada", label: "Tarefas atrasadas", descricao: "Resumo de tarefas suas que passaram do prazo." },
  { tipo: "projeto_participante", label: "Adicionado a um projeto", descricao: "Quando voc\xEA \xE9 inclu\xEDdo na equipe de um projeto." },
  { tipo: "suporte", label: "Mensagens de suporte", descricao: "Novas mensagens no canal de suporte do cliente." },
  { tipo: "documento_revisao", label: "Documento aguardando revis\xE3o", descricao: "Documentos que precisam da sua an\xE1lise.", minRole: "ADMIN" },
  { tipo: "conta_vencida", label: "Contas vencidas", descricao: "Alertas de contas a pagar/receber vencidas.", minRole: "ADMIN" },
  { tipo: "conta_a_vencer", label: "Contas a vencer", descricao: "Aviso de contas a pagar/receber que vencem em breve.", minRole: "ADMIN" },
  { tipo: "lead_novo", label: "Novo lead pelo site", descricao: "Quando algu\xE9m se cadastra pelo formul\xE1rio p\xFAblico.", minRole: "ADMIN" },
  { tipo: "lead_atribuido", label: "Lead atribu\xEDdo a voc\xEA", descricao: "Quando voc\xEA vira respons\xE1vel por um lead do funil." },
  { tipo: "lead_convertido", label: "Lead virou cliente", descricao: "Quando um lead do funil \xE9 convertido em cliente (venda fechada)." },
  { tipo: "lead_desistiu", label: "Lead desistiu pelo Portal", descricao: "Quando um lead informa pelo Portal que n\xE3o deseja mais avan\xE7ar." },
  { tipo: "lead_retomou", label: "Lead retomou o interesse", descricao: "Quando um lead que havia desistido retoma o atendimento pelo Portal." },
  { tipo: "proposta_aceita", label: "Proposta aceita pelo cliente", descricao: "Quando um cliente aceita a proposta pelo link/Portal." },
  { tipo: "proposta_recusada", label: "Proposta recusada pelo cliente", descricao: "Quando um cliente recusa a proposta pelo link/Portal." },
  { tipo: "servico_solicitado", label: "Cliente pediu servi\xE7os pelo Portal", descricao: "Quando um cliente escolhe servi\xE7os no Portal do Cliente." },
  { tipo: "documento_cliente_enviado", label: "Cliente enviou um documento", descricao: "Quando um cliente anexa um documento pelo Portal." },
  { tipo: "servico_cancelado", label: "Cliente cancelou um servi\xE7o", descricao: "Quando um cliente cancela um servi\xE7o pelo Portal." },
  { tipo: "incidente", label: "Alertas do sistema", descricao: "Incidentes t\xE9cnicos detectados na aplica\xE7\xE3o.", minRole: "ROOT" },
  { tipo: "erro", label: "Erros do sistema", descricao: "Novos erros registrados na aplica\xE7\xE3o.", minRole: "ROOT" }
];
var EMAIL_TIPOS = EMAIL_CATEGORIAS.map((c) => c.tipo);

// ../../packages/shared/src/constants/institucional.ts
var INSTITUCIONAL = {
  /** Nome fantasia, como aparece na marca. */
  nome: "MedConsultoria",
  /** Posicionamento do site: "gestão estratégica para clínicas". */
  tagline: "Gest\xE3o estrat\xE9gica para cl\xEDnicas e consult\xF3rios",
  /** Site público — é este que vai em documento/e-mail para o cliente. */
  site: "medconsultoria.com.br",
  siteUrl: "https://medconsultoria.com.br",
  /** E-mail comercial divulgado no site. */
  email: "comercial@medconsultoria.com.br",
  telefone: "(11) 94072-3055",
  cidade: "S\xE3o Paulo, SP",
  instagram: "@med.consultoria",
  instagramUrl: "https://instagram.com/med.consultoria",
  /** Endereço do workspace interno — NUNCA usar em material cliente-facing. */
  workspaceUrl: "https://workspace.medconsultoria.com.br"
};
var PENDENTE_THAIS = {
  razaoSocial: null,
  cnpj: null,
  enderecoCompleto: null,
  /** Foro de eleição dos contratos. */
  foro: null
};
var aPreencher = (campo) => `**[A PREENCHER: ${campo}]**`;
function qualificacaoContratada() {
  return [
    `a ${PENDENTE_THAIS.razaoSocial ?? aPreencher("RAZ\xC3O SOCIAL")}`,
    `nome fantasia **${INSTITUCIONAL.nome}**`,
    `inscrita no CNPJ sob o n\xBA ${PENDENTE_THAIS.cnpj ?? aPreencher("CNPJ")}`,
    `com sede em ${PENDENTE_THAIS.enderecoCompleto ?? aPreencher("ENDERE\xC7O COMPLETO")}, ${INSTITUCIONAL.cidade}`,
    `e-mail ${INSTITUCIONAL.email}`,
    `telefone ${INSTITUCIONAL.telefone}`
  ].join(", ");
}

// ../../packages/shared/src/schemas/auth.ts
import { z } from "zod";
var INVISIVEIS = new RegExp("[\\u200B-\\u200F\\uFEFF\\u00A0]", "g");
var textoColavel = () => z.string().transform((s) => s.replace(INVISIVEIS, "").trim());
var emailColavel = (mensagem = "E-mail inv\xE1lido") => textoColavel().transform((s) => s.toLowerCase()).pipe(z.string().email(mensagem));
var loginSchema = z.object({
  email: emailColavel(),
  // A senha também: colar de um gerenciador costuma trazer espaço rígido ou BOM na ponta.
  password: z.string().transform((s) => s.replace(INVISIVEIS, "")).pipe(z.string().min(1, "Informe a senha"))
});
var senhaForte = z.string().min(8, "A senha deve ter ao menos 8 caracteres").max(200, "Senha muito longa");
var updateProfileSchema = z.object({
  nome: z.string().trim().min(2, "Informe seu nome")
});
var changePasswordSchema = z.object({
  senhaAtual: z.string().min(1, "Informe a senha atual"),
  novaSenha: senhaForte,
  confirmar: z.string().min(1, "Confirme a nova senha")
}).refine((d) => d.novaSenha === d.confirmar, {
  message: "A confirma\xE7\xE3o n\xE3o confere",
  path: ["confirmar"]
});
var aceitarConviteSchema = z.object({
  token: z.string().min(1),
  novaSenha: senhaForte,
  confirmar: z.string().min(1, "Confirme a senha")
}).refine((d) => d.novaSenha === d.confirmar, {
  message: "A confirma\xE7\xE3o n\xE3o confere",
  path: ["confirmar"]
});
var solicitarResetSchema = z.object({
  email: z.string().trim().toLowerCase().email("Informe um e-mail v\xE1lido")
});
var redefinirSenhaSchema = z.object({
  token: z.string().min(1),
  novaSenha: senhaForte,
  confirmar: z.string().min(1, "Confirme a senha")
}).refine((d) => d.novaSenha === d.confirmar, {
  message: "A confirma\xE7\xE3o n\xE3o confere",
  path: ["confirmar"]
});

// ../../packages/shared/src/schemas/cliente.ts
import { z as z2 } from "zod";
var clienteTipoEnum = z2.enum(["PF", "PJ"]);
var situacaoComercialEnum = z2.enum(["PROSPECT", "NEGOCIACAO", "ATIVO", "INATIVO", "PERDIDO"]);
var SITUACAO_COMERCIAL = situacaoComercialEnum.options;
var SITUACOES_CLIENTE = ["ATIVO", "INATIVO"];
var setAtivoClienteSchema = z2.object({
  id: z2.string().min(1),
  ativo: z2.boolean()
});
var emailOpcional = z2.union([z2.string().trim().toLowerCase().email("E-mail inv\xE1lido"), z2.literal("")]);
var textoOpcional = z2.string().trim().max(2e3).optional().or(z2.literal(""));
var createClienteSchema = z2.object({
  nome: z2.string().trim().min(1, "Informe o nome"),
  tipo: clienteTipoEnum.default("PJ"),
  documento: textoOpcional,
  email: emailOpcional.optional(),
  telefone: textoOpcional,
  observacoes: textoOpcional,
  // Vazio = mantém/atribui ao criador (definido no serviço).
  responsavelId: z2.string().optional().or(z2.literal(""))
});
var updateClienteSchema = createClienteSchema.partial().extend({
  id: z2.string().min(1)
});
var portalMeusDadosSchema = z2.object({
  nome: z2.string().trim().min(1, "Informe o nome").max(160),
  tipo: clienteTipoEnum,
  documento: textoOpcional,
  email: emailOpcional.optional(),
  telefone: textoOpcional
});
var createContatoSchema = z2.object({
  clienteId: z2.string().min(1),
  nome: z2.string().trim().min(1, "Informe o nome"),
  cargo: textoOpcional,
  email: emailOpcional.optional(),
  telefone: textoOpcional,
  principal: z2.boolean().default(false)
});
var createNotaSchema = z2.object({
  entidadeTipo: z2.string().min(1),
  entidadeId: z2.string().min(1),
  conteudo: z2.string().trim().min(1, "Escreva algo")
});

// ../../packages/shared/src/schemas/lead.ts
import { z as z3 } from "zod";
var emailOpcional2 = z3.union([z3.string().trim().toLowerCase().email("E-mail inv\xE1lido"), z3.literal("")]);
var textoOpcional2 = z3.string().trim().max(2e3).optional().or(z3.literal(""));
var valorOpcional = z3.preprocess(
  (v) => v === "" || v === null || v === void 0 ? void 0 : v,
  z3.coerce.number().nonnegative().optional()
);
var createLeadSchema = z3.object({
  nome: z3.string().trim().min(1, "Informe o nome"),
  empresa: textoOpcional2,
  email: emailOpcional2.optional(),
  telefone: textoOpcional2,
  origem: textoOpcional2,
  valorEstimado: valorOpcional,
  observacoes: textoOpcional2,
  pipelineStageId: z3.string().optional(),
  responsavelId: z3.string().optional().or(z3.literal("")),
  // Serviços da MedConsultoria que o lead precisa (catálogo editável).
  servicoIds: z3.array(z3.string()).optional()
});
var updateLeadSchema = createLeadSchema.partial().extend({
  id: z3.string().min(1)
});
var moveLeadSchema = z3.object({
  id: z3.string().min(1),
  pipelineStageId: z3.string().min(1),
  ordem: z3.number().int().nonnegative()
});
var novaOportunidadeSchema = z3.object({
  clienteId: z3.string().min(1),
  servicoIds: z3.array(z3.string()).optional(),
  valorEstimado: valorOpcional,
  observacoes: textoOpcional2
});
var solicitarServicosSchema = z3.object({
  servicoIds: z3.array(z3.string()).min(1, "Escolha ao menos um servi\xE7o"),
  mensagem: textoOpcional2
});
var capturaLeadSchema = z3.object({
  nome: z3.string().trim().min(1, "Informe seu nome").max(120),
  email: z3.string().trim().toLowerCase().email("Informe um e-mail v\xE1lido"),
  telefone: z3.string().trim().max(40).optional().or(z3.literal("")),
  empresa: z3.string().trim().max(120).optional().or(z3.literal("")),
  mensagem: z3.string().trim().max(2e3).optional().or(z3.literal("")),
  // Serviços marcados no formulário público.
  servicoIds: z3.array(z3.string()).optional(),
  // Rastreamento de atribuição (preenchido automaticamente pelo formulário).
  utmSource: z3.string().max(200).optional(),
  utmMedium: z3.string().max(200).optional(),
  utmCampaign: z3.string().max(200).optional(),
  utmTerm: z3.string().max(200).optional(),
  utmContent: z3.string().max(200).optional(),
  gclid: z3.string().max(300).optional(),
  fbclid: z3.string().max(300).optional(),
  referrer: z3.string().max(500).optional(),
  landing: z3.string().max(500).optional(),
  // Honeypot: deve chegar VAZIO. Se vier preenchido, é bot (tratado no serviço).
  website: z3.string().optional()
});
var precoRecorrenciaEnum = z3.enum(["AVULSO", "MENSAL"]);
var createServicoSchema = z3.object({
  nome: z3.string().trim().min(1, "Informe o nome do servi\xE7o").max(120),
  descricao: z3.string().trim().max(1e3).optional().or(z3.literal("")),
  categoria: z3.string().trim().max(60).optional().or(z3.literal("")),
  valor: z3.number().nonnegative().nullable().optional(),
  valorRecorrencia: precoRecorrenciaEnum.default("AVULSO"),
  percentual: z3.number().min(0).max(100).nullable().optional(),
  percentualRecorrencia: precoRecorrenciaEnum.default("MENSAL"),
  clausulasContrato: z3.string().trim().max(2e4).optional().or(z3.literal(""))
});
var updateServicoSchema = z3.object({
  id: z3.string().min(1),
  nome: z3.string().trim().min(1).max(120).optional(),
  descricao: z3.string().trim().max(1e3).optional().or(z3.literal("")),
  categoria: z3.string().trim().max(60).optional().or(z3.literal("")),
  valor: z3.number().nonnegative().nullable().optional(),
  valorRecorrencia: precoRecorrenciaEnum.optional(),
  percentual: z3.number().min(0).max(100).nullable().optional(),
  percentualRecorrencia: precoRecorrenciaEnum.optional(),
  clausulasContrato: z3.string().trim().max(2e4).optional().or(z3.literal("")),
  ativo: z3.boolean().optional()
});
var roteiroTarefaSchema = z3.object({
  titulo: z3.string().trim().min(1, "D\xEA um nome \xE0 tarefa").max(120),
  itens: z3.array(z3.string().trim().min(1).max(200)).default([])
});
var setRoteiroSchema = z3.object({
  servicoId: z3.string().min(1),
  roteiro: z3.array(roteiroTarefaSchema).max(30)
});
var createOrigemSchema = z3.object({
  nome: z3.string().trim().min(1, "Informe a origem").max(60)
});
var updateOrigemSchema = z3.object({
  id: z3.string().min(1),
  nome: z3.string().trim().min(1).max(60).optional(),
  ativo: z3.boolean().optional()
});
var etapaChaveEnum = z3.enum(["novo", "qualificacao", "proposta", "negociacao", "fechado"]);
var ETAPA_CHAVES = etapaChaveEnum.options;
var addServicoPassoSchema = z3.object({
  servicoId: z3.string().min(1),
  titulo: z3.string().trim().min(1, "Escreva o passo").max(200),
  etapaChave: etapaChaveEnum,
  obrigatorio: z3.boolean().default(false)
});
var updateServicoPassoSchema = z3.object({
  id: z3.string().min(1),
  titulo: z3.string().trim().min(1).max(200).optional(),
  etapaChave: etapaChaveEnum.optional(),
  obrigatorio: z3.boolean().optional()
});
var requisitoTipoEnum = z3.enum(["DOCUMENTO", "INFORMACAO", "BRIEFING"]);
var addRequisitoSchema = z3.object({
  servicoId: z3.string().min(1),
  titulo: z3.string().trim().min(1, "Descreva a exig\xEAncia").max(200),
  descricao: z3.string().trim().max(1e3).optional().or(z3.literal("")),
  tipo: requisitoTipoEnum.default("DOCUMENTO"),
  obrigatorio: z3.boolean().default(true),
  formularioId: z3.string().optional().or(z3.literal(""))
});
var updateRequisitoSchema = z3.object({
  id: z3.string().min(1),
  titulo: z3.string().trim().min(1).max(200).optional(),
  descricao: z3.string().trim().max(1e3).optional().or(z3.literal("")),
  tipo: requisitoTipoEnum.optional(),
  obrigatorio: z3.boolean().optional(),
  formularioId: z3.string().optional().or(z3.literal(""))
});
var ativarServicoClienteSchema = z3.object({
  clienteId: z3.string().min(1),
  servicoId: z3.string().min(1),
  valor: z3.number().nonnegative().nullable().optional(),
  observacao: z3.string().trim().max(1e3).optional().or(z3.literal("")),
  avisarCliente: z3.boolean().optional()
});
var cancelarServicoClienteSchema = z3.object({
  clienteId: z3.string().min(1),
  servicoId: z3.string().min(1),
  motivo: z3.string().trim().max(1e3).optional().or(z3.literal(""))
});
var atualizarContratacaoClienteSchema = z3.object({
  clienteId: z3.string().min(1),
  servicoId: z3.string().min(1),
  valor: z3.number().nonnegative().nullable().optional(),
  valorRecorrencia: precoRecorrenciaEnum.optional(),
  percentual: z3.number().min(0).max(100).nullable().optional(),
  percentualRecorrencia: precoRecorrenciaEnum.optional(),
  observacao: z3.string().trim().max(1e3).optional().or(z3.literal(""))
});

// ../../packages/shared/src/schemas/projeto.ts
import { z as z4 } from "zod";
var textoOpcional3 = z4.string().trim().max(5e3).optional().or(z4.literal(""));
var dataOpcional = z4.preprocess(
  (v) => v === "" || v === null ? null : v,
  z4.coerce.date().nullable().optional()
);
var projetoStatusEnum = z4.enum(["ATIVO", "PAUSADO", "CONCLUIDO"]);
var cardStatusEnum = z4.enum([
  "A_FAZER",
  "EM_ANDAMENTO",
  "AGUARDANDO_CLIENTE",
  "AGUARDANDO_TERCEIROS",
  "CONCLUIDO"
]);
var prioridadeEnum = z4.enum(["BAIXA", "MEDIA", "ALTA", "URGENTE"]);
var createProjetoSchema = z4.object({
  clienteId: z4.string().min(1, "Selecione o cliente"),
  nome: z4.string().trim().min(1, "Informe o nome"),
  descricao: textoOpcional3,
  previsaoFim: dataOpcional,
  responsavelId: z4.string().optional().or(z4.literal(""))
});
var updateProjetoSchema = z4.object({
  id: z4.string().min(1),
  nome: z4.string().trim().min(1).optional(),
  descricao: textoOpcional3,
  status: projetoStatusEnum.optional(),
  previsaoFim: dataOpcional,
  responsavelId: z4.string().optional().or(z4.literal(""))
});
var setParticipantesSchema = z4.object({
  projetoId: z4.string().min(1),
  userIds: z4.array(z4.string())
});
var createCardSchema = z4.object({
  projetoId: z4.string().min(1),
  titulo: z4.string().trim().min(1, "Informe o t\xEDtulo"),
  descricao: textoOpcional3,
  status: cardStatusEnum.optional(),
  prioridade: prioridadeEnum.default("MEDIA"),
  prazo: dataOpcional,
  // Vazio = atribui ao criador (definido no serviço).
  responsavelId: z4.string().optional().or(z4.literal(""))
});
var updateCardSchema = z4.object({
  id: z4.string().min(1),
  titulo: z4.string().trim().min(1).optional(),
  descricao: textoOpcional3,
  prioridade: prioridadeEnum.optional(),
  prazo: dataOpcional,
  responsavelId: z4.string().optional().or(z4.literal(""))
});
var moveCardSchema = z4.object({
  id: z4.string().min(1),
  status: cardStatusEnum,
  ordem: z4.number().int().nonnegative()
});
var addChecklistSchema = z4.object({
  cardId: z4.string().min(1),
  texto: z4.string().trim().min(1, "Escreva o item")
});

// ../../packages/shared/src/schemas/evento.ts
import { z as z5 } from "zod";
var textoOpcional4 = z5.string().trim().max(2e3).optional().or(z5.literal(""));
var idOpcional = z5.string().optional().or(z5.literal(""));
var dataHoraOpcional = z5.preprocess(
  (v) => v === "" || v === null ? null : v,
  z5.coerce.date().nullable().optional()
);
var eventoTipoEnum = z5.enum(["COMPROMISSO", "RETORNO", "REUNIAO", "LEMBRETE", "PESSOAL"]);
var eventoEscopoEnum = z5.enum(["PESSOAL", "EMPRESA"]);
var recorrenciaEnum = z5.enum(["NENHUMA", "DIARIA", "SEMANAL", "MENSAL"]);
var eventoBase = z5.object({
  titulo: z5.string().trim().min(1, "Informe o t\xEDtulo"),
  descricao: textoOpcional4,
  tipo: eventoTipoEnum.default("COMPROMISSO"),
  escopo: eventoEscopoEnum.default("EMPRESA"),
  inicio: z5.coerce.date({ message: "Informe a data/hora de in\xEDcio" }),
  fim: dataHoraOpcional,
  diaInteiro: z5.boolean().default(false),
  local: textoOpcional4,
  linkReuniao: z5.union([z5.string().trim().url("Link inv\xE1lido"), z5.literal("")]).optional(),
  recorrencia: recorrenciaEnum.default("NENHUMA"),
  recorrenciaAte: dataHoraOpcional,
  clienteId: idOpcional,
  projetoId: idOpcional,
  // Membros da equipe convidados (além do dono). Cada um vê na agenda e recebe lembrete.
  participanteIds: z5.array(z5.string()).optional()
});
var MSG_FIM = "O hor\xE1rio de t\xE9rmino deve ser depois do in\xEDcio.";
var createEventoSchema = eventoBase.refine(
  (v) => v.diaInteiro || !v.fim || v.fim > v.inicio,
  { message: MSG_FIM, path: ["fim"] }
);
var updateEventoSchema = eventoBase.partial().extend({ id: z5.string().min(1) }).refine((v) => v.diaInteiro || !v.fim || !v.inicio || v.fim > v.inicio, { message: MSG_FIM, path: ["fim"] });
var listEventosSchema = z5.object({
  inicio: z5.coerce.date(),
  fim: z5.coerce.date()
});
var conflitoEventoSchema = z5.object({
  inicio: z5.coerce.date(),
  fim: dataHoraOpcional,
  ignorarId: z5.string().optional(),
  participanteIds: z5.array(z5.string()).optional()
});
var resumoAgendaSchema = z5.object({
  inicio: z5.coerce.date(),
  fim: z5.coerce.date(),
  rotulo: z5.string().max(60).optional()
});

// ../../packages/shared/src/schemas/conta.ts
import { z as z6 } from "zod";
var textoOpcional5 = z6.string().trim().max(2e3).optional().or(z6.literal(""));
var idOpcional2 = z6.string().optional().or(z6.literal(""));
var dataOpcional2 = z6.preprocess((v) => v === "" || v == null ? void 0 : v, z6.coerce.date().optional());
var contaTipoEnum = z6.enum(["PAGAR", "RECEBER"]);
var categoriaTipoEnum = z6.enum(["RECEITA", "DESPESA"]);
var escopoEnum = z6.enum(["EMPRESA", "PESSOAL"]);
var carteiraEnum = z6.enum(["EMPRESA", "PESSOAL", "TUDO"]);
var carteiraInputSchema = z6.object({ carteira: carteiraEnum.default("EMPRESA") });
var createContaSchema = z6.object({
  tipo: contaTipoEnum,
  escopo: escopoEnum.default("EMPRESA"),
  descricao: z6.string().trim().min(1, "Informe a descri\xE7\xE3o"),
  valor: z6.coerce.number().positive("O valor deve ser maior que zero"),
  vencimento: z6.coerce.date({ message: "Informe o vencimento" }),
  categoriaId: idOpcional2,
  clienteId: idOpcional2,
  recorrencia: recorrenciaEnum.default("NENHUMA"),
  recorrenciaAte: dataOpcional2,
  observacoes: textoOpcional5
});
var updateContaSchema = createContaSchema.partial().extend({ id: z6.string().min(1) });
var listContasSchema = z6.object({
  carteira: carteiraEnum.default("EMPRESA"),
  tipo: contaTipoEnum.optional(),
  status: z6.enum(["TODAS", "PENDENTES", "PAGAS"]).default("TODAS")
});
var marcarPagaSchema = z6.object({ id: z6.string().min(1), pago: z6.boolean() });
var listCategoriasSchema = z6.object({ escopo: escopoEnum.default("EMPRESA") });
var createCategoriaSchema = z6.object({
  nome: z6.string().trim().min(1, "Informe o nome"),
  tipo: categoriaTipoEnum,
  escopo: escopoEnum.default("EMPRESA"),
  cor: textoOpcional5
});
var updateCategoriaSchema = createCategoriaSchema.partial().extend({
  id: z6.string().min(1)
});

// ../../packages/shared/src/schemas/usuario.ts
import { z as z7 } from "zod";
var roleEnum = z7.enum(ROLES);
var createUsuarioSchema = z7.object({
  nome: z7.string().trim().min(2, "Informe o nome"),
  email: z7.string().trim().toLowerCase().email("E-mail inv\xE1lido"),
  senha: senhaForte,
  role: roleEnum,
  // Obrigatório quando role = CLIENTE (escopo do Portal). Validado no serviço.
  clienteId: z7.string().optional().or(z7.literal(""))
});
var inviteUsuarioSchema = z7.object({
  nome: z7.string().trim().min(2, "Informe o nome"),
  email: z7.string().trim().toLowerCase().email("E-mail inv\xE1lido"),
  role: roleEnum,
  // Obrigatório quando role = CLIENTE (escopo do Portal). Validado no serviço.
  clienteId: z7.string().optional().or(z7.literal(""))
});
var updateUsuarioSchema = z7.object({
  id: z7.string().min(1),
  nome: z7.string().trim().min(2, "Informe o nome").optional(),
  email: z7.string().trim().toLowerCase().email("E-mail inv\xE1lido").optional(),
  role: roleEnum.optional(),
  ativo: z7.boolean().optional(),
  clienteId: z7.string().optional().or(z7.literal("")),
  // Se preenchida, redefine a senha (e revoga sessões existentes).
  novaSenha: senhaForte.optional().or(z7.literal(""))
});
var deleteUsuarioSchema = z7.object({
  id: z7.string().min(1),
  // Para quem transferir clientes/leads/projetos/tarefas do excluído. Vazio = deixar sem responsável.
  transferirParaId: z7.string().optional().or(z7.literal(""))
});

// ../../packages/shared/src/schemas/conversa.ts
import { z as z8 } from "zod";
var conversaTipoEnum = z8.enum(["INDIVIDUAL", "GRUPO", "PROJETO", "CLIENTE"]);
var chamadoStatusEnum = z8.enum(["ABERTO", "EM_ANDAMENTO", "RESOLVIDO"]);
var chamadoPrioridadeEnum = z8.enum(["BAIXA", "NORMAL", "ALTA"]);
var conversaCategoriaEnum = z8.enum(["direta", "grupo", "cliente", "lead"]);
var startIndividualSchema = z8.object({ outroUserId: z8.string().min(1) });
var createGrupoSchema = z8.object({
  nome: z8.string().trim().min(1, "Informe o nome do grupo"),
  participantIds: z8.array(z8.string().min(1)).min(1, "Selecione ao menos um participante")
});
var sendMensagemSchema = z8.object({
  conversaId: z8.string().min(1),
  conteudo: z8.string().trim().min(1).max(4e3)
});
var renomearGrupoSchema = z8.object({ conversaId: z8.string().min(1), nome: z8.string().trim().min(1).max(80) });
var gerirParticipanteSchema = z8.object({ conversaId: z8.string().min(1), userId: z8.string().min(1) });
var addParticipantesSchema = z8.object({ conversaId: z8.string().min(1), userIds: z8.array(z8.string().min(1)).min(1) });
var conversaIdSchema = z8.object({ conversaId: z8.string().min(1) });
var iniciarChamadoSchema = z8.object({
  clienteId: z8.string().min(1),
  assunto: z8.string().trim().min(1, "Informe o assunto").max(120),
  prioridade: chamadoPrioridadeEnum.optional()
});
var setChamadoStatusSchema = z8.object({ conversaId: z8.string().min(1), status: chamadoStatusEnum });
var setChamadoResponsavelSchema = z8.object({ conversaId: z8.string().min(1), responsavelId: z8.string().nullable() });
var setChamadoAssuntoSchema = z8.object({ conversaId: z8.string().min(1), assunto: z8.string().trim().min(1).max(120) });
var setChamadoPrioridadeSchema = z8.object({ conversaId: z8.string().min(1), prioridade: chamadoPrioridadeEnum });
var editarMensagemSchema = z8.object({ mensagemId: z8.string().min(1), conteudo: z8.string().trim().min(1).max(4e3) });
var mensagemIdSchema = z8.object({ mensagemId: z8.string().min(1) });
var togglePreferenciaSchema = z8.object({ conversaId: z8.string().min(1), ligar: z8.boolean() });
var portalAbrirChamadoSchema = z8.object({ assunto: z8.string().trim().min(1, "Informe o assunto").max(120), mensagem: z8.string().trim().max(4e3).optional() });
var portalEnviarChamadoSchema = z8.object({ conversaId: z8.string().min(1), corpo: z8.string().trim().min(1).max(4e3) });

// ../../packages/shared/src/schemas/documento.ts
import { z as z9 } from "zod";
var assinarSchema = z9.object({
  token: z9.string().min(1),
  metodo: z9.enum(["DESENHO", "DIGITADO"]),
  imagem: z9.string().optional(),
  // data-URI PNG (quando DESENHO)
  nomeDigitado: z9.string().trim().max(120).optional(),
  consentimento: z9.literal(true, { errorMap: () => ({ message: "\xC9 necess\xE1rio concordar para assinar." }) })
}).refine((v) => v.metodo === "DESENHO" ? !!v.imagem : !!v.nomeDigitado?.trim(), {
  message: "Assine desenhando ou digitando seu nome.",
  path: ["imagem"]
});
var tipoModeloEnum = z9.enum([
  "PROPOSTA",
  "CONTRATO",
  "BRIEFING",
  "ESCOPO",
  "ONBOARDING",
  "CHECKLIST",
  "ATA",
  "RELATORIO",
  "PAUTA_REUNIAO",
  "PAUTA_POSTAGEM",
  "RECIBO",
  "DIAGNOSTICO",
  "PLANO_ACAO"
]);
var statusDocumentoEnum = z9.enum(["RASCUNHO", "EM_REVISAO", "APROVADO", "ENVIADO"]);
function situacaoDocumento(d) {
  if (d.assinadoEm) return { key: "ASSINADO", label: "Assinado", variant: "success" };
  if (d.propostaStatus === "ACEITA") return { key: "ACEITA", label: "Aceita", variant: "success" };
  if (d.propostaStatus === "RECUSADA") return { key: "RECUSADA", label: "Recusada", variant: "danger" };
  if (d.propostaStatus === "PENDENTE")
    return { key: "AGUARDANDO_ACEITE", label: "Aguardando aceite", variant: "warning", atencao: "AGUARDANDO_CLIENTE" };
  if (d.assinaturaSolicitadaEm && !d.assinadoEm)
    return { key: "AGUARDANDO_ASSINATURA", label: "Aguardando assinatura", variant: "warning", atencao: "AGUARDANDO_CLIENTE" };
  switch (d.status) {
    case "EM_REVISAO":
      return { key: "EM_REVISAO", label: "Em revis\xE3o", variant: "warning", atencao: "REVISAR" };
    case "APROVADO":
      return { key: "APROVADO", label: "Aprovado", variant: "primary" };
    case "ENVIADO":
      return { key: "ENVIADO", label: "Enviado", variant: "success" };
    case "RASCUNHO":
    default:
      return { key: "RASCUNHO", label: "Rascunho", variant: "default" };
  }
}
var textoOpcional6 = z9.string().trim().max(200).optional().or(z9.literal(""));
var createModeloSchema = z9.object({
  nome: z9.string().trim().min(1, "Informe o nome"),
  tipo: tipoModeloEnum,
  corpo: z9.string().min(1, "Escreva o corpo do modelo")
});
var updateModeloSchema = createModeloSchema.partial().extend({ id: z9.string().min(1) });
var createDocumentoSchema = z9.object({
  modeloId: z9.string().min(1, "Selecione um modelo"),
  clienteId: z9.string().optional().or(z9.literal("")),
  titulo: textoOpcional6,
  variaveis: z9.record(z9.string(), z9.string()).optional()
});
var OPERADORAS_COMUNS = [
  "Unimed",
  "Bradesco Sa\xFAde",
  "SulAm\xE9rica",
  "Amil",
  "Hapvida NotreDame Interm\xE9dica",
  "Porto Seguro Sa\xFAde",
  "Golden Cross",
  "Care Plus",
  "Omint",
  "Prevent Senior",
  "Cassi",
  "Assim Sa\xFAde",
  "Mediservice",
  "Allianz Sa\xFAde"
];
var documentoServicoItemSchema = z9.object({
  servicoId: z9.string().min(1),
  valor: z9.number().nonnegative().default(0),
  quantidade: z9.number().int().min(1).default(1),
  // Cobrança do item: avulso (1x) ou mensal, e um % opcional (Faturamento).
  recorrencia: z9.enum(["AVULSO", "MENSAL"]).default("AVULSO"),
  percentual: z9.number().min(0).max(100).nullable().optional()
});
var criarPropostaSchema = z9.object({
  clienteId: z9.string().optional().or(z9.literal("")),
  /** Modelo de proposta escolhido (comercial × credenciamento) — vira a moldura do documento. */
  modeloId: z9.string().optional(),
  itens: z9.array(documentoServicoItemSchema).default([]),
  /** Credenciamento: operadoras a credenciar (entram no corpo) — em vez do catálogo de serviços. */
  operadoras: z9.array(z9.string().trim().min(1).max(80)).max(40).optional(),
  /** Credenciamento: investimento por operadora (o total = valor × nº de operadoras). */
  valorPorOperadora: z9.number().nonnegative().optional(),
  prazo: z9.string().trim().max(200).optional().or(z9.literal("")),
  condicoes: z9.string().trim().max(300).optional().or(z9.literal("")),
  observacoes: z9.string().trim().max(2e3).optional().or(z9.literal("")),
  titulo: textoOpcional6,
  /** Se true, a IA escreve a apresentação/escopo (quando disponível). */
  usarIA: z9.boolean().optional()
}).refine((v) => (v.itens?.length ?? 0) > 0 || (v.operadoras?.length ?? 0) > 0, {
  message: "Escolha ao menos um servi\xE7o ou uma operadora.",
  path: ["itens"]
});
var criarContratoSchema = z9.object({
  clienteId: z9.string().min(1, "Selecione o cliente do contrato"),
  modeloId: z9.string().optional(),
  itens: z9.array(documentoServicoItemSchema).default([]),
  /** Vigência em meses (padrão 12) — vira o texto de prazo/renovação do contrato. */
  vigenciaMeses: z9.number().int().min(1).max(120).default(12),
  observacoes: z9.string().trim().max(2e3).optional().or(z9.literal("")),
  titulo: textoOpcional6
}).refine((v) => v.itens.length > 0, {
  message: "Escolha ao menos um servi\xE7o para o contrato.",
  path: ["itens"]
});
var contextoClienteDocSchema = z9.object({
  clienteId: z9.string().min(1),
  tipo: tipoModeloEnum
});
var updateConteudoSchema = z9.object({
  id: z9.string().min(1),
  conteudo: z9.string()
});
var responderPropostaSchema = z9.object({
  token: z9.string().min(1),
  decisao: z9.enum(["ACEITA", "RECUSADA"]),
  motivo: z9.string().trim().max(1e3).optional().or(z9.literal(""))
}).refine((v) => v.decisao === "ACEITA" || !!v.motivo?.trim(), {
  message: "Conte rapidamente o motivo para nos ajudar a melhorar.",
  path: ["motivo"]
});
var setStatusDocumentoSchema = z9.object({
  id: z9.string().min(1),
  status: statusDocumentoEnum
});
var gerarComIASchema = z9.object({
  modeloId: z9.string().min(1, "Selecione um modelo"),
  clienteId: z9.string().optional().or(z9.literal("")),
  titulo: textoOpcional6,
  instrucoes: z9.string().trim().min(1, "Descreva o que a IA deve gerar").max(4e3)
});
var melhorarComIASchema = z9.object({
  id: z9.string().min(1),
  instrucao: z9.string().trim().min(1, "Descreva o ajuste").max(2e3)
});
var resumirReuniaoSchema = z9.object({
  anotacoes: z9.string().trim().min(1, "Cole as anota\xE7\xF5es da reuni\xE3o").max(12e3),
  clienteId: z9.string().optional().or(z9.literal("")),
  titulo: z9.string().trim().max(200).optional().or(z9.literal(""))
});
var gerarPautaSchema = z9.object({
  topicos: z9.string().trim().min(1, "Diga o que voc\xEA quer tratar na reuni\xE3o").max(4e3),
  clienteId: z9.string().optional().or(z9.literal("")),
  titulo: z9.string().trim().max(200).optional().or(z9.literal(""))
});

// ../../packages/shared/src/schemas/formulario.ts
import { z as z10 } from "zod";
var campoTipoEnum = z10.enum([
  "TEXTO_CURTO",
  "TEXTO_LONGO",
  "ESCOLHA",
  "MULTIPLA",
  "NUMERO",
  "SIM_NAO",
  "DATA"
]);
var createFormularioSchema = z10.object({
  titulo: z10.string().trim().min(1, "D\xEA um t\xEDtulo ao formul\xE1rio").max(120),
  descricao: z10.string().trim().max(2e3).optional().or(z10.literal(""))
});
var updateFormularioSchema = z10.object({
  id: z10.string().min(1),
  titulo: z10.string().trim().min(1).max(120).optional(),
  descricao: z10.string().trim().max(2e3).optional().or(z10.literal("")),
  ativo: z10.boolean().optional()
});
var addCampoSchema = z10.object({
  formularioId: z10.string().min(1),
  rotulo: z10.string().trim().min(1, "Escreva a pergunta").max(200),
  tipo: campoTipoEnum.default("TEXTO_CURTO"),
  obrigatorio: z10.boolean().default(false),
  opcoes: z10.array(z10.string().trim().min(1)).optional(),
  ajuda: z10.string().trim().max(300).optional().or(z10.literal(""))
});
var updateCampoSchema = z10.object({
  id: z10.string().min(1),
  rotulo: z10.string().trim().min(1).max(200).optional(),
  tipo: campoTipoEnum.optional(),
  obrigatorio: z10.boolean().optional(),
  opcoes: z10.array(z10.string().trim().min(1)).optional(),
  ajuda: z10.string().trim().max(300).optional().or(z10.literal(""))
});
var salvarRespostaSchema = z10.object({
  requisitoId: z10.string().min(1),
  respostas: z10.record(z10.union([z10.string(), z10.array(z10.string())])),
  enviar: z10.boolean().default(false)
});

// src/lib/email.ts
import nodemailer from "nodemailer";

// src/config.ts
import { z as z11 } from "zod";
var schema = z11.object({
  NODE_ENV: z11.enum(["development", "test", "production"]).default("development"),
  API_PORT: z11.coerce.number().default(4319),
  DATABASE_URL: z11.string().min(1, "DATABASE_URL \xE9 obrigat\xF3rio"),
  SESSION_SECRET: z11.string().min(16, "SESSION_SECRET deve ter ao menos 16 caracteres"),
  WEB_ORIGIN: z11.string().url().default("http://localhost:4310"),
  OPENAI_API_KEY: z11.string().optional(),
  // Interruptor GLOBAL da IA (privacidade): "false"/"0" desliga a IA MESMO com chave presente.
  // Útil para cortar o envio de dados à OpenAI sem remover a chave. Ver docs/IA_PRIVACIDADE.md.
  IA_ENABLED: z11.string().optional(),
  // Pasta persistente onde ficam os arquivos enviados (upload). Relativa ao cwd do
  // processo ou absoluta. Na TineHost deve apontar para uma pasta FORA do diretório do
  // deploy (que é sobrescrito no rsync) e entrar no backup. Ver DECISIONS (pendência de deploy).
  UPLOADS_DIR: z11.string().default("storage/uploads"),
  // E-mail transacional (opcional). Sem SMTP_HOST, o app roda em "modo dev":
  // os convites/links são exibidos na tela em vez de enviados por e-mail.
  SMTP_HOST: z11.string().optional(),
  SMTP_PORT: z11.coerce.number().optional(),
  SMTP_USER: z11.string().optional(),
  SMTP_PASS: z11.string().optional(),
  SMTP_FROM: z11.string().optional()
});
var parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error("\u274C Configura\xE7\xE3o inv\xE1lida:\n", parsed.error.flatten().fieldErrors);
  process.exit(1);
}
var config = parsed.data;
var isProd = config.NODE_ENV === "production";
if (isProd) {
  const origem = process.env.WEB_ORIGIN;
  const problema = !origem ? "WEB_ORIGIN n\xE3o definida" : origem.includes("localhost") || origem.includes("127.0.0.1") ? `WEB_ORIGIN aponta para o ambiente local ("${origem}")` : !origem.startsWith("https://") ? `WEB_ORIGIN sem https ("${origem}") \u2014 o cookie de sess\xE3o \xE9 "secure" em produ\xE7\xE3o e n\xE3o voltaria` : null;
  if (problema) {
    console.error(
      `\u274C Configura\xE7\xE3o inv\xE1lida para produ\xE7\xE3o: ${problema}.
   Defina WEB_ORIGIN no .env do servidor com o dom\xEDnio p\xFAblico exato (ex.: https://workspace.medconsultoria.com.br).`
    );
    process.exit(1);
  }
}
var iaDesligada = ["false", "0", "off", "no"].includes((config.IA_ENABLED ?? "").trim().toLowerCase());
var isAiEnabled = !!config.OPENAI_API_KEY && !iaDesligada;
var isEmailReal = !!(config.SMTP_HOST && config.SMTP_USER && config.SMTP_PASS);

// src/lib/email-template.ts
var LOGO_CID = "logo@medconsultoria";
var CORES = {
  azulEscuro: "#002463",
  verde: "#30AD73",
  link: "#003591",
  texto: "#334155",
  muted: "#64748b",
  borda: "#e2e8f0",
  fundo: "#f1f5f9"
};
var FONTE = "'Montserrat', Arial, Helvetica, sans-serif";
function esc(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function montarEmail(opts) {
  const origem = config.WEB_ORIGIN;
  const ano = (/* @__PURE__ */ new Date()).getFullYear();
  const paragrafosHtml = opts.paragrafos.map(
    (p) => `<p style="margin:0 0 16px;font-size:15px;line-height:1.6;color:${CORES.texto};">${p}</p>`
  ).join("");
  const botaoHtml = opts.cta ? `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 4px;">
         <tr><td align="center" bgcolor="${CORES.verde}" style="border-radius:8px;">
           <a href="${opts.cta.url}" target="_blank"
              style="display:inline-block;padding:13px 26px;font-family:${FONTE};font-size:15px;font-weight:600;color:#ffffff;text-decoration:none;border-radius:8px;">
             ${esc(opts.cta.texto)}
           </a>
         </td></tr>
       </table>` : "";
  const notaHtml = opts.nota ? `<p style="margin:14px 0 0;font-size:12px;line-height:1.5;color:${CORES.muted};">${opts.nota}</p>` : "";
  const saudacaoHtml = opts.saudacao ? `<p style="margin:0 0 12px;font-size:16px;font-weight:600;color:${CORES.azulEscuro};">${esc(opts.saudacao)}</p>` : "";
  const html = `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title>${esc(opts.titulo)}</title>
</head>
<body style="margin:0;padding:0;background:${CORES.fundo};">
  <div style="display:none;max-height:0;overflow:hidden;opacity:0;">${esc(opts.preheader)}</div>
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${CORES.fundo};padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="width:600px;max-width:600px;background:#ffffff;border:1px solid ${CORES.borda};border-radius:14px;overflow:hidden;">
        <!-- Cabe\xE7alho (fundo branco p/ o logo aparecer + faixa verde de acento) -->
        <tr>
          <td align="center" bgcolor="#ffffff" style="padding:30px 24px 26px;border-bottom:3px solid ${CORES.verde};">
            <img src="cid:${LOGO_CID}" alt="MedConsultoria" width="185" style="width:185px;max-width:75%;height:auto;display:block;border:0;">
          </td>
        </tr>
        <!-- Corpo -->
        <tr>
          <td style="padding:32px 34px 8px;font-family:${FONTE};">
            <h1 style="margin:0 0 18px;font-size:21px;line-height:1.3;color:${CORES.azulEscuro};font-weight:700;">${esc(opts.titulo)}</h1>
            ${saudacaoHtml}
            ${paragrafosHtml}
            ${botaoHtml}
            ${notaHtml}
          </td>
        </tr>
        <!-- Assinatura -->
        <tr>
          <td style="padding:22px 34px 30px;font-family:${FONTE};">
            <p style="margin:0;font-size:15px;line-height:1.6;color:${CORES.texto};">
              Atenciosamente,<br><strong style="color:${CORES.azulEscuro};">Equipe MedConsultoria</strong>
            </p>
          </td>
        </tr>
        <!-- Rodap\xE9 -->
        <tr>
          <td style="padding:20px 34px;background:#f8fafc;border-top:1px solid ${CORES.borda};font-family:${FONTE};">
            <p style="margin:0 0 6px;font-size:12px;line-height:1.6;color:${CORES.muted};">
              <a href="${origem}" target="_blank" style="color:${CORES.link};text-decoration:none;font-weight:600;">Acessar o workspace</a>
              &nbsp;\xB7&nbsp;
              <a href="mailto:${INSTITUCIONAL.email}" style="color:${CORES.link};text-decoration:none;">${INSTITUCIONAL.email}</a>
              &nbsp;\xB7&nbsp;
              <a href="${INSTITUCIONAL.siteUrl}" target="_blank" style="color:${CORES.link};text-decoration:none;">${INSTITUCIONAL.site}</a>
            </p>
            <p style="margin:0 0 4px;font-size:11px;line-height:1.6;color:${CORES.muted};">
              Voc\xEA recebeu este e-mail porque h\xE1 uma a\xE7\xE3o relacionada \xE0 sua conta no Workspace MedConsultoria.
              Se n\xE3o reconhece esta solicita\xE7\xE3o, ignore esta mensagem.
            </p>
            <p style="margin:0;font-size:11px;line-height:1.6;color:${CORES.muted};">
              \xA9 ${ano} MedConsultoria. Seus dados s\xE3o tratados conforme a LGPD.
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
  const linhas = [];
  if (opts.saudacao) linhas.push(opts.saudacao, "");
  linhas.push(opts.titulo, "");
  for (const p of opts.paragrafos) linhas.push(p.replace(/<[^>]+>/g, ""), "");
  if (opts.cta) linhas.push(`${opts.cta.texto}: ${opts.cta.url}`, "");
  if (opts.nota) linhas.push(opts.nota.replace(/<[^>]+>/g, ""), "");
  linhas.push("\u2014", "Atenciosamente, Equipe MedConsultoria", origem);
  const texto = linhas.join("\n");
  return { html, texto };
}

// src/lib/brand-assets.ts
var LOGO_PNG_BASE64 = "iVBORw0KGgoAAAANSUhEUgAABQUAAANsCAYAAADiK86oAAEAAElEQVR4nOz9CXxcd33v/3+OJNtxnCCFrWxBGhK2kMTKF2hIQFih7EutWI4ld8HKbbndiVOaXYll0A1bb+PQ3tuFJXb/99Yj21Ls0pVSIiMaCMuJREhISGCsQH/00kIsCEkc25r/4zs6Y4/k0cw5M2f7fs/ryUPY1kgzJ0ejmXPe5/P9fJxisSgAAMRB7c13iEh3lZu6RJyuOt9e8b1O9a8oLvN5kcMizrSPTZyscv+H3U39fr4XAAAAAIzhEAoCAIJSe/+mt+KfvRUhmg72KsM9HeK1V7zt1HpLCrAFgUPBcO7/5OdnFoLGpWFiyaGFj9LXHnI3Xa7/DQAAAACpQigIAChRe/9PZbVe76khn7Mk4Fv0duL3bafB21IXCjZyH7MVYeHk4gBRxN3UVxksAgAAAECkCAUBICPU3v/TXbEEd+mfXtjXaKhGKOh/n9Tdj+UqxGnvz3JwOO1uWl9ZnQgAAAAADSMUBABLqL3/v3LA17Xko1vEWabCbylCwdr7IepqQ1/3P1PRI1GHhLrC8LC76ZfpewgAAADAN0JBADCM2vvX5Qq/Xv/BX9SVfFQK+t8nkS5xnhVxDpWDQq/acNrd9B4qDAEAAAAsQigIACml9u4qV/3pP8t/Xxtt2EQoaEClYCP3P7cQEJaqCw+dDAvfTVgIAAAAZBShIAAkTO3d2eEN8agM/9Yt/x2EgoYOGvFxH7Hfvzf8pFRZWAoM3U3vZhkyAAAAkAGEggAQewBYCv56K0LAzvSETVQKNr6PjQwFl3PQqyr0KgrfRVAIAAAAWIZQEAAipPbe0XsyACxVA3Yu83Ic4F4JBakUjPp5UPVrD1YsQZ52N72ToBAAAAAwGKEgAIRE7b2je0kV4NolL7m1Xo4DPBKhIKFgKu7f61NYWnpcWn7sbnonPQoBAAAAQxAKAkCD1N7PeFWATjkEbK/zktvgbX6/luXD9BRM+nkmM5VBobvpnbpfIQAAAIAUIhQEAB/U3s/oXoAVS4ErB4FE3a/P79cSChIKJv08O+Vr5yoqCSfdTe9gyTEAAACQEoSCAFCF2vvpyhBQVwOurfFS6vclt8Hb/H4toSChYNLPs7pfWxESOpPuprcTEgIAAAAJIRQEAI/a+2kdAPZ5QWAE/QAJBSPfB8VUB2I+7sP0+w+8LeWQcP9CJeHbWW4MAAAAxIRQEEBmqb2fKg8F0UHgusbDFELB1OwDQkHTQsGlZnUF4cmQ8G0MLgEAAAAiQigIIDPU3k91VFQC9p06GIRQ0Ph9QChoeii49PMzXkC43930NpYaAwAAACEiFARgNbXvk91SdHQAqD9q9AW0IBCjpyChYOLPszCek8t+z1y5gtALCakiBAAAAJpAKAjAKmrfJ8sDQspBYHvt6rFKhILG7wMqBW0OBZeakaKzs7TMeOCtVBECAAAAAREKAjCe2vdXXSJOOQhcf8oXEArGENoRCvrfJyZUjDZ6/2FsS4D7P/m7PXuiD+HAW/WfAAAAAOogFARgcBBYCgGHFpYF1wgSCAUJBVMViBEKhraPq/9ue8uMHS8kfAvLjAEAAIAqCAUBGEPt+6tuLwTUYWDn4lsJBekpyPLhur8LqQlGQ7p/f8vFD5wYVkJACAAAAJxAKAjA4CCwEqEgoSChYN3fhWyGgpUICAEAAAAPoSCA1FH7/rIiCHRqBIGVCAUJBQkF6/4uEApWCQid/e7Am1liDAAAgMwhFASQCmrfX5Z7BG5dXBEYwgALegrSUzDQc6nW19JT0PBKweW+TgeEO92BNzOkBAAAAJlBKAggMWrfX3QsVAQ63rCQaggF/e+TJKcDM33Y/z5h0Ejj+yeyUHDJkBLdf5CAEAAAAHYjFAQQO7XvL8o9Atd7L0U1vppQ0P8+IRQMJyRqdB+HcR+m37/xoWClWW+C8U534Jem/W8UAAAAYAZCQQCxUPv+ordiYEj7kpeiGt9JKOh/nxAKEgom/TyzKhSsvG1Gh4NeQEj/QQAAAFiBUBBAZNS+P+/ygkC9RLixycGEggH2CaEgoWDSzzNrQ8FKB0Scne7Am+g/CAAAAKMRCgIIndr350uWB5debmq9FDV4m8+vY9AIPQUDPZdqfa3py3vTsg+MDgXLn5/zqgd3uANvOuTzwQAAAIDUIBQEEGZVoJ4cPHTq8uDSy02tl6IGb/P5dYSChIKBnku1vtb00C4t+8CKULDSQS8g3O8OvInlxQAAADACoSCAMKoC9ce6Oi83Edzm8+sIBQkFAz2Xan2t6aFdWvaBdaHg0unFunqQ4SQAAABINUJBAIGpff+7oirQaff5chPBbT6/jlCQUDDQc6nW15oe2qVlH1gbCp5SPegOvElXEAIAAACpQygIwDe1739XqQqM8sQ7pPsnFDTj5xRG2BRKSFTra00P7dKyDzIRCpa/tqL34GX0HgQAAEBqEAoCqEnt+18dIk65V2CnkWEToaAZPydCQUJBO0PByn8cWKgevIzJxQAAAEgcoSCAqtS+/9XtLRHekmwYRCjof58Y/nMiFCQUtD8ULJvVlYMizk53oJfBJAAAAEgEoSCARdS+/xVwibABYROVgmb8nAgFCQWzEwpWWVrcy9JiAAAAxIpQEICofX/WxBJhA8ImQkEzfk6EgoSC2QsFly4t1uHgZIA7BwAAABpGKAhkmNr3Zz6nCBMKGhGImf5zIhS04P7D2JbMhoJlMyLODndgHVOLAQAAEClCQSCD1L4/6/WqArekPwyiUtD/PjH850QoSCgY9HlgZyhY/rzXd1APJllH30EAAACEjlAQyF4YOLK4X2DawyBCQf/7xPCfE6EgoWDQ54HdoWDZnBcO6upBwkEAAACEhlAQyAC178+GvDCwSr/AtIdBhIL+94nhPydCQULBoM+DbISClXbp13J3YB1DSQAAANA0QkHAYmrfn+pegXXCwLSHQYSC/veJ4T8nQkFCwaDPg+yFgmWEgwAAAGgaoSBgGbXvTztODg/RYaDpYRChoP99YvjPiVCQUDDo8yC7oWDZgYWhJG9kYjEAAAACIxQE7AsD9Ue7PWEQoaD/fWL4z4lQkFAw6POAULC8vw4uLCsmHAQAAIB/hIKA4dS+T3SIOFXCQFvCIEJB//vE8J8ToSChYNDnAaHg0v1FOAgAAADfCAUBo8PAcmWgUyUMtCUMIhT0v08M/zkRChIKBn0eEAout78IBwEAAFAXoSBgdBhYrgy0OQwiFPS/Twz/OREKEgoGfR4QCtb7nfLCwR56DgIAAOAUhIKA0WFgFsIgQkH/+yR1P6c5EZmu+PchEefQkq/Rtx+uch/T7hUD3uejo/bs6xYR/bu1hFPt870V26hvW5vczymt9x/GthAKRrCPCQcBAABwCkJBwABq3yf0JOEd1XsGpjIMStf916wmsqhKLp5t1OGCpsO9csA3LeKUA7xp94rNkYd5aaP2TFSGiN7fS/ur1/tc18I0cFOeB43efxjbQigY4T7Wv79D7kDP0nAeAAAAGUQoCKQ/DBw5GSZYGtoRCqYlDDrofd3kkiq+Q+4Vv0qIEBK1Z385KCwHiV0nP5w6v+uVCAVZPlzreVDztl3esmJ+rwEAADKMUBBIIbXv9r6FykC/AYHhoR2hYFyh4KxX3VcO+0p/ulf8Gv3GUkTtOVAOCcuhYfnPdYu/klCQULDW86DebSfCwa3uQE/mqnsBAABAKAikitp3e69XGbgu/mWphILp3Qd+v3ZR/7Dy8l4d/B1yr/j1yt5+MJTac6AcEnaLOPrvvYuXJmssH66/H2Jc4pzK+19kTsTR7Sl2uANvIBwEAADIECoFgRRQ+27XJ/X6pGz94lsIBekp6Dv8m9RDPNwrfp3lgBml9vytFxA6XdXDQo2egmaEdrGGguWv04OBRtyBN+j3IgAAAGQAoSCQILVvhx5GoE/AtlT/CkJBQkGpXPY76Q31mHaveC/hH+q/xuz5bEVlYam6sOvUZcgGB2I1hwhRKdjgPtCvN1vdgTfs9/+DAAAAgIkIBYHEwkDZuvDhLDNRWCMUzGAoqE/Ip72PUgjoXrGFJX0IldrzdxVBYemjSlBIKGjEPojutemgVzlIz1EAAABLEQoCMVP7diyZKJyWXnWOvfef3lBw7mT455T+JABEwkFhb0VV4drUB2JUCsbx+uxNKn491ckAAACWIRQEYqL27VgyROTEr2GN7yIUtCwUnFlcATjE8A+kltrz9+Wlx73eR8ABSPW+llAw5ZWClbfpCxjeMJLXU7kMAABgCUJBIGJq32268f9IY30DCQUNDwUPVoSAk+4VV3IyDaOpPX+vKwjLIaH+qNH+QCMUNHj5cLXbZr2qwZ0+7xgAAAApRigIRETtuy2EvoGEgoaFggcrAkD6cMF6as8/lCcdlz8CTDumUtDAUHBJv8HX8zoHAABgMEJBIAJq32193lKrJvsGEgqmPBSc8foB6hCQSZ3IPLXnHyqXG/c2dkGEnoIGhIKV/Qa3ugOXUgUNAABgIEJBIPSlwrIzvL6BhIIpCwX10jldGaMDwEn3iv/GiTBQg9rzjzok7Fvck7De7xuhoEGhYLnf4Ig7cKm+EAYAAACDEAoC4S4V3rbMr1qtX8MGb0vLfVgfCh44WQ343xgMAjRI7fnHjooqwj4RpzPA72F1TB9O0+vzjFc1yJJiAAAAQxAKAqEvFa76qybh35aW+7AuFJw9WQn4GywJBiKi9vyTrqzu8z4qqggJBQ2rFFyKJcUAAACGIBQEGqT2/YmeKlxlqXDVX7UIbkvLfVgRCuoKl50L1YC/QTUgEDO15586Ti4zdvrqTzX2UCmY1tdnlhQDAAAYgFAQaIDa9ycj9acKL/pVi+C2tNyHAfdfXHZZsFcR+JuHfD4IgBioPf/sLTEufSxfhU0omPbX54PekmIutgAAAKQQoSAQgNr3J/pEdae/qcKLftUiuC0t92HA/S8EB3PlEFD/6V7xmwwJAQyg9vyzHlYyVDUgJBQ05fX59oVhJJfwugsAAJAihIKAD2rfn3R4fQO3LPkV8vurFsFtabmPVN//QhBYdHQISH9AwHBqzz+X+xDqkHAtoaBRr8+6X+tWd+ASXosBAABSglAQqEPt+5M+rzqwPeUnXAndR+ruv1wRuN/d+D5OPgGbA8Jiqf/g1upLjB2DB4EYPWik3tfp1g1DVA0CAAAkj1AQWIba9z91RcoOEWd9jV8hv79qEdyWlvtIzf0fqAgDWaIGZIga+1yVJcaEgil6fV76iTmvalBfcAMAAEBCCAWBKtS+/6krT/QwkXZDArEE7yPR+9dN7PVJ5X53438nCARQDgi3+p9inMZKPqsrBSsdFHGG3IHXMewJAAAgAYSCwKnVgTpkWlfxa1LrV8jvr1oEt6XlPmK//1mvv6MOAjmRBLAsNfYv5f6DDVZ8EwrG8PqvqwZH3IHX6dd1AAAAxIhQEKhaHbjo16TWr5DfX7UIbkvLfcRy/+U+gTvcjf992ucDAkCJGvsXPSyq3H9wbfOvTVQKBtsPvvaxrvymahAAACBGhILIPLXvj7tEnCXVgYt+TWr9Cvn9VYvgtrTcR6T3f0DE0RWB9J0CEAo19i9dXjg41HiLCELBYPvB9z6mahAAACBGhILINLXvj73qQKc9g4FbSPcR+v3r5cE6BNzpbvwtlgcDiHh5sVNjeTGhYELvL1QNAgAAxIBQEBmuDqzsHZiaQCzm+w/jPkK7/wNeEKiXCQNAbNTY5/V7wpD30bnktakKKgWD7YeG3kPmRJwRd+Bieg0CAABEhFAQGa4OrOwdmHggltD9h3EfTd2/VxXoUBUIIBXU2OcrhpMQCqbg/cWrGryYynEAAICQEQoiM9S+P9aN5vdX7x2Y1tDO2lBQn+TtcDf+NlWBAFJcPehU9B6sRKVgzO8vutfgVnfgYvrLAgAAhIhQEJmgxv+4T4ql5cLtZoV2VoWC+qRupxcGUvEBwBhq7F+HFk8uJhRM6P3lgFc1eNjnAwMAAKAGQkFYTY2XqgN1P6ItUjQxtLMiFJz1hrnsdzf+NidyAIylxv61d6Fy0Nni/7vSON04rPtI5P7npCh97uDFkz4fHAAAAMsgFIS11PjHe3WvuhNN4wkF4z4p9JYI/w5LhAFYRY19oTyYRFcP1pherxEKhv7+svB+fru+4OQOUjUIAADQKEJBWEmNf1wPEtm26ISCUDCuk7ZdpRO1jb/DEmEA1lNjX9Dh4MjiqcWVCAUjCgW1mdJy4sGLp33+uAAAAFCBUBBWUeMf19Ub+6v2fSIUjPKkbc5bpq0rA1kiDCBz1NgX+rzKwSXDrAgFIwwFy193tTv4i/o9CAAAAAEQCsIaavzj+oRsyTARQsGIez7Niji6QmY/YSAAlMJBr++geH0HCQVjCAVPDiEZ/EUuTAEAAPhEKAjjqfGPnxwmcgpCwYhCwdLwEHfj7+oQFgBQve/gSO2hJAwaCTEULFet97mDv8gQEgAAAB8IBWE0Nf6xbm+YiLdceClCwZBDwYNeGMgJFwD4eZ8au6vGUBJCwZBDwbLt7uAv6ip2AAAA1EAoCGOp8Y9t9aowakx+JBQMKRQkDASAJqixu3RV+9bF4SChYEShoHbQW07M0CsAAIBlEArCOGr8Y/rESlcHrg90QsGgkTqWPakacTf+HpWBABB6OLjcRS2/F3MS7Smb9lBQmxNxhtzB1+oBZAAAAFiCUBAGLhcuTRfuPPlZQsEITtoIAwEg8nDQWVI5WPX1uI4UhnbpCQXLt93uDr5W72cAAABUIBSEMdT4x4a8gSIBTp6oFAx40kYYCAAxUmOTAZYVGxLapS8ULL+/9bmDr2U6MQAAgIdQEKYsF15murBGKBjCSdtBEYdlwgCQinCwVq9cA0K7dIaCFdOJX0tLDAAAAEJBGLJcuMZ0YY1QsImTNq8y8Pc5QQKA1ISDyy0rNiS0S28oWLbdHXwt04kBAEDmUSmI1FLjH+vzAsE6J0WEgg2cEM3oE07CQABIJzV2sFw5uK32V6YwtEt/KKgdWJhOzHJiAACQXYSCSCU1/tEdIs5V/r6aUDDACdGsVxmow1YAQMqpsYNd+nW76RYaNWUyFCxfINPB4HStLwIAALAVoSBSRY1/tMObLrwu9JONYgj3Eei2VN3/nFcZSBgIAOaGg/o1fJ2F71FJhYIn3x8HX8v7IwAAyBxCQaSGGv9otxcIdi58hlAwhH0wJ+LoIS073I2/z8RFADCcGjvY61UOrkttaGdWKFj+utvdwdfo5doAAACZQSiIVFDjHx3yJgxX9A8kFGxyH+xaqA78A8JAALCMGjuo3zdHRBzvQlo1hIIB94EevtXnDr6G900AAJAJhIJISf9AqdI/kFCwwX2gT2qG3I1/cCikHxEAIKXU2BdHlp9UTCjYwD6Y9YJB+gwCAADrEQoiMWr8Ix0ijtc/sBpCwYD7YNYLAydD/DEBAFJOjX1R9+MdOfUCG6Fgg/vA6zP4GvoMAgAAqxEKIhFq/CO6f+BOEWft8l9FKOhzH+i+gSPuxj/QFZcAgIxSY19cMoyEULDJfbDdHXyNDlsBAACsRCiI2Knxj+gm6bpCsD3WBuZ2Th++XVeHuBvfT/8jAECJGvtir3fhrTPh9yiTBo0sd8MuEWerO/hq3mcBAIB1CAURKzX+Ed0Y/Y6Kp2CNryYUrLEPdN/Are7G99PzCABQ/T13bKpGv0G/77eZDwX1PpgRkV6CQQAAYBtCQcRGjX9EL2nasuQpWOM7CAWr7INZrzKQPkcAgPrvvWNTekmxbi+xvrH3W0JBbx/MecEgF+MAAIA1CAUR00ARWWagCKFggH2wXZ/YsVQYABD4vXhsyltSLFWWFBMK+twH3gCSV3NhDgAAWIFQEJFS4x/uFnH0wfMyA0UIBX3sA5YKAwAiXFJMKBhwH2x3B1/NABIAAGA8QkFEHAjKpIhTo5cRoWCNfaCnCuu+gVQkAAAiXFJMKNjAPtjlDr5a90kGAAAwFqEgIqHGP1wxUCQlJxtmTR/etTBI5CqmHQIAIqHGpvoWwsFaU4rpKVhjH8yIOL3uoOK9GgAAGIlQEKFT4x/Wy5Juq3ia1XoKNnibtaGgHiQy5G68atLnHQMA0DA1NtUh4uilsFdV/wpCQR+TifvcQXWIpyEAADANoSBCpcY/HOKE4cyFgtvdjVfRowgAEDs19iXd8qNKD2BCQf+TiRWTiQEAgFEIBREKNf7hDu9kYn2Vp1mtp2CDt1kVCnqDRK7iZAIAkCg19qUlg0gIBQNMJh5yB9X+GH5MAAAAoSAURFiB4GT4E4atDwX1CcSIu3GrbvYOAEAqqLEvdXkX+tYRCgY+DrjSHVQMCAMAAEYgFEQYE4arLDda9DST8G8zPhTU1YFD7sat9CACAKSSGvvSVq/foFc1GNuwrdq3nfJ+nrpqxu3uoKIdCAAASD1CQTQbCE4uf7Jw4mkWwW3GhoJUBwIAjKHG/q2ianApQsEa+2CXO6iGIv7xAAAANIVQEA1R47f2ijj76weCpadZBLcZGQpSHQgAMJIa+zfdZ3BJ1SChYJ19sKvUM3hQHY7hRwQAABAYoSACU+O36ivfdyR2MmBeKDinl1/ROxAAYFfVIKGgj30w400mJhgEAACpQyiIBgPB0tPH79MsgtuMCQW96sCr6R0IALCsatDxsVogkz0Fl5oRcXrdwYsIBgEAQKoQCsI3NX6rXja0reLp4/dpFsFtRoSCV7sbr2ayMADA0qrBUhuRGoPGyjIfCup9oCsGh9zBi6Zj+PEAAAD4QigIX9T4rXq50JYlTx+fey9zoeDCgf/GqznwBwBYTY3dveSCYTWEgt4+0MPGdMUgxwcAACAVCAXRYCBYevr4fZpFcFtqQ8Ht7sar9QkSAACZoMbu7vZ6DS5TNUgoWLEPCAYBAEBqtCS9ATA1EMQSsyJyGYEgACBr3IFLdeVbr4jcnvS2GED3YZxU+Xt1kAoAAJAoKgVRlRr/Hx36oFXEqdEriEpBbx8c8JYL00AcAJBpauzuPq9qsGIICZWCy+yDK93Bi/S+AgAASAShIGoEgnoZUOon+iW5fHhOxNnqbryaA3oAADxq7G59HKGHkKxr4j3WpunDtb6OYBAAACSGUBA1AsHSU6TW08fv0yyC2xIPBb1hIn9Is3AAAGoOISEUrLMPrnQHu7nACAAAYkcoiBqBYOkpUuvp4/dpFsFtiYaCt7sb/3Crv20DACDrQ0gcXTXYWf0rMl8pWN4HBIMAACB2DBpBjUAQS+iJgZcTCAIAEGgISbfXfxfLu0Plp4fYQQAAIE5UCqJOIEiloLcP9HLhPnfjHx7iKQMAQHBq7Mu6yv62po8z7OopuPQ2KgYBAEBsCAUzrn6FoEUH2o0vH2a5MAAAIVBjX9ZVgxXLiQkFq+wDgkEAABALlg9nGEuG62K5MAAAIXIHLmE5cX0sJQYAALGgUjCj/AeCma0U9JYLf4DlwgAARLac2FmynFiyvny4EhWDAAAgUlQKZpAaH2WoSG27RKSXQBAAgOi4A5fsEJHLvMp8nIqKQQAAECkqBTMbCDo+pwxnrlLwSnfjB3b6fGAAANAkNfaVZS5WZr5SsIyKQQAAEAlCwcxWCEYd6BkXCs56y4V1ryMAABAzNfYVXTl41cnPEApWIBgEAAChY/lwRrBkuKaDItJNIAgAQHLcgddt1eEXy4mrukPlZ4bi/pkAAAC7USmY2UCQSkHP7e7GP9InIQAAIAXU2Fe6RWS/iNOZ8UEj1b7uSndwLW1OAABAKAgFM1shSCi40D/wjziwBgAglX0GnSrHL5kPBTWCQQAAEApCwcwuGc50KKinHPa6G/+I/oEAAKSYGrtHX7zbsuiT2a4ULCMYBAAATaOnoKXU+IdqBIKZNiMiXQSCAACknztw8ZDXZxCL0WMQAAA0jVDQXnqCH4HgYru8CsHDCf1MAABAQO7Axbpa8DIGkJxih8rP6P6LAAAADWH5sIXU+Ie8pTapXO6S1P1vd/v/aMTnHQIAgJRRY/foAGynFIP0STbqWKWR+1hoiTK4lpYoAAAgMEJBawPB1B/ExnX/+mB5q9vPQBEAAEynxu7pkKKeTCzrLDpWafY+5kScXnfwQoJBAAAQCKGgRdT4h/SS4asMOoiN5yC5n4EiAADYROUrB5AYfawS5kVQgkEAABAIPQUtocY/NLQ4EMw8PVCkm0AQAAD7uIMMIFmiXS+tVvlv6kFzAAAAvhAK2hMI3pH0dqTIwdLV8v5rDiW9IQAAIBruYGkAiZ5MrKvksDBgbpJgEAAA+MXyYcOp8Q/1icidBi93Cfv+d7n91+iQFIBH7fn7Ll05K1LUTfr1R7mSpDy1clqkqP/UQbruSTXtbnrPJDsQgAlU/qv6tWzSq5Yz4Vgl6vuYcQcvZCoxAACoi1DQYGr8g90izjIHwUYexDZ7/1e7/dfovopAZqk9/6ADv14vBPT+LL9GlIK/ZZxy25xIUTfz3+9u+mX9JwCklsp/VV/80K9VASYT+/06I4+ndrmDF3KRFAAA1EQoaHQgqK+KO8sEgsYexDZ6/1e6/dfoZURApqg9/1AO/sp/di4f9AUKBSs/NysiI+6mX+Z3DEBqqfxX9UWRycXBYKqOVeK+D4JBAABQE6GggdT4Bzu8JX6dlh7EBrl/PWG4z+2/hqWOyAS15x91+Ff+WBcs6Gs4FCybFSkOuZvW8/sGIM3B4A5/k4krWXs8td0dvHDE5wMAAICMIRQ0MxCsuApu7UGsn/vXjcV73f5rdUAKWEnt+aeKELC47tSviDUULH9ul4hsdTetP1zjDgEgMSr/VV3ZvCUFxyopuA/nSnfwAiq9AQDAKQgFDaPGP6gDwXUZOYitdaczItLn9l/LhGFYRe35Z70EuM/rB7iuseAu8lCw/DuoqwYJ5QGkksp/dauIc5u/r7b+eOoyd/ACqrwBAMAihIIGUeMf9K56Z+ogtpoZr0KQKiUYT+35Z90cXweAfd6fNYaCpCoUPFmtSzAIIKVU/mt62MYd9b/S+uOphdfrwQu4kAMAAE4gFDSEGv+g7gezLYMHsUsRCMJ4auxzuhpwSJxSNeCSSZllRoSCGsEgAAuCwUwcT+nX62538AJWWQAAgBJCQQOo8Q/WOJjNxEFs2S63/1q9LwDjqLF/0UuCdTVg34lqQCeSkK7GbZE93sKJ5qb1nGgCSCWV/5q+GDN5sho7s8dTCxdXBy9gtQUAAJA29kG6qfEP9vpb9mI9AkEYRY39ix4KVA4B14vd9En2fh0MJr0hAFCNO/jaaZX/Wm/tYDAT1nqv13pfAACAjKNSMMXU+AfrXNXOzJVtAkFYEgQuqbKzp1KwfNvt7qa+rTW+AABSWjGYieOpSrvcwQtYfQEAQMYRCqaUGv+gDhd0M+jO2l9p/UHsdrf/Wt1PEUglNfb5iiCwWKci0PpQUP/fRe6mPhrZA0h7MLhzcU9X64+nqrnaHbxgh88HBwAAFiIUTCk1/sHp5QcQVLL6IPZKt/9afdAOpI4a+9dyj8At/gKzzISCB91NfSxLs5Da90lvUnZRByr6o+PU96mi7leme5VNex/73Y2/Re8ypI7Kf63Dqxhcm4HjqVp3eqU7eAHHWgAAZBShYAqp8e07RZyKoKEWaw9ir3T7r+MgFamixv5VByFbTw4LCRK6ZSYU1C5zN/Xpk20YTu37pA5OhryPtQ0+j3RQqF/Pd7obf5uAECkNBq09nqp3/wsT5AcvoMIbAICE5HpG9cX3rooL70sd8j6mC1PDoR5PEwqmjBrfrgOH2xI+QEz6PggEkRpq7Av6xVlXBW49dTk/oeAy++OAu6lPB6cwlNr7KX0wskOcUjVse4jh8gGR4k534+/oQQdAioJBZ62Fx1N+718Hg11MJAYAIB65ntHKXvS9AYegzXoXNfcXpoabPqYmFEwRNb5dPyHuTMkBYlL3QSCIVFBjXxhaPDDET9UclYIVcu6mPn01C4ZRez+l+7jqELy9ejVrsxWnxXIIoasHd7gbf4fnCVIQDDoVS4mtOJ4Kev8zIk6vO3g+1bwAAEQk1zOqA0B9nulzZWhdJ46pC1PDDR1TEwqmhBrfvmQaXioOEOO+DwJBpKEqcKv3Qu2jOopQsMb+uNrd1EcDe4OovZ86dfhCdKFgpYMLS4t/h5YRSIzKf31Jj0Gjj6cavf9d7uD5TCQGACBkuZ5RfZytz43WSXR26XPZoMuLCQVTQI1vrzJpODUHiHHdB4EgEqPG7vJ6phVrvEgTCi6/H6ruIwaOGETt/ZSuit15ShgeTyhYNqeXFi9UD/4u1YNIUTBo1PFUs/d/tTt4Phd0AAAIb5mwXoVzlcRDVw6OFKaGfb+XEwqmgBrfXmXScKoOEKO+DwJBxE6N3dVVMUChM+KwI2uDRkrcTX1+XySQILX3U/p34I6qN8YbClbedtALB+k9iBQEg8YcT4V1/5e7g+fzuwcAQPPVgYtX4cRHH0v3+akaJBRMxaThauvJU3eAGNV9EAgiVmps0uvjUKzye0coWH9/BNpHTCFOObX30/p3oXogmGwoWDYrUtRXOne6G3+PXmdIKBg04ngqzPv3JhKfz0RiAAAakOsZrb4KJ16l9/PC1HDN93NCwQSp8e3LV2ek7wAxivu40u2/nh5SiIUamyxXBXpLhOMOO7JXKVj6Hd/Ux+94Sqm9n9YB+V01f6bJh4KVg0l05dKIu/H3WFqMmIPB1B9PRXH/M14wSBgPAEAAuZ7RGjlP7Oa8PoPLnpMRCiZEjY90izj3GnaAGOZ9EAgicmrsYMfJwSHFip6dGqFgY/sjUKCz3d3Up3toIGXU3k/r5fP6qmG7IaFgpQO6etDd+Ps6sAFiCAadtSk+nory/g+4g+frSgcAAOC/QvBOSZ+LlqsYbIl/W6DGR8pXn7OKQBCRUmMHu9TYQb3kUFcUbVs8xAdACpYzNGO9rnBU+/5sUu37MyalIjLu4Gt0lVyvVzWXRetV/ltc2AEAIFgPwTSa9LbvFISCyZg0+GSsWQSCiDoM1C/EBW/CU1Z/z4A6fQTLy+iNpv8b7lD7/uwQ4SCiQjAo21T+W1QLAgBg9kV3vV07vWnIixAKxkyNjyQ1fSYNCAQRCTX2xV419sVyGFhlgAiA0u/K3s/oAwFdRWuTzopwcETt+9NTDnaAZriDr856xeBOlb+/anUBAAAQXSU4YkDOo7fvlBUAhIIxUuMjQxkOLAgEEVUYqCtv78rw7xYQxNYUX8EMIxzU7QIOqX1/SjiIUGU8GCxVF6j8/QTuAAAs4S3L1cegJrgq1zOqj2dOIBSMdbCIddUZfl3NlGGESY1NVYaBNiyDBOIylJEAg3AQUQaDsxncvWszfBwLAEAtpr0/LqoWZPpwfINFpk8ddmDkJLqg97HL7b8hCyehiCkM9F7E1jU/GZfpw43tj0CTYy93N/Xtr/ENiJHa+xlvGlqAacDpnD4c9D7m9LRifcDmbny/DnWApqj8N7pP9oe2evpwtduudgdfZdrJDwAAkcgtVN3pQhXTXFaYGi4Nv6VSMB47Mzr9lEAQIVYGTlEZaB49/RnpkdVhARWVg58YUfs+wRJINMUdfLW+0KtPAuYyuCtvo78gAAAnDBncUqiESsGIqfERvbNvs/yqcTUEgmiaGpvq8sqx1596K5WCy++HVFRozbmb+ghfUkTt/YyukmvPYKXgKc9NfSDkbny/vmAHNFkx6HgVg/VYdcynf4e63MFXUXkLAMis3MIk38fEXLnC1PChtqS3wmZqfJs+WFwmELTaQZYMoxlq7Etd3jJhhoeYq1SOjnRQez/TbfGAkaD0frhDVw3q15nlwkHvQC+IucLUcK20EhZWDKq825emZUPFI0cDhX3OqhWN/g7p1hCLGpUDAJAxfWL+9u8gFIyIGt/WkdGT4hkLfjmQEDX2Jf17s9Wg6U1YHr0E04WT91JgUpTiMZH5x47rf3Y+/d1jd7zi8x/9+NHZY9+af7zY9D7K9YxW/vNuEfm69/f7ROQRr8KqICJHClPDTzb7eEieO6gmVd69UgfNkTzAfFGKR49J8amnZf7xI6XQ7+i//1fppuM/mpNj//GTUB+u7XnPlNbnnlX6e+uzniGt7WvEWblCWp6xRpwVbSItJwLGdSp//4g7+KpFzcoBAMiQPjGbPvYlFIz4hLg9g4Fgr9t/A8tJEJga+9KIFwhm7ffGRjr4IBRMl47MhX9PFuX4j4/L0R8ck6PfPSbzP5tf7sufHVFoeqn3UStALAeHd4rID0Tk3wkLzeMOqp0q70pTweB8UeZ18PfY43LsPx6T4/81J08/8kOJmw4Z6wWNK899obQ+u0MHiNsu+Mi/3vf433/5H3jeAgAyqFcs2H56CkZAjW8bOVnplJr+L/H0lyEQREBq7N9KZcsixSrDeMLoPbbcbUwfbmx/+NrHu9xNfaY23TVWrmfUWRqqF6aGSxdp1N7P6Mr1dQuftayn4LzI/JPzcvw/FgLAI9NHxAKf8FYb6ArDQ4Wp4WNJbxDqU3m34viv9vGUrvg7/l8/lae/9x9y9Hv/T+Yff9KW560OuB8Skf9gOT0AwFa5nlHdmudeMV+OUDCSPoKVT47UhHZR3v+cVyGop/EBvqixf9NXJkaWDyqW+1yt2wgFUzLgIedu6mPycIRyPaO6/Yfuval/j94qIlfU+vqVr1j97yvPWf3C1me1SUtHq/Gh4PzPj8vRwjF5+oGn5dgPM5GX3e1Voemg8LuELeml8u7Oav1wi0eOnQgBj3wzMy+Pe0Vkt4h8pTA1HH/ZIwAAEcn1jPZ5F8JMdxmhYPh9BHUw1pmy0C7K+ycQRCBq7O4OkeKOU0+aCAUtmT5MlWCEcj2j54rIH4jI+5u5n9WXnikrzz1NWjrazAgF56W0FPjIA0dsqQQMI2z53yJyD8s200flXd0+Yf383BOlJcBHvjUr848/lfRmpcGN3nOX6lcAgNFyPaM1VgcYZTuDRsKlrw5XWQJpta1UCMIvNXY3fQPtNuf1hUQ0YeCuWj3qgnjy7p+VPtqev1JWX3KGtL1opaSOFwQ+9bUn5emHn056a9LminJ1aK5nVFcR/rGI/BMBYSqW8J/jrFoxUzxydH3Cm5NGt3ofel/pcPDDeok8y+MBAEgOlYIhUePb9InwbVV2ca3d3+Btqbn/K93+G3QQCtSkxu7uXRyaR1EFF/Tr6SnY2P6ouY8vdzf1MWAkRLme0dVeGFhzeXCz2p6/Qta88yxpWdOSeKXg/OHj8uTdBIEN0gHhTSLyJYKW+OR6Rp8vIkPlwAsNVxCyNB4AYIScRZWChIKR9BHMRCi4y+2/kUECqEmN3a17numlwksqJggFF369Yuvx18DXBn68Xe6m9bwmhCjXM6rD9LskRqf/UrusepXOIeMNBYvHivL0g0/LU199otaUYAQf+vCnhanhR9hxkfX1fI+I3C4iZ7OPQ/F9EfmgiPxfql4BAGmWIxTEkj6CuvH32gyFggSCqEuN3a2rZ0eWTkNdQChoWSg4425ary+OILwliDua7RvYqJUvPU3WvKMjllBwoSrwCZYHx1M9eJABJc3L9YzqX47foSowcoTaAIDUylkUCtJTsHkjyweCVpqhZxhqUWNf7vUCjSz9XmSZfk3QP3OEt1z482H1DmzE0w/rgQiHTwaDETj2g6Py8889TlVgPC4tV5zmekbfp1s5sLQ4+b6eqEtfFHm/1zPz9/UgP0JtAADCx/LhJqjxbT7GUFtVKTgrIt1u/42HfX4zMkSNfbnDC8mvWvhM3FVwQb+enoIh/ExKgaC7aT2vCeEFgg+lZSliqWLwne2h/l4uhIE/IwxMHuGgT4SBqVpa/F4qXgEAaZCzqFKQULC5ZcOHqi+NtDIU1FNFe93+G6d9fiMyRI19pU+kuGPx9G1CwVNZtXyYHoIWB4K1g8HgzyPCwNQiHFwGYWBqEQ4CABKXsygUZPlw43bWDwStMkQgiKXU2Fc6vN+FJYNEYDF9gWDI3bSeKcPh9hD8fNoCwfJS4pXfPU1WnLOqoe9fCAN/SmVgen1Sf7Cs+CTCwNQ721sO//1cz+j6wtTwMoP+AACAHy2+vgqLqPFbtmYsBLnS7b+RAABVqgNL1bJZ+l3IOt1Pq4tAMHQ70tyn7PG/OyzFI7WqA091/D+Pydxnfiw/Gz9MIGhOOPg9PfHaC6kzOUAk1zOqJwk/nObfRywKB91cz+i/5XpGn89+AQCgMSwfDkiN39Klmx2LOD6rBI1fPsykYSyixu7pEClWqQ6MbdJtSF9PT0Gf+0NXBuqLAiPupl/WITBClOsZvUif2KZ9p7Y9f4WcuemZdX/Pikfm5fEDc3Lsh0dj2zaETg922FiYGv5hFvatF4L+hheMwuxpxdcXpoafTHpDAAD2y7F8ONP2Z2jZ8EG3/8ahpDcC6aHG7unL4NL5LNJB4KT3erff3fTLDBKJQK5nVLfwOCAG0CHfsR88LW0vWln9C+ZFnvrGE/Lk3Y/HvWkIn66S+/9yPaM6ZPmAzZOKvVD+QBqX7qPhacUb9PsWk4oBAPCHnoIBqPFbdDPJtZINetKwDoAArzqQ3oEWB4DTXgioKwGn3U3vYaBQPIZMCiN0b8D2//bsUz6vw8KFicLHE9kuRBqyXJ7rGX1vYWpYvz7YNtjnI95/I+wyoatdcz2jmal2BQCgGSwf9kmN39ItIvemcHlvFPfvTRq+iWAAOhDsPbVC1s/SW5YPp3T68IwXAOrf72l307v5PU+uStC4NbbP+JVnSetzWkt/Lx4ryhOf+6k8/fCRpDcL0dsrIltsWJqp+yZ6gypgvxt1+EvVIAAgbDmWD2eSXjKZFUMEglD5UnXgiDhyFXvDaAe9EHDS3fRuq6p9DPcGMdATd/1Uztx0lhz97hF5/O/09SNkxBX6I9czqkyd9uoF8X/j/bcgG24Vkd/J9YxeTNUgAADVsXzYh4wtG97u9t/EpOGMU/mvdntBeFae9zY5cDIEfBdVgOn1P8RAuregnirMUuHMcr1eg1tNqr7K9YyeKyJfMGm5PkJzttcjk16DAABUwfLhwMuGT+y6et9q4vLhA27/TfQRzDiV/+pWEbntxNLTqk8Vlg9X3w+JLB/Wy4F1kD/pbnonlYDm9DN7IuntAJrwfRG5sDA1fNiAycLXexVjgDXL4AEAycqxfDhTsrJsWAcLTBrOMJX/aocXLq1LeltQ01w5BFyYDPzOVJ+Uo6qL2S+woPrqsVzP6GVpHULihe+7WC6MCnrp+OtyPaNvKkwNP8KeAQCA5cM1ZWjZ8JzXR5BwIaNU/qtVhokgRcrVgPvdTe9gSbD5Lkl6A4CQ3JXG5cQsF0adQPvhXM/o+0Tk02l63gIAkISWRB7VAGr8Zr1seJtkA4NFMkzlvzbiTWIkEExfEHi1Pr91N72929309hECQWu8O+kNAEL0fhH5kleZl7hcz+jlOvShfyDq+KSIjHkDaAAAyCzeCJeXlWXDtzNYJJtU/mssF07nkBCvIvDtVO7a69KkNwCI4Dn9UJJTXr3+gTu8kBIIspw49f0xAQCICqFgFWr85qwsGz7o9t+kh0ogY1T+aywXTldFoD6R3e9uehsnJZajKgUZmPL60rj7tXm/V39D/0A00R8z9uctAABpwPLh7C4b1n0EmTScQSwXTtvS4Ld1u5vetpNAMDPOSHoDgIjpfm2/Gdde9pYtf49AECE8b/XScwAAMoVKwewuG+5jsEi2sFw4FUG8fn3Z6Q68lWEhAGz2yVzPqBSmhj8V5YPkekZ1G4xv0j8QIZnQA0iift4CAJAmhIIV1PjNWzOybHi723/TZNIbgfio/Ne7vV51nez3RPoE7nQH3qL3PwBkKRi8IKrJxN6EYT1QBAj7eftWERlgMjEAIAtYPuxR4zd3iYjuJWi7g27/cBb+O+FR+a8PiYgOgQkE4zOrw/fS8uCBt/QRCALIqPd7E171EJDQEAgihgEkoT9vAQBIIyoFT9LL+trFbvQRzBiV/7oeYHFV0tuRIVQFAsCpAYsO8kKpvCIQhInPWwAA0opKwYUqQT1wY53Yr8/tH2a6aQao/Dc6VP7rujqQQDCesP12qgIBINrKKwJBJPC8nfWG2QAAYKXMh4Jq/OaOjAwX2e72D9NHMANU/hu6f+BkRoLupJcIX+kOvLnDHXjzVnfgzYeS3iAAsDUYJBBEQs4WkYcIBgEAtsp8KOj1EbR92TB9BDNC5b/R5wWCWRiYk5SDInKZO/BLXe7Am7NwQQEAEg0GCQSRMIJBAIC1Mh0KqombezOwvJI+ghmh8t/QA0XuzEDInZRdC0uEf6nXHfglqm4BoIlg0O8XEwgiRcHgBMNHAAC2yXQoKCJ6CIPthugjaD+V/4auWLsj6e2wNFT3pgj/0pA78EssEQaA5l2R6xn9zXpflOsZfb6IPMwOR0q8nanEAADbZHb6sJq4eWsGllje7vYP7096IxAdlXd1T0z9M6Z/YPhhoL5osMMdeBPDeQAgfJ/M9YxKYWr4U9Vu9Hq43cOOR8owlRgAYJVMVgqqidJwEd1L0GYzbv+wDj5hdyDIQJFoKgO73IE3jRAIAkDkweBFywSCD3lLNoE0BoNZWG0EAMiATIaC3hu57X3XdH85WErlXT1h+FAGql3jQhgIAMlwvb6BJV7Pts8TCCLl3u9nCTwAAGmXuVBQTQzr4SJbxG5Xu/03Tye9EYiGyru9XoWg7cF2zGHgZVQGAkAyHvaqA8UbQnIpPwgYUumqj8kAADBWFnsK2l7uf9Dtv9n2/8bMUnlXV4AyUCTUnoGX0TMQAJL3UK5n9M/LPdsAQ9yV6xl9aWFq+JGkNwQAgEZkqlJQTZR67K21POjoS3ojEA0CwdDsOlkZSCAIACmh+wfemvRGAA34QkWlKwAARslMKKgmhrMwXGTI7b+ZqicLqfy9O6kQDCUMzLkDvUPuQC+/JwAAIAxne5Wuuh8mAABGydLyYduHixxw+2/en/RGILJA0PY+mFE6qC8IuAO9ug8jAABAFMGgPte4il0LADBJJkJBNTHcbXmoopcNM23YMip/b4d3gGnzczdKsyKy1R1YR1gOAADimEg8WZgavpNdDQAwRSZCwQwMF2HZsJ2B4KTlPTAjHSLiDqyzvV0AAABIl4lcz+gLClPDP0x6QwAA8MP6noJqYlgP3lgn9rqdZcN2UflpAsHm+gZ2EwgCAICE3EN/QQCAKbJQKbjD8uWRVENZhECwYTPeUmH6BgIAgCTRXxAAYAyrKwXVxLAOzDrFXiwbtgiBYMNLha92B97Y7Q68kUAQAACkpb/gRUlvBAAAmQ0F1cSwXoK5Vey1y+2/hRDEEgSCDTmwsFT4jTZXAwMAADO5uZ7R1UlvBAAAWV0+rHsJtou91VE2B56ZQiDY6FThNzJVGEAo2p7fKq2/0Cqtz2qR1g6n9LnW51ReNy3W+O6iFI+JzD82X/rX8cNFOf7jeTn+/+bl2A8XPgdE5Psioifd3icij3ife0hEnix/Qft733K9s3LFdcvdwfH/0oeUIsUjR+Xov/9Yik88JU8/8u/8wMLtdbyJHQoASCubQ0GbQ7Mht/+Ww0lvBJqn8tPdIrLf8mXuYbpd99F0B3p4/gNoyMqXrpCVL19RCgCdM1rEaVsa+NUKAKtzVom0rGkt/b3tRYvvo3ikKMUnF4LCpx+al6cfPs5PDo3YKyKfE5FviEihMDXs933wepW/7+0isrbajW0vfPaJv694yQtKf65522uleOy4FJ8+KvOPPS5Pf++HcuSb3+Wn1pgrcj2jvYWpYVb3AABSycpQUE3c1CXiVD34scABt/8WKqQsoPLTXSIyaXFFa9jVgUPuQA8H1QCCultE/njlK1Y8sOatqzeLI9vi3IXOKmchNOxolRXntMoaWSHzPy/K8f+Yl6e+cZxqQtSqAvygiPy9iPxHYWo4eFp90pCI3BvoedvWWvpoOf20UnB4es+FpWpCXVl45Fvfo5owmL/O9Yy+pDA1fCzg9wEAEDkrQ0ER6RU7zXkHdjCcys/onpc63CUQrG+7O9DDlG0AgYNAEfmnwtTwiaWUutJY7fuEfu3duVzlVBxa1jjScm6rrDi3tbT0+Nih4wSEKAeBV1V53jbFHbxgWuXvu92774Y5q1aUAkL9seYtuvp1Tp5yv0NA6G8a8f9sdv8DABAFQkGzbGXZsDWBoK54s7WaNSwzXnXgdNIbAsAY7xORfbWWVrob369fU7rVvk/oiw2xVg1W47SJrDi3pfRRPCKl5cVPfJ6Cooz5hIh8pDA1/MMIH2PE67cdTruSFkdan9Mha972i7LmLSJHD/1QnpiakfnHQ8sybZxGHPXPGACAwGydPqz7tNnmoNt/i65sgMEIBH3TFQ29BIIAfFZXXaaPaQpTw5/y22vN3fh+HZJc5F2ASAW9zHjV+a1y1vtXypkb26TlzIWhJ7A6xF5RmBq+KuqwyB284HBkq01anFI/wvYt75D2X3urtD3vWZE8jAX25XpG+aUGAKSKraGgjRVYLBs2HIGg796Bl7kDb9jqDryBYSIA/ISBnbqJfyM917yqwV7vQkR6tOiBJS3S/hsrCAftDgN1iB1bWag7eIFepXAgysdoaT9DzuxfRzhY3aUisi7K/Q8AQFC2Lh+2zXa3/5ZDSW8EGkcg6Muu0hJ5wkAA9ekw8GCTwxdK3I1X6QsQW9W+28u9BlM1DX4hHGyRo4/My+N/x7JiC8LAnQkPnNAXmQ9F3dO4HA7Ozz0uP9s/xbLikxg6AgBIlRY7Jw9bZdbtv4UhCwZT+W/SQ7D+AJ3L3YE3DBEIAqjjRq/CqqHKwFrcjVdNeu1HIq2kapTuOaiXFa/qtu7QLQv2ishZcVcG1lhGHNtxpQ4H9bLiM97xurge0oShI6z+AQCkho1HlraFghw4mG+/pUvaw3BQn4S7A6/X+wgAai0VfkFhavjDUYYqumrQ3bhVD2O40rtgkS4tIqf3tkr7EP0GDXJZYWp4k99el3FwBy/Y4b3/xkb3HOz4rT5Zee6L4nzYtPpkrmeU1VoAgFSwMRRMzUFXCHa5/bfoygUYSuW/qZei0T+muu3uwOt73YHXszQeQL3qwM44p3a6G7fu9HoNpmYISaWWDkfaf6ONqsH0VweerqtaJZ22xv2ATlurrHnbxXJm3xvjfug02p70BgAAYGUo6G74H7ppuA3mkjhgQ+iB4Bb2adXn9mXuwOtZFg+gXnXgS73qwFCXCvvhbtw67W7c2p26ISQVdNXgM36FgqMU2uBVBz4pKeUOXjCd1HO77YXPkY7f/GVpOWO1ZNiNuZ5R3V4GAIBEWRcKWmTE7b/FpqrHTFH5b+rAi0DwVHq5Upc78Pq0Vk4ASE+V1csLU8OPJL0h7sat+gLd5alcTiwirc91pOP39XLipLcEFcvc7zRkb+hjldkkHthZtULat7xTVl14rmQY1YIAgMTZGgqmcrlPADNu/y263wsMpPL36T6Q25LejhTa7g5c2usOXErYDaDehNaBNFVZuRuv3p/m5cROm5SWE698qZP0pmRZOciObZl7SENHEl2VcnrPWjn9MiUZ9X56CwIAkmZrKGj6EmKWDZsdCN6R9Hakc7rwpSwXBuBnKMOnklguXI+78eppLxjcJSm15l2tcvqbbT20S7VPpC3I9ssdvGB/3ENHllp1Xk7af+3tklEMFAQAJMrWI0eTQ8Fdbv82llYaSOXv072nqPBcTFfVdLsDlzJdGEA9un9gqt//3I1XH3Y3Xj3kTSdOpVXntxAMxut9hanhq9IYZJt0Mbql/YysBoNMIgYAJMrWUNDUAILhImYHgvpktj3pbUkRXU2jlwszXRiAn0Aw8f6Bfrkbr9aDpC5Ka59BHQyeudHWQ7zUBYKfEsMlOXRkaTDY8VuXS8sZp0vGvCfpDQAAZJeVR4zuhv9xKK19f+oYcfu30W/NMCp/n54ep08QCQRPutoduHSI/oEAfA5mMCYQXLKcuCutxxttL3Kkfag16c2wmRWBYIWRNITcTlurPONX35a1YPD2XM8oDUEBAImwMhT06JDGJLNu/zaWnhrGCwR1heDapLclJfQJxWXuwCU8lwH4cbFJgxmqLyf+w+609hls6RCCwWjYFgimYuhIhoPBs0XknKQ3AgCQTbaHgolf8QyARsNm0uEXgeCi/oGXpLonGIBULRk2NhCs5G78w9T2GdTBIMNHQmVdIFjmDp6/My2Vr+VgMENuTXoDAADZZG0o6G4Y1Vc8TalWOshwEfOo/H16qc2WpLcjJQ4s9A+8hP6BAKzrIeiHu/EPdaByWRovSK463yEYDIe1gWCFVFQLloPBDA0fuSLXM7o66Y0AAGSPtaGgZ0caD86roErQMCr/Lf0z25b0dqTELnfgdX3uwCX0wwTgxwbbAsEyd+Mf6krp3rRUWy0NBle/3vbDvkjtFZFPi+XcwfMnvQt9qVCaSvyrmQkGL096AwAA2WP10aFXLZj2wG2727+N6iqDqPy3dP+oO5LejpS40h14Xdp/xwCkx42FqeE7xWLuxj+cTmsweNprHVn5UuYZNOBuERkoTA0XJRtSUy1YDgZP7321ZMBHkt4AAED2WB0Kau6G0f1puuK5xIzbv00vQYUhVP5b5cEiWacrcC93B15n2kAfAMlWWmXipNfd+IHD7sYPpHIAyZp3tEjLmUlvhXETst+coUBQVwvqi9XbJUVWnZeTVReeK5Y7O9cz+vykNwIAkC3Wh4KeoRResdehChVWZgaC7ZJt+rnb6w68TgfuAOA3WNmSpWBFczd+QL/P3y5p0iLyjF/LyuFfKN5UmBp+UrIndS14Tn9Dt7Q971liuXclvQEAgGzJxFFhxTLiNB3c9Ln92/QSI5iDScMnJgy/jucugCCyGqzoYHBr2iYTO6tEztzIMmKfy92t7H9Zjzt4vj52Tt1qljN+eZ1Y7pakNwAAkC2ZCAU1d8NoucdPGoLBK93+EZagGkTlv6VP6rI+aVgHgr3uwMX0wAQQRGaDlTJ34x/tTFsw2PYiR1Z1EwzW6SOYieXuy3EHz9cXQ2clRfRE4jPX68N5a7GEGAAQq8yEgkuCwaQOcHQgeZnbP0IfNoOo/P36OXObZNsBLxBkwjCAoMuGMx2sLAkGL0rJxcmS09/o0F9wee/K2nL3ZaSuWrDthc+RVRe+VCzGEmIAQGwyFQpWBIO6+ffBRKqsqBA0isrf3yUiWe+dt8sduLiPQBBAAy4mWDnJ3fhHaVq1UDoKPOM9mTsU9GNDYWqYi2AL1YI7Ezhmruv0S9dKyxmni6VYQgwAiE0mjwTdDR867G74kD4ovzqmA/Ptbv9It9s/Qh82g6j8/R1eINie8UCQgTgAGl02/EN23bLBYCqWZbY+V2SVvlSKyurWrF8MTH21oLQ4suaXflEsXkK8OumNAABkQyZDwTJ3w4d0rxRdCbYroofQ95tz+0fSdzAFP7I+WGSXO0ggCKDhYOXj7LuawWC3t4ogFcuIsWgoDsuGK7iD50+msVpQLyO2eBrxxUlvAAAgGzIdCmpu/4cOu/0f0pVQOV3RF8KV+7mTYeD2Ibd/hKEMBlL5+4cyPljkSgJBAE14b2Fq+Bh7cHlu/x8d9ioGZ1KxjPjdBIMi8omsD8WpQQ9cS50z3tUjlvr1pDcAAJANTrHIxdCl1PjN+up9n4ijD9bXLbPrKv+hr57qq/6Tbv92lpwYTuXv1z//ycXLhqv9ntT63Vl6W7PfH8bX+/7+K93BX2QYDhCBXM+obkvwWAaqBDuptvJHjf9xh0hxcnFlehjvD8Hfo+Y+XZT5n0mWnUUvweWp/P07q18w9RsoO43dVqz9dU98aVqOfPNhsVALr6MAkE65nlG9GnSbmG97W9JbkEZu/4d0wHei/58av0WfxFXruHPI7d9OJaBFVP4B/bPemeE+ggSCAJrF8suAFYNq/OP6IuSSYDB+a97myM/2FbNcJchwkdpG0riKQg8dsTQU1Guj/yvpjQAA2I1Q0Ae3/4OHvYN12G9nhvsIEggiNdS+P+5dUhWiL8x0LK4SqVZZ4tT7u77gc7jic4fcjX/AxZ3w3M3yy+Dc/mtSEQy2vUik5UzJarWgDVf7I+UOvuqQyt+/K3XBYIsjp/e+Rp6Y/LpY5nzOPwAAUSMUBDwq/4DuI7g+ozuEQBCxUOMf610S8ulhT11eSLfQrmHZQqVGA8E627TvT8tfr3vKlgPCSe9zXojoHHI3/i7hYX2/73vHI5XBYEarBakSNLxacOXLXmxjKHg5oSAAIGqEgsBCINjtTRvOIgJBhEqNf6Qc+OmAwwv9nO5Tl+VXCfGW7R3VzBAE3wFip/dxMqCsuF3t+9/6jxkRp1w9rkPCQyLOtLvxt1l2uNBL8ETrDZgZDGa0WpAqQcOrBZ22Vll14UttW0b8fhG5KumNAADYjVAQmZfxPoJXuoOvZagIGqbGP6wDDB34dXtVf+v8hXhVbvddnNTQsuE6n/N7u1MOahYNoVL7/sKrMnR0mFPqS+tu/K2sVRZeRVP8sILBjyUaDJ52sSNPfL6YpSXvhPoWVAuepl5pWyioG9mvLkwNP5n0dgCwW65n1LugX76YX1L597KukxfQa9KDWJearPL3ad6Dk0coCCwc3GaxjyCBIAJR47fqAwYvBCxV/vn8vWkkhAtSJRh2FWGQ7TilyvBEWKj2/dVceTJ9xZ82+2zSG2ALt//aRIPBVeeJPPF5yQqWvFtSLdhy+mnS9rxny7H/sGo2xwtF5BExVK5ntM37bygvhy7TLXuW8vNap2uYv1elSv1fK/5eWkdemBrWF+sAnPx97Dp5If9E4FdlJU8o1tX53IkK/VzPqP5jxuv5fWIlTmFq2Pbj5tRwisXMXAkGTqHyD/SJyJ2LP1vtd8Lv55a7rdnvD+PrF/2bQBB1qfH/oUMJ76Ny+W/YlXpOjWXDQe+v2b6D0T528an5bx3+y//UzeNt7MnGMreQqfGPdZwaDMbzHvXzvy/K03YVXS2nhQrX4FT+fn0yWQh2YaZmFfbyN9V8f1h827F//5H87IBV55EbClPDS45T0yXXM9oiImeLyKUico6IbPSCwGdLOuiw4f+JyD/qTFtEvlWYGv5J0hsFxBAAVqzmqRrSmWCmvAJHHw8VpoZT06Ym1zM6Ykn7ke1UCiKzKpYNZ812lgyjGjWulw6U+gD2Lh66Y0SlXpPbEfVje7c7jo2BoKantcCiisHVr3fk6Yetv3B8I4GgXdWCbc9/jlhG//6nKhTM9Yx2elV/7xCRS0TkTEm38mvnW5dUJhW8CsN/EpG7CAphQQioi13Kx/G2tMVa632U3mtyPaNz3jHRZNpCQpMRCiLL9lv0gunXLnfwtfqqBiBq/EMdXhVg+SCiM5EQz3cVSBDNVglGGXRa6btJb4CtkgoGW/Srg/2yeGHQ7t6CLY6sPOdsefq7ehWpFXT4dlUKeo0NisivisiLxB45EflN70P/dx73Kgn168L/LUwN6/ABSK1cz6g+fg9wDG+Fdq9wYX1FSLjfO0baT3/CxrB8GJmk8g9sFZHbqt9q7fJhHQhW6+GCDFHjH9STgHu9g4j14S63rbX0dpmvL0a1FDjov8N67NpfWzxSlMN/8SOxsNrqw0lvhO3U+Mf0ifmkSLE9nvcokae+JvLkv1ldLcjS4Sap/P07RZwtaVk+rB3/r8fkp3v+RSwS6/M01zN6mhdGXpfRnttlOln+cxHZqy98UVWMpOV6RvXlunIQWLGiBxUOeCFh5AFhjuXDgLlU/tvdyweC1iIQlKwHgaUDiKGK6bkRV7SluVIvwcEmduYreukVIub2XztdUTEYS5X7ik4dCoqtWDpsabVg6zOtK3PVv+9Rn9w+U0SuFZHfSFEvwKTpPom3eh96H33CqyK8rzA1fCzpjUMmKwJT9VqbUuUqwjtyPaOxBYSmY/kwsihry4V0g1ZdGYkMUePbO7xlwVv9XemPOsRzmgjIwh5sEuT2EJdLFx1bU8H7kt6AbAWDH40tGGy1OxogzA6tt+AD6eot2OLYNoVY/yYejrAiUIdddv+2h+P93kc5INS9dKkgRJQ9AvUx/FAG212FHRDuyPWM6nBwBz0Iq9PTooDMUPlvj2RsKYQOBHvdwddwdSQj1Pj2PjW+fb+I85i+Srb4+Z7GIC2KbQv62H62w+/tmXM3FRPxcvuvm47tQk+LHtwgtiLMDk/qehWf1v1ysUioffxyPaO/lOsZ1TXAT4rI3xAINkSHg3o++3yuZ/Q3vWWdQBi/n325ntFJbxCO7idKINi8du/C1b25ntHpXM8o7bSWoFIQWVs2bMPYcL9041UCwQxQ4yO6T2Cdq4lpCdIk5OEiYfZEbIafKkEr6eAZMXP7r9upxj8ay/5f+SqRYz8U23yfMDs87uB5qasWbH3es8QiF3rVwc1WBf62iOj+r/rvCM8n9UeuZ/Ru73eA6kE02itwJEMDQ5Ky1ltavENXDuoVhIWp4UOScYSCyJIsLRsmEMwANT6iQ0D9sS7eari0BIxhB20RL5e2U1Mnqmg6GOyOejLpCptmjZ6khwfA4t6CLaetEouc0+g35npGzxCR/yUi7w13k1DFpV714PdzPaP6dfmzXHyAjzBwq/dBRWC82r1ioW25nlF9UWsky+EgoSAyIYPLhvvcwdfoJWawjBrf1uUNDKk4gIirGi6kIC20KsF69xNXyFfne+2tEtT+PekNyDK3/7qtavyjHVGGMY6OFOzz5aQ3wNJqwYOnXqRKiF19BV8W9BtyPaO62uhAxo590zSgZEL/Jdcz+j6vEonBJDiBMDB1tuiPLIeD9BSE9VT+wawtG77SHXw11TuWUePbetX4Nl3tWhBxtjV+RTHMKsEGwq6iCZV6ESyXtlRhalj3pEKC3P7rhrz+sZFw7Lx8zEWzDPQWbH3uWWKJtwcJA3XPLBHRJ7UEgulYWnzU6zto56spAsn1jI54v59NHMsjwnCwkOsZ3ekNeskMQkFkQZaWDW93B1+dpf9e66nxbUNqfJsOee+qXg2U5iAtJZV6SQ42sbtKcG/SG4ATeqMMBle+1MoWGwiZO3iefq/S1YKpsDL3QjFbseKj/jJhwsBUIxzMOD3cItczShhoVjg4kpUhQoSCsJrKP5ilZcO73MFXp+oqPRqnxm/RYeAhb5DAuvB76oUZpPn8/vrnNQ3cd9iTkyW8x64aCFoVEt6b9AZggdt/vZ4wPxRV2NX6XLv2dGFq2PerEQJLzYXJljNOF/N4IWBRf5z8Z65ndGW1r9bVZ96St59l6HjXhnCwN9czatUBAarzftaT3vE8Q0TMsk1XdeZ6RnXLJqsRCsJaKv9gV4aWDesKEetfsLITBt5yKPjBQ9TVcIZW6qV6sInx6MuWIm7/9dPe9MLQtT1fbPKJpDfAZu7geToUnJUUcIwaNlIOA8sX0IoV/5sXmX96zdLvyPV86GoReYohIkbSqz9mcz2j5ya9IYiGrjDzJtzelZpeq2hEu4jcpiuxdcBr6y4kFITNUnO1Op5Jw6/WlSIwlBq/eUkYmLalwGkZLpJwT0S/921/laDGEsyUcfuv19UIV4Z9vy12DhtBdFKxasFZtULMcDIMrIwCFz4xX6oaLM4/feINpOv1t+RyPR/6qYjzJ7qQN9ltR5MDSR7O9YzuyfWMrmZP2iPXM6ov0Oljej2FGnZYqwNer9+gdUuKCQVhJZV/cGtGrsoQCFoRBt58SMSpUxkYVqVes0Fa2NJSqZdkCGusQtIbgFO5/dfrC2J6OWFoHLtOV+9MegMyYD8XDfw4uUy4WhBY+rP0Of3vY06XurI194btdzotK78n4pwZ+U8RcblCRJ7I9YxezpJis+nhFN5SYf0+wxARe/sNHtI9IsUihIKwjso/2JGWq9Qx2OoOKqYoGh0GVlsmnOYlr2FWCVo62CQbVYJIMbf/+qE0DXxAtriD5+mVC3rZXOLS21fQqw48JQz0gsDivBR1haD3p7ScfoOz5iVHxGmNpEUAUmFCRL5kYxVShqoDpzNSlJJ17d75mzWtuxiNDhvtzMjVmdvdQZWVJdLWUBM393qhdYDhIWEFSgkst21quIiBy6WzFQiyfDjdyicoTTc2d0xqzVYfz9t47ExDX+cVL3mhHPnmw5LuQFD/dSEYLAWA5QrC0m2OtLSuEnGcDyS80YjHpSLyWK5ndIOuuGUoUvp5Ia5+vVuf9LYgdu227HMqBWEVtfvB3oy8KB90B5U1VyeyQE0Md6mJYb2k6i4pNnMVMa5quCDbkbJKvUQHm9RjT0DIyUq6uf03HPaCQUKwxVj2Hsfzb/C8Q2EvY7dyufCJZcK6ItCrFCwel2LxuDhOq7S0naYDwaQ3HPGjatAA3uCJ6Yyce8JihIKwTRYq5/RUP5aPGEJNDHeoiWFdGVgQcdZnKkgr2tATMcwqQU7sEC+3/wZ9ssIFJCQlFUuI07tc+GR1YHF+IRDUYaD+uw4DndaVSW800lE1aO3EU5PlekZHvMnCTVfjA0kjFIQ11O4HRzLywtznDiomDRtATQzrvl6HFi2himQKr0QQlKV522wYbGI+tWdvV9LbgPrc/htCHzwC+OEOnqdDaXpbLgoEpSIQLFcHHl8IBOePl25tXbmmVCUIePTE09sZQpKe5cLeMJHE2yMAYSEUhBXU7ge7MlINcTWDRdJPTdzUrSZumvSa0Lanf8lrBJV6kYSfCfRE9Hvf2awSnFZ79mVlqJPR3P4b9AWKmaS3A5mUhRUcAQPBclVgeaDIQoWg09ImrSvW2Pp+gea8X68UYghJsnI9o90ME4GNCAVh0xIVa5p9LmOXO6hYipNiauKmDjVxkw5J7hVx1jUXlKUlSAubiT0R4660NIWjX3O3qT37dDjI8qb0o78gYucOnrfTa3uSQUuWDJ/oGbgwVXihd+DCny1tqxf6BwLLO9tbTnwROyl+uZ5RfXFtMiOr0pAxhIIwntr9UBaGi8xkpBLSWGripnKz4W3Bp/BG3VOvGWFWCcZVzdjIYzexbVWrBBvdDiOt1cub1J59O9SecT2FDynk9t+gWxnokxogbhmsFqwyUKTcP7BcKTi/8NG64oxSlSDgk5vrGf1NlhPH3j+wYvUPYBdCQdjA9oNNPTlyiD6C6aQmbuxQEzcuTBU+cfXQkCWvUQRpRRMq9UIMYesuG84S56qFJcXjDEJKKbf/Bv1adXvS24HM2ZHVQHDpQJETw0RKE4dF2ladIeJwOobAPikiYwSD0cv1jOrzTPoHwmq8C8FoavdDWzNQxj3iDl6kK9CQMmriRh1+HFo8VbiZoKyetC23NXHb0rZc2hYn/tv06/Gdas/EfrVngqrBFHL7b9Dvm/QXRHzPucHzDmdn2E39QFD/6TiOtK48w/L3BUTsChH5Uq5ndDV7OrKBIvr8awv7F7YjFISx1O6H9Amn7U3uD7iDF2XsCrtR1YF31l5KkEClXlPf22Slnu+eiVEvl46pH2M2h4v4UPrv1kH5IbVngqrBdKK/IOJm+6oO/4Fg60ppKQ0UAZp2qYg8RDAYLm+gy6TXHgWwHqEgTDZieW8H3Zib/k8poyZuLPcOXO8rBIpkCm+agzQLeiL6uq9mtsM2y/636dfnO9WeO3eoPXdSNZgibv+Nur8gfWoR33Nu8LxJuweO1AoEj58IBFvaVkpL66qkNxb2DSB5Itczem7SG2LRhGECQWQKoSCMpHY/1CUiun+VzYbcwYv0khukhJq4ccfyvQNTUKmXyuEiYW1HE9sW2mNXoEowyH7zeg3eqQ+0kRJu/426cutA0tuBTBnJZiC4MFikpW2VOC0EgojMwwSDzSEQRFYRCsJUti+p3e4OXqSvUiEF1MQN3WrixunaQXSzU3hjWvIaRZBWNLVSLy2DTUzme7/pIP1etWe/paGAsYbsrt5Cyuz3hqdlLhBsXbFGnJaVSW8s7Ecw2HwgaPMqNKAqQkEYR+3+jl6+WTHYwToz7uBFnDinhJq4YUjEqbKMoF4lWTOPmuRyWzGjUi/JSsuqVYJ+tiPrSvtim9qzf1LtOcBy4hRw+2/U1ei0qUA8z7fBVx72gsHMBYJMGEbMwaA+V4JPBILIOkJBmMjmwExfQecELQXUxA0dauIGvbzujvpXDROu1Ivtsev1TExrpV6cw0WypOHn1rqFISQHOGlJAbf/Rn3RY3vS24HMsGSlB4EgUu2uXM/obya9ESYgEAQIBWEYtfs7Q94Jpa1G3MFuvUwVCS8X9pYQbGkoSCtmYclrkj0RbRlsklWlfaCD9rvUngM2X+Qxhtt/k/45zCS9HbCfO/jKafOfawSCMMIncz2jlye9EWlGIAgsoFIQprH5BPKgO9htyRV0c6mJG/oanzoWZpDWyP03870NhFmRhJ/NVjs2o9kqwawGfk0FxNvUnr/dr/b8LcuJk0eVOuKiq/CNDgQX/o8lw0i9CYaPVEcgCJxEKAjTqgS9qa/WYdlwCqiJ63XofOfJ5cINhB3FJCr14g7SbKnUS3Kwic0C/3fqHrGTas/fMp04QW7/TbqCi2XEiMNO0wPB4ik9BOfpIYi0YvjIErme0Q7vdYihIgChIEyhdn+nw/IqQb1s+FDSG5FVauL6DjVx/X4RZ1vtr0xLkCbJB2mBJis3sh1NbFug+/f5vYGqBLMUCIb2vF6rB/qoPZ/VlbpICMuIEePAkV3mBoJSJRA8XvqzpW0lQ0WQRgSDiwPBBlcEAXaiUhCm2GpxlSDLhhOkJq4v9w9c33TYESgoS8ty2wa2I5LhIn6/v5nHDrIdUW6bLUJ/bukr9neqPZ+1+QKQCVhGjDiYNYW4MhCU5QNBp2VV0lsKLOcLuZ7R1eweAkFgKUJBmFIlqENBG7FsOEFq4vrek1cLmwzSfAdlJi95TbBSL8nBJlWrBP1sh9/bsyDQftmm9vzdTrXn7+gzmADblxE/Y+ipX0l6G1CqFtSh4KwZ++JkFLhQMTi/UClYEQg6rSsIBJF2Z4vIQ1kOBnM9o3rJMBWCwBKEgjDBVot7PrBsOCFq4npdDXNX88+tBCr1fH9vBCFeU1WCQbYjrvCzzmMzXCTE/brc11a9bctCn0GCwSTYvIy4ZbVcn/Q2wKRqwSqThou6SlAHgwsfjtMiLa2nJb2hgN9gcFeuZzRzVyhzPaMj3rEFgCUIBZFqavfDNlcJzjBtOBlq4no95fmOk58Js0owrkq9sIO0FFfqhRowxtWbMe7HTrOGf376av602vP3DCBJhp3vvY6crSZuYol0Ouj3YrMCQZn3/u0NFtGB4Io1SW8oEMQV6f/dC1euZ1S/5tfpGw5kF6Eg0s7mKkFOShKgJq7XSweuSl+lngFBWiThZ9oqLcOsEsxSCBjZ81r3kp0kGIyf23+Tbq1wu9iJvpUp4A6+8lCqK1K9PoKLAsGKScP6760rTk96K4FGvD/XM3p5FnZdrme0O2shKBAUoSBSy/Iqwe3uYLfu24SYqInr9IThydpLBxoI8QIFZWkJ0sJmS6Ve3AGxLSJ/XusLQ5Nqzz9wISWZ8MyQvm+BdKqJG3k+pYO+UJfuPoInJg3rP7wKweK8tK1cY/lrOyw3kesZPVfsnzS83+ICEyAUhIJIM1urBPUJFlesYg4ERRwdCK4LNUgrmrrkNcwqwbiWSzfy2E0slw5UJRh3CJtmkT2v9XvBHQSD8XL7bzps8cU5qgXTYWfqlw0vmjSsA8Hj0tJ2emnpMGA42ycS7/dWHACowSm9yQHprBLUy0raqycvxeX/XfU8s8bX1/3aIJ/z9XiXu4NrDWiubVMgqCcMO2vDCzAaCcqccB87lPvy+fXFKLZt2a896P3jkIijXwM0XVV7uOJ7Drkbf698W11q31/0LnlsvZSkPNm21/tc14kDx7qBoO//llP+XjwyL4f/8t/FBmf9wXnNP7ca+lq50t30zhQGCfZS46OTj+1YelHFTB2/+5Q4q8phj1zpbriV51LCVP7b+0Wc9ct+ge+K/FNve+JL98qRbz7cfB/B+fkT04adltaFUBCww14RGShMDRctHCxCH0Ggvu1tPr4ISIKtVYIHCATjoyau6/YCwSrPpSaDtqYOneKqhguyHbFumw7+DnkfpcDP3fh+XckZCXfjby+972UfS+37pA4H9Uc5ONSh4cnAMFXLpdMs0uf1HWrPP/a6m97B8s/46H1dEPvok0ZCweTpC6XLh4Jp6CN4YrCIQyAIGweP7BaRO8USuZ5RfexGIAj4RKUgUl4lqFlTKTingwZ3cK3vCieEEQjq51G9CqY4qwSDbktUVYI+q+FqVmjUvb85L/TTwaz+c9rdeJWxz3+199O64lA/r8ofa4P+TOyqFHxV0s/rXQSD8cn1jBYtrBTUqBZMAZV/8PCyF4NjqxSsqBLUAeCJZcPHFwaLzB+TtlXPyPDFHljuBYWp4R+KHX0E9TEny4YBf6gURGorEmysEtxBIJiGQHCpZqsEw67UC7AdsVcRLne7U9kvc7IcArobt1o1TMe94je8/7YFau8d+sBTP9d6vY919BoM+3ld8/Ytas8/CsEgmkS1YHqqBWsMAku+j2DrCgaLwGr35HpGOy1YRqyrvwkEgQBYPow0srGp+aw7uJam5qkIBJsJ0sIMGBvZtqCP7Wc7atxeP/yc807kSmGZu/FqY6sAG+FecaWubFkSFO4sB4R9C5WEWRDl87ruY29Re/5J3E1vZykxmppETG/BjIeCpywbLv99oZeg09JW+gAsdraIXC8iHxZD5XpG+1LTigAwCO9uSBW1++EhS6/u2Bh0po6auLbbmzLcHlmQFqhKMKyQL+ref1Usf514RsTRJ2/73Y1/aFUlYBjcK4bKIeGI2rtLVxL2nQwJdW9L0y/ANyuS5zXBIMJ4j6a3YILcwVfsV/kH55JZKVKsyAWXVAmWegmKtDJYBNlwa65ndG9havgRMUyuZ1T3f+Z1PFyzFT3Ayxf+K/9eS7lHt1T06e62dDWg8QgFkTY2VtMdZLhIEoFgs4FDFcUkl0yGpaH9MuMdaO13N34gU9WAzXCv2HLY22+lg1S196/7iseKm0Rks1gjNUNztqg9/yzuprdRMYhGrFUTN/a6G26NbOAR0lotuNyyYf3nQpVg60q9bBghOi4i3xKR/yci/+h9Tv/9bp/ff7n35/NE5O0i8iwReRE/odB8wdBlxDsInJpy8GQfcDlUmBqejngQzJIe3UgSoSBSQ+1+WFfUUCWIGCoEDajUi+2xl+2ZSBAYMveK9+7P9YxO2hMKxrXcvdrnqn4/wSCavSipT1SQpVCw2rJhLww8sWzYaY11kyzzM2+q7T95od/3C1PDeopLs+FPmV7uWpLrGX2miLzY+z3WF4gIGjKyjJhlww3Rx/n6mHR/YWo41gti3uNNLhkOU26902tpHpBqTB9GaqjdD+sXh3Wn3mL09OFd7uCFVK5EHgiWBlu0RxekLZ3C28z9RTmduOnH1ssE9ktRdrgb/4iKwAh4Bz6PiQXO+oPzI+yn2dT04l1UDIbP4unDlS5yN9xKW4S0TSGObPpwtWnDC2FgcX5h4vDCtGEErAL8vyLy1yLyb4Wp4aeS3Hu64k1EfkdEfpVqwsDOKkwN699HE46r9DEry1LrO3HBvzA1nNrj/FzPqD63G7J4+GjaMH0Y6aB2P9xdPRA0mu6NQy/BCKmJa/WBwP7FgWA1hlXqNfW9DQUxB/RBgtv/R7pKAwhBgkNzis4WNfa5aXfgrZXVJIAf+j2bC3lZqRZctGzY6ydYXjYs89K64vRYNsOiIPC2KJccNqIwNTzrVb1dn+sZPc1bevyXInJm0ttmgL8XkdeLGVXeBEe1z0dLrWzS9vu5HG879fvxVq8KVL8vM0AmQlQKIhXU7od3Ln8QaGyl4HZ38EIbeySmKRDU1aVro1vq62e4SFMVTSFWFAZ+7DkRR//e7XD7r0nt1ULb2FkpmKrntQ4Fy3+70h14K03HQ5KRSkEt5264ldfEhKj8g33ectOIKwWXVgnqgSL678dLVYKO0yItK+gl6KPq6AOFqeF/FcPkekafIyJ/LCLvTXpbUu6yuJeWNlBRdm/S25FSOhAf8aoCU1/x6XOQzEiiU+rttb0l6S0A1O5Huiz8BdcvxFSppC4QTFlFU2wDRZylz80rRZwut/+arQSCCO95Vve5FwLfgaC+/Q419i9UfSEonjMJTyH2KltiHi6i/1gIBnWlYAtVgrXopcHPKkwNd5sYCGqFqeH/LEwN63MP3TDyaq/aEaf661zPaJpnEHCudarScX5harirMDW804ZAUNPLnQtTw/r9+SwdYiW9PbYhFEQa2HgAPuIOXmjFi3BK7WysgXQDIV4xrpAv8sEm+or+lW7/tV1u/7U73f5reH4iZokM7NHBoK4kAPzaqiZu0BeekJxoW1ksM1xkoZ/gcWltOy3ii3ZGh4GrdZhWmBr+iVhADz0pTA3rYGkl4eCyQ0dSeZ6W6xkdsrD1VDPmKsNAsZQOOQtTw7piMKd7SCe9PbYgFEQa2NZ3b9YdvNDaF+OkqYlrd57sKxH2ssQlmlosF3nY4Xc7DurlH27/td06DIzwgZA5UfbTbOCxF1cJVt4ySTCIAHRvKr2EFVaGgsUlb++6MvBkQKj/6rSuiu7hzTRTEQYmOjgkxnAQJ30y1zO6OoU7hBZNJ90uIlaHgTUqBy8SEX2ugyYQCiJRavcjNk4V4k0qImri2q0nl5rHvCwxtpAvtMcuh4G9bv+1qe0HA5skODRnUSB4inYRZ78a+zzVX/CL9/HklxDHUyXIcJFafuYFDd22hoE1wsEVInJj0tuTIh+RFMn1jOrXaD1ZOut0YH9RYWp4qy3LhBsZSlKYGu71wvyIW0/Yi1AQSbOtSnDGHbwgM1dp4qQmrtEB8m3Vb40gxPPd2LyeMIcw+Lr/Ui8Rt/+6Xrf/OsJAJCR1vT71ycMkwSB86lQTN+iTDCTnQCxVgqV/6WXDCxWDTkua26fFSp9gd3jTezOnMDV8rDA1/GEReYGIfD/p7UmB93uD0hLnbYdt54+N2O4F9kZMFI6aF+brdjFUDTaAUBCJUbsf6W2sL1yq8SYVATVxTbeIsyN9w0OqfS6xbdPThHUY2OX2X0cwjZglOLBn+WXDSz+n329oSg6/UtlHK0P2x1clqD+OSyvThrUfeENEduiqOcm4wtTwD72LSlQNpme4w1YLV5k1Uh1IRXv1JcXlqkEEQCiIJNl2wH3QHbyAyqyQqYlrOkScyeUPACJYlhioSjCsJZNNVTvqAzXCQKRExL0+m+JsUWP/yoE0/NiiJm7oYlfZEgpWVAl6PQRPVgkuZF9UCZYGiXTaMkQkLIWp4aJXNfjSjFcNJl4tSJVgabBGL9WBvqoGda/BTFY6N4JQEIlQux/pONkbzhqcaEYSCMqSQDB1yxKTHC6iS+Rzbv/1I27/9ZnsJYI0iHJoTmhVgpV/36bG/tW2i1KIBs+ThLiDrzgc6jKwyirB0l8rqwTns14leFxE3uwNEsl8deByClPDj4jIy0Vkr2RX0tWCWa4SvFoP1shq78CgvOCU5cQ+EQoiKbYdaFMlGI0dIs7aWEO8YhIVTYEDxFkR53K3//pet//6QyFtBBCyiAf21B4uUoezQ419QR8sAlk6VslotWCtXoKZrxLUw0SeW5ga/tdw9rXdClPDT4rIQIaXEydWLZjhKkE9POMyr/oNAegA1VtOrCssUQOhIJJi24s6VYIhUxPXVEwajmlC8KJAMKgwqwRr3n67vvLl9l8f3XRGwLdU9NNs5HdOVxrsV2NfSEXjdKR64Ehf0huRYSG8z5Xf2JfrJZjpKsEfeMNEWC7c2HLiDZJNv5PQ4/ZlsEpwzlsuTHuqJugKSz2EMbwfi30IBZHUgBGbxshTJRgyNXGNfo7cFu2yxBgrmgI/dtXbdWPhy9z+G7a6/TewdAApEFY/zWqfC7JsuOFt0+9DhOuoh2rBhLiDrzgUSk8onQEuM3E4w70EP+f1D2S5cIMKU8N3en0Gs+bWXM9oEr80WSvA0Mf9XfQPDEdhalgPYSQYXAahIJJg2wF21t6k4ugjWOdEPeoqwbBDvgBhR/XH3u7239Dt9t/AlUKkVJLDRZrq9blOjd3FazhqWc/AkUSFF9x7A0bKVYI6GGxtO00y6K8LU8NvIxAMrc9gFoPBWM/lcj2jfZYVlPgJBHWFIEUA4QeDl3sVmKhAKIhYqd3ftW3AyCwThyM5AWgPIUhLR0VTc2HHrFcdSGiBDAlzuIgv29TYXbo6GcjKxUyTTIY3YESHgd6/vaXDTusqyWAgaNNxeFqCwdMzNpn4llzPaJRLeGxvO1ULgWCEClPD+jxTH/MRDFYgFETcbDuwJqwJkZq4Ru/PdbFXDQWqEgxr2+qGjbopLtWBMEDEvT6b4vux96uxSfoLIivHLsZwB1/RdKXgQg54Mhhc+Pu8tGSvSpBAMNoBJC/PUDB4tjfZNXK5ntGuhXODTCAQjIG3JDtLQXNdhIKI25BlVYK6DBnh9RHcFvuyxGJkyxIbDTv0lavL3f4bhugdiPSLuddnoCrBQNtWGjwS5BuQKZ1q4noGjiTnQOPfWg4Dy39d6Cmolw87LSslQwgE4wkGL5bs+LOYHicr4Y1eHcSS4ZjQY3AxQkHERu3+rr6itNaiXU6VYCR9BB1L+57Vux+nfIWw2+2/kXACBoq4SrDucJFafD32OjU2yes6lkMomJwQ+ulWDhiZF6elRRwnM6dBBIIxKUwN/zBDPQYvzfWMxlFhn4XXXl0Q0EcPwUSCwatjfthUysy7IVLBpirBOaoEo+gjGPOyxJpVgvWEWbFUul0vF+51+2/U0xYBA1jZ63ObGjtIf0FUs0VNXM8S82TsD2Xp8IkBI0VpyU4vwR/QQzCRHoNKsmFjlHeeoQEjfd6SVsSsMDW8wzsHyzRCQcTJplBQv4AgBGrimq0ne4UEDtIaFHXfs8Bhx5Vu/41Dbv+NTBmDpZpcil+MtdfnTjV2kPAHWa1YSR138ysOeUvrgisuGTBS+vt8RpYOF3+QkUAldQpTw/eKyPvEfp+MeOBIFl5zry5MDYdQDY1GFaaGh7zVWplFKIhYqN3f7ateCWYsQsEQqIlr9JLy2+p/ZZhVQ9LAcJGgj+17O+ZEnIvc/hvpTQmDxb0UP/Jen/okmt9J2H5x0zRNnjSfrBZsaVkhGXC8ePznLytMDc8nvSFZVZga/pSI7BX7RTJwxFuabPuk7F1epRqS15vlicSEgoiLTQfSu9zB86noCsfOkJf+pXlZ4lL6ilSX238jywWQcUGqBKOcXrzoe9ersYNZqFBAMOvUxPV6EiaMWUK8eOlwqUqw1f6pw8X5p1966O6P6MEXSNZABiYS3xDR/dr+HjyToSEqqVeYGj6cgefcsggFETm1+7v6Ss96i3Y1jehDoCauGTk5eCbmqqFiEhVNi+7H6x94E+EyDBf1UvxmNN0GYKca+yLLiLFUZk8ajKwUXMgDK/6ipw63itWKx/7o0L99sJD0ZqAUNOgn3YWW74srcj2jbRHcr+2vtUMMFkmXwsIy7u2SQYSCiINNL+oH3cHzGQQRzrLhbYlMCE5+uMgut/+mIQJB2CnkgD/UKsHAFcS65QXLiLEUlR0JcDe/4nBjPZ9OVgqWBozYvnS4ePy+wpdG/mfSm4GTvOBng+X75III7tPmoV/bGSySToWp4ZEs9hckFEQcbAoF6fsQ27LhMEQ8vTj4dlypA8Em7ghIkQh6fQYaLhL0sYNsx4nPrVdjX7TpPQzN61QT10fSQwtRVQsW9XgR+5cOF4vHi0d/8rqkNwOnKkwN32l5f8EbIpg6bFMv+kozXvCE9BqSjCEURKQsWzo86w6e32BPG1RfNlxLBCFeU1WC0txjLwSCVB3BYlb0+qz2vTvV2BTLiJHpE4aUCH4M5lUInlw6bO+pT/H445ccuuf2J5LeDizL5qEZYS8htvliHO8fKVeYGp7O2jJie98ZkRY2vfAR6IS+bDispX/1RF0lWDPs0JOsLicQRLY0WakXaNlwUIF/91lGjCydsKaWu/kVgSsFdYVgeQmx47RG3Mc0OcX5o/cf+vJHv5b0dmB5halhPfjlMov3UZhLiG1dOnw7y4aNWh04KxlBKIio2RQKsnQ41H0Yc9XQssNFgj5+oLBjzhsoQoUpLBdliBfmYze8HevV2JStJykIjiXEyTkY6Ksrpw63rBQrFeePy5OPsmzYnOfv3WKnt4dxJ7meUT3hvVPso88JWDZsVi/QrZIRhIKIjNr93S5/y0SNsMsdPJ9JsU1QE9foF9Z10QQKqeg9tlQ5ENQl6ICN9BTtBoRZJRhrBfFONfYllhHDxouelvcV9CoFW+0cMlI8/vNth9w7Hk96O+B7GrGty4hvDel+bK3E3sG0YbMUpob3B74QZShCQUTJphd1lg43QU1c07H46ljMId6yVYKRLUucE3EIBGE1d9O7dSiyK76BPZJw30GnM0tXjZGpYxx7Q0HdS9D7cBz7TnuK80d/Lo8/9NGktwP+FaaGHxGRT9i4z3I9o88P4W5srMrXy1BZcWamEckA+94dkSa9Fg0YaWziHcp2LD9FLMwJwRLycJGGto0KQWQwGGxE1FWCkVx82KbGvqSr4AGWECfA3fzyyUaqBFtsrRI8+tivH7pv/7GktwOBVfTXtkoYy9htnO4+QpWgmQpTw5NZqBYkFEQkLJs6zJWdJqiJa3oXL5WIsmoozICxoW3zAsHS1CogE9xN76pSMdhApd6iQDDSXp9N3k7lOE5gCXEyDgbtKSgW9hMsHn/6idmvfuLOpLcDwXkBkY3Vgpub+WZL+wnqcwN6i5ttRCxHKIio2LSshhfyWELVCEK8QMNFQtk2AkFkORg8YECvzxA469TYv9n0HofG8TxIxnTQ6cNOS5vYpnj0x4TSZrOxWvCKXM9oM2/Atqwyq0QvQcMVMlAtSCiIqNhyoHzAHXzVoaQ3wlRq4pqhxcNmEl/6V+P2prftSioEkXH6930m+uEiqaggpoIc5SXELCePn/8lxKVM0L5+gsX5p5+e/dr/2pv0dqBxFlcLLtMuKLNLh+lLb4edYjG73iGRCmr392xaOmz1C0AMw0V2hL/0r9rnggwXCfr4vr5XB4I8V5Bp7qZ3Hvau8s+ku03Acl8bSKcau9v65STI1EVQkwToKzgv4kRZOZyM4tOP/XHS24BQ/KmF+7GZYM+2UHBXYWqY4hILFKZK53l6YIyVCAURBVtKv+fcwVexdLhxW9M5XCT03mPbCQSBU4LBuWSGi8RaQbxVjd2tL34g21jCGTN388sPL1+VvERRxLGxn+BPv87EYXsmEd8tdrmkie9dJ3bhPNIu+8VShIKIgi1Xzan8apCauKbLCwXj6O+1zN8buT2wXW7/MNVCwLLBYL0AP5Zenw3+7tetINYXPfj9x1o1cR3hcGr7Cto3efj4kf86+OhDX/5p0tuB0NhW9fnuJoaM2GSuMDVsbYiUUTvEUoSCiAKhIEbiqRKsN1wkqECPfdDtH6ZCBKjC3fSO6VPfCxLp9elTwxXEV6mxu207kUF2j3usW0JcmjzstIpNnKM/uTXpbUCoPmvZ/ry0wWEjtr2XEghaprCwFNxflbphCAURKrX7e91NNphNi1l38FW+p9vhlCrBLSc/E2VvMYk2YFyefkPgJBCowd30Dn3SfuWyv191qwTD6kMaeQUx1YLg/SB+vo/RHIt6Chbnj87P3vvXn0t6OxCewtTwMRGxbWhMe4bbT5URCtppp1iIUBBhs+XA2Mpf+HTtu6irBCNblqiXRA65/aWpcQBqcDe9Xb8e7Grsd26526PsO9jQY29RY1+27WQGwfDzj5m7+eXTy/curVCcj/iCZLzmn/7JvyS9DYjEhy3br7mMVwqydNhek2IhQkGEjVAww9TENb2LmwTH2t8r4O0Nb5sOBKkiBXxyN7196JTlFoGGixhRQUy1YLa1q4nrCAbjV/e9uPjzp8UmztGffCLpbUAk7rNsv3ZlPBS0MjiC6MreaRunEBMKIjRq9/d0o+21FuzSGXfwVYyPb8xIYv29AlUJNrxt293+m1kOAARXYyJxPWGGeJFVEK9TY18hFMo2Wy6K2nXifeSo2KT4k4OfT3obED4LlxA38n6oW1DZglDQbpNiGUJBhMmWA2KWDodSJRhjf69iLMsSD7j9N1MNBDTA3fS28kTigFWCxlQQa7w+ZBuhcBorBZ+yJxQ8fuQns48++gO7Sh9RabdFu+PyBr7Hhp701oZGsPvnSyiIMNlyQEwlWKJVgvVEPL24Ol0mzqRhoAnuprdNS9G5uvF7CLPvYCP3X/d7qRbMtrVq4jqblr/ZEQrO656Cljj2U45P7fYVscfZQSYQ53pGuy3rJ0ibIbtNimUIBREmG0JBlg6nukqw3nCRZtR87D63/2YGiwBNcgfeukNX3fr4nQt7QnDA7234dYlqwWyz4TjIGO7mlx+q29vpWGgHCYlzjv44n/Q2IFL/Ydn+DVL5p1tQ2YJA0HKFqeH67z2GIRREKNTu7+krPJ0W7E6WDodaJZhYf68wlyXqPoK8wQPhGareXzCs14MIWhT43451auwegqHs4mcfv9rvz/ZkglKc+9q9SW8DolOYGi5a1ldwdUZDQeuqyFCVVfMHCAURFlsOhHkhD0hNXNO9fJVgVP29pIHhIkEfu+QgfQSBcLkDbz0s4tTpQRtJGwCfmn7srSFvEMxhy7GQRaGgHang/LGnjj366A+OJL0diNznLNrHLw/wtTYtH7YqLEI2MgNCQYTFhgPhWXfwPCrCgtsazdK/xAcI6Eom+ggCEXAH3qIPpm73/zuZugriWretV/l76C2XTZ1q4jqbTm7NPzFbNNjIYPNHaGGSDd9IegPQNELBbDgkFiEURFhsCAVp4ByQmrhGn/huSaS/VzHypYFDbv/NVr3gA2niDrxFX1CYqf1VUYZ4kfYdpLdgdtlwPGSSTFzMLRaPfjvpbUAsChbt50syunw4E69JEKvOEQkF0TS1u9BtyRh5+gkGtzWR/l5NrQby9dgH3P6bCYmB6A1FUKkX4PYIBpssvD5tUfmv2nSSA/8IBWPkbn754eo9Si0zf4xKwWyw6bn8vABfa02FdWFqmN/VbJgWixAKIgw2HADPsXQ4GDVxTcfJ5bVp7u8VeNtYNgzExB14iz6o2h7zhGCf99/AYxcXfY7egtlkwzGRFSdnx37ymNhj/mjSW4DYho3AXHVWP8AWBcvCX0JBhMGGA2CqwoIbql8hGkGIF9rh0rKPvdXtv9mqF3ogzdyBN+ultrPxTQiObbAJoWA2tdNXMB19BYtHnhZrzB/7WdKbgNh8wpJ9/RrJHs4fsmVWLEEoiDDYEApaNUEoJluT7+8V+gABPW2YZeRA/IZSXkFcfzsWVwlq7Sr/NYYVZZMNx0UmsWoZV1VFQkEY59KkNwCI2CFb9jChIJpiUT9BKgUDUBPX9Okpi7H391p2uEjQx1/2Nk7ggQS4A2/WF2Z2RR/i1RP6YBOqBbOJUDBe1pyYARQqGM3+CxSwEqEgmmXDge9Bd/A8yr2DqXKi2+zSv8SmhJY/t51pw0DirytzKawgrn9bcdnb16r812x4n0Qw1jTNN4G7+eWciMMmNjXD9KtL7MD5JIxEKIhm2XDgy9LhANTENfqNe13sId6yVYKh9B6bdftv1n3NACTEHfilwyJOgAsOYV98iGywCRXI2dOpJq615STXFDT4B8zVmfQGAFlGKIhm2VABwdLhWKsE4x4u4uuxWeIHpIA78Kadi0/uE68grq/+69MWlf+antaObLHh+Mgkp1YLzh9PZEMAAJkwLZYgFETD1O5ClwVXdubcwfOs+YWOyVC6+3sF3jY9XIRgGEiPZUL6MC8+BOX4HS6y3GNTLZg9NqykMLqv4JEHvpfMlgDNeYgdCBjhsFiiLekNgNFsOOBl6XDwASM1BstEXSUYyfRiqgSBFHEH3jSpxr5wQMRZH92jxNV38AQdCu7wt22wBJWC8R/Pbav8RMvpq8QWx4ttv/78V/Sd47S0HZOWFcec0sfKhT9bVx4Tp+2401L6mBendV6kpeg4LcXS65Ojj6SivICLkD2fPQogToSCaAahYPYErBKMa+lftc/5+v5dbv/NVIoC6aPD+vWxtSjwzddwkWqfW6vyX+92B1/D6012rE16AyTrE4hb7VkQVRSn/ejx4jtaxBHHaZGWYqs4oj/apEX/6bRKsbQArPQVIk4pCfRekQgEAQDLs+fdEkmw4So4lYI+qYlrOmpX7oQZ4tUbLhL08avepqecMlwESCF34E36BP/2ZC4+RDbYhCXEGaMmrrXhOMkI7uaXnxoKFptqSAwAQCYQCqIZ6wzfffQTDGYo1v5excgHCOxw+28+9SQCQFqMeOF93BXE9fmuElx0O6Fg9tiwosIkTCAGACAgQkE0RO0u2HCgS5VgIFGe0MY+QEAHDfT3AlLMHbjssIizI8RKvSa+N5TXpXaV/4buy4rsoFIwXlzoA9Lj+0lvAAB/CAXRKELBDFET13Qt7o8UcX+vplb8+K4StGZiFGCxHadWCyYV8jXz+nTi/ggFs8WGYyWT0LMTSI87k94AAP4QCiLLB7pUCvrmVEzojbJhddQDBEq3UyUIGMId6NXh/Y6YKogDDBdp+HVpi8q7HSFtGNKvU01cy887PoSCAAAERCiIrIaC9BMMZpnqlqirBCOZXkyVIGBtteByQr+40Mx2UC2YLaYfL5mEFQBAelApCBiCUBBZHTJClaBPauJafULTGcEkzhC+N/CUUKoEAWOrBaMK+YJWCUqDj80S4owiFIyJu/llHNsB6dHkxTwAcSEURFaHjLDExL8GB4w00N8rUJVgQyf6++klCBhpZ3QVxIEvLgS8/1OsZwlxpthwzGQSggggHQpJbwAAfwgF0Qg9dMJ0XE0OPD0x4gnBxVgGCIzUuSMAKeQOrNNTRXfFH/IFrRL0sx0lTKXNDkLBeHHRF0gHAnrAEISCyOQBrjt4HqGgD2riWm/qcNjDRSKeXlzdLrf/Zh0sADDTSAz9/mrcT6iDTegrmB1rk96AjOF9HkjePxWmhmte7geQHoSCaITpFQ4zSW+AQfriHy7SjJqPXbH8EICh1YIHI6ggrn1fDb0+1X1sQsHs9eZFPAgFgeSNJ70BAPwjFEQWlw+ztMS/vvgqcyKdEjrj9t9MdShgvh3JDBcJ/XWpXeXvNf0CG/wjFIwPoSCQPI65AYMQCqIR3iRaYxEK+qAmru04dcp0mBOCpYHhIkEf+4Qlk0sBmMgdeON+EZkN9l2hXVxoQM3vpVowO0y/mGoSQkEged9NegMA+EcoiEDU7kM2VDYQCjZUJRj2JM4wA8aaXzvn9t/M0mHAGs6O6EK+alWCkQ02IRTMDhuOnUzBMR6QrL30EwTMQiiIzF3tdgdfSUl7JCcxDfT3KkbWxL8SgSBglwC/02H2HWzk/mt+b6fKTxv/ngpf+DnHxN38ssNxPRaAqj7MfgHMQiiIrB3YMmTEN6c30kmcTQ0XCdTfi1AQsIg70KNP+g+EUKm3PN9Vgsvd7vs1kwqybDC97YppONYDknMfOx8wC6EggjL9BIZlJT6oieu6wz2JabZJf8MDBGbc/mF+5oB9dobb7y/q4SLLYglxRjCBOFZUCwLJuLEwNXyMnQ+YhVAQQenhEyajAbU/IVYJxj1chCpBwHbuQI8eODK3+LOxhHg+BHps0y+0ITsrLUzCsR6QDFbnAAYiFERQaw3fZfQT9Kc3gUmcUUwJ5eAEsFZla4CQXpciqRKseXu7yk/rymzYj59zfAgFgfjdXZga/iE7HjAPoSB8U7sP2XCVm6WkgULBCCYEF2ObXnzA7R9mCRFgr2VC/1AnBAe8vaHXTKoFs8GGYyhT8N4PxG8LOx0wE6EgsnRAO+cOvpIDRX/9BNsTmMQZ4HZf26aXFwKwlDvwBn2RZza016XIh4ss+/2Egtlg+jGUSbgADMRfJfgIOx0wE6EgsrT0hYNEf3yeoDZwsrxslWATU0KXf2xCQcB++2OYEBzg/v0+9iKEgtlg+jEUACyHKkHAYISCyNKQEUJBf3qjHy4SVODHZukwkAn1+go2UyVY97HrPI7v29tVfobAyH7tSW9AVribX0b/aCA+VAkChiMURBCmVzPQeNqfkE9OIwgY66NKEMgAd+D13hJiP5wYh4sE5RAKZoCauMb04ygAWGojuwQwG6EgsoRKwTrUxHVdIk5ntFWCYS+/q/rYhIJAduyPeEJwA98b+DWTsAgIl8+LBQCa8AkmDgPmIxREEOsM311UCtbXndzwkGqfa6i/1wxTh4FMCbhUsFqV4DK3xxcwUimYDYS/8eGYD4jW90XkA+xkwHyEgsgMd/CVHCA2vYStgRAvUJVgKAEkVYJAhrgDr98fwcUFn7eHduFjbZ07AgAgTdYXpoaPJb0RAJpHKAhf1O5Dpl/dnkl6Awyx5Ofc5Ml0zeb9kU0JJRQEsudAOMNFkpterPL3mf4+i/r4GceHYSNAtMuG72UHA3YgFERWHE56AwzRxBK26E6WA5hz+4fpHQlkz2SKX5eWccpjs4QYAGDCsuGtSW8EgPAQCiIrV7e5YlyHmri+S0TaoxkuElTDj83PGcimyUC9/xp6fQozYKy6bYSC9uNnDMB0Fxamhps6ygeQLoSCAKqcrCQ+iTPg/Z+4jVAQyCB34FJdITwXbLhImK9LzThx3wRG9qu48IaIcTwAhE8VpoZZfQVYhlAQfukqMpNxcFjfMiekzVYJxjW9uPR3fs5AZlVeFIhlqNEyn2s4YGTYSAaoiWtMP54CkE3vo48gYCdCQfjFQWxmQsFUTOJspL/XnNt/E/0Egeyq31fQ93CRZKYXq/x9VAvaj+MpAKbZW5ga/lTSGwEgGoSCyAR38JVUkDV0otLAJM5AVYJhVetQJQjAb1/BuKsIl7u96rYRGAEhcDe/jOM+IBx7RWSAnQnYi1AQfq1jV1lvbdMn08VIT5br3RdVgkCGuQOX1H4N8F0lmOj0YioF7Wf64DYAGQsEGSwC2I1QEFlwMOkNSDs1cX13CidxBt0OqgKAzHMOxhziBeDrsQkFAQBpQCAIZAShIOpSuw+xnMl+HU2HeDWrBINoLEB0+28iFARQ/XWgodenRC58dPj9QhiLn3FMivPzTEkFGkMgCGRIW9IbACOYHgoeSnoD0s9pYjlT1CfLvpr0z9S5EwDZML38cJG4XpfqqfnYtOqwH9WgcTl2bI4QFmhoyjBDRYAMoVIQWUAoGKhyoYFJnKENF2m4vxc/YwA1XgviGh5S7XPBvl/l76eSDACQBEUgCGQPoSD84AQl05ULiU7i9PtADBkBIO7A66arVwnWe11xQnxdavrCB5VkduOYCg2Ist8pIHeLyFmFqeF72RdA9hAKwg/TT1DoNef7JKWBEK8YVxP/mvfNzxjAMsOl4npdqne77zCS0Mhua5PegKwoPn30saS3ATDAjSLyhsLUMD04gYyipyAAbW1DJ8tNDRcJtUk/y4cBVL4erEt+uEhTF+L2h3FHQJYVjx4l5ABqVwe+izAQAKEgkHFq4oaOFE/irHM/C9z+mwgFAZQdima4SFANPzaVggDqvGYADfu+iLy3MDXMKhsAJSwfhvXLh93BV/CmV1t3QyfLgYaL1NJ0f68lSwUBZFwIr/mJTlU3+j0X9amJa/gZA0giDLxMRDoJBAFUolIQflC1gMQmcfrA8iAAJxXLrwlxhXhR9x2EhTiuAhDnMuHf10P5ClPDTTX+AWAnQkEg86pVpdSp1CvGOomzxteWPsfkYQAnuIMXT6v8V2N6Xar2uab7DlJFBoSgeORpLhoiy1WBHxSRffQMBFAPoSBsN5v0BphXsZC6SZz1cNAPYKk5EWkP/3Wp3vcHVfWxve0G0IziU09ZdXzgBHypoe44c/aKyG4RuYsgEEAQhILwo8vg3cQAiqYEqRKMbBJnvfumUhDAUvp1YV34r0uJXPiAfUw+rkKiln8NcXhNyZJPiMh9IvKI9343x9JgAI0iFIQfnewmq/U2NlwkqLT09wISdYT9nybpnKqu8g/0uoPnMSTLXoSCCKTFmS+saj36x05L8ag4x4+JM3/UkeNHRVYec4rHjklx5TFH5o9LsW1epG3eEZkXp2XhqK1YlBN/hykeEpEnl3zuSGFqeOnnAKBphIIAfEjPyfJSbv+NnDjDGPqAPtczKpY0Lk+zSRFnXXKVelZe+NA/80uT3gjAL2fFip+JHLNih7Ucf3z3o9/++/+d9HYAAOy7wNeS9AYASIsgVYJhh3yhNukHEL2v27WTo77w0cxgk9Sw4mfurKJgKitOf13358UWx3/6t0lvAgBgEUJBwBBUkdXXlfJJnLUem0EyMLUXkOn+Q1LNOZRcpV4ofQfTeKCZ8p85sFjbi87+qTX75NjhJ5LeBCBCM+xdIDlUCgLobHy4SCyTOGvdziAZmMiGixVflnRb8tpg3IWPNIaCaf+Z17XqIjuWksI3a44RHn3oS3qoBGArWyaFdyS9AUAjCAVRk9p9iBc369U5Ya250opJnEADbDi5M3jqd5jDRaJ87FQ2vjfaihfNS0pwbBUDd/PLrAkFARihO+kNABpBKIh6eHHLlCRPlqWRx7blyiKyxYYT1TlJt8PxDxSJcuBSKhi/fLj1+akJBTm2AgDAbN1iCUJBAD6HiwQVS5N+g6uVkFWFqWG9hnGvmOvGwtRwqqc1uIOvnY7+wkdcA5fSwfuZG/u8bTmzKC1rUv20BZbV+ap3vIbdA6QeVeDZ0i6WIBQEMkxN3NRh3iTO9J0sAw34sMF7zaBgKMnhIk31HUzriYWxz9vTXkc/QRisZdXKpDcBQF1r2UfZkOsZTetxWkMIBYFs6/ZXJZj4JE7ANqZWuX5fRL4rxgtzuEgj91/3e9O6JMXYfpgrX0EomEmOHdWhxbb2NyW9DUCEbBjAZmVYhGWl9TitIYSCAEyYxBnC9wLp4S3FfJ+Y571pXzoczetSWNXN5i0brrL03bjn7aqLjovTlvRWIBErbfnBtz436S0AkL2wCMvqEosQCsJ21lx5ik6VE9JiGidxUkUI6+wU86oED4r1qG627Hkrqy+hSjCzbDnTaXvG+qQ3AYAvhILZ0CUWseWtEkBYUjNcBLCbV3V1mZhjvTlVgmm5+GDfa6Jp1YKnv+WoOKsMfNoiFM7pq6zYk07bmhckvQ1AhExtqWJ9WIRl9YpFCAWBTDN5EqcZJ9BAHbry7m4D9tInClPD94pxwn6diGngUvozrE97laOpnzi86vzjSW8GErTiuc+0Yv+3tK1ue/FL1bOS3g4gIoct2rNUCmZDt1iEUBBABCeiUTfpP3E7y8NhNK/y7l2Sbjr8+YCYZ8lS57Rd+Fjm9qIxz9uLJeWe8etPJ70JSNrKFWIL5/SXXpr0NgAROWTRnl2X9AYgWrmeUR0Ittu0nwkFAcRwshxWk37APoWp4cMpX0Z8obdk1DCRTwhOaLBJOhSmhn+Y5mXEZ17xNMuGIStzZ1uzF4pt7b+a9DYAUShMDR+yMDSCvbrFMoSCQObVGy6Stkmc6T9ZBoIqTA1PpjRgeakXWhp+tT7Mqep+v98vs6oEKxWmhj8lInslhX0E2140n/RmIAWcFa1ijdZnvDXpTQAiNGvR3rWq3xzs//kSCgLZdsjsSZwEhLCHF7C8L2WB4CNivLAr9bjwscRAmoLB099yjD6COKHtOc+xZm+0ruo468UvffXqpLcDiIhN1YLWhUZYpE8sQygIZJi7YfRQ7SrBtE3iPOV2mw4ggHIwuCEFPQQtCQT9iDrk88mwKsEl/QV1MHhj0ttCIAjrrXklS4hhK5smEK9PegMQjZyF/QQ1QkHYjis19RRlpvHdG1ffwerc/usIBWGdwtTwnTqUS2i6q56E/HJ7AsEkWxRkpz2CDgYLU8MfTrI3ZvvQ01QIorrTLFpC3HbW7ye9CUBETG1VUlWuZ9S6ajKUDImFCAUBTKd6Eufyj71ksihgDy+Ue3nMyzJ1pdcbClPDT8b4mCkX04UPQ6sEl+mNeZYXLsei7fnz0vH7R6Slw5KdiNC1nnWGNXu1dfUvrGUJMSyl3z9sQihopz6xEKEggElDJ3HadvAALKLDucLU8CYRURFXDeoA5yxd6eUtBbWEIVPVi1Uf29hlVN5gmjd4VYORPW9bzizKmRuPypkDR8Vpi+pRYIPW5+qc2iJrzvuVpDcBiIBtq3/6cj2jHUlvBEJfOtxp4z4lFASwP7WTOGvfXmW7AfsUpobv9Q5CLgu5Autur3fg6w2eMBxAXNXNoVz4MPrn4S0nnqx43oYZDur7uqz9N55mwjB8WXVOl117auWzb056E4CwFaaGdSg4Z9Gebbe1qizDtoqlCAWBjHP7P3RYxDlg2CTOWbf/OmMraYBGQxYd4InIC7wpxd9vMAjUg0xO98JAS3oHLqbyrr6am2B1s8/HrlqXaWZfwTrP2xd7fTJvbPB5+33ve3WI/WIvcAR8aX3Os6zaU62rntXZ+co3PTfp7QAiYNuxvZX957Iot1D1aW3IG9qCCzVxnb4M1y3i6ANx/fell+UOeR/6l33a3fAR20qEbWXbizOq23lyUlZKJnHWfuwdId8xYIzC1PAPRURPKf5Urmd0tYi8UEReJCLnisgFS75chyePichDIvKfhanhY5INS5bsxFXdHPWSZXN5AbQeRvLhJc/bs6oMBbtPRPTX/0BE/t3CPpccW8XIaW0VcYoiRXt+v4qnv+zTIvKepLcDCJk+Zlln0V5dl+sZ7fKqIGG2PhunDocSCqqJ67q9BLzPx/rqRb/gauKGWW/53053w4c5OEopd3PXYbWb1zHbuf0f3K/Gb5kVcTrTO4nzxN/nvBATyDwvLHnE+6B6quHXoqZfl4KzqHtjk89bTU/czhKjl4ebQu3+zokCBeeZa6T44yfEFi2nPfedeuDIow9/w7bAHEt0XdDXJqe98JyFf1Uk2/NH5w5945P6IqFNbMwERqgYtObnaK2GQkE1cd2Qt6Z6bROPrcOHq/SHmrhhRlf+uBs+zIk+kJyt9U/M4mrSX9MOt/86TqgA1NKVjqnqTpDhIpXfyNU4IMTXgVXnni1P/VgXTNvBaVnZImdedKuIXJ30tiCCEHDNuW+XltP+SJy21zgdr1mz3NfmekalOH/058X5p++V+af+r/Pk93cf+uY+k/vy2Xhxc0uuZ3RrNno32ynXMzpk64CRhnoKqolre9XEtfpA9Y4mA8Gl9H3doSZumFYTNyxdQgI0g+dTgGpBETmY+CTO2o+tewlafaUGQChCmCyQ6MAlQsEa1PgtvLcjkBVn69XqdmlZ/YL3v/ilv3ha0tuBcHSpK8/ouvSmMafjNUedFR2fdVpPW+e0tC0bCJY5LSvWtLSteUPLymf9udPefbjr9bf8vOviPxzpunCjcUsdveBMrya0jbUDKjJiRCznKxRUE9d2qIlrdQ+vuyJOSXU4eJeauHGHmriREd5A/PSVkLkUTuIso2EvgADiqm4O8L11qwTt6XsGpEXbc58jtlmoFlyr+3TC8MrAUhi45pyfOa2rNzV7f07LytOdlc/cpgPCzktueKjz1f/tfDGLjdWCW71BFTBMLgNVgr5CQTVxbbf3y6mX+sZFP9akmrgxhCv9APxy+7cfOnk1K4FJnLVv3+72X2fjgQKA8PXGV90c2lR1AFFaE9p8xdRoWf18qgUN1nXxB17ntKunwggDq2lpW/OyltNfcl8pHFRXLh1EllY2Huu3Z6HazFIjkgEtPgPBMJcK+6Ufc1pN3Ki3AcmysYwby3D7t+8UcXY1voMiOVk+wLJhAOG8LklyIV7R32O7m19q40kRTmJ5eAJWnquHXVtYLdj+2r9NejsQXNclN97urDzry+K0tEa9/0rh4Jpzvtn5umvv7nzFupWSbra+/12lJxEnvRHwL9czujULVYI1Q8GKQDDJfgTtXsUgwWCyTD545cW3AW7/iC6V3hVvk/5qSvenBxGxbBhAkNeO7niqm0Obqo5svbebfFxlrFWveoXYqHX189/Sef57zk16O+Bf16XDY07b6e+Pe5+1rHjGJc4z3/hYV/fmF0tKFaaGD3nH/jZiqKohcgvLvTNRJbhsKKgmrklDILg0GDT9ABDJyES6H10wGFbFYLXP+bpdDz7pZdowgIACHL/EFOJVrRKs+jgmT46MC8eECPw8aeto9/OLaKTimlfek/Q2wJ9S/8DW0yJZLuyH07rqdOfMV812vua3BiS9bK0WXJfrGe1LeiPgO8Btz2woqCau6UjhTtDbsp/hI0C83P5tukJve0KTOHe5/dcRCAIIROXvDVAlGHY/VKfB4SKLTDexUQBqhMctL7Sz13/rymc888Wv/u9/kvR2wE8gGE3/wKBaVp+d73zNfx+UdNov9trJ0JF0yy0Et+slQ6pVCo4k1EOwnrVZKuFMGT0eHhnl9m/Tv3eXndpbMqwm/ad8bk7EudLtv44lwwAa0eBZf5AAMdSp6iwjzh6OqxKy+qJXiq1aT3/x1Z0X/PI5SW8Hquu65MZPpCUQLGtZ/eLdna/+75slZQpTw5MWV83rYieWEadUbmHZcOZ+PotCQTVxTW/MU4aDukpN3Ki3EfEyumpB5R/kOdMkt3+bfnPW1Te3V/+K0E6W9XLlbrf/usy9GAMITW9C1c3Vv9fncBFb3nNjYvT7urvh4/yME7LiRWeLzYqnv+KeF7/0F09LejuwWNfFV1/itJ3+B2ncL85pL/g/nRduTGO7JZurBdfnekYpfkinnSlbMZtIpaAJJ+ImbCNgHbf/lsNu/y16ClMu/F6DckBXI7r91w+5/dfTgB1ABP3mwqpuDm2q+nKoIgMi4rS0SMuzV1u7f1tXPuNZ0n6xPqZCSnSpK89wVpw1JSnltLS1yJpXfPvFL79klaSLzaGgtiPXM8ow1fRNG14vGXQiFFQT1+i0Oo1XCZbqVBM3kqwDCXH7bznk9t+sfwfPEpGrRZyZBk+WZ7zvz7n91/e5/dfb2lQYQLy6og/5fApeJag/RxUZEOEFglXd9i4h1lpX/8JbOy8aem/S2wHP6hd/R5yW1jTvj5a201Y7Z170QUmRwtTwfouXEJ9YRkx/wXTI9YzqFQi3SUa1VfzdpH59OsWlYjA+pp+g6F9yAqeQuf0362qWHfpDjZf6L3R7+7prmQPxw95zSX9Muv03UA0DIALOuiqfC+u+4wgYeW2sr8rP2BgVF9KQSCh47jny5Oe/YXUvz5Yzzt3VecH6L83ed+B7SW9LlnVdetMep3X188UALatfcG3nq97+sdn7/+nHkh46GNwi9lrrnUtR8JSgXM9oVwYqU+uHgl4vQROqBMvWqokbu90Nt5oeVpmCExTU5PYPH/aCV8JXAAlPHo6zStAJWCVY73tLn+PYxm4cU6VhCfELOmT+/7O5CEnEeUb3w52veusvzN7/uf9KeluyqOt1H3iPs+KsK8QgxdNf9n9E5B2SHjssDwW1Lbme0cOFqWFd9ISYeZWa+7PYR7Da8mET02kTtxmp6i8FALCL0xXZUuAgAWGx8YDR3XwuoVENavwW3tPRtNWvPs/6vei0rGiRMy96kMEj8et6zW89z1lx1t+KYVpPe+7bO1/11mdLShSmhvVFslmx31UMHknMpFexmWktBk9x60t6AzLE9MEPnEAAQDYEaNodpEqwqanqQW47WOdOYf57OpWgKXiurDz7xVJ05sV2LSvOfJbzrMt+kMIhElYHgnLaC38ghiquPjdtfdV0tWAW3EEwGK9cz6huR7c25odNpRY1cU23YUuHyzrVxE2mHxgawd3cZXooCADIht7oQr6gVYJ+tuOUz1ElaD9+xvGpeX6z6vxsnEaUgsGz3vjvBIPR67qgr01WPf8RJ+WDRWpxVnRslHTJ0hwBgsF4A0Hbl6YHqhQ0eRS2iRWOiJ/JDckBAA293oe1VLjZ4SKBUEVWH8d+CMXpr7koM3uSYDCmQPAZF37faWlbIwZraTv9tM4Lr3itpERhqtS3fJdkB8FgxAgEq4eCJl8mM3nbTcOSJgBAaqn8dI2LnKFPCK6uuSpB/XdCQfsxkCslnNWnScsLniFZQTAYRyC48nligeKKZ18l6ZKlakGNYDAiBILLh4ImX3E1ucoRMVL5b5v8PAcA1NcbTpWghFglGLjvIO066uP9HHWp3d/x9Tw5/dLXZGpvesEgPQZDZFsgWNK6+vWSIoWpYX0xZUayhWAw5CnDBIL1B42YSo+QRjw4UQEApNkyIUCkIV6dKkGf3+vd7m4+h0pB+3E8lSIrnvsckdONbf/WkJYVZz6bYDDEoSK2BYI6E1z1zDSuxsvKwJGlweDWpDfChkDQq9Knh6CloSDiY/pBLJUFAGC33lBDviDfWwxlsEnWqiAy2SfY3fBx04+nrLP6kgsla3Qw2PLstz7ReUFfLultMX3KsG2BYFnn+e85V1KkMDWslxDPSvbc5lW4oQG5ntEuLxBkyrDFoSDLhwEAyDivn2B77a8KEhA2Mjyk6cEmVAkCCVwMPu3lL5Oiczxz+95pWdHiPGPtI50XvfetSW+Labpe94FfLgWCBk8ZrqtlxbMkfUYkm7bkekYnvYo3+JTrGe31jq0IBC0PBeucACBEpjfGplIQADJbJRjqhOBlqgSbXrJMKFiHGr/F9Pdyhral1OlvylZvwcpgsOWMl/1z52t+96NJb4spui654U+dFWcdsDoQ1G9tbc/cLCmT4WrBcpX8dK5nlKIoH7xl13eRF2UjFAT84soKANirN7SQL/LhIssiFKyP93JEIqvVgmUtq19wbefF1zzSef67npn0tqR5oEjXpTc/4LSt+f2ktyXjslotqHWKyL30Gaw7UEQXM90W48/FilDQ6INQNXGT6VeNjeBu7jK9UpCyYQCw1/oEQrwGh4tUf2x38zmmv8/GwfQKCX7G8Ql8fpDVasGylpXt5zjtr/3PTjX05qS3JW26Lt56ibSrp5zWVa+U7GjmSltkMl4tWNlnUC8nTuNAmMTkekb7vDkIRvceTioUPJzIIwMxU/lv88IJAJZR+em+0EK+IAFi3eEifu+/hCEj/vA+jmirBdvqJv1Wc1raWlrWnPsvnRd/4B6qBsvVgcOTzspn3237cmHDZLlacOly4sxPJ/aqA/eLyJ0sF87u8mGWksTH9F44nEwAQKYqgpqtEgw7YFz2dqNXbcTI9PdxKgVT/lw5s+9N4W+JgVpWnvWLparB1/7+rZJRXa+75n0L1YGnZbTqqJjKSsGKakEupi3MVyhXDWZy9aQXih46dcUIgoaCph+gmL6UBPHhuQIA1nH6Kv5e72sbvC1olWDgwSamH4vFhfdxBOm9FdiK5/6CyBobaiZCqho87Xk3dF46/ESn+m+/JBnR9drfe3nX60ced1a0/1WWqwOd4z/7vKRb5ivkKujg+q5cz+jOrCwp1iFormf0kNc7kOGzTeJdD0GYftKSiRdJAMgKlZ/pXv7k34lxuEhQp3wvlYJ1qPFbOkw/8Hc3fNz046hMaN/07qQ3IVVaWk9b3bLmJZ/vfN11D3de9OvdVoeBlw4/4Jz2/AedlrY1knXzT/+npFhhali/nh5IejtSZoveNTaHg14YOOlNFm7o4g/s7Clo7ZtTCvFcAQCkyVA8IV6FYugB45y7+RxCQfuP9+aS3oCsULu/09QyupbVp0vbuc8Nb4Ms0bLizHNbznj5vZ2X3Pijztf81oBYouviq9efCANbT8vSIJGaZu/b/2VJP6oF64eDpr93luR6RocqwsCMLumPTpu74ePTauIaMRg9BeNj+kmLFS+KAIATKpYOBxFmlWDTYSPVY9l4Dzf9GCpTznjzOnns4bw4TmZXjy6rpe3050jb6fmu14/8TfHo4c84Tx665tB9+40qHOi66NfOlFUvuEpaT7/eWfksqgKXOH7k8GNigMLU8KFcz+h2EdmW9LakOBzckusZ1XMBdB/G/YWpYWN+V71qxyHvg6rACLWJ+awsjU0pvW7fZO0q/+0Od/CVxrwYAgD8LB0OM8SrcXvdwaQNBYyEgtk43jP9GCpTAbJuJbfmXZfKE/9wTzhbZGnPQWfVs39TVj37NzsvuelHcmzuQ85TP/g/aQ0IS0Hgyl/YLK1rtjtnvOJ5SW9Pqh2b+xcxRGFqeERXkREa1bTO+9jhTenV4aD+M61BoK721j9TKgJjDgVnDf5FMnW7jeNu7jqkdh+y4UCREzAAsGbpcEwTgusOF2nk/kt4T8pGpaDxB1BZW0W0qisnT6z5msjP58O4O6u1tK1+rrSt/lM57Xl/WgoIjz9xQI4d/tNZ9477ktyurtf+7iuk9Yw/kJZVGwgC/XOO/OAWMe94QC8rRW3tFdWD4vVk1Mcgk4Wp4cSq2b3Jyb3e6o+1SW1HlrVVHKgYG66piZs63A3/I5VXpSw0Y/gvq37B4QQMAKzqJ9hIpV4jfQdDml588nNz7uaXsKzUH9MrBvg5G1hV2r7pPXL4MxMsIw4eEL5PVj3rfTp4mD/25I9k/um7pfj0v8jxn31RnvrBQ7P3f+6ohKjzVW9d4azOnVtsXdPjtKx8qzgrXu+0rnqec9oLwnyYTDh+5LHHHr3/Hx8Sg+ihI7me0dtF5Kqkt8Uw670PHczNee9Tk96fh6IICr0AsMu70NdtwXu7VaGg6YEa1V/xMf25YvryIwDIPJWf0VeT20Oq1Kv/vU0PF1n2+7lI5YMav8WG927Tj59MEtrzpWX1ajntkvPkyFeMykjSFxLKav2a3SfyHJHTX6KDAZk/9vOHSq+DxWMPOMVj3/ReE4t+GjYUW1a+xZGWZ4vTcpbTuuoXWp75xjDHSWXbkf/vejHTiFdpZmyhUwqqCMvLjEu8asJyWCjen4cDvhaXX48J/wwIBafLKbGhGDYSn0nDf6lNX34EAPBdJRjVcJGglv3eVPb0SSHj37vdDR8jADb0vOB0dZEc+eZ3RJ6o21QUAbS0rXm591f95+VBvpfwLxrzRx8/8ujM7r8SA+kBGl5vQZYRRxMWiuEZAGpoETsYf7BoENN74pi89BkAMk/lZ/QJ//rYJgQ3XSVY83aComwc5+ne3TD4WK994JelWDwe9t0CqVJ8cvb9YjC9jFhE9DJiAA2Egqb3OaFSMD6mh4Ki8t/WvQwAANZUCQbRbJVgaDUqs+7mlxj/nhoT09+3+TnHRO3+TiTnBHoZ8Zp3vz6KuwZS4fhT//l9U6sEKxWmhrd6PfABBAwFTe9zYvoVZGO4m7tsqGrg+QIA5toabohX4/ZipAEjS4ez875tw7GTZP25sqozJy0vODOquwcSUzx+ZN752fQvWnbxUPfCA+ADlYLI4jIY008uACDDA0acJpqIBwgIi5FPLyYU9EGNb+vyehqZjErB+EQ6lOYZv/wOKbaxjBh2mf/5w783++DB/xBLeFNzdcUgAL+hoLvh46ZXCtInLl6mH9wSCgKAmbY2XqnXdIgXUM3vnXM3v4Tqsey8Z5t+3GSSSENBp6VV2gfeRX9BWOP4z79/8NGZ/F+IZQpTwztFZFfS2wGYNmjE6OovNXFTpAcBWMT0ExlCZAAwjMrPdIk462KZEBztcBGNKsEMhYJMHo5V5OcDre1nyZp3XRr1wwCRO37kJ4flp/e809ZdXZga1suI6S8IBAgFTb+KSSgYH9MH04jKP2B603IAyJqRYF8eaogXModQ0D/T3685IbXwfGBV10tkxflnx/FQQHR9BB//1qWPPjL9RAbeQ+gvCGQkFDT+SrJBTH+u2HCSAQCZofIzHSLOllgmBEdeJejYUHEfp4rqUCPZcMxkktjOB8544xvEOWtFXA8HhGr+59/5/dkHPvdt23drYWpYt0njvA/ISCjYkfQGZIW7OWd8pSAhMgCYxGmiYXiAEK/ucBG/91/TAXdzzvRezrFQ49tsuOBrwzGTSWIdStO+qY/BIzDO8ccL44/OjP25ZIQ3eOTKpLcDSCubQkGuAMTroJiN5wsAGFMlWDlgpNkqwciGh/jdNpYOZ+u9mqrQmKjd34n9+eK0tslZvzEoxeKxuB8aaMjxJ/79W4/e++mNWdt93uCR7UlvB5BGNoWCVArGy/Qr3+0q/4ANFQgAkIUqwfbGgroAIV4xtunFhILZCgVNP14ySSLnAjoYfMavvZtgEGYMFpn78sWSUYWpYd2bmInEQI1Q0PSDFibKxsv054stJxsAkPEqQYk6xPPJ133vYulwpt6nZ90NH2OpeHwSu9jb1n5WKRgEUj1Y5KdfPy8Dg0X8TCQ+kPR2AKkMBd0NHzf+oEVN3MQE4vjYEApSKQgAxlQJhj0huFqVYOTTi6kS9EmNb+uKuz9cBGw4VjJJosd1Ohhc3XthkpsALBsIFg/fc/7sg1/8IbuoRAeDTIYHqlQK2tAnjlAwJpYMGzG9AgEAMlQlWE/oE4JDVLq/OXdzjlAwW+/RNhwrmSTx84DTznsVwSBSZ/6n071ZmDTcwERigkGgSihoerWgDQeQJjE9RO5U+QcSP4AEAFTjjPivEmwixKtaJbjc4/h97Kq3Ewhm75iOISMZbCV02nnnEwwiNY7/9L7fffRbn51KejvShmAQWD4UNP2KJgFPvGw42O1LegMAAIup/Df1+/lVje2XACFe3eEifu/flx2NfmNGGf/+7G74mA3HSUZQux9K1TkAwSBSEwjOjP150tuRVgSDQPVQ0PQJxKk6IMgA00NkWyoRAMA2ukqwgUq9sIeLNPK9VbdnxpK2G7FQ49u6LegnyLK0jJ8DEAwiSQSC/hAMAvaFguuS3oCMseEEh1AQAFJE5b+pX5e3LP8VaRkuUu/7F9lZf9tg2XuzDcdIJknlc4ZgEEkgEAyGYBBZZ9vyYSYQx8jdnNMh8qyYrV3lH2AKMQAYUyUY+YRgnwJtG6GgBQFPQCwdznilYBnBIOJEINgYgkFk2aJQ0N3wcdMHjaT6oMBSNhz0Gt+3CABsoPLfHDpZ9R92iCchVgkG2rZd7uYuG46v4rRezGfD8ZFJUn2Bl2AQcSAQbA7BILJqaaWgDRNlbbi6bBLjq0t5zgBA8lR+piPYMI4wQ7yQwsbq902VYABqfJsNx3Fz7oaPmd6SxzSpmDxcLxg881feIcXisaQ3BRYiEAw9GDwQ0l0CRoaCph/EpPpKoYVsuBK+TuUf0CejAIDEOCMnh0s0G+I5AasEJaqAccbd3GXD+2ScbKje52ceI7X7IWOO/ds6ninP+NX3EAwiVASC4QeDhalh/V60K+S7BlLJxlCQ5cMx8qYpzon5bKhMAACTh4tc1dh3BwgIiyEHjHU5ASofYdH7MaFgvIw69tfB4Fm//atSbD2a9KbAcMXjR+aPP3bPGx+dGfvzpLfFRoWpYd3SZHvS2wEkEQqafiCT+uUDFjL9OWNLZQIAmGpnY5V4oU4IbvB7l922OXdzF0uHA1Dj27osOY6z4bjIJMZUCpY5rW1y1m/+mkhHW9KbAoMDweLhe85/9FufnUp6W2xWmBrWqxiutKQIBshMpaCeQGzDVWaT2HDwSygIAAlQ+W/qA+7O5b8ipAnB8Q4X0agSzOZ78Zy74aM29Fs2iZHH/aVg8FcGxPmF076f9LbALMeP/OTw/I8+e+bsA5/7dtLbkgWFqeGd3usMwSCyEQq6Gz5ufCho2jICC9gQCrar/APGXWkGAJOp/Ix+3d3WWKVe6CFek055bKoEMxLuWHhMZBqjj986+vs/M//z7723OH90PultQfod//mjB+UnX3jho49MP5H0tmRJYWp42ssYZpLeFiCOSkEbJhAbfXBgGov6Cuq+EQCA2FRO5o1wQnDkVYKn3L7L3dxlw0XW2KjxbXrg13oxH6FgjNTuh7pODigy1vSs+5n/X/GnM+fOH/3Zj5PeGKTX8Z9+e+RR9696CQQTHUCic4bbE9oEINZQ0PQDWULB+NlwEGzDsiUAMILKz+xovH9c6CFeiEr3rZdEI5vvwTYcD5nEhtVBpeXms/ftLxQf++ILjz/1o39KeoOQ1oEi/5ehFylQmBreKiKXW1IUA0zaGgquS3oDMsiGg+BOlX/AhoNLAEg1lZ/pFXGuCi/EcwJWCUYaMB6gSjCzS4fpJxg/45837ubcifOuRx/68pFHv/aJd7CcGGXHn/zRD3T/QAaKpEthani/V4jEcmKY7nCLrQGPmiiV9iI+xj9nLKtUAIBUUvmZDhFHH0xHPyG4mMj0YgaMZPf915ZjIZOYfrxftWVTaTnx4S//AsuJs+34zx7580e//omzWS6cToWp4UPecmIqOGF0v8zlQkEbpqaZfpBgFHfzS/RzZlbMR19BAIjWzsU9wMIcLlLv+4MKvG0H3c1dBEMBqfGRPgv6wml1wm5EwPTj/WVXZ83e/7n/mv3KR589/8QP/me8m4RUTBf+8RfPe3R65+8mvS2orzA1rFuGXGbJuTD8mfOWkB8Qs5W2v2oo6G74+GEL1sibfpBgIhtOhNaq/P0sIQaACKj8zFYRZ310E4KrVQnGOr2YXoLZrRK05TjItCEjnWK2uoUYs9/4iz+aP/y1c6gazIbjjxfGH/3qn5w1+8Dnvp30tsC/wtSwfv1nCEk27NL9bL0l5PttOG5ZrlLQhmpBQsH42XIwbMvJCQCkhsrP6Pfl24J9V+QhXhOoEgyRDe+7s+6Gj5rek9s0Nhzr+zrfmr3vwPcWqgZnry3OH52PfrOQWHXgvZ/eyN43ejqxHkJyEb0GrTSrK0ILU8ND+mdtSf6xv14oaPp/IMNG4md6Ul7GEmIACL2PoD6uiGlCcORVglW3jSrBBrB0GE3ITChYNvuNT35c9xo8fuS/vhHdJiH2ycI/e+R/Ux1oV482r9fg1RasvoSUfobbC1PDujpwcmlfyeV6wxrggLf9VlcK6mEjxk8kM4m7+SWHLZnAxBJiAAiXDgSb6BkXIKSrO1zE7/0H2jZ6CWa7StCGi+kmMv04f9bdnDsc+Jvu/9x/PfrVHa+Z/+nML84fe+KpaDYNcTj+8+8fLP7k4Isend75e+xx+xSmhvXgsS5vuSnM7bnX7fWNrNUr20QnBuPVCgVtWAJhwxVE01AtCAA4QeVn9MHS2sW7pNkqwbiGh1T7HFWCYVHjIx22hILuho/acvxjEtOP85sqwJid2fu12S/funr+8UeGWFJsluNP/ugHxw9/tedR9y97Zx/84g+T3h5EvqR4yBtEYmpFWRYd9JYK95Wr6ZZTmBreaWBF6MHKqsdlQ0F3w8eMrxS04AqiiWw5KGYJMQA0SeVn9GvpluZCvgDfW7dKMOzpxaXbdjFxuGG2TB02ffqgcdTuh7oteO6Ecq41e+/OXfM/+sc1x5/4/p8QDqbb/NHHjxz/6bd++9Gvf+LsR+/72y8lvT2Ijw5gClOlVYxMKU5/38Ar9c9q6VJhv1V3hlhU+VirUlAsSLNNv4JoHHfzS6YtGcfeqfL38/wBgAap/Iw++L2juRAu7uEiDW0bvQQbZ0WVoEUXRE1iwzFaaEvOH334q089+o2//ADhYLrDwNmvfOS0R2fyf5n09iDxcFAvKb7SknNm28LALq/yL6gdBlUL3r408KwXCppeLdipJkq/dIiXLX11qBYEgMYnDe+PdUJw5MNFqtJVgja0W0lq6fB6sYMtxz0msWE1UOjnWYvDwUdvo3IwWYSBWI4OnirCQRt68ptqpskwsMSbRjxiyH/vKdtpeyhoy5VE09hyxZxQEAAamzS8v7GlfZFPCG7CKfetrwhvDflBssSW99gZd8NHCYbj153FISPBwsG/+kMdDs4//p0rGUgSf8/A+bnpDVQGwmc4qF/P6DmYTM/A7mbCwCqDZdK80lYftw55AWbmQkEbriQaxd38EltCwXaVv9+WpU0AEDmVn+7wqqY6Yw3xqlYJSpOPXXfbdribuyI7qc8AW0JBW455jKF2P9Rx6vAi48RyjqXDwdl7/3pnaSDJzx549/GnfnRvHI+bRcXjT8/racLzP556pe4ZOPvNfXcmvU0wsudgTi/vNGgpqknmvEnQuQZ6BgY5tknjz05vk/5vrvreUzMUZNgImmBL021bTloAIIZA0Jk8ebIedm8/p8HhIn7vP9C2zbqbu0xYJpJKanx7twWhThmhYPxsuOAfe+HF7PTf/P2jX/uEmv/xXc/VS4vnj/38qbi3wUbHjzx2WPcLnP/R355Zmib8wD8/mPQ2wVx60m1halivQigvLU5z5ZlRS4T1PtWToOtNE26Gd99pLCraulwgqLX5uAP9RFwn5rLloNPEg2QbegWtV/n7O9zBV1ENAgC17Vj+PTdIJV4kE4ID3l5321g23BxbLrjNuhs+YsOqGtPYEAom1ody9oF//U8R+UP90dn9K+8qtp21tWXVs97ktKyst4IMFb0Ci0f+67POkw//waMPHvwPdgzC5i3x1Mtad+Z6Rru8982hkysx4GNwiM4jdkQZAlajKxBzPaNXVh+2F7uaFYJBQsFJw0NBURPDve6GUZpAx2t/Sn4RwjBk4JhxAIiNyk/vFHG2xFipF9JwkXrfX9VBd3MX1WHNsSUU5HmQDNP7CWqpCJN19aCI6A/p7N787mLbM68iIFy+IlCOzf2L89T3b6EaEHHyQi29OmEk1zPa7b2H6osjFD9VDwJ1n8ZEX2MLU8M6zD3UeI/t0PZHn5990WbKm1aT9C8NoWCM3M3nHFa7v3vAkmpBXRFCKAgAvgLBZkK4SCYE+3zserc7tgVaiVDj24cSPEAOWyjNyRHYOuOH00Q4ZKRRs9O7/05E9Id0Xrjh4uKK514lbWe+rXVl+zMlo44/+cP75NhP9zlPPfpXVAQiDbyAp7Rawasg7POyDhvOuRtx0Ave9sddEeizYrDXO1aIO8A9sNxQkayHgoifLUuIO1X+W73u4PkEywBwSiAoW+IL8STEKsGGhotsdzd3peqg00C2hKosHU6A2v2QDcf0qT+3mv3mxD0i8iv67y9+6atXy5rzNkvbmb8irWsusjUk1INC5o/O/bsc++lnnWM/+ZvZ+w78W9LbBNTihWA7ysUrXgBV/jD94kmtEFCfk+vBLJOGhLjduZ7RES/MbY+hOlD3Dwy0kqFuKOhu+NghNXHtrOHr1239pUg725YQp/6FBwDiDwTDqtSLJMQLycJwEarGm6PGt3dZdEzG0uFkEArG7NGHv/GkiHzG+yiFhM7qzguLbc/cLC2r1zltZ7yiZcWa08Qwx5/6z+/L8Se+Iscf/7xz7PDB2fv/8aGktwlohheSnThf9ZYa69dM/aeJ7796QMh0+cOEEHA5halhvfR7hxcMRhEO6mPUEb1suZFvdorFqpfaF1ET1y6p+GqmoXdi93EZfQXjp3Z/t0q1YLXnXK3noZ+vL9Z5WhTDeLyz3MHzU7fcAwCSrRBsdGDI0tsD/LvuxOGwA8bSvy9zN3cZe0CaBmp8uz4gvirE9+XFnAaPGxp7vIsYMhI/tfuhGr3OjTk/ucjdnEt9tWBQnRdc/rpi6xmvkpZVF0rrmaVj/9bTnpVoUcnxI489JsXjj8vxn39Fisf/n3Psx3k5evi7swwHQUZ5QWGHFxZ2VXx0JjgIQ78eHvb+1NWPegKz1cdbuZ7Rvoql351NBIGTXg/FpvaXn+XD2qQFy0DpK5gMW5YQawwcAZBpKj+tDyR31A8EI+ztVzcQbOT+637vAQLBULB0GM0yrdJlqTkbA0Ft9r47vyIi+kNOhv8LOl/1zpdJy6pnihSd4opnbV70jV6AGNixn+qeWSc4x36SP7kt++9u6D4By1UMnTglRMr1jHZUDHIqh4WyzL/9Kgd+suRxDyc9DCRJhYXlvfsrekN2VVTCL1cRXxme6srJ0NrZ+A0FbfiB2bDcwEQ2LSFm4AiArAeCk/6aJQepxAt7QrAT9rbNWRRmJcayASMsHU6A2v1gb7RtAmJhwzlVYLP3/8N3Kv755SU3vz/mzQFQhTeUwuoKvTQqLIR7h5Lc9y1+vsjd8DEbnhymX1k0dgqxN/1GLBk4ost8ASBTqgeCYYZ8QasEY51ePORu7qJ1RPNK0xItwdThZNhwDGbDORUAwCK+QsGKSS9GUxPDNhxMmMimK+o2ndQAQF0qf2+3V92yTCAYVOQhXhOcasuGbXoPS4Qa397rr8LUCEwdTo4Nq34IBQEAxoaCNryJ2XAwYSKbTqjWqfy3GumnAADGUfl79XK9ydpNkGOaEBx5leApt7NsODw2Lb+26ZjGGGr3gx2WBMuZXD4MALAjFLThTYxQMLklxLvEHiNJbwAARE3l7x0Sce46tQ9cWJV6oYd4ISrdN8uGQ6DGP9h1cjCNFfSgHcTPhmP4GXdzjlYEAIBUyVql4Fo1MayvNCJ+Nl1Z71P5b/E8AmAtlb93p78hUWGGeE7AKsF639vUtrFsODw2VQnOuBs+Etq0PwRiQwsgG86lAABZDQXdDR/TV7ZmxHw2HFQYx918zn5vKZYNdNUMvQUBWEfl7+1Q+Xv1yoAtkYZ8Qb63GPv04lnLgqzEqPEPdlj2fsmAkeTYUClIKAgAMLpS0JY3MxsOKkxl08G0TSc5AFAeKHKosb5dQUK4sEO80LeNZcPhGTp1+bnRbDqOMYba/WBX7b6mxrDhPAoAYBlCQcTJpoPpdpW/j0oSAFZQeVdf6Lj3ZIATpEow7AnB1aoE/WxHKNu23d3cxYl7eGy6gHbA3fAR+sElw4ZVPjPu5pfw/AEApE4WQ8FONXGzroZAzNzN50xbsgS9jIEjAIym8m6Hyrv7RZzb4qnUS9twkUX3fdDd3MXrekjU+AeHLKnusvHCpmlsWOVjwzkUACDroaBFfQVtOLgwlU0H1Z1UCwIwlcq7vd5y4fXRLQVuIsSLd7iI7nlL9Xe4bApY59wNH7FpYJpplrxGGYlQEABgRaWgLW9qNixDMJVNoaBtS6MAZITKuztE5K6F5cJxVeoFuO+6w0X83r/vbdN9BJkqGxI1/kF9nEWVIJp/LuUftOWY3YbzJwCAhbIaCq5TEzfriXiImbv5HF1tusuiHb9W5e+j8hSAEVTe7VZ5V7dyuKr5e4tyOnEjj93wtuk+glSBhcu2C2Y6REcybDjGop8gACC1shoKarZceTSRbdWCNi2RAmAplXdHvGEiFdOFw6wSrHV7gO+tWyUY6vTig+7mHK/hIVLjH9Qhzjqxx0F3w4epIk2ODcfrtpw7AQAsFDgUpK8gmuVuPlcfHM1atCfXUS0IIK1U/hu9Ku/qUGPb4ltiCvnCnxAc4LFr3j4r4tgQOKSNbSGrbRcyjaHyD3ZZsgydUBAAYFWloC1vbpwIJMu2pTi2nQQBMJzKf6ND5b+x0+sdWOfEOsyQT0IeLhJJwKgHi/S5m7t0SwuExMIqwTl3w4cJBZNjy7G6DedNAABLNRoK2tB7p11N3GxDnxJT2XaQTbUggNRQ+W/onm66OnBLspV6oU4IDsGJ+9vqbs7p3ooIl20XyGw7VjGNDaEg/QQBAPaFgu6Gj9pyxcuGgw0juZvPtW3giI0nQwAMo/Jf71X5r+uw67aFycJhiCnEq1olKE0+dtXbb3c35wh7QmZhlaCNqxqMofIPdljyfLKhkAIAYLFGKwW1A2I+QsFk2XZSRrUggESo/Ne7VP7r+uTzLhFnmUEicVfqBbjvusNF/N5/XbvczTnbJuOmhW0XxhgwkixbjtFtKaQAAFiqJeNvcp1q/ObupDci4wNHZsQutp0UAUgxlf9ah8p/XV9gKYjI+oiCtBrfG8uE4Aa/95Tt0e83BIIRUOMfokoQYbMhFJxzN7/EhvMlAIDFsh4KavQVTNYOC6sFbTiQBZD6MPBrIyf7BkYWpAX8fr+qVQkG2Y7A26Yn3ve6m3MMFomGbe/ls+6GD7PsM1nrxXy2nCsBACzWcCjobvjotHeQbbqhpDcgy9zN5+70pkDaxLaTIwDpDAO3iTjt6avUS3KwSdXbvUnDBIJRUOMf0sdRFUvWrcD7eIJU/kFbLq4SLAMArK4UtOUK2Fo1fnNX0huRcbYdfHeq/DcJmwGERuW/2qXyX9txMgzUQ0QiDdISHC4S+vRiXSHIpOHo2NY2Y87CnsemsSUUtOE8CQBguWZDQVuugNly8GEqGw++R1T+m3pyHgA0TOW/2q3yX90p4uiegVctP1E4yUq9evcT12CTqq4kEIyOGv+Q7tHYKXbZ7274MMvMk2XDcfmsu/kl+iIOAACpRqXgAqq6EuRuPlcfNO0Su+iTJBraA2iIyn91SOW/qqtM7hVxtsQbpIUZ4jkBqwTrfW+gbdOBoI0XnVJBjX+ow8IqQbH0v8m0pcPLXPwwii2FEwAAyzUVCrobPqqvpB4U87GEOHm2LSHWtlItCMAvNXZPl8rfM6Ly9+gLJXfowUVmVeoFCAiLkQ82uZpAMHJbLQlvKh1wN9xKdVeybKgS1AgFAQBGaAvpTa+BE5dUHoTYGEwZwd380mm1++GDljyXytq9igMqBpEotWdCT1nXH7p/apcXrni/a44eGKVPgg+LOLrvmv6YdDetZ/lcXD+fsXt0tXqfFMvTNmOq1KsryGMnOdjklM/tcje/hPfzCKnxD3VZ+t7G8yZ5NoSCc+7ml9BPEACQmVDQljc9fVLGwWCydIB2l9jlKpX/5g538EIqDxArtWdcn1gNiThe0LRsmNJZ0RPsxNeqPQd0SK972e13N/0yAWHYP5+xr/SJOPpntGSpXGJBWnwTgqMdLqIDQVqCxPN+bVuV4EF3w622HNMayaKlwzyPAADGcIrFuk196lIT1x06eVLp96ShmRObZu9j2ZOTnNv/IcKbBKndD1c8l8qqPUeLy/+76o++xtfX/dogn6t620F38EJdpQVETu0ZH/JO2DtDDIEO6HCw1IB/03sICBv92Yx9WQeB+rWg75Sfj+/ltM2EeEH+HeZjL7m9GOZjL/ocgWAM1Phor0ixygW8Zt9XQ3hfdpp6vCvdDbfSgzJBKv+g3v+n9lAthnzsX1Mo93Glu/klPJcAAJmpFNT2e1MRTccS4uSNeL20bLJO5Wd63cG1XDlGZNSefTpw2lH7Ak3DlV7rvY871J7Pzog4+mRn0t30br3UGMv9TMbu7qgIAfXPp05FYEyVenVvj7DvYHRVggSC8bFxEMcsgWAq2LB0WKOfIAAgc6HgpCWhIEuIE+ZufulOtfthr8rJKjpE0T2YgFCpPfs6vOfXkmXC9TQcxKwVkdsWHvvvdD/CSa+KcNLd9K7MVxGqsbvL/Rt7RRx/PVIbKtgPbbltkwI8dnTDRQgEY6LGR4cs6/1rc9BpFIuWDs+4m1+S+fdCAEDGlg9rauI6/QbYbvjyYY0lxAlTux8eWlwtaPzy4fK/t7uDaznxQGjUnn3dXkVCZ3MhUWjLSnUV4eTJYSXvtL4dgxr7t3IA2HtqWOJjuW3Ty4Yb+Xqf29bQY9f4d93/1ob+OwgEY6LGR/UFCP073d78e2Kqlg/rKkEu2qV16bB5y4evdjefQ49yAEDmKgXFOzGt/mZuFpYQp6NacIclV4wrbVX5mZ3u4FrrgxLEFghOBrsYE/Wy0lIV4dqT2/gPs5UTjXWg4G56h7HPfzX2JR386f3eLeJ0n/xvbXa5bdg/vzCXAjdzghxmIFj1/gkE42XjcBGNACcdbFk6TKsYAEBmQ8FJS0LBrRwgpuYgfZvYpd3777LlwBepCASXCns4RRDLTjbWS5u36dvVnn+aWwgJS2HhYe+/47C76W2p6E+oxr7YJeLoqiG9j3VllA4C9ec6Q99HdfvrpSFgDLIdsW4bgWCM1PhotyVtYpbSr0cMhEiYyn97aHHPVWPNupvPScV7GQAASVUK2jAgolON39zt9n+IN/Vk7fACWhsOEiutZ+gIwg0E4wr5QqtIa/eW2ZaX2pbCf7Xnn0WKjhcYlr6+HBpWVF6cuI9pd+DNvns2qbHJcsBX3pbKf+uqP/33rsZ6mUYdwoZUqRfJtvl87PCHi7A8L362VtPtcDfcSv+35NlysZQBIwCA7PYU1NTEdftFnPWG9xTUbnf7P6QDKSTIGziyzaKegmWz7uBa+heh0aEik5VLdJPrHRfyYxfj2rawl9sG+XeYvQSb/e+I8bGLoT63rnQ3n0NlV/zDRZZc9LWip6C+CNFFKJgslf+2fl97rOZxuzk9BS+iUhAAYJr/f3v3AhxHdt/3/oy0K/nacQhXKcmNVXUJRC/urlbEHllSbAsB1i9ZsmJiOVxiUMkNwTwcO34s1pYUa8VdAitIu5IlEZQlPxMTSFzJDDmzAuO3HWsBQY/dlXQI2LGk3LoVgLeunXKiqktY8Usv3PoDZ4jBYB7dPf04ffr7qYK44oANoNHTffrX/3P+z4t5e748IfPliaUPlQkyaPfNcV3dpOEIopiLJxB0bN26Q4Ggr5V6cYR4cUrp2On73JFA0GW68S4JbKgSRJIkdPYBU4cBALlEKNh9CjHBYMbM9MtueXwzclFXN2QKIxCIvlqfiG9Nr6TXrfNgymvf1wfYh5EK9JOsdoz6fcRVDdlv+3sPh6QChwrB9C15uIxH85jydXyRN76EgjQYAQDkUqyhoDn9Hglx1pQfCAXd4Gu1oOCGBGHMJRcCxR3ihfg++lYJxhVgZVmpF+e04bglHRAP8m/3Xr8pzV6Ykpc+3XiXPIgIuCRM7rCWoAN09fPDh6vfc82X2VIAgIKJu1LQp4viOd14rGVhemTB82rBcV3dYO1KBK0SHPd/ymtKlXqRpBXChvk+HA6I+4afgY6dTWkEQyCY2bRhXyszqRJ0hy9joB0z/RJf7n8AAAUTZ/fhJrkoXlL+VAv6OijOE187EYs5Xd1YMZXR7ay/EThtLp0gLW5hqgRTqtTLMkjr24W339cu0pqIpWU575vpl9AZNrtzToRu3LmwaE6/i+PKDb7MyiEQROJGxhbkAbF8BLW6tX6Bae0A0g8Fzeknt/VTP73pyXQACaIIBTNmpl9+S//H/2vOo7C51TF7jIW5yKNA9NX6cPcqwSQr9bJcty5vlXphvo88f28B7Q78+5s30y+hGVO204ZjWr/UOTc9nn2QK7r6+UmPgmdCQaRBzs0XQ/4bQkEAmUwfVh4FaSd14zG5IUfGzPTLF+1g3kdMI0ZCi7A7HKTturwmYpyVemGrBIN8HzF/b4l/7VKYaZ3nCQSz4/m0YTFHlaAzfKkSZOowACDXkgoFfXpi5st6Jz7wuXJEphETQKPPjVNalXpxBmkqQnORsF87zPeRVviZdojXT0ohbN/OyqU+DUVe6nMglQc+Txu+aU6/i+PLAbr6eQmfzyk/+HTPAwAooERCQZlC7FEX4gGqdBAnM/3yJY+rBZvTiIHb9NX60MFSDGk1p8hy3bokvrewXzvI9xH09aBBWRJfO4OAOHBn5SP//vp+Q5GXbkT7HhEHz6cN+/5gMW98GlsTCgIAci2pSkHlUcBxTDce82WKgw98rtxkGjHajXbeJY5NBXamuYiDQVrgoCzL31+mAfG8mX7ppJl+KY0fMlSAacObVAk6xZdQkKnDAIDcSzIU9OnJmS+Dl9wz0y9f8agKtROmEaNDKJhWpZ7PU17j+j6ifG2Hp3LHHn4G/j52lCrdb6ZfSvWWG3yeNuz7A8Vc0dXPj3rSjFB5HqQDAAoisVDQnH7ylp0S5INTNBxxis83kcc8C9QxGKneyWbKayRxVgmmVQ0X5WsHDGF38zyVO9GAWB7sDJvpl9IV0QG68e5Jz6cNr5nTCxxr7vApoCUUBADkXpKVgsqzcINqQUeY6ZfL4H5Z+eukrt7wOfhEcEPpVeplOd1W5aMazrlKS0cC4nBVgvNm+mUTZvplTBd2gG682/dpw4Lxm1sNRnxZkuemmX4J66ACAHKPUDA4BpVu8T00u6irN7qsJ4cCCXkMOLxuXaxVgnFVw/X72gOEeJk3F3EuIJYmUfeZ6Zf5fu7OmyVboe6rZXN6QZrfwQ2THh1vPhU+AAAKLNFQ0E4h9qWi6zgNR9xhpl8hg/x55bcVXb3RYfooiqN0y4sgbTet7y3LSr1O04Ydnsod17HTN/zc+7eX97sLv4yqGofoxrtlGucp5a8dz6aq+sCnhwKLWX8DAADE4Q6VzpO0c8oPMrjkyaBbA7JZj546tztuf0aqVItrI9pNe5xBWpTtD/Jv06qGU55Nl05yPUYVMfwsSSgzY6ZfxnXTMbrx7lHPAppOFs3pBaapO0JXPzehVMmXZjabZvolVKACgENGxhZG7X1z+0wrGYeubK1f4Lyd0fRhqRaUX4LcGPhgnIYj7jDTr7hVgCqAc7p6g1Cw8FKa8ppEiBdq2nBYcVYJxvR9JFIlWHL42On6ujQaGyYQdI9uPNFcR9DXB2ripjm94HvomTc+jWV8X4cTAHJlZGxBCmlu2MZp420fl5RSWyNjC77nBu6Ggh5ePDmYHGKmXyHH1qby2yLrCxZWlydargRpcSt8kObOmoj9vnb35iLyEPABM/3ySZqJOEsGzieV3xirOURXPzfk0awhQfUzADhiZGxhyYaB/VwaGeOBYSeEguHN6MZjrPPmFt8H/1LNsaSrhuOueLad6TAb5WvH2lwk6PcR9PUEKvX6duF1eSp3LAGxrB04bKZfzg2zo3TjiRnPwplO1szpBY5Bt/g0TrvO1GEAcMPI2MJEyHHNxZGxheEEv6VcSiUUNKef3LCdB30JaKR7Ghxhpl+x6lFDm26kqoNFrQvGnC3LsZ1ikBZjiNe3uYiTU15z1Nik3+sJhrBHw8+bSpXuN9MvnzXTL2cNN0fpxhOjBbmO+DRN1Rc+/U4InAEg3w+dfHpQlatKQeXZQJR1atz8nfiydmU353TV+DSwRjCyNlsArq1bl8fvbYAQr28X3kG/dtqVlqUgaybKOXfeTL9CqgM7BNhwRUHWERSXzel3spC4Q3T1czJu8aXByI6ZfolPSyIBQN6NpvRvvJZG9+HWJ2uyyKMPjuvGxQlTnucmyBFm+sS2/o9fkOD5ovLboq6aDVPRUn2LYlg56EBcyse6dbtFqNRLurnIIFIJYSWsnjXTryCAyYcirCMoITUPbd3j08NMqgSBgy6vYQp+lrbWLxCoIwm+PHQqRqWgOf3kdvCKl1yg7NQxZvrEXAGajkiVxwrrCxZKgJuQvKxbl7M1ETOtZkzrewvxb3dbpwq/YpJAMB9044nZAqwjKGbM6Xcyfd0huvq5Udv50Rc+zXoCBjHUocNrrw/WcAMclub0YeHTE4JTunGRE5x7ZgvyRMSn9xJ6MGdPy03uciYdZhNvLjIIR6bb7hZmurRUYT1spk8M23VckZ91BH2ZpdHLmim/kyou9/g0Jrtppl/CLA0AcEuUgiAeIGYZCprTT654tu6bT4MdL5jpE0VoOiJO6aphmlRhlAb4Xbuybp0vlXpZNjZJ4nsL9LXn1a50FT5BlUz+1hEsSoDr0xRVL+jq54Y9q1Dl/AcA7okyzuEhYsaVgsqzCqcZ3bgog264F9b6FD53c5HGI8Vgzj6wfRB2O7xuXagqQVcam8TdXCSHayJ2f12OuRFTOTFnpk/wVDVHdOPJZiDoe2MRMW/KNBdxkG9BrU/3LwBQ1Ac2khEQCjoQCvr0pO2Yh4Oe3DOVvZvXolRxSuMROigVw5xSpQHC7oSrBPs2F3G1Uk85HOL1k1gI2wwDZ0zlBI1E8qkIjUXETVN+J1XzjtHVzw15Ng5bNtMv5cEIADhma/2CjFPPh/gnk1vrFzifZx0K2oYja8ofPg16vGEqJ5Y8O876NB75LBWrxagWbLn5Zcprpo1NOlYJ5mUqd9dtyznzPlO5izAwx3TjyaI0FhE8mHXTpGdVqlSVAICjbGdrCQZ7FU/cVErdv7V+oSjLqjhfKehbCf5x3bjIoNRNMwWZRiyNRzjBFYA5O7nYfc1MV5qLRNl+Hir1OjUXcXgqd7hKy2UbBk6Yyl0spJ9juvHkZEEai4jLpvxOrn1u8ql686aZfimhIAC4HwwO23Bw2T7olo/LSqkHttYvDBMIdneHyoZcXBc9eoo461nQ6QWZ9qarX5Dj7KLy30ld/eySqbyagNp/s0qVRntPDXRl3bp+r9PYJJn9Evj3J4OmOVO5iynCHtCNJ0cLNBbZ8Sx48oaufm7GPqz0RVHeUwCQa3ZasJyzOW/noVLQnH5SfmE+PXU7qRsXJ7L+JnCULJAfsVV5Hp3T1c8ynd1z5uyknD8nDh/XGa5bl2lzkbSCtE5VgnnsXlxqhiny1HTEVO6eMZW7CQT9aSyy4tHD1n5mTPmdrAnkJt8eTnJzCQDwWlbTh5WHT3h9+3l84tsAtZdLuvrZIv28hWTOnuoQDLq2bl0/qVXDRfi3rjQ2ifV7k7VUHpapFaZy9yxhoD904z3NTsM+VWf1ct2UH/fpwbI3dPVzcl0aV/64bqZfyoMTAIDXMgsFzeknfGs4Mk61oJtM5YSskTWvimNRVz9LR+LCBIN768FlE1bFWiUYVzVcv689wHTpwFWCQb6PmL+37l9brrPnTeUeCQMXTeVuqqv8U5ROw81KVx58uWvOw/cWAABey7JS0MeSfAaqjjKVu4o0jVimj63q6mcIBgsQDJqzPzhjK8B2kgvSVITmImG/dpjvI4PGJk40Fwn8tXdsWDxiKvdMmMo9vl1rYenGe5YK1GlYzJjy4wTbDtLVzw17ViUoDUZoZAMA8F5WjUb2mNNPLOmn3u5Tw5FzunFxzpTnmWrgJglPbqhikPfUkq5+ZsJUvo0bKM+Zsz+4qK/+mkynk/D7XLbr1nX6u6I2NlEDfu3Q35tUBS6ZyisJAQtAN94zU7BAMNK04ZGxheaaz93Wft5ufmytX8jt+G1kbEEeBMpU8uaf3X7ODbsYuyp6leBX//h/qK9/6c/V177050fOtc974Qt+feTnqsN5PCZGxhYkoB3ucSyIZuCZ1PEAeMteV5rn227vr1tb6xdktlohjYwtNPdP+7VXzqmreTy3Jny+Fr16VMh5eu94SqKLcml3t+N8qNTop94+d7Q7bNAbs1JCi8YPtP1lU56nYtBRuvp5e7z1+sXvDvB33V4b9N9H/nypjiQYLBB99deGlSrZcDCOAGrQacMxf+2BXo/4tWOpEgz7/wN+b/trBS4pVZIwkAFWsQLBK8leo8Jue9Bt9Pz3Ugk9HKRKcGRsYdIOrCciTKuWr7NqP1ZcvmmxNxKT9iNshd7N5s9ob85uxVAluNX/M4OPq7/2xVtq96+/0uHQOLqN579oSJVeeGff7cv2vvyFLfXlrf9XffVP/qcKcUzIflpK4kYsLiNjCzP2mJ+MUGyxY2829479NH/OltA+kCS+t5ZAPbPvIYiRsYUO98w9zW+tX5hLaL/Ia5dCbE5mL0R5YOlEaD3gdUXuxVbtOWTD8VCqn74Pz+y5SPbXqaSOzbav1yucde09PGqPIflz0Op6Oa427FhlxYdQsMNAItehoBihWtBduvr5DaV2TxYkFBRrpvJtdMcuGH3114fsRXlGqdJ4rCFe5LUEkwzxEvzau7GGeHF8b82b1EVTude5ASaSpRvvkfP504f/1vtQ8IFeVYL2pmbWzgiIc/aJDLoX7aDbhRvT5nl9NsZ1JG+fT6LesOrq5wJOYw8+rv7SR9YCB3ff8Jq71f/2mnu6bl+qAf/yuT9SX/6vA2e8EqbOuBIO2uNh1n7EPevquj0uEj32R8YWQt2Ibq1fiL2kf2RsYTXMzXkS34OjoWCo/ZKQ+zMMcJK4rtgHuXvn28yvKRGOq67HlA34lwI2PYszFOwwJnLnPTyyHyg3Q+WkGsI1r+NzUR9mZr2mYLPhiFx4fJK7KRQFM3l0/TWvjevqZ5hOWDDm7JtvmbNvXjJn3ywXoRG77mCAdTWTCgRdm247yIOjpKdLd3xdzlnLSpUeMJV7h0zl3hkCweLRjffK0+Widd693C0QlJu2kbGFJftw+aEEgpGTtiJzW26cbAiTiZGxBbk53bbfT5yNZY7ZQO+GhAD2RjgwXf2jYZensf/lp/9I7fz734gjEFT2hu5pOeayPBZabuS37c18EsswnWo59lmjGoUh7+0EryvH7Xs282tKnEbGFhZtMJdU6JXHY2huZGxBztEfsdfIJPdN8zq+FfX6lHko6Gl3L1lbMNSgCukxlbu2CxjcntPVTxMMFpQ5+wPb5uwPLJqzPzBqA8LzBw9jXFxTL8s1EQcNI8Pq+W9vKlW6rJR6wFReNWQqr5IgsGiBEA4HgqsercMctKqiW1WC/P1GSoHUseaNnEqZVEHYG4tLKfzux+1NxWKImwonx1NSHfhnV39X/dWn/yiJzcsxt5rFDb292VxNMAxsJ1/Di+ACCPHw5Vxa1xRbSZYXEx3ORxs2PMWBUfv7zSIkPRfluHIiFDSnn1i1Az+fODlIwj5TuXvRwwrVIMGgbwE8QjJn37Rtzr5pyZx9k1wsvkUCJ7vWS9s5OOkqwcSCtPhCvEirawwcMG7aqs77TOXksKm8atZUXkUQWHC68d7hAgaCYtKU5291uQlJKxRplerXs8FnFtUXD9nQazSPVYKyHuGf1X53788ESbVmqudmG0K6MKUT8EpL2J7Gw5dW8rU+4kL18QDnozgr1xHvcTWTq1DQ0xCNakH3zRRsGrF4SFc/TSMc7DFn33TLnH3jijn7xhlz9o1yc3fffiBVun7kvXEoEPS1Ui/u5iKB3LShrISz32IqJ0dN5eSiqZxkrUDs0Y33DtnwoWiB4Lwpzx96H9iQatv3mxB7g7oScv2wuJ20weBknsbuEgR+aeVptftl26QkWeM2uE0cN+BAYu8tua5sZBy2Z1Z9PIAV36/FHrgSNBh8nmMHlm8BjXODJRwwlbvlEXKeSrbjcoVgEJ2Ys9+/Yc5+/6I5+4ZJc/YNMjC5X27MbVXtTuqVepGkteZhmO/j0N/ZELAkU7hHTGV02FRGZ0xldMVURp1YdBrOBYJFfBK/Zsrzcx1u3LyvlmwJf3p1bsy82sDFKsGUA8Gmi2HXYYxoroDnASBRLdcVF9bCaz6IGc7JGoJULOcnGJzMTShoTj8hN0O+TW08pxtzzr+xi8xU7pYLgazZVTQEg+jLnH3Dqjn7hrm9kHDq++RG9T4bZi0fblqSQKVebK9H+D7irRJc2w9WS7YS8L5hU7lPQsAlUxlNfX0y5EeBA0F5ADFTxEDQcvF33qnawKkH37t//RX1v37r42kHgqnsC3v8s2YXEP/7yrXryt6yBC5XDNpuv5yP8qXv9PQ7lFuWMp4qkdRAgemaDjOVu2d19XMTDg7C0wgGlam8hgYkCMRMfZ9Mr5CP28eMrv2evHdG7cewUqVxd9cdTLSxyY7dN6tKlSTs2zAVzRRgRFLgQFDMmPL87cDcVk24duOWCNvx0tXfuTQf2dhav7DhYpWgdBn++pf+Iqsvf04aFGytX0iq2luaHwCIiQ1IXF2WY69i0I6rXcR9Y/4cs5nUbC5CQXP6iW391NuXXRtoxFAtOGfKc1SEuG2mKDcdbQgGMRAz9b3yvpGP23Tt9+WGUT4kMGz+92jv91eUgDCBgHG377+VCslb9meWPzeUKm2YyquZ+otY6MbPFDkQXDbl+fbmDa7euMXKVuLFNf6VZQpax51xTPM6ZitYRr/lRx9wqkrw63/2F+rL/zXzYfZMEjOebHhxboDjoPkwr9XQwYM8J6ZNAmlbifHYb44LVYzvqZMyRXdr/YJrDwSYMpycZnFB+7k6rrHgQ7IGbreHV06FgtaiZ6GgoFrQcaZy94aufk5OvFdU8VzR1eeUqbyWJz+IhZn6brk7224PC4WuPS03IkNKleyfe9WFzWUW+lQZJt7YxF6Q9/5OLsy3bNXf3oepvCbzu074reCBoNxYHboBsk0cTsa07RW7b7e31i+0VyI2H1yM2ocZqQYl9nsYJFDasT/f3s/YadBvv8aE3cdR9+nx533jCz/g2jg9bCB4x7f+LfW8b/4m9by/+U17//9rX7z1p1/Z+uO/GvD3PpHQMkiy3Shh4MzW+oUj1+AuoaMc97LmVBFnzaA7OVd0m3IY9iGGFP1Euc+IfcaFVPUOGG7dtO91Oddu9JhiO2n307EBQpyVIO9j5M6mHY/sPbTpdhy1TXUftcfTeBIPr5wLBc3pJzb0U4+seZZEUy2YA6Zy95KdRuzUYDclBINIhZm6v3nh6znI0bWPtdwIlfrcGIVa+68Z8jVtm6nXEfYhcwUPBPfWETTl+VttIdagVRJyIypPxru+x+1rhx5i2AH4zIA3dGEsDvB1pBmUVJT0rFa2P+eSXVuoGWCFPta+/hd/ff6rf/xFdceLX6Ty5M6RF6sXnhjZ+7ODipl+2eog+yXBxjCjEY75wFOZ7efdrvi377vmsU8VYYH1CirseyWMbRfCLRuCzw0QBsr1pG+4aX9WOac0p2zORjzHy9fKa3+C6/ZB1e3Qq+XhVBHH3debD+/CLjVh99/e8k0DXqfyEwpaPna0oVowH2btAKyIN2UEg3CGmfoH7YPHzAeTQFIKHgiKWVOe3+gwbjo2wFN4qZSKVGVi/92svaGTao+5pAISO8A/lebPaG9YR+3PF3ot77987vPqmx8YU3nw/BcNqW/6rteq57/oW7p9yqYEgm37ZSnKA2IJk6MeczGFghJaDLS2oQ2P5biYs1PanZoqDmT0ACZU2N5kP3/OnlNWIlzjj8v7MEgQ6Vj4Jftqu8fDqSI98FyUn7nXw8kwBrxOybT04U7fizPdh1uZ0+9esRc2n9CJOAdM5W45ec/YN7EqaDBIYxwASIluvK/ogeCyKc8dukmw1QTnBrghmYgjnJEbOrkZ21q/MGwr8pIYG8xFDAQH/hm31i/I15aO8qF89U++qKRa0HUvfNXL1N88+317wWAPi10eEEe5D0mioidMF9K+FaNhNI99Fyq8gEENcF1Z3lq/MBND2C4PgGQ2ZFh5Cebl+vjA1vqFybgCsBy7ZccMcv7sOVshKjkm7VgglgdNToaCOXsDhJHEWiOImancs1chUOAdSzAIACkgEDy6jqAV9Rq8bG9IYm/8YwO00QRuUscjBoKx/Iy2AiV0MPhXm/+3cplUB37j6+/r92k3zfTLlrpV90T4sll3C6XjPdDdTNRAMI6das8rkxGCnL1qQeV+ICjXpfZGYYW0tX5Bpkx3beoRo1nvQ0Fz+t1LHlZrndKNuSgLBiNlpnKPHH+XC7zjr+jqs65fgAAgtwgE98Z4k6Y812nQPBNjwBibBJ72z0bZZ3HfaNhgUCosA/vK1n9XX//SXygXveAVw+oFJ4YHfVifx5tbCRwAxHO+3YwrEOwQDO549N5uBoI8lEiZreIOGzIP5yoU9LiyzscKSC+Zyj2zEctyfQoGi7TuAwCkQtffJ09qtws8ZVjMmPLckZBtZGxhMuKaTwNN78pI2Bu9RKYhWaGXTvnKf/sT5eQagt/92iCfKj9r1zGOPZbCTvVL4sF/mKm7M7aRAoDBryuJFEe0rNsZximH39uR1+9FLFaKEgr6Vi04TrVgrkx4eAyGcU7XCAYBIOZAcDWlrraumjfluZUYg5XlvN2U2A7HYZqX3Nxav5DYw3IbgoXa/pf/239XrvnG7ww8g3fRTL+sX4jswlp6YULgY7bjaV67lQJJmXDpmmLP5Tc9qBa8zJThzMXyoNDpUNCcfnfoAUpOUH2VE6ZyjxyDRZ/yTTAIADEgENxz3ZQv9qqSmCjILIywP2ca4+HFsA1HXHLHt/4tdceL/3aYjpB5EDaYlOrjjZGxhSKvjQ14d751YM3STufRPF57fbPtfSho5eWiHcZx3ZhjvbZ8NR4JvQi3h8Hghq4962rpOgA4TdffJ9f9GwWvEJQlOfqNf8JOqb6e006Ho649ULbVgsth/o1LXYhfeGIk6KeuBKgSFJlXn9pjO+w0ZjnHXBoZW9geGVuYo3IQCHVdkarsNN77Yc/prhWpxNrtHNm6QzlOqgX1U48sR2wh7rI53ZhfMeWLvJlywFReuaSr/2XCw+Mw7AV1VdeenTBTr+O4BYBwgeCVgu8wqSqY6TXuGRlbiHLTk8eGECLMFM+1FG++VsOMdb72xVvqjhf/LeWCO0deHPRTg1a3uDLWke/36Qj/TqanX5SPkbGFTRtCrOQ0RAciiXBdSeWaIud0+74MGli6tgaxj4VbWR6jw/ZjqM9DQ7kuNUNrOZcPFSIUbLkY+hbGyIVaSvspu80JU3nljK7+l1EHT8ppkp99W9eemTBTfz/zJ+gA4Dpdf/+Sh2OYKCQQ7HfdiLIWmgvrvkUx7ujPGOprff2vv6JcmTpceuGdQT512Uy/bDtvHSZHxhbWQh4zncZvl2wF4aYNPpYICFEAYa8raZ9vA99XStWvI+9ZWXPRlYcmuTOyv6awPCyeiJgrnIr7e8rD9GGpFtwOO50hJ2Z1Y57pmPkyEWFhWN/sLWQtwWDW3wgAuErX3z9EIHjbw6Z8MUj1RehQ0JEbpKSl9hAu7P782hd3nOk6HFBeH8aH7g7dw0lbQbg1MrYg6w+ypBF8Fva6su3wud2VJkJ5rdDPzMjYwpBdzmHbLiXzkEuFRrkIBXN+Ee8XrlB6myOm8spbtvuTG6PgbI/dp3XtGQaSANAhEAw7DdNjy6Z8MamxTti11py5OQj5T9KtyHj+8z4f9FN3HakU9LVKsC2snUhg/Ck3pVdGxhZu2RtWihVQaCl3ss/l+SjHFfqZhYFq/3d90c4WdU5uQkGPqwXP6ca8a92E0IOpvFIuFnR123dF154h2AYAS9c/INf0DZeeAGdIpilyvTzK6XHf87/lm91YJDCE573gBd4XGNiwIolgsPmwV25YpTkJD3wBdLPJ1OFg7DThDXtudbrJXG5CQR8u5j0QquSw8YhMh8r6+3DEQ7r2zJKufYqnywAKTdc/MGGfoDv5JDhlstTGhCk/xrpDOSJN1UovuPNFKmcCTB/ObZVgh2BQphBeT+hLHLOVg7KOIeM6AO1yfx5Nw8j+w5UbeRkP5ioU9LhacFw35mVKKnLEVO5d9PR4jEKmyK3q2qdcWesCAFKl6x+YtR1CnX4anBKpZJokEMzlTZWvD6q9KSyQKp2t9Qty3/BAgutcj9uqQaerWtETa38jCTSaDBYIXlE5kqtQ0LeLekEGYV4zlXtn8rqmUQJkqtyGrn2KASSAQtH1DyzZzp7YJ4FgGjcOuXwQ5WpzFF39LzKmOfnVP/mi8owXVYLtttYvrGytX5D3wHk7VT+RxnIFCAZ9/fnGpVtt1t9E3qS8z6jG9czI/vnySgwPVtdsRfh828d1+1qs+cMdKmekWlA/9ciyh4t3H9eN+TlTvuhr6OmzybAt5T0mA8gbuvap82bq2+UmGQC8peuXhpTa5fx/2HlTfizqIuRhpxrnYlpODJrT0hOjq384pFRpMWzjkDtenIuZxl6PrbfWL8h4a2lkbEGOkxk7Lo2rYlm2syI3uj6uI2anSPtc3S1FJ0WfjRb2uJVQcNvRQNq796CHliL+u037b+VhT+DjzzYxkTULC1cp6PPFfVY35nmikzOmci8diY+6omufJBQE4C1dvySDeRm48UDowGVTfmyQc3/o6kIbhOTRpmOVTDK2PvbVP/axSvDl3lUJdrK1fmF1a/3CzNb6hSE7tXg5pqYkxz2+98rT+SNK9fWpkbGFvVC307nTdpz2tVIy6n5L85iYcLgzMqJNGw47JpQlIO7fWr8gD14WI8wkiKXaNJehoMdrC8qTKqYR55Cp3LudYEe4vDqna5/c0LVPUhoPwCu6fqm5gLTPFSZhLZvyY4N2Go4S3uS1CmbblZtUXf1DCQUekv/+8tZ/D/Vv73yx842KfQ2zgkwtbgaE90lgP+D6gw95OhU1T+ePqOH2KblejYwt7LZ+2DVwpcLI93H6hsPHhKzdGVRS64ciu+uNTAGWMHCQmQCjhQ0FPb/In9KN+Tw9tYJlKvdu5GxwkQZ5WrKta5/kmAbgxXRhXb+0lLcFpFOwZsqPSVA6EPuEPOzDtYG/bg5uVI/ZCoSk3H4g/ZX/Fi4UfP6LnM7FC1Ml2K+6aGv9wqxdf/CBAdaiynyMG2dHZLutzH+mkFViFB+E32+3QgZqJ9MIwCOc06kSdNjIfsVtmCVN5JicjGFZhjDBsn+hoMfVgoJqwZwylXtX7YLPOCB3DE/r2id9DfIBFGe68KqHaxrHMQ02zhvrsE/Mkw7MkhL250zkZ9TVP5xs3lR8+Qv/j9r98ldCBYKlF96pHMa4o3MF4YQNB8MGTC4EaHFOdZXKZqdT7Q5Wsv4Gcirs+XbQqvckzumJriuLgYUtgJkdNBCMc+yT21DQ84v9Sd14PI2TERJgKvdKFQnB4FEXde2TK0wnBpA3un6JhlLdA8EJU370VsY3vYtxVhClwU4X2gnZSXQy/uYiBw+i//K5L/jUZIQqwT7hYIRlb1xYey6WCi5bCZbHey1X1usOW4E7nLeHMElWC9pzedgKLwJhf0LBHXsOHhShoDCn3+VzteCcbjye9QkUEZnKq5Y8PjYHIeuabOjaJ5hODMB5ur44pOuLEpp8JIcVJUmTMGEm5kBQrBRoTeawP+tSzOHnXHO6kwSCX//SX4T6xy884XTzZ18LB+KejhrmfePCOTCu8eOSIz9PlIcJUad/FzkUXAkZgCd2TbHn8LDb3ozQgALpGkpzKrhtshbL1GEfKgWbF30f11fI6wAXlqm8StJ7gsGj5C7iaV37BAN2AM7S9cXmdOG9Bgw4ZMdWCMa+xpGdThPl2nluZGwh8cqfmEO5pQhjw5W4m4tIx+G/+vR/DfXvZeqww+sJXmYtwWQqqBKongobcE0O+h4cGVtYivNmOgN5rHDMtMrUXldWInRuTmJfy/EX9okKmQASPSZyHwraakFf3yindONxKqpyjGCwp4u69olVXftErqZ8AfCfri/O2JtlaZaElALBGKbIXUoqGJSn8iNjCxtx3tzaqh+Zgq1CTiOOYwrh3tj5a1/cUf/rN58L/Y+/4eRLlcPHpzcPHSWEc6zrb9bfiyTRkd/j9r1zzoMKz7wtUyRrv2Z9T7sY8ZoS2xRNe/zJrKmw5zSmDvtlKIbjKNbxae5DwZY3uY/VgmJJNx4nNMl/MOhCqb+L5Enttq59woXFqwEUnK5flunCK7a7sLNlUBmTKcMbDk+Rk5u4lbgq+mwYKAPwpxMKiRcjVkWuRv0ZdfUPJVQZl8YiX/rIJ0I1FxHP++ZvVC848X8oRy2a6ZfHPaU96xBuS47BhEKV0QjvzThF2d7FsEGNdAa1oX6uA8GmrfULWa9fHuU9NudAmBrlunJlZGxhoO9dztVyXYp4/C3G0KEWbjkZ9WGPPffFfh7zIhQ0p991y+NqweM5LRPHYZMRqgGKQm68P6JrH1/UtY8TgAPIhK5flhvujQhP8YvkvCnHsjh2EIPchMnvcFtu5KIEZ/YGThaaX7Vh4LmEb+7Xoj5UCxuOSHORr//Znz/+v37zWfXnv38jdCAovvH1r1KO2vH4fkCOwacl2JJq2DiqByUoyzqoGWBtrStB3t82DJT32A3fKr/tueN+pdTNDL52lN/beMQwN8774KhVfxftg5jQwbz9maOOLXw+pxXdUth/MDK2sGgfWsfuDuUP2UnypnN61eOILurG4yum/FiiT+aRHFM5eUtXN+VCwnS07mRto0ld+/iMmXp93E+iAaBrdaC9MWbtwP6BYGqdL6UiaWRs4fIAvxd54HRRHqzaCg25rqx2WqzdBizyIdfpWBfvDmjWhhZRfsZmFYv8blZ63axLx8s7j/+dD37l5p9+c9Rv9I5vfZG68+/9XeWoOc+qBDuRYOuSrYjdtL93Oa43IgQViyEropN4uD3IeK/5/pZttP/8zfezj/eF7ZWbw/b3ORPh3CWBYtT3zM0I+/dKM4zuVv1mg7dJ+3HcPjSJJRiT8//I2MK8PXbCGrfB/FrL+bbbzzBsv//ZAY/BGaoEc2Mj5PtvbymQrfULfYNq+55YTPLBhjehoFQL6qfeMZdUeuoAORCyXosBAyAYDNOE5OPzZur1WT+9BuA5Xf+g3JzEvjaLh1INBFvMtdwYRnXMVlntVfuNjC0o10igM8CNqrL756KtZtnpEJAMNY/xr9z808jfZ+kFd6pv+p5XKxftfv3rf2qmX160ippmQKhafu8SEknw3alTqRwHEwO8p2J/YCuBhw1Zxgd4f58asMJ7J+/LRdiqwWZ38tGWe0b576G2Y+KWPVY2BgycViNWUcuDnofs7735/Qy1nqeStLV+QSpMJwf4WuP2QwJOCcrb9+FwTGH09a311CrzMbiNiEuBTNixzqGQ2QbLExHD/uKGgsKcfteSDQZ9fCo0rhuPz5ryY0Ub8HiFYDCwi7r28UmldmfM1BgVsgBip+sfnBsghCmSrALBZmAwaW8+c33THvBGNY4qxWNJ3UB803e/em89QRd97X/+f5kcow5p/t6TvHlMah9n3Q14yZdKcRsq7FVFp/DlooaCTVn+zmdiuq4kFWJKFWZsDU6QipWIxWnH7b+TkDnqQ4pBHqz4s6ZgG5/fQHO68XjWXb8QQzBok3/WGOx/ob2ha+tUDAKItTpQ1z8oDxsIBB0OBJvstMiirK3s7PrDEgg6PG1Y/eUzf/jbWX8PnluLuI5c0Cq3rBpGXqez60AhSC4bfdpj2dUmh7JPJ5k2nC9b+4H8cgybOhbhHDbwQwDvQkFz+l2DdKxznRwkVAp6gGAwlIu6tr6ha+tMnwcQma5/cMhWB3q34HxCzpvyO5yovnKg02aaNxXOPTT8pu/WLncbRjqSfkCbxQPgTc+LSdI4Xy3mfD3G8w4GghNJBfBI3FzK+zi2ilLvQkHL58qiU7rxuKtPNhCCqYw6Ofh3lNzAP61r64u6tk6HYgCh6PoHm52FqQ7MWSDYRDCYDQJBKKUu2wAlMVvrFxZTHg9v2vDF98Y0SVvMa7VgWwdnF34GAsGc29pvZCYN0nJXUeplKGirBeMo33TVkm48TjDiAYLB0GTNF6oGAQSi6z87pOs/KzctT3u63nAhAsG2G7j77NPxIlQMZjaWlaYi3zz5eioEsby1fiGt6fuTKYUz7YEgVVkR2X2Y62IVG3hnXaQhsxyHqRD0pjhtM28BspehYMsvxIXUP6lpxE4O2BEewWDUDsUfW9G1j7HGJoCOdP1nZUrFti8LyBc9EGyyg+DRFJ/GZ3azvbV+QY7hB9Iez9458nfVsX/yfeqOF78ozS8LNysEZ1KusplI+Hi/3l4hSLWgl9Nwo1xXJjK6rsxvrV+gatUTW8kvA9IpEBy4WtDbUNCcXtjO8zoHATCN2CMEg5Gc2q8a/FhRFqAHEICu/+ywrv/squ3m5nXH2qIFgm2B2ayd9pXWOtIywH8g6WmU7bbWL8hi/sNp3KxKZ2GpDvwbb3qdKr3wzqS/HILZtkFWmm7aY302w3BmM4Eb6Ye31i/QwCHZ5R1yW5DTcl25L6XrilSCj0jn+RS+FrIJBq+nVFE6cMWgt6Ggtej5FJMl3Xgn04g9QTAYidzwX9K1j0k4SCMSoMB0/UNDuv4hGVxvKaXGs/5+ciY3gWArCeikwsKGg9cTvHG7f2v9wqgN6LK8WR2RqpK4b7zv+NYXqb/xxtdSHeggqZ6TIKvld5/ktLSb9mtkdqy3BYNxHevL9kba52IRV4LB0QTOxWk/iNloua7EvYTDTksYOGOrY+Ghrf3r9qQNy2/G9KAmsYrS0u7urvKZfmqv7F2qBVqUDv6z549fivhaHNsIvP3rpvxortdywGG6ujGk1O7q0e6YvQ7W3QB/F/Hfl1L+eoNtQy60c2ZqnIssUCC6/iG51ksgeHzwc0ks56L+n1Ny5vx53pQfyV0g2MnI2II8KJ20HxMRK0Vl8L1qP1ZcnVo4MrbQ+nMejxIEvuDv/e/qzr/3d/cqBFMaswZ+7ctf2FZf+7O/6PypX/36zl/d+EJ7wLMU9w32yNiCVGiGmT4rAV7i7yX7fU3Yj9EBu6nfbDnWMwsC+7ynZ+xHmJ9TwtMle1z0fQ+PjC0Ertaisqu/kbEFOS5n7TnqWITgbO+YdOEcHMN1Zcf+LE5eU0bGFprnkqDkYVyqQW3M5+lM3sMjYwsz9hiSmW5BXbfHzFKM+6Djdcr7UFDop/YO3HFPQ0H5nwdM+VHnLuSITldvyAVIBrznDv6WUDDgTbBcfBfN1Djl+IDndP1Do/Zc2XKNJxTsvh8O7aO9znWm/Igzg/uEbkxlsCx/KvvfrWvRNn92uUmT6qQN127YQty0jtqPoW8YfckPf/V/3Po78trz/uY33g797njRsb3///wXdbundScU7H4o733e/Wb6Fd4etwPc2Ku2m/u946HtGM/t8d5ynE90+Pk22n4uHg67dR5unoubv8Om1bb/3nb9d9fnutI8DnPz8yBdfc5jq1kFr0UJBSds50FfQ0EZ2A+b8qO5ubAjGF29sXQQDBIKHtb3xl+efs+aqXECc8DDqcJHH5w0EQp23w+399HeQtWm/AhdNz2jq38gD8QuOjxmHTQUXDPTr2C5EAAAYuL7moJ7zOmF1QTWBHAJ3Yg9ZSr3zXh+7CZJplN9RNfWVnVtjRsIwAO6/uEhXf+whB7bnQNBBEAg6Cld/YPRo4Ggd1LrhgsAQBEUIhS05vLcESmAU7rxTgZK/gaDstgyopFphU/r2uqSrq22ThsDkCO6/mE5F27Y0IOuwtHIOltUCHpIV/9Aqme9WBuyh8tm+hVMxQMAIEaFmD7cpJ/aW1TyoofTh5sk9Bw15UcZMHlIV02HpjlNNBrpvh+O7COpvJw1UxNMtwdyQNc/PGmnCh+PtxFH4RqN2EDw7Zz7PKSrfyDvkYdyNGYN/tr+oby/VM70CY5fAABiVKhQUOinZLHP0nFPQ0GxZsqPMlXS72Bw8WiVDKFg9/3QcR/tKLUr+3HRTN3PDQbgIF3/ObmWzSm129JEpIlQMOTfre03FSEQ9JGubk4oVWpZOzs3Y9Zgr+0fyufN9AnfKyEBAEhdEUPBwwMn/0JBMW/Kj9J51VO6amTNoNXDwSChYPf90G0fHXQqJhwEXAwDmx2Fk6jcK1Sl4LIpv53lRTylq5sybXjj0APvfI1Z+7+2q9bM9AkeeAMAkIDChYJCP/WodCM95XEoKO4z5UfpKuh3MCjHsb0JIBTsvh8C3XTbcHB30Ux9F5WDQAZ0/ecnlNptCQObCAWj7Y+9v7tsym+fjfHXBMfo6qYd0+Z6zNovFLzPTJ9gTAsAQAKKGgpKswEZXBzzOBTcVKo0YcoXCDg8patmyFYMniQUjK0aqKVykHAQSC8MbFYGRl4vL8bP96ZS8Lwpv53plh7T1c2WtYZzPWbt9dplUzlBsA0AQEKK1H34NnP6ndv2xt9nJ+1NFjxlKloC3wnbOAPxOGY7m27r2kfndO2jErwCSCgM1PWflwcbsqRHh3UDEZE83LifQNBvuro5XICxrBzLjGUBAEhQISsFm/RTj26o3b3wrAsvnro+YMoXZGoJPKarn+3QdTCmypOOh1iC05Vj30a31wL9e7khWbKVg3T1BmKg6z8v1U3yMZ7jc4OrlYI39xuK/DRTLT2nq5vyOz7p2Zi13QOmcoIxLAAACSp6KDihdvcqFLrwYoAlocaoKUvXZfhMVz/bMo1IEArGfOMvFZlzZuq7eS8BUc5R9V+Ysd2EezREIBQMcC7q9nebUj1uyj/NsiGe09XNDg8CvRiztlozFZqLAACQtEKHgkI3HpUqoHOdX/VmgLVmytJ1Gb7T1c/K71meqh8jFEysGmjNhoMy7RFAr3NS/ReHlNqV9cBmDzqme1FF7FqloDy0mCUQ9J+ubsp1/mmPx6xNI6ZygodwAAAkjFCw8aisGbZ9cLNyaPf02nVBd3ECr0XaxrwpX2BdlgLQ1c/KOkMrSu22TY1n+nD//RFqH920nVJXzNT3UJkDtJ6H6r84aoPAc54uLeBSKPiwKf9r39eWw34gWJwxa+UEY1YAAFJQ+FBQ6MajbdMub++eXrsu6C5O4LXI27jflC9Q3VQAuvpZqc6RKthTB39LKJjQjX/LuoPfQ1UDCk3Xf7HDeoGEggmFgnLumTHlf82aawWhq5ur3ZvyeDNmvWkqJ+ThJgAASAGhoKUbj3YYaHkzwGq9gRg25QtUNRWErn5mznbTJRRMpxpIphYvmqnv5SYdhaHrvzRsg8BZpXY7VDARCiYQCm7aQJCGIgWhqxtzSpXs9bwTb8as95vKCR5gAwCQEkJBSzcelZsaGVwf83CA1Yr1BQtGVz8zuV/J1ulmvYnuw933Q4B91LkDqFQPLpmp76V6EF7S9V+atGFgn4pkQsGYQ8HrNhDkAV9B6OqGXUfQuTFl3Nu/bConZNkBAACQEkLBFrrxaEtV1d7u6bXrgu7iBF4beBusL1gwuvqZUTuduG2dwSZCwe77IcA+6vk5e41JJByU/Q/kmq7/8rBtHCJhYICqwE5/x5qCA4SC86b8NtZaKxBd3WhZR9DJMWVc29+fzVI5QdgNAECKCAXb6MajGwfBSe4HWL1eu9+U38H0jALR1U/LjUXbOoNNhILd90OAfdTzc27bUWpXphUvmqnvY8ofckPXf1nOHVIVKGHgyWTfJzQa6bIf7PqBb2NpgoLR1Y2W5W2cHVPGsf0HTOUExzcAACkjFGyjG49Kx8Qbdvf02nVBd3ECr8WyfbnBGDXldzC1sWB09dNyY3/p8N8SCnbfDwH2Uc/P6TG9uLS7ZM6+gfcgnKSv/ZtJVdptmx4sCAVT7j4s6wdOmvLbOFcUzP46gnHMYHF+zHrdVO6SBw8AACBlhII9pxHneoAV5LVNU36HhKAoGF39tKxPtHIw/Y9QsPt+SCQU3Fe63TBAKjhXCAjhRBC4XxUoH8fsMdqGUDDFUHBZKjRN+W1MqSwYXd2Q9+BHcjSmjLp9O234Lo5xAAAyQCjYgW48KlOlNpQqHe+x64Lu4gRei3X7l035HSzqXNzpxBIMjhMKZhoKtiIgRPZBYCtCwaxCwR0bBrIWaQHp6kaH5ne5GFNG2f55U7mL4xwAgIwQCnahG49OKFV6useuC7qLE3gt9u2fN+V3MCArKF399JxSuy3Tk9puUjseRqwbllAo2Pq5zYBw1Zz9ftYgRGz0tX8rDwQmDoLAHp3JCQWb78de79W4Q8FNpXZl/UDe98VtLLLauTFYLsaUYT5vzVTuknMRAADICKFgD7rx2KJS6qEuuy7oLk7gtdi3LxUJE6b8Dm5ACkpXn2ubTiwIBTOoFOz2ubIG4Yo0KjFn30iDIISmr/3K8EEQuBt8jUBCwbRDQTtd+K1MpSwoXd2Qh0HncjymDPp5+2tbV+5irUwAADJEKNiDbjxmpxGr4zkZYA3y2k3beIQbkYLS1efauhMTCjoUCrb+ndxIrdoQd9WcfSM3VOhIX7syodTupA0DT0Y6bgkF0woFbXfht9J9tcB0daNDI7BcjimDfN7DpnKXPHwHAAAZIhTsQzcek5upp3MywBr0tTVTfgfTOApOV5+TmxKZUrxfNcj0YddCwU7TjFebH+bsmwj2C0pfuyKNoyZaPo4NfNwSCqYRCq7tTxd+KwF/genqhrx/b3g0puz1eUwbBgDAEYSCkacROzfAius1Go9AgsFRpXalavAkoaDzoWD7X6y1BIRMNfaYvrZkpwTvNkPADlXthILd90O3fZRSx+X9y/C8Kb9lrsfGUZx1BCUU7r6+Zz7HlJ0+j2nDAAA4hFAw8jRipwZYcW+fxiPYo6vPLqpSp3U1aTTicCjY/tqaPX+tKrW7as6+mUrCnNLXlkdbAsDRg2tSgl2zqRRUCe3jm6qkJk35LazlW3C6emNIqVKXxiJejCnbP49pwwAAOIRQMCDdeKxtWodTA6y4t0/jEdyma89KALF0OBQnFMxRKNj+/2X9ULkBlTBiw5x9M9WEDtLXlqUKUK47zSnB46lWsTURCiaxjy/LEg3mzFsI6CGh4JJSpS6NRY68IRN4LdXtXzeVu2SdUwAA4AhCwRB04zGZ4nPR7rqguziB11LZPo1HcJuuPdu5CUnkgCyJwCvs56ccrrgTCnayqdTuxkFQ+A8JClOkr/27tgBwd7T7NEJCwe77Ia59lNg+3m8mcuYtNBPBHl29YRuLZD7mS2P7O0qVhk3lLsJwAAAcQigYkm48JjfNJx0ZYCW9/U1TfofcnAJ7dO1ZecK/dLsJySGEgjkOBTu9JkGhrHHVDAu3zdkfZKrjAPS1Xx2ygZ982CCwUwCYZODV6e+oFExhH1+3gSCBCPbo6g25nn7EoTFf0tt/wFTuJhAHAMAxhIKRpxE7McBKY/vLpvzITMBPRmGqBndbqgabCAU9CwV7dTuWYGPV/mkDw1N0TrX0tV+V6b5DLeFfsxKwQzfgtCtkO/0doWCC+9hWB/4UYQhu09Ubo/YcesyxMV9S2182lbsZSwIA4CBCwQh047FZpUqXAu7iBF5LffsPm/Ij0oEZuE3XnrFVg82bGkLBgoSCvbYhyw5st3zcstOSlTn7gBdTkvW1/9AM+Wzot7c/JARUvdf9ayIULNDSArY68KeoDkRbY5FCNa/bX46mcjfvAwAAHEQoGJFuXFw9uAHsuYsTeC2T7T9gyo9Q6YBDdO2ZlrUGCQUJBQNVpUnlVHMacrPSsPma/PehG0dztpxImKiv1YaV2pVwr5WEfHJMq5ZKv+Z/n0wvqKVSMNt9NPDX21Fql+pAdKSrN+wyNE6P+eLc/v2mcrcXD4UAAPARoWBEunFRbiY3ui8Gf3sXJ/BaJtu3HYkfYU0xHKFrz0hzhAAdir268fep0UiKv5PEfqc7dp9mvD5f2G0QCia/j1P9ndjOwj9JVRS6dBpW53Iw5ovrtXlTuVua9AEAAEcRCg5ANy62LBLddRcn8Fpm25eb7mFTfoSbHRyha5+SaioZ/D/kTgDV6zVCwWx+JwmHdEeCVkLBgX4nJVePAefODTJFcsac+UkqotCRrt6Q6+PFHI35Bn1t01TuplkdAACOIxQckG5c7PLU9/YuVvG/lun2N23FIMEgOtK1T43aDsVt06O8uPGPsM0er1MpGP/vhFAwwj4lFBzwOJw3Z36Saih0patmRqnSlRyO+aK+tj+7pHI3s0sAAHDc87L+BjwwaysEikKCHglCgY7M1LdvmKlvl2Dw4dtTOgHAP2tKqRECQfSiq0auhz0CQS/NEggCAJAPVArGQDcuyoDvRpdd3Gv3R3zNie0vm/IjMwE3goLStU+2NCJpRaXgHioF21ApmMo+olIwwv44sn7ljDnzMM23ECQQlCnlx3I+5gvz2nVTuVuW1wEAADlApWAMTHl+w1ZFFck53XhCqiSBrszUd9wyU98hNwf3F6yiFoCfpJHIMIEg+tFV03wo1qchnVf21tbM+psAAADBUSkYI924KE+Dx9t2ca/dH/E1p7Z/3pTfznRiBKJrn5QgeU6p9g6xgjUFo+0Pug8fPi3RaCT8McOaggH22ZqtDtzu8CLQKRCUMeFJz8Z8/V67j2nDAADkC5WC8Zos4BpqV3TjiYmsvwnkg5n6jkWpspHp51l/LwAQsPLpAXPm4QkCQYQgD0t7NNvy0jyBIAAA+UOlYMx046IEZE+37OJeuz/ia3FsI9bte/JRQAAAKHVJREFU73eZK7+dLnMITNc+IWstLR5U11IpeBiVgt33Q499RKVghOOISsEO+0Oua4vmzCxdhRGKrhoJBM91ODn5Mubr9NqaqdzNA2IAAHKISsGYmfK8TBeZV8UiU0FXdeMJqQADAjFT37lhpr5TbiIeYL1BAA6RSuZhAkGEpatmsXMg6DUJ0GksAgBATlEpmPj6gs4+1U1i+5u2YvBWwI0Dt+nax6UiR9YcPJZOF9aUu7h2ep3uw/H/TqgUjLBPqRS0ZN3AWXPmIareEZquGmmwcaVAY76m+03lHhnzAgCAHKJSMDlFXF/wpK0YlAW2gVDM1OslFBwuYKUtgGzJA637zZmHJggEkUwg6K15AkEAAPKNSsHE1xcsPd1j9/v61HjTlN8u68UBkejax4dtl+Ie07CoFOy+H7rtozgqL5OspqRSMJV9RKVgaxOROXPmJ2QNOCASXTVta0kXZsy3Zir3sI4gAAA5RyiYMN2Yk+qni112v28DxFbLpvx2eXIORKZr6xIOyhpNp46+SijYfT9020eEgvEeQ64eh2E/v3DTh6WKf5YwEIPS1c+OKlVaPbzsRTdejfnkPTRsKvewXAwAADlHKJgC3Zhb6RxqeDVA7IRgELHQtXWpRpg76FTsahjDmoKD7SMqBVPZR8UNBfc6Cu93Ff4JwgzEEAiqVaVKAQJB78Z895nKPay9CQCABwgFU6Abc7LGngyejrftfp8GiN0QDCKhcJBQcB+VgodPSymHkE4eh2E/3/tQcEepXcJAJBAISoVgauMpV8Z8D5vKPfJ+AgAAHiAUTIluzMkA8kbb7vdlgNhvG5dN+aelqywQYzi421Y56EIYQ6XgYPuISsFU9lFxQsGWysAfpzIQsdDVz7Y96C1UKLhsKvewNAwAAB4hFEyRbsy1dafzYoAYdBvnTfmnWcwdsdK1j7VNKyYUdKxCi1Aw0v4gFBxwHxEGIslAUCoETx78bWFCQenSPcE6ggAA+IVQMGW6MSfB2DlPBohht0EwiCTDwVmldjus3dlEpSChYL9jIq7PzzqcLmyloHQTXpKpwlQGIp1AsDCh4I5SJQkEWUcQAADPEApmQDfmZFB1MucDxKjbIBhEYnRtbdhWDtrgvRWhIKFgv2Mirs8nFAz/3htoH0sYOGfO/BjV6Eg5ECxMKPiAqbxSmuYBAADPEApmQDfmJLjY6N2xzvkB4iDbIBhEGuGgrGMpU/bt+4xQkFCwHaFg9/2Qi0rBNakMJAxEknT1M0NKlboEgoUIBedN5ZXysA0AAHiIUDAjujE3oVTp6ZwOEOPYBsEgEqdra0MH4eBuW/dvGo1E2x8uBEI9XqP7cBFCwev7U4R/TIIaIOFAUCoES10CQSfGU0lu/7qpvHIy4D8GAAA5RCiYId2Yb2s8kosBYpzbIBhEanRtdcYGhPbmjlDwMELBbPYRawoG3B/SPESmL86ZMz+63WMHAzEHglkv9xLHNiJt3zYWeSWduwEA8BihYMZ0Y76l8YjzA8QktnHelP8160AhNbq2OmErBwOsOxhnBVSH10uDfr1+X5Puw+k37Yjjd0KjkRY3pSpwf5rwjxJOIINAMDfjqTi3v2MDQRqLAADgOUJBB+jGvG084vQAMcltEAwidbr2tKw72Kwe7LLuYCtCweT3EdOHU9lH+Zg+LOsFLpoz/4rmBsg4EMzVeCqu7dNYBACAgiAUdIBuzMsAVKZDHXN4gJj0NggGkRlde3rGVg+Od/8sQsHu+yGufUQoWPBQcEep3SUbBjJFGI4EgrkbTw26/YdN5ZVSnQsAAAqAUNARujE/ageixxwcIKa1DYJBZErXPtqha3EToWD3/RDXPiIULGgoaLsI/whLScDBQDCX46mo2182lVfK9Q8AABQEoaCzjUecGSCmvQ2CQThB1z5qqweVrR4kFOy+H5oIBcPvo8KuKShrltmqwB+hKhCZ0tVPDylV6hII5nY8FXb7m0qVaCwCAEDBEAo6Rjfm55RSFx0ZIGa1DYJBuFY9KFOLJSA8fvhVGo303h9h9xGVggUIBa/LFGFz5kdYKxAOBYJSIVjqEgjmejwVdPsS0g+byr008wEAoGAIBZ3tSFzq0Bm1MKGgIBiEc3Tt923nYjW5P72YUPAwQsHw+6gQlYKbtipwyZz5YUIHOBgISoWgt+Opftu3nYbvpdMwAAAFRCjobOORXtNYWnk9iD1vym9jjSk4Sdd+X6oHJRw8FSws6fB6x8Cl17YGDWjS/npJfQ89XjuyT9MO2MJuw9tQ8KZSSqoBF82Zf8n0YDgeCHo/nuq10QdM5V4qdwEAKChCQUfpxuMyWN04Ol2xnfeD2GVTfhuLXsNZuvaf5b0q4eCkUrstAWEnhIKEgl6HgjeV2pVwYcmc+ZdUHcFZuvppae62dPjhq/fjqU4eNpV76TQMAECBEQo6TDceb+tI3EkhBrEEg8gFXfu9oZbpxbZBSStCQUJB70LBm/Y6tWLO/BDVRshLINhhbFWI8VSrZVO5l4euAAAUHKGg43TjcVnD7Onun1GYQSzBIPIYENoKwuYUY0JBQkEvQsHm1OAlc+aHqAiEB4FgocZTYs1U7pXxJQAAKDhCwRzQjcflSe6Vzq8WahC7rJSaNeW3sVA9choQ7k4cNClhTcGjWFPQ4VBw0waBK+bMvyAIhGeBYKHGU5u2sQhjKQAAQCiYF7rxuKz58lCBB7GHB7MEg8gxXfvd/XCwtNeopMu6oTQa6b4feuwjGo1EOI667uPrqrRrpwb/C5qFILd09dM9Hq4WajwlnYaHCQQBAEATlYI5ohuPy6LY5wo4iG1HMAhv6Ku/M2yrByf6dzKm+3Df/UEoGOGYOdIxeNU8+M9ZHxAFCgQLMZ7asRWCVPoCAIDbCAVzRjcel8Fc0bvlNW9eJ035bQxu4RV99XcmWqYat7zXBaFg3/1BKNh/Hx38nYQEq7ZjsASBVAPCK7r63KxSpUvBPtv78dT9pnKvVP4CAADcRiiYM7rxuKxNtnoQFng/iO1l/6k3wSA8pa/+trzfJw4+dttCwrDTa+NYqy7B9etYUzDpfdQMAeUasmoe/Gc8VIG3dPU5O7si87GKA9sonTeVe2V/AAAAHEIomN9gUCo6jnk+iA2y8R2lSjOm/FamusF7+upvtYWE8nCAUPAQKgVb7TQDwP0Q8J8SAsJ7uvqcnCcXD5ZbcWKskuU25k3lVXMBvwAAACgYQsGc0o3HbRe9UpcuerkfxIbd/nlTfitPwVE4+upvtoaEcl5oOSdQKZh+J9+w24j1e5D1VjcOQsDzTAdGEQPBltkUzo1V0t7Gsqm8StZUBAAA6IhQMPfBYEkGv8c8G8RG3f68Kb+Vp+EoNH31N4cPAsJdCQnHD15l+rBHoeBNGwBuSDWgefA8a4Wh0HT1OTn3yayBk46PVdLaBoEgAADoi1Aw53TjnT266uVyEDvo9pdN+a08FQda6Ku/MWpDwpbAsP1hAmsKdt8PSe6jQP++WQG4bacDb5gHZ271+CJAoejqc3b2RKeHpE6OVZLexqapvEr2CQAAQE+Egl4Hg7kbxMa1/bX9zsRv5aYZ6EJf/XWZZjdqQ8JhGxi2VBUKGo2kHArebAn+ZOrvhnnwHOsAAj3o6rMzSpUWo82aCPp5uRpPyUOECVN5FWMgAADQF6GgJ3TjnbNKqUs5HsTGvf1NGwyyphYQgr76a82wUCoLm41Nhg6m5NF9eMBQcOeg6m8vANz7b/PgPyH8AyIFgvJQNLdjlbi3QSAIAABCIRT0iG68c+mg216uBrFJbV86E0+Y8lu42QZioK/+p2ZFYfuHDQ2DBGTedx+Wjr/Nc85q65/mwX/Mun9ATHT12ZYxT67HKnFtY8dWCDLmAQAAgREKeh0M5mIQm8b2z5vyW+hMDKRAX12RykJ1EBjuhWajNjiUEE3+/ngOQ8G1ltfkpttOzdub6iu2zYP/iMpkIGG69uyQ2t1rKDLu2Vhl8IegBIIAACAkQkGvg0HnB7Fpbn/elN9CZ2LAMfrqUxNtgVyz+rD175p6vRYkFFzt/9rtv9s2D04T8gEO0bVn5QHDktoN02E4V2OVKNuwFYInqRAEAAChEQp6SjfeuapUqa1pgFOD2PS3v6uWlVKz5sxbWHwbAIAc0bVn5QGCVAgeO/o8wKOxSrhtEAgCAICBPG+wfw6HTdoFp3FAplWv6vr7WiqNAACAy3Rtr6HI0907DBfWLBWCAABgEISCnjLlR6UaTp6qEwweJlOONnT9fTIFCQAAOEzX9hqKXMn6+3DQeVM5yXrJAABgIEwf9pxuLAzZtbJCrL/j6ZSco8uPnTdnaEACAIBrdO2ZIaVKHcYvna7nHo1Vgm2DQBAAAMSCSkHPmfIFKga7u6Lr7+MpOwAADtG1Z6Saf6NjIAgCQQAAEBsqBQtbMUilYItNpUoT5sxP0YAEAIAM6dozsn7g4v76gV3GKsWtFCQQBAAAsaJSsCCoGOxJgtJtXX8/6wwCAJARXXtm0a4fSEORowgEAQBA7KgULGzFYCnglByv1xTs9HkPmzM/JTclAAAgtfUDQ6x/XLxKwfOmMspyJwAAIHaEggWkGwvDSpU2gj2JL1woKJaVUrNMJwYAIFm69syEUmql85iEUJBAEAAAJInpwwVkyhe2lVIyCN/J+ntx1DmpWGA6MQAAydG1T80qpZ5munBXVAgCAIBEUSlYYLrxrlE7XadHxWAhKwWbdmzFIFN2AACIia59SqYLy7X1VKRxQDGmDxMIAgCAxFEpWGCm/A6ZQjy8330XHUhYekXXP8AagwAAxEDXPiUPJGX8cYod2hWBIAAASAWVgpCKwS4LfO8dIr0On6CHWQKvpVIp2PqaBKeT5sxPytRrAAAQbbrwpZDX36JVChIIAgCA1BAKok8w6NFAe7BQsDmdeMac+UlZEB0AAISeLhzp+luUUJBAEAAApIpQEH2CQW8G2nGEgm3diX/yVrDvDwCAYtK1T44qVZKHacc7fwahoN0HBIIAACB1rCmI20z5HbdsV2LWGAzUnfgDsi4SAADoQNc+OaeUutE9EIRFIAgAADJBpSD6VAxSKdhjH+woVZozZx6mEQkAAM1xRO2TMo6Q6sBxO9zsNRQt+vTh86Zyn0ytBgAASB2hIPoEg6WTPQ6foIdZAq9lOn24/bXr+2sNPsx0YgBAoenaJyft+oHHDv6WULDDPpB1imcJBAEAQJYIBdEnGCx1WRh87/AJepgl8JpToWBzcD9pzjwsFZYAABSxOlCmCz909FVCwbZ9IGOGCVO5byPFXxEAAMARhILoSzfevWTX0Ws/fALuvUKEgk2X5aaIqkEAQLGaiexVB3aZXUAo2PYQkUAQAAA4gUYj6MuUH5mxHXfRn1RIrOr6JZqQAACK1Eykx3IjsAgEAQCAU6gUxAAVg1QK9tkH8+bMw3KzBACAV3TtE8NKlVaChYFUCipV2txbf5gpwwAAwCGEgghFN94tVYNX7OET9DBL4DVnpw+327RrDW73+0QAAPJA1z4xu79+YKmlmUgvhQ8FN5UqyZRhGpIBAACnEApigGCQUDDgPthRqjRnzswucrgBAPJdHbi3duD4/t9kNA7YzfABY7SHgxOmogkEAQCAcwgFEYluvHvSdiYOUCVQ6ErB1s9b25s6dGaWqkEAQE6rA1uv+4SCffaBrMc8SyAIAABcRSiIyHTjCWmmsdo/GCQUbOs6SNUgACCn1YGtCAV77INlU9EyswIAAMBZhIKIIxiUhcaP9zjMVPyv5bJSsBVVgwAAp+nax2dl+YvuD/8IBbvsg3lT0TQaAwAAziMUxMB044khWzHYpQMhoWCXfSBVg4vmzCw3DgAAZ+jax1uqAx1cr8/tNQXPm4qWfQcAAOA8QkHEGQyuhJ9eVNhKwdbXZBHyGXPmoY2AGwMAIBG69nF5UDV7UB3oVODmcigoD/pmTEXLWAgAACAXCAURK914Qp6On2s7zHodghFf8yoUbP7H/H7l4EN0KAQApErXPi7LgSwdrfp3InBzPRTcsR2GebgHAAByhVAQsdONJ6TK4GLLYdbrEIz4mpehoLhpqwZlOjYAAInStfUhu27gQ50/I/PAzfVQUKr9J01Fbwf8QgAAAM4gFEQidOMJ6bh3xR5mvQ7BiK95Gwo2XbfhIFWDAIBE6Nr6pFSoK1VKoFlYIULBTaVKUiHItRoAAOQSoSCS7ky8qlTpWI9DsMcWCh0Kih2p3jBnfmIx4BcBAKAvXVuXRiJybTnV5zpEKNh9HyybyqvlASgAAEBuEQoihWCw1GGNotuHYI9/XfhQsLkP1mTRd3PmJ1irCAAw2HW5tt7WSGSQa3FhKwXnTeXVsh8BAAByjVAQidONJ6Uz8WrnYJBQMMQ+uKyUkspBpikBAMJdi2vrE7aRSIepwoSCIToMz5rKq2U/AgAA5B6hIFKjG0/G2Jm4ENOHO722f0Ny5ie4IQEARJgqnOg1yudKQdth+NVU7QMAAG8QCiJVuvGkTFm61HII9vhsQsEe+2DNVg3SpRgAEGKqcNjrLaGg7TAsgSCV+gAAwCuEgkidbjwp3Q6l0u0YoeDe23CQYHTZVg5yowIA2L/O1j5mpwr36ioc9FpT+FBwWamSTBnmOgsAALxDKIhM6MaT0pl4pfcNC5WCAfeBdCleNGd+nEXPAaDAdO1jw/ah23im03v9mT48byrfxrUVAAB4i1AQGTcgKa0c3Ly0IxQMuQ9u7lcN/rjsUwBAQejax6Shl4RXDx1+hVAw4j6Q9QNnTOXbuJ4CAACvEQoic7rxnsWjNzKCUDDiPrDrDf446w0CgOd07WM91g0kFIywD+QB26SpfBsNRQAAgPcIBeEE3XjPjFLqyuG/JRQccB8s23BwO4ZfEQDAIbq2JtfNuVSX4fB/+vCaDQRZPxAAABQCoSCcoRvvkXUGVw+qHQgFY9oH80qpRXPmx7jJAYCc07U1aSIyF2zdQELBEPvgsql8m1RcAgAAFAahIJyiG++RdZHsOoOEgjHugx0bDLJgOgDkkK6ttTURaSIUHHAfyPVx1lReI/sWAACgUAgF4fA6g6UO6wx2EvBmYDeGbYR6zcnty1pJc+bMj3HzAwD5CQPlgc65Alyj0p4+vLnfUOQ1rB8IAAAKiVAQztKN98p6SYudF09vRSgY4YaIcBAAHKZra1I5L9NZL/b+TAdDu3yEgtdtIMjSGgAAoLAIBeE03XivrDMoVW0nu38WoeAAN222U/GP0akYAByga6tDSpVmu3cUzkFo534o+LCpvEYeOgIAABQaoSCcpxvvlWqJxYGnTjF9uJc1pUpz5syPEg4CQGZh4F4QOKtUKUAY6HBo524oKOsHTprKa7jWAQAAEAoiT3TjvXKzdOnoK4SCMd602cpBwkEASD8MbFYGBj1v9/tcQsGWfbBmA0GmCwMAAFhUCiKP04mlO/Hxg78lFEzgppBwEAASpGtP95gmTCgYc6XgvKm8Rpq1AAAAoAWhIPI6nVjWGTy1/zeEgglWihAOAkDsYWC/acKEgjGFgjtKlaSZiDxMBAAAQBtCQXgwnZhQMIXpYzYc/FeswwQAA4eB/aYJEwrGEArKdWvGVF67zQELAADQGaEgPJhOXGqbTtyKRiMxrym1KU1fzJl/JZWaAIB+16na08MSToWbJkwoOGAoOG8qr2W6MAAAQB+Egsg93fiZHt2JCQUTWmj+pq0cJBwEgE7XptpHJQycU6p0Lvx5l1AwYihouwu/lqp2AACAAAgF4Q3d+JkZGw62VGIQCibcffKmUiUJBhfNmR+hoyOAwtO1j07YysBz0c+thIIRQsHrdrow1yIAAICACAXhFd34GanMkOnEJ/f/hlAw4VCw+ZpUZzTDQdZvAlA4uvbRSTtFePzwK4SCA15fgoSCD5vKa+WhIAAAAEIgFISXdONn5ObgIULB1ELBVss2HNwI+IUBIJd07aOyfIWEgXOB1rYN/BqVggFDQVnndsZUXsf1BgAAIAJCQXhLN35mwk5tPd65siDBKobcbD+ObXR9TTo/LpkzP8K6gwB8XC+wS/OQdoSCCVUKXt5b27byOqYLAwAAREQoCK/pxvukikNCqVOEgpkFl9KUZFECWnPmh7l5A5Bbuvb7dr3AXs1D2hEKxnx92VG70kzkdTQTAQAAGBChIApBN943qXb3wsFj+arky3WlYPvn7dj1HhfNmR9mqheA3NC1329WBR5dr7YvQsEYry/7zUSmqA4EAACIA6EgCkPX3yfTvZaOLgLvcmjnVSjYYWrxDzO1GICTdO0/DytVkiBw5ugDJULBlK8v8lBp1ky9jmsGAABAjAgFUTi6/r5Zuyj8MfdDO29DwdYbPTu1+F/StRhA5nTtP0/aIPBUdo1AaDTSsh/WbHUg1wgAAICYEQqikHT9faO2ajDAVLDcBm4pbSO27cu0MAkHZYoxAKRcFbgXBM4c7iJMKJjh9WVHqdKcmXrdYsAvAgAAgJAIBVFouv4+qRi86EAgltH249hG7Nu/ebD2INWDAJKja783qVTJVgX2PTcF+Puwn0ulYJd9YKsD/z7VgQAAAAkiFETh7VcNllqqBo+8TXq9hYK+1RJ4zZVtJLr9Nfu7WTFnfojOxQAGpmu/J1WBLWsFuhjaFXb6sCwpMWem/j7VgQAAACkgFAQsXX+/rRo88jbp9RYK+lZL4DVXtpHK9pudi5fMmR9aDfgFAWCPrv3ekFJq8nAH4UHOTYSC4fZDoH1MdSAAAEDKCAWBFrr+fllrcPFwh+LMA7EEtx/HNlLfvkwvXrIBIVPLAPSZHtxsGhLnuYlQMNx+6LmPqQ4EAADICKEg0IGuv7+lQ7FTgZiD28h0+5stASHTiwEoXftdebgzq1Rp8nCX+TjPP4SC4fZDzyUiWDsQAAAgI4SCQBe6/n5Zd2pJqdJ4j7dQ0LdaAq+5sg1ntn/dTjFeMWf+BQEhULwgUCoCJw+6Byd5biIUHHAfS3XgrJn6dnmoAwAAgIwQCgJ96PoHZuyU4mMOB2IZbsPJ7RMQAp7TV39nWO3uVQPOHgSBrQgFHT4/z5ipb+fhDQAAQMYIBYEAdP0Dskj90tF1qZy84Up5G85v/7raLe1XED74z7kJBfIeBO5XA8rDmpNqN6tzE5WCEfbxTVsdKOdjAAAAOIBQEAhB1z8wYcPBFKanpbH9OLaRg+0fBAcHFYQEhEAu6Ku/02FqsEUomJfz82VZp5fqQAAAALcQCgLRqgZlutpFh264MtxGDrbfOTiQgHDVBoR0MQYcoq/+zoQNAY8Gga0IBV0/P6/tVwd+x0bAbwQAAAApIhQEItL1DwwrVZKqwfEAb7UEXnNlGznYfs/g4HYX4xWlSivmwX/GzSuQMn31t4dsADgRvGswoaDD52dpJDJnpr5D1uMFAACAowgFgQHp+qUejUhuv9VU/K+5sg0vQsH2da/2KgjlT/PgP2MdQiAB+upvN9cHnDz8cCXEen1UCrp4fl621YGcOwEAABxHKAjEQNcvSZXLnFLqoS5vtV5vw4ivubIN70LBTtPfpIpw1Tz4T6kiBCLSV39LzpMTLRWBXaYFEwom38gkrm2U2iuuJQyUhyoAAADIAUJBIEa6fmnUVg2O5yNwi2Mb3oeCnaoI7VqE/5RKGKAHffW3Rg9CwKDnRULBnIWCTBUGAADIKUJBILkpxXPBuhQTCuYoFGwnlTGrUkW4P9X4PCEhCk1f/c1RGwDaj1KEZRUIBXMUCjJVGAAAIMcIBYFkpxQH6FJMKJjjULD9NRsS7n8QEqIgIWBrEHh88PcUoWAOQkFZVmHOTH0nU4UBAAByjFAQSJiuX5IuxTKl+FSXt2GPf8304ZyFgu0ICeEVffU3RpUqtVQC9usSTCiY+D5I9xpy04aBSwE3DAAAAIcRCgIp0fVFuYGWcPBk29uwx78iFMx5KNj+ea1rEm6YB2doXAJn6au/MdRWBTieTmBFpaCDoeCOvX4tmqnvZJkEAAAATxAKAinT9cUZe3NlK2wIBT2aPhx2+3KjvWHXJZQ/N8yD57YDbgyIlb76680A0E4JLrU9wGgiFHRqHyR/DVm21YGcmwAAADxDKAhkQNcXm+sNzkZbiD/M5zkbiKW3fXdDwU6vSTXhXkB4UFF4jsocJBEAtn6M5zIQ6/neTvJ979A+SO7cZNcNfD3rBgIAAHiKUBDIkK4vynqD0qX4XOfPIBQsYCjYSUtFofxZ2jYP/hOmHqMvffXXmlOAm9V/w50DwJwGYoSCSZyb5MHErJl6/UrwXwQAAADyiFAQcICuX5Yb9sWjN+uEgoSCnZRaK3m27YdMQd42D/6fTPErKH31P8nU32Eb/Nn/DtMNuB2hYMFCwR1bGSjXIgAAABQAoSDgEF2/LDfyc+EX9M/59F6mD8cd1rSGhVJRKGEhlYUe0Fevt1T+lYY6h39xvF9zEohRKRjH73tHqZJtIvJ6lioAAAAoEEJBwEG6flmakcwpVWqr8vE0tCMUTCGsKTWnBTaDwlvNP82D/5g1wxyir16XkG/Yhn9DLX8GrCQmFOy/HwbdXw4Fo4P9vqWJyKyZGiMMBAAAKCBCQcBhuv5BGw62TwH0LLQjFEwrFOxnzX7eodBwv9LwHzEtOSb66opU96mWsK8ZAg4HfxAgCAWpFOx1HPR8zXYUHuN9DQAAUGCEgoDjdP2DLZ2K1TEvQztCQVdCwSDbkKnJqmV6srLNT5qVRtvmwenCBQ366lPNoK8l7NvbX82/b5nim2UlH9OHC14peN1WBhbuPQoAAICjCAUBL8LBnId2hIIOhUGx/p6aXZObtqUZStvnNKsR27exbR6cSjy40FfrrWFei1Kziq/VRMv3KK+dzF9oRyhY0FBwzVYGslQAAAAAbiMUBLwIB50Lg9zafs9mBHF8H2k2hOn1uTn/PcWxD2JpPNHrc135Pbm6/Ti+lxDbp9FIv31MGAgAAICuCAUBL8LBUpdpxT6EQYSCwfdJzn9PhIKEgmGPA0LBbvvLhoH/gMpAAAAAdEUoCHgRDpZ6rDmY9zCIUDD4Psn574lQkFAw7HFAKNi+vwgDAQAAEBihIOAJXf/ZLmsO5j0MIhQMvk9y/nsiFCQUDHscEAo29xdhIAAAAEIjFAS8DwfzHgYRCgbfJzn/PREKEgqGPQ4IBa8rVVpkmjAAAACiIBQE/A4HJ5UqzSmljuc3DCIUDL5Pcv57IhQkFAx7HBQ3FFzeXzNwPPEO3QAAAPAXoSBQALr+oRm5gewdDroaBhEKBt8nOf89EQoSCoY9DooXChIGAgAAIDaEgkCB6PqHJu204vH8hEGEgsH3Sc5/T4SChIJhj4NihII7SqlF+TBT47dCfGEAAACgJ0JBoIB0/UMTNhw85X4YRCgYfJ/k/PdEKEgoGPY48DsUvGnDwCXCQAAAACSBUBAoMF3/0LCdVnzO3TCIUDD4Psn574lQkFAw7HHgZyi4ud88ZHwpxBcBAAAAQiMUBCDh4JBSJakcnOm87mDOw6aewYFHgVjef0+Egh5sP47vpbCh4PX9KcITqyE2DgAAAERGKAjgEF3/sASDEhCebDlV9DqNBD3dJPBawM8jFMzH74lQkFCweKGgrBe4ZMNAOgkDAAAgVYSCADrS9Q/LuoMzg00tDvp5hILuVIgRCkbfx0E/Nw8Vo1G3H8f3UohQ0K4XWFoyUxM0DwEAAEAmCAUB9KTrHx5WqtSsHjzW4TQS9HSTwGsBP49KwXz8nqgUJBT0PxS0U4TvZ4owAAAAMkcoCCAwXf85CQflY7zlNBL0dJPAawE/j1AwH78nQkFCQT9DwZYpwvczRRgAAADOIBQEEJqu/9yorRycVKp0LODpJoHXAn4eoSChYKhjqdfn5n16ryv7oBCh4JqEgWbqu+giDAAAACcRCgKITNd/TroWTx5tTNLxdJPAawE/j1CQUDDUsdTrc/Me2rmyD7wNBaUqcGW/KvC7NgJ+AwAAAEAmCAUBxELXf76lejDs2oOEgu6EQUwfjr6Pg34uoaCHoeBeVaAEgmbqu2gcAgAAgFwgFAQQO13/+ZBrDxIKuhM2EQpG38dBP5dQ0JNQsGWtwO9irUAAAADkDqEggMTo+s8P23BwRqnS8R6noh5bYfpw8H1CKBhPSBR1H8exjbxvvxCh4HWlSrJWoEwTBgAAAHKLUBBAKnT9F2Ra8WTn6cWEgu6EQVQKRt/HQT+XUDCHoeCmrQpcMlPfzfRgAAAAeIFQEECqdP0XhlrCwVP2VNTjX1ApGHyfEApSKZj1ceZVKHhTqdKKDQJpGgIAAADvEAoCyIyu/4JML55UqjTTvXsxoWDwfUIoSCiY9XGW+1Cw2T14xUx9D9ODAQAA4DVCQQBO0PVfHG7pXtyy/iCh4FGEgl33AWsKEgpGO3dc368IJAgEAABAcRAKAnCOrv/iqG1QMtm7QUnAAKBnUBRwG5lW4QX9XCoFCQWzPs5yVSkoQeCKTBE2U9/DOoEAAAAoHEJBAE7T9V9qCQhbKwjbEQoSClIp2Pe9QCh4/WB68PcSBAIAAKDQCAUBeBIQEgoSChIK9n0vFDMUJAgEAAAAOiAUBJDngLDZxfgkoaBg+jDTh+M6DnIdCu4cTAv+XpqFAAAAAF0QCgLIPV3/pWGlShIOTiilTh35BNYUTGHdQ0fWVaTRSFFDwZt2WvCqmfo+gkAAAAAgAEJBAF7R9V8estWDE/bPY4SCglDQnUAsDw1nom4/ju8l8PY31W5pyQaBGyG+KQAAAACEggB8p+u/PKp2SzM2JDzpdZUc04epFMz8OIvjmOz6b+y0YLW61yjk7BtoFAIAAAAMgEpBAIWhr/2bYRsOHlQRHkIomPt9wPRh30LBzdvdgs++gWpAAAAAIEaEggAKS1/7N81mJRISjuc+EKNSkFAw8+Ns4GPyplKlvUrAvWnBVAMCAAAAiSEUBABLX/u3zYCww1RjQsFc7AMqBfMWCsqU4JYQ8Pu3Q2wcAAAAwAAIBQGgA33t3w61BIQTSpVOOh+IUSlIKJj5cdb3c5sh4KpUBJqz38+UYAAAACAjhIIAEIC+9ittIWFrJSGhoDP7gEpB10LBlhBQKgHfSAgIAAAAOIJQEAAi0td+pVlFKH+OHm1ccuSUG/G1oJ+b5fReQsHg+yQPx0HU7e81Btk4CAHfxHRgAAAAwFGEggAQE33tigSD8tEMCRNYl7DX5xIKUimY6nG20xoAyn+bs2+6FeILAAAAAMgQoSAAJERfuzJ0OCQsyX8f73I6DrFlQkGmDyd9HHT83LX9ELC0YQNApgIDAAAAOUYoCAAp0teW2oLCvY/jhIJ7l6QQe5I1BRMOBdea4d9+APgDBIAAAACAZwgFAcCJoHCvirD5MayUGu/+L6gUJBSM7Ti4qZTabk7/lf82Z99MAAgAAAAUAKEgADhKX1tuBoStYeFJQkFBpWDI48Cu/7dX/bd9UAH4ZtYABAAAAAqKUBAAckZf+3etYeHwQWUhjUZoNCKVf6Vm5d+tg/DvHxL+AQAAADiEUBAAPKGv/fuhtqBQ/tv+XelYsK1EDRaDrlWXcGfc3Sw7PMexjUDb39wP/Paq/m41A0Bz9geZ9gsAAAAgMEJBACgIfe1XpbmJaP7ZEhoqGxoSCjoQCm62VPkd+tOcPUXFHwAAAIBYEAoCAPboa786rFRJKgxbg8Nm1aFcMiI0Pwnzed5XCjYr/JSt7hPb9kOZs5PNvwMAAACAxBEKAgBC09f+QzM0FBMtAVhLiLinpQpx77LT65KUp1CwWc3X1Bro2aBv73O3zdkH9kI/AAAAAHAJoSAAIDX6WrU5Xblda5ViNy3/NnQo2FyDrx8b7h3azi1ztsx6fQAAAACUT/5/fC6MBEVWfLIAAAAASUVORK5CYII=";

// src/lib/email.ts
var anexoLogo = {
  filename: "logo.png",
  content: Buffer.from(LOGO_PNG_BASE64, "base64"),
  cid: LOGO_CID,
  contentType: "image/png"
};
var transporter = null;
function getTransporter() {
  if (!transporter) {
    const port = config.SMTP_PORT ?? 587;
    transporter = nodemailer.createTransport({
      host: config.SMTP_HOST,
      port,
      secure: port === 465,
      // 465 = SSL direto; 587 = STARTTLS (negociado)
      auth: { user: config.SMTP_USER, pass: config.SMTP_PASS }
    });
  }
  return transporter;
}
async function enviarEmail(msg) {
  if (!isEmailReal) {
    console.info(`[email:dev] para=${msg.para} \xB7 assunto="${msg.assunto}" (n\xE3o enviado \u2014 modo dev)`);
    return { enviado: false, erro: "SMTP n\xE3o configurado (modo dev) \u2014 e-mail n\xE3o enviado." };
  }
  try {
    await getTransporter().sendMail({
      from: config.SMTP_FROM ?? config.SMTP_USER,
      to: msg.para,
      subject: msg.assunto,
      text: msg.texto,
      html: msg.html,
      attachments: [anexoLogo]
    });
    return { enviado: true };
  } catch (err) {
    console.error(`[email] falha ao enviar para ${msg.para}:`, err);
    return { enviado: false, erro: err instanceof Error ? err.message : String(err) };
  }
}

// src/modules/emails/emails.service.ts
import { TRPCError } from "@trpc/server";

// src/modules/emails/emails.registry.ts
var EMAIL_TEMPLATES = {
  // ───────── Transacionais (e-mail; sempre enviados) ─────────
  convite: {
    label: "Convite de acesso",
    descricao: "Enviado quando um usu\xE1rio \xE9 convidado. A pessoa define a senha pelo link.",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome da pessoa", descricao: "Nome de quem recebe", exemplo: "Maria Silva" },
      { chave: "link", rotulo: "Link do bot\xE3o", descricao: "Link para definir a senha", exemplo: "(link seguro)" }
    ],
    temCta: true,
    default: {
      assunto: "Seu acesso ao Workspace MedConsultoria",
      titulo: "Voc\xEA foi convidado para o Workspace",
      corpo: "Voc\xEA foi convidado para acessar o Workspace MedConsultoria \u2014 o ambiente onde centralizamos clientes, projetos, agenda, finan\xE7as e documentos.\n\nPara ativar seu acesso, defina sua senha clicando no bot\xE3o abaixo:",
      ctaTexto: "Definir minha senha",
      nota: "Por seguran\xE7a, este link expira em 72 horas e s\xF3 pode ser usado uma vez. Se voc\xEA n\xE3o esperava este convite, ignore este e-mail."
    }
  },
  boas_vindas: {
    label: "Boas-vindas",
    descricao: "Enviado logo ap\xF3s a pessoa ativar o acesso (aceitar o convite).",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [{ chave: "nome", rotulo: "Nome da pessoa", descricao: "Nome de quem recebe", exemplo: "Maria Silva" }],
    temCta: true,
    default: {
      assunto: "Bem-vindo ao Workspace MedConsultoria",
      titulo: "Acesso ativado \u2014 boas-vindas! \u{1F389}",
      corpo: "Sua conta no Workspace MedConsultoria foi ativada com sucesso.\n\nAqui voc\xEA acompanha clientes, projetos, agenda, finan\xE7as, documentos e se comunica com a equipe \u2014 tudo em um s\xF3 lugar.",
      ctaTexto: "Acessar o workspace"
    }
  },
  reset_senha: {
    label: "Redefini\xE7\xE3o de senha",
    descricao: "Enviado quando algu\xE9m pede para redefinir a senha (Esqueci minha senha).",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome da pessoa", descricao: "Nome de quem recebe", exemplo: "Maria Silva" },
      { chave: "link", rotulo: "Link do bot\xE3o", descricao: "Link para criar a nova senha", exemplo: "(link seguro)" }
    ],
    temCta: true,
    default: {
      assunto: "Redefini\xE7\xE3o de senha \u2014 Workspace MedConsultoria",
      titulo: "Redefini\xE7\xE3o de senha",
      corpo: "Recebemos um pedido para redefinir a senha da sua conta no Workspace MedConsultoria.\n\nPara criar uma nova senha, clique no bot\xE3o abaixo:",
      ctaTexto: "Redefinir minha senha",
      nota: "Este link expira em 1 hora e s\xF3 pode ser usado uma vez. Se n\xE3o foi voc\xEA quem pediu, ignore este e-mail \u2014 sua senha atual continua v\xE1lida."
    }
  },
  lead_confirmacao: {
    label: "Confirma\xE7\xE3o de contato (lead)",
    descricao: "Resposta autom\xE1tica ao visitante que se cadastra pelo formul\xE1rio p\xFAblico.",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [{ chave: "nome", rotulo: "Nome do contato", descricao: "Nome de quem se cadastrou", exemplo: "Jo\xE3o Pereira" }],
    temCta: false,
    default: {
      assunto: "Recebemos seu contato \u2014 MedConsultoria",
      titulo: "Recebemos seu contato!",
      corpo: "Obrigado por entrar em contato com a MedConsultoria. Recebemos suas informa\xE7\xF5es e nossa equipe vai analisar e retornar em breve.",
      nota: "Este \xE9 um e-mail autom\xE1tico de confirma\xE7\xE3o \u2014 n\xE3o \xE9 necess\xE1rio respond\xEA-lo."
    }
  },
  portal_boas_vindas: {
    label: "Acesso ao Portal do Cliente",
    descricao: "Boas-vindas com acesso ao Portal \u2014 enviado ao lead na capta\xE7\xE3o e ao cliente novo. A pessoa define a senha pelo link.",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome da pessoa", descricao: "Nome de quem recebe", exemplo: "Maria Silva" },
      { chave: "link", rotulo: "Link do bot\xE3o", descricao: "Link para ativar o acesso (definir a senha)", exemplo: "(link seguro)" }
    ],
    temCta: true,
    default: {
      assunto: "Seu acesso ao Portal do Cliente \u2014 MedConsultoria",
      titulo: "Bem-vindo(a)! Acompanhe tudo pelo Portal \u{1F389}",
      corpo: "Que bom ter voc\xEA por aqui! Criamos o seu acesso ao Portal do Cliente da MedConsultoria \u2014 o espa\xE7o onde voc\xEA acompanha o andamento do seu atendimento, documentos, reuni\xF5es e fala direto com a nossa equipe.\n\nPara ativar o acesso, defina sua senha clicando no bot\xE3o abaixo:",
      ctaTexto: "Ativar meu acesso",
      nota: "Por seguran\xE7a, este link expira em 72 horas e s\xF3 pode ser usado uma vez. Se voc\xEA n\xE3o reconhece este contato, ignore este e-mail."
    }
  },
  cliente_boas_vindas: {
    label: "Boas-vindas ao cliente",
    descricao: "Enviado quando um lead se torna cliente e J\xC1 tinha acesso ao Portal (sem novos dados de acesso).",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome do cliente", descricao: "Nome de quem recebe", exemplo: "Maria Silva" },
      { chave: "link", rotulo: "Link do bot\xE3o", descricao: "Link do Portal do Cliente", exemplo: "(link do Portal)" }
    ],
    temCta: true,
    default: {
      assunto: "Boas-vindas! Agora voc\xEA \xE9 cliente MedConsultoria \u{1F389}",
      titulo: "Que alegria ter voc\xEA como cliente!",
      corpo: "\xC9 oficial: agora voc\xEA \xE9 cliente da MedConsultoria. Obrigado pela confian\xE7a!\n\nVoc\xEA continua com o mesmo acesso ao Portal do Cliente que j\xE1 usava \u2014 \xE9 s\xF3 entrar para acompanhar seus projetos, documentos, reuni\xF5es e falar com a nossa equipe.",
      ctaTexto: "Acessar o Portal"
    }
  },
  assinatura_solicitada: {
    label: "Solicita\xE7\xE3o de assinatura",
    descricao: "Enviado ao signat\xE1rio (cliente ou equipe) com o link para assinar um documento.",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome do signat\xE1rio", descricao: "Quem vai assinar", exemplo: "Maria Silva" },
      { chave: "documento", rotulo: "Documento", descricao: "T\xEDtulo do documento", exemplo: "Contrato de presta\xE7\xE3o de servi\xE7os" },
      { chave: "link", rotulo: "Link para assinar", descricao: "Abre a p\xE1gina de assinatura", exemplo: "(link seguro)" }
    ],
    temCta: true,
    default: {
      assunto: "Documento para assinatura \u2014 {{documento}}",
      titulo: "Voc\xEA tem um documento para assinar",
      corpo: 'A MedConsultoria enviou o documento "{{documento}}" para a sua assinatura eletr\xF4nica.\n\n\xC9 r\xE1pido e seguro: basta abrir o link, revisar o conte\xFAdo e assinar (desenhando ou digitando seu nome).',
      ctaTexto: "Revisar e assinar",
      nota: "Sua assinatura fica registrada com data, hora e um c\xF3digo de integridade do documento, conforme a Lei 14.063/2020."
    }
  },
  proposta_para_aceite: {
    label: "Proposta para aceite (cliente)",
    descricao: "Enviado ao cliente com o link para revisar a proposta e aceitar ou recusar online.",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome do cliente", descricao: "Quem recebe", exemplo: "Maria Silva" },
      { chave: "documento", rotulo: "Proposta", descricao: "T\xEDtulo da proposta", exemplo: "Proposta - Cl\xEDnica Bem-Estar" },
      { chave: "link", rotulo: "Link da proposta", descricao: "Abre a p\xE1gina de aceite", exemplo: "(link seguro)" }
    ],
    temCta: true,
    default: {
      assunto: "Sua proposta da MedConsultoria \u2014 {{documento}}",
      titulo: "Voc\xEA tem uma proposta para revisar",
      corpo: 'Preparamos uma proposta especialmente para voc\xEA: "{{documento}}".\n\n\xC9 s\xF3 abrir o link, revisar com calma e responder com um clique \u2014 aceitar ou, se preferir, recusar. N\xE3o precisa baixar nada.',
      ctaTexto: "Revisar a proposta",
      nota: "Qualquer d\xFAvida, fale com a nossa equipe pelo Portal do Cliente. Ficamos \xE0 disposi\xE7\xE3o."
    }
  },
  reuniao_agendada: {
    label: "Reuni\xE3o agendada (cliente)",
    descricao: "Enviado ao cliente quando uma reuni\xE3o/evento \xE9 agendado com ele \u2014 opcional, a equipe escolhe se avisa.",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome do cliente", descricao: "Quem recebe", exemplo: "Maria Silva" },
      { chave: "titulo", rotulo: "T\xEDtulo da reuni\xE3o", descricao: "Nome do evento", exemplo: "Reuni\xE3o de alinhamento" },
      { chave: "quando", rotulo: "Data e hora", descricao: "Quando acontece", exemplo: "12/07/2026 \xE0s 10:00" },
      { chave: "link", rotulo: "Link da reuni\xE3o", descricao: "Meet/Zoom/Jitsi (opcional)", exemplo: "(link da reuni\xE3o)" }
    ],
    temCta: true,
    default: {
      assunto: "Reuni\xE3o agendada \u2014 {{titulo}}",
      titulo: "Sua reuni\xE3o foi agendada \u{1F4C5}",
      corpo: 'Agendamos uma reuni\xE3o com voc\xEA:\n\n"{{titulo}}"\nQuando: {{quando}}\n\nSe houver um link de acesso, use o bot\xE3o abaixo na hora da reuni\xE3o. Qualquer d\xFAvida, fale com a nossa equipe pelo Portal do Cliente.',
      ctaTexto: "Entrar na reuni\xE3o",
      nota: "Se precisar remarcar, \xE9 s\xF3 avisar a nossa equipe."
    }
  },
  lembrete_reuniao_cliente: {
    label: "Lembrete de reuni\xE3o (cliente)",
    descricao: "Enviado ao cliente automaticamente na v\xE9spera/no dia de uma reuni\xE3o agendada com ele.",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome do cliente", descricao: "Quem recebe", exemplo: "Maria Silva" },
      { chave: "titulo", rotulo: "T\xEDtulo da reuni\xE3o", descricao: "Nome do evento", exemplo: "Reuni\xE3o de alinhamento" },
      { chave: "quando", rotulo: "Data e hora", descricao: "Quando acontece", exemplo: "12/07/2026 \xE0s 10:00" },
      { chave: "link", rotulo: "Link da reuni\xE3o", descricao: "Meet/Zoom/Jitsi (opcional)", exemplo: "(link da reuni\xE3o)" }
    ],
    temCta: true,
    default: {
      assunto: "Lembrete: {{titulo}} est\xE1 chegando",
      titulo: "Sua reuni\xE3o est\xE1 chegando \u23F0",
      corpo: 'Passando para lembrar da nossa reuni\xE3o:\n\n"{{titulo}}"\nQuando: {{quando}}\n\nSe houver um link de acesso, use o bot\xE3o abaixo na hora. Nos vemos l\xE1!',
      ctaTexto: "Entrar na reuni\xE3o",
      nota: "Se precisar remarcar, \xE9 s\xF3 avisar a nossa equipe pelo Portal do Cliente."
    }
  },
  // ───────── Notificações (sino + e-mail; respeitam preferências) ─────────
  presenca_confirmada: {
    label: "Presen\xE7a confirmada (cliente)",
    descricao: "Quando um cliente confirma presen\xE7a numa reuni\xE3o pelo Portal. Vai para o dono do evento.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "cliente", rotulo: "Nome do cliente", descricao: "Quem confirmou", exemplo: "Maria Silva" },
      { chave: "evento", rotulo: "Nome da reuni\xE3o", descricao: "T\xEDtulo do evento", exemplo: "Reuni\xE3o de alinhamento" }
    ],
    temCta: true,
    default: {
      assunto: "{{cliente}} confirmou presen\xE7a",
      titulo: "{{cliente}} confirmou presen\xE7a",
      corpo: '{{cliente}} confirmou presen\xE7a na reuni\xE3o "{{evento}}".',
      ctaTexto: "Ver na agenda"
    }
  },
  lembrete: {
    label: "Lembrete de compromisso",
    descricao: "Aviso antes de um evento/reuni\xE3o come\xE7ar. Vai para o dono do evento.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "evento", rotulo: "Nome do compromisso", descricao: "T\xEDtulo do compromisso", exemplo: "Reuni\xE3o com Dr. Paulo Andrade" },
      { chave: "hora", rotulo: "Hor\xE1rio", descricao: "Hor\xE1rio de in\xEDcio", exemplo: "14:30" }
    ],
    temCta: true,
    default: {
      assunto: "Lembrete: {{evento}}",
      titulo: "Lembrete: {{evento}}",
      corpo: 'Seu compromisso "{{evento}}" come\xE7a \xE0s {{hora}}.',
      ctaTexto: "Ver na agenda"
    }
  },
  tarefa_atribuida: {
    label: "Tarefa atribu\xEDda",
    descricao: "Quando algu\xE9m atribui um cart\xE3o/tarefa a voc\xEA.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "tarefa", rotulo: "Nome da tarefa", descricao: "T\xEDtulo da tarefa", exemplo: "Enviar proposta para a cl\xEDnica" },
      { chave: "projeto", rotulo: "Nome do projeto", descricao: "Nome do projeto", exemplo: "Credenciamento Unimed" }
    ],
    temCta: true,
    default: {
      assunto: "Nova tarefa atribu\xEDda a voc\xEA",
      titulo: "Nova tarefa: {{tarefa}}",
      corpo: 'A tarefa "{{tarefa}}" foi atribu\xEDda a voc\xEA no projeto {{projeto}}.',
      ctaTexto: "Ver tarefa"
    }
  },
  tarefa_atrasada: {
    label: "Tarefas atrasadas",
    descricao: "Resumo de tarefas suas que passaram do prazo.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "qtd", rotulo: "Quantidade", descricao: "Quantidade de tarefas atrasadas", exemplo: "3" },
      { chave: "projeto", rotulo: "Nome do projeto", descricao: "Nome do projeto", exemplo: "Credenciamento Unimed" }
    ],
    temCta: true,
    default: {
      assunto: "Voc\xEA tem tarefas atrasadas",
      titulo: "Voc\xEA tem {{qtd}} tarefa(s) atrasada(s)",
      corpo: "H\xE1 {{qtd}} tarefa(s) atrasada(s) no projeto {{projeto}}. Que tal colocar em dia?",
      ctaTexto: "Ver projeto"
    }
  },
  projeto_participante: {
    label: "Adicionado a um projeto",
    descricao: "Quando voc\xEA \xE9 inclu\xEDdo na equipe de um projeto.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "projeto", rotulo: "Nome do projeto", descricao: "Nome do projeto", exemplo: "Credenciamento Unimed" }],
    temCta: true,
    default: {
      assunto: "Voc\xEA foi adicionado a um projeto",
      titulo: "Voc\xEA foi adicionado a um projeto",
      corpo: "Voc\xEA agora faz parte da equipe do projeto {{projeto}}.",
      ctaTexto: "Ver projeto"
    }
  },
  suporte: {
    label: "Mensagem de suporte",
    descricao: "Nova mensagem no canal de suporte de um cliente.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "cliente", rotulo: "Nome do cliente", descricao: "Nome do cliente", exemplo: "Cl\xEDnica Vida & Sa\xFAde" },
      { chave: "mensagem", rotulo: "Trecho da mensagem", descricao: "In\xEDcio da mensagem recebida", exemplo: "Preciso de ajuda com o envio dos documentos." }
    ],
    temCta: true,
    default: {
      assunto: "Nova mensagem de suporte \u2014 {{cliente}}",
      titulo: "Suporte: {{cliente}}",
      corpo: 'Nova mensagem de {{cliente}} no suporte: "{{mensagem}}"',
      ctaTexto: "Responder"
    }
  },
  proposta_aceita: {
    label: "Proposta aceita pelo cliente \u{1F389}",
    descricao: "Quando um cliente aceita a proposta pelo link/Portal. Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "cliente", rotulo: "Nome do cliente", descricao: "Quem aceitou", exemplo: "Cl\xEDnica Bem-Estar" },
      { chave: "documento", rotulo: "Proposta", descricao: "T\xEDtulo da proposta", exemplo: "Proposta - Cl\xEDnica Bem-Estar" }
    ],
    temCta: true,
    default: {
      assunto: "{{cliente}} aceitou a proposta \u{1F389}",
      titulo: "Proposta aceita! \u{1F389}",
      corpo: 'Boa not\xEDcia! {{cliente}} aceitou a proposta "{{documento}}". Que tal j\xE1 preparar o contrato e dar sequ\xEAncia?',
      ctaTexto: "Ver documento"
    }
  },
  proposta_recusada: {
    label: "Proposta recusada pelo cliente",
    descricao: "Quando um cliente recusa a proposta pelo link/Portal (com o motivo). Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "cliente", rotulo: "Nome do cliente", descricao: "Quem recusou", exemplo: "Cl\xEDnica Bem-Estar" },
      { chave: "documento", rotulo: "Proposta", descricao: "T\xEDtulo da proposta", exemplo: "Proposta - Cl\xEDnica Bem-Estar" },
      { chave: "motivo", rotulo: "Motivo", descricao: "O motivo informado pelo cliente", exemplo: "O valor ficou acima do previsto." }
    ],
    temCta: true,
    default: {
      assunto: "{{cliente}} recusou a proposta",
      titulo: "Proposta recusada",
      corpo: '{{cliente}} recusou a proposta "{{documento}}". Motivo: "{{motivo}}". Vale um contato para entender e, quem sabe, ajustar.',
      ctaTexto: "Ver documento"
    }
  },
  documento_revisao: {
    label: "Documento aguardando revis\xE3o",
    descricao: "Documentos que precisam de an\xE1lise. Vai para admins.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "documento", rotulo: "Nome do documento", descricao: "T\xEDtulo do documento", exemplo: "Contrato de presta\xE7\xE3o de servi\xE7os" }],
    temCta: true,
    default: {
      assunto: "Documento aguardando revis\xE3o",
      titulo: "Documento aguardando revis\xE3o",
      corpo: 'O documento "{{documento}}" est\xE1 aguardando sua revis\xE3o.',
      ctaTexto: "Ver documento"
    }
  },
  conta_vencida: {
    label: "Conta vencida",
    descricao: "Alerta de conta a pagar/receber vencida. Vai para admins.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "descricao", rotulo: "Descri\xE7\xE3o da conta", descricao: "Descri\xE7\xE3o da conta", exemplo: "Mensalidade do plano" },
      { chave: "tipo", rotulo: "Tipo", descricao: "A pagar / A receber", exemplo: "A receber" },
      { chave: "valor", rotulo: "Valor", descricao: "Valor formatado", exemplo: "R$ 1.500,00" },
      { chave: "vencimento", rotulo: "Vencimento", descricao: "Data de vencimento", exemplo: "10/07/2026" }
    ],
    temCta: true,
    default: {
      assunto: "Conta vencida: {{descricao}}",
      titulo: "Conta vencida: {{descricao}}",
      corpo: 'A conta "{{descricao}}" ({{tipo}}) no valor de {{valor}} venceu em {{vencimento}}.',
      ctaTexto: "Ver no financeiro"
    }
  },
  conta_a_vencer: {
    label: "Conta a vencer",
    descricao: "Aviso de conta a pagar/receber que vence nos pr\xF3ximos dias. Vai para admins.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "descricao", rotulo: "Descri\xE7\xE3o da conta", descricao: "Descri\xE7\xE3o da conta", exemplo: "Aluguel" },
      { chave: "tipo", rotulo: "Tipo", descricao: "A pagar / A receber", exemplo: "A pagar" },
      { chave: "valor", rotulo: "Valor", descricao: "Valor formatado", exemplo: "R$ 2.000,00" },
      { chave: "vencimento", rotulo: "Vencimento", descricao: "Data de vencimento", exemplo: "12/07/2026" }
    ],
    temCta: true,
    default: {
      assunto: "Conta a vencer: {{descricao}}",
      titulo: "Conta a vencer: {{descricao}}",
      corpo: 'A conta "{{descricao}}" ({{tipo}}) no valor de {{valor}} vence em {{vencimento}}. N\xE3o esque\xE7a!',
      ctaTexto: "Ver no financeiro"
    }
  },
  lead_novo: {
    label: "Novo lead pelo site",
    descricao: "Quando algu\xE9m se cadastra pelo formul\xE1rio p\xFAblico. Vai para admins.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "contato", rotulo: "Nome do lead", descricao: "Nome (e empresa) do lead", exemplo: "Jo\xE3o Pereira \xB7 Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "Novo lead pelo site",
      titulo: "Novo lead pelo site",
      corpo: "Um novo lead se cadastrou pelo site: {{contato}}.",
      ctaTexto: "Ver no funil"
    }
  },
  lead_atribuido: {
    label: "Lead atribu\xEDdo a voc\xEA",
    descricao: "Quando algu\xE9m te define como respons\xE1vel por um lead do funil.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "contato", rotulo: "Nome do lead", descricao: "Nome (e empresa) do lead", exemplo: "Jo\xE3o Pereira \xB7 Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "Um lead foi atribu\xEDdo a voc\xEA",
      titulo: "Novo lead sob sua responsabilidade",
      corpo: "O lead {{contato}} foi atribu\xEDdo a voc\xEA. Fa\xE7a o primeiro contato e conduza pelo funil.",
      ctaTexto: "Ver no funil"
    }
  },
  lead_convertido: {
    label: "Lead virou cliente",
    descricao: "Quando um lead \xE9 convertido em cliente (venda fechada). Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "cliente", rotulo: "Nome do cliente", descricao: "Nome do cliente/lead convertido", exemplo: "Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "Venda fechada: {{cliente}} virou cliente \u{1F389}",
      titulo: "Lead convertido em cliente! \u{1F389}",
      corpo: "Parab\xE9ns! O lead {{cliente}} foi convertido em cliente. O projeto de onboarding j\xE1 foi criado.",
      ctaTexto: "Ver cliente"
    }
  },
  lead_desistiu: {
    label: "Lead desistiu pelo Portal",
    descricao: "Quando o pr\xF3prio lead/prospect declara pelo Portal que n\xE3o deseja mais avan\xE7ar. Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "contato", rotulo: "Nome do lead", descricao: "Nome (e empresa) do lead", exemplo: "Jo\xE3o Pereira \xB7 Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "{{contato}} desistiu pelo Portal",
      titulo: "Um lead desistiu pelo Portal",
      corpo: "O lead {{contato}} informou pelo Portal que n\xE3o deseja mais avan\xE7ar e foi movido para os perdidos. Talvez valha um contato para entender o motivo.",
      ctaTexto: "Ver no funil"
    }
  },
  lead_retomou: {
    label: "Lead retomou o interesse",
    descricao: "Quando um lead que havia desistido decide retomar o atendimento pelo Portal. Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "contato", rotulo: "Nome do lead", descricao: "Nome (e empresa) do lead", exemplo: "Jo\xE3o Pereira \xB7 Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "{{contato}} retomou o interesse \u{1F64C}",
      titulo: "Um lead retomou o atendimento",
      corpo: "Boa not\xEDcia! O lead {{contato}} decidiu retomar o atendimento pelo Portal e voltou ao funil. D\xEA sequ\xEAncia.",
      ctaTexto: "Ver no funil"
    }
  },
  servico_solicitado: {
    label: "Cliente pediu servi\xE7os pelo Portal",
    descricao: "Quando um cliente escolhe servi\xE7os no Portal \u2014 vira/atualiza uma oportunidade no funil. Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "contato", rotulo: "Nome do cliente", descricao: "Nome (e empresa) do cliente", exemplo: "Cl\xEDnica Bem-Estar" },
      { chave: "servicos", rotulo: "Servi\xE7os pedidos", descricao: "Lista dos servi\xE7os que o cliente escolheu", exemplo: "Faturamento, Marketing" }
    ],
    temCta: true,
    default: {
      assunto: "{{contato}} pediu servi\xE7os pelo Portal \u{1F6CE}\uFE0F",
      titulo: "Novo pedido de servi\xE7os pelo Portal",
      corpo: "{{contato}} escolheu no Portal os servi\xE7os: {{servicos}}. Uma oportunidade foi aberta/atualizada no funil \u2014 d\xEA sequ\xEAncia.",
      ctaTexto: "Ver no funil"
    }
  },
  documento_cliente_enviado: {
    label: "Cliente enviou um documento",
    descricao: "Quando um cliente anexa um documento pelo Portal. Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "cliente", rotulo: "Nome do cliente", descricao: "Cliente que enviou", exemplo: "Cl\xEDnica Bem-Estar" },
      { chave: "documento", rotulo: "Documento", descricao: "Nome do arquivo enviado", exemplo: "RG - Dr. Silva.pdf" }
    ],
    temCta: false,
    default: {
      assunto: "{{cliente}} enviou um documento \u{1F4CE}",
      titulo: "Novo documento recebido pelo Portal",
      corpo: '{{cliente}} anexou o documento "{{documento}}" pelo Portal do Cliente. Confira na ficha do cliente.'
    }
  },
  servico_cancelado: {
    label: "Cliente cancelou um servi\xE7o",
    descricao: "Quando um cliente cancela um servi\xE7o pelo Portal. Vai para o respons\xE1vel e a gest\xE3o.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "cliente", rotulo: "Nome do cliente", descricao: "Cliente que cancelou", exemplo: "Cl\xEDnica Bem-Estar" },
      { chave: "servico", rotulo: "Servi\xE7o", descricao: "Servi\xE7o cancelado", exemplo: "Faturamento" }
    ],
    temCta: false,
    default: {
      assunto: "{{cliente}} cancelou um servi\xE7o",
      titulo: "Servi\xE7o cancelado pelo cliente",
      corpo: '{{cliente}} cancelou o servi\xE7o "{{servico}}" pelo Portal do Cliente. Vale um contato para entender o motivo.'
    }
  },
  servico_ativado: {
    label: "Servi\xE7o contratado (aviso ao cliente)",
    descricao: "Enviado ao cliente quando a equipe ativa um servi\xE7o para ele \u2014 opcional (opt-in).",
    grupo: "Transacionais",
    notificacao: false,
    variaveis: [
      { chave: "nome", rotulo: "Nome do cliente", descricao: "Quem recebe", exemplo: "Maria Silva" },
      { chave: "servico", rotulo: "Servi\xE7o", descricao: "Servi\xE7o contratado", exemplo: "Credenciamento" },
      { chave: "link", rotulo: "Link do Portal", descricao: "Portal do Cliente", exemplo: "(link do Portal)" }
    ],
    temCta: true,
    default: {
      assunto: "Servi\xE7o {{servico}} ativado \u2014 MedConsultoria",
      titulo: "Seu servi\xE7o foi ativado \u{1F389}",
      corpo: 'Ativamos o servi\xE7o "{{servico}}" para voc\xEA! Para darmos andamento, acesse o Portal do Cliente e veja se h\xE1 documentos ou informa\xE7\xF5es que precisamos de voc\xEA.',
      ctaTexto: "Acessar o Portal"
    }
  },
  conflito_agenda: {
    label: "Conflito de hor\xE1rio na agenda",
    descricao: "Alerta proativo quando dois compromissos seus se sobrep\xF5em. Vai para o dono e os participantes.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [
      { chave: "titulo", rotulo: "Compromisso", descricao: "T\xEDtulo do compromisso em conflito", exemplo: "Reuni\xE3o de kickoff" },
      { chave: "quando", rotulo: "Quando", descricao: "Data e hora do conflito", exemplo: "15/07/2026 \xE0s 10:00" }
    ],
    temCta: true,
    default: {
      assunto: "Conflito de hor\xE1rio na agenda",
      titulo: "Conflito de hor\xE1rio \u26A0\uFE0F",
      corpo: 'Aten\xE7\xE3o: "{{titulo}}" ({{quando}}) est\xE1 no mesmo hor\xE1rio de outro compromisso seu. Reveja a agenda para n\xE3o perder nada.',
      ctaTexto: "Abrir a agenda"
    }
  },
  projeto_parado: {
    label: "Projeto parado",
    descricao: "Projeto ativo sem movimento h\xE1 mais de 14 dias. Vai para o respons\xE1vel (ou admins).",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "projeto", rotulo: "Nome do projeto", descricao: "Nome do projeto", exemplo: "Credenciamento Unimed" }],
    temCta: true,
    default: {
      assunto: "Projeto parado: {{projeto}}",
      titulo: "Projeto parado h\xE1 +14 dias",
      corpo: 'O projeto "{{projeto}}" est\xE1 ativo mas sem movimento h\xE1 mais de 14 dias. Que tal dar um empurr\xE3o ou revisar o andamento?',
      ctaTexto: "Ver projeto"
    }
  },
  projeto_sem_responsavel: {
    label: "Projeto sem respons\xE1vel",
    descricao: "Projeto sem ningu\xE9m respons\xE1vel. Vai para admins.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "projeto", rotulo: "Nome do projeto", descricao: "Nome do projeto", exemplo: "Credenciamento Unimed" }],
    temCta: true,
    default: {
      assunto: "Projeto sem respons\xE1vel: {{projeto}}",
      titulo: "Projeto sem respons\xE1vel",
      corpo: 'O projeto "{{projeto}}" est\xE1 sem respons\xE1vel definido. Defina algu\xE9m para que n\xE3o fique sem dono.',
      ctaTexto: "Ver projeto"
    }
  },
  upsell_oportunidade: {
    label: "Cliente quer mais (upsell)",
    descricao: "Cliente ativo com uma oportunidade aberta no funil (quer mais servi\xE7os). Vai para o respons\xE1vel (ou admins).",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "cliente", rotulo: "Nome do cliente", descricao: "Nome do cliente", exemplo: "Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "Oportunidade: {{cliente}} quer mais",
      titulo: "Oportunidade de upsell \u{1F4A1}",
      corpo: "{{cliente}} tem uma oportunidade aberta no funil (quer mais servi\xE7os). Vale dar sequ\xEAncia para n\xE3o esfriar.",
      ctaTexto: "Ver no funil"
    }
  },
  documento_parado: {
    label: "Documento sem resposta do cliente",
    descricao: "Proposta ou documento enviado ao cliente que est\xE1 h\xE1 dias sem aceite/assinatura. Vai para quem criou e admins.",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "documento", rotulo: "Documento", descricao: "T\xEDtulo do documento", exemplo: "Proposta - Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "Sem resposta: {{documento}}",
      titulo: "Documento parado aguardando o cliente",
      corpo: 'O documento "{{documento}}" foi enviado ao cliente e ainda n\xE3o teve resposta (aceite/assinatura). Que tal um lembrete amig\xE1vel?',
      ctaTexto: "Ver documento"
    }
  },
  lead_parado: {
    label: "Lead parado no funil",
    descricao: "Lead ativo sem movimento h\xE1 mais de 14 dias. Vai para o respons\xE1vel (ou admins).",
    grupo: "Notifica\xE7\xF5es",
    notificacao: true,
    variaveis: [{ chave: "contato", rotulo: "Nome do lead", descricao: "Nome (e empresa) do lead", exemplo: "Jo\xE3o Pereira \xB7 Cl\xEDnica Bem-Estar" }],
    temCta: true,
    default: {
      assunto: "Lead parado: {{contato}}",
      titulo: "Lead parado h\xE1 +14 dias",
      corpo: "O lead {{contato}} est\xE1 parado h\xE1 mais de 14 dias no funil. Um retorno agora pode reaquecer a conversa.",
      ctaTexto: "Ver no funil"
    }
  },
  // ───────── Sistema (ROOT; título/detalhe dinâmicos) ─────────
  incidente: {
    label: "Alerta do sistema (incidente)",
    descricao: "Incidente t\xE9cnico detectado (event loop, mem\xF3ria, etc.). Vai para o ROOT.",
    grupo: "Sistema",
    notificacao: true,
    variaveis: [
      { chave: "titulo", rotulo: "T\xEDtulo do alerta", descricao: "T\xEDtulo din\xE2mico do alerta", exemplo: "\u{1F6A8} Uso de mem\xF3ria alto" },
      { chave: "detalhe", rotulo: "Detalhe", descricao: "Detalhe do incidente", exemplo: "Uso de mem\xF3ria chegou a 88% (limite 85%)." }
    ],
    temCta: true,
    default: {
      assunto: "{{titulo}}",
      titulo: "{{titulo}}",
      corpo: "{{detalhe}}",
      ctaTexto: "Ver no Sistema"
    }
  },
  erro: {
    label: "Erro do sistema",
    descricao: "Novo erro (ou regress\xE3o) registrado na aplica\xE7\xE3o. Vai para o ROOT.",
    grupo: "Sistema",
    notificacao: true,
    variaveis: [
      { chave: "titulo", rotulo: "T\xEDtulo do erro", descricao: "Novo erro / regress\xE3o", exemplo: "Novo erro registrado" },
      { chave: "resumo", rotulo: "Resumo", descricao: "Resumo do erro", exemplo: "TypeError: cannot read property 'id' of undefined" }
    ],
    temCta: true,
    default: {
      assunto: "{{titulo}}",
      titulo: "{{titulo}}",
      corpo: "{{resumo}}",
      ctaTexto: "Ver no Sistema"
    }
  }
};
function exemploVars(chave) {
  const meta = EMAIL_TEMPLATES[chave];
  const vars = {};
  if (meta) for (const v of meta.variaveis) vars[v.chave] = v.exemplo;
  return vars;
}

// src/modules/emails/emails.service.ts
var escHtml = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
var interpolar = (s, vars) => s.replace(/\{\{\s*(\w+)\s*\}\}/g, (_m, k) => vars[k] ?? "");
function efetivo(chave, o) {
  const d = EMAIL_TEMPLATES[chave].default;
  return {
    assunto: o?.assunto ?? d.assunto,
    titulo: o?.titulo ?? d.titulo,
    corpo: o?.corpo ?? d.corpo,
    ctaTexto: o?.ctaTexto ?? d.ctaTexto ?? "",
    nota: o?.nota ?? d.nota ?? ""
  };
}
function construir(chave, campos, vars) {
  const meta = EMAIL_TEMPLATES[chave];
  const assunto = interpolar(campos.assunto, vars);
  const titulo = interpolar(campos.titulo, vars);
  const corpo = interpolar(campos.corpo, vars);
  const paragrafos = corpo.split(/\n\s*\n/).map((p) => escHtml(p.trim())).filter(Boolean);
  const nota = interpolar(campos.nota ?? "", vars);
  const cta = meta.temCta && vars.link ? { texto: interpolar(campos.ctaTexto || "Abrir", vars), url: vars.link } : void 0;
  const { html, texto } = montarEmail({
    preheader: titulo,
    titulo,
    saudacao: vars.nome ? `Ol\xE1, ${vars.nome.split(" ")[0]}!` : void 0,
    paragrafos: paragrafos.length ? paragrafos : [" "],
    cta,
    nota: nota || void 0
  });
  return { assunto, titulo, corpo, html, texto };
}
async function listarTemplates() {
  const overrides = await prisma.emailTemplate.findMany();
  const map = new Map(overrides.map((o) => [o.chave, o]));
  return Object.entries(EMAIL_TEMPLATES).map(([chave, meta]) => {
    const o = map.get(chave) ?? null;
    return {
      chave,
      label: meta.label,
      descricao: meta.descricao,
      grupo: meta.grupo,
      notificacao: meta.notificacao,
      variaveis: meta.variaveis,
      temCta: meta.temCta,
      personalizado: !!o,
      ...efetivo(chave, o)
    };
  });
}
async function atualizarTemplate(chave, dados, atorNome) {
  if (!EMAIL_TEMPLATES[chave]) throw new TRPCError({ code: "NOT_FOUND", message: "Template inexistente." });
  const data = {
    assunto: dados.assunto.trim(),
    titulo: dados.titulo.trim(),
    corpo: dados.corpo.trim(),
    ctaTexto: dados.ctaTexto?.trim() || null,
    nota: dados.nota?.trim() || null,
    atualizadoPor: atorNome
  };
  await prisma.emailTemplate.upsert({
    where: { chave },
    create: { chave, ...data },
    update: data
  });
  return { ok: true };
}
async function resetarTemplate(chave) {
  await prisma.emailTemplate.deleteMany({ where: { chave } });
  return { ok: true };
}
async function renderTemplate(chave, vars) {
  const o = await prisma.emailTemplate.findUnique({ where: { chave } });
  return construir(chave, efetivo(chave, o), vars);
}
function exemploCompleto(chave) {
  const vars = { nome: "Maria Silva", email: "maria@exemplo.com", ...exemploVars(chave) };
  vars.link = `${config.WEB_ORIGIN}/exemplo`;
  return vars;
}
function gerarPreview(chave, campos) {
  if (!EMAIL_TEMPLATES[chave]) throw new TRPCError({ code: "NOT_FOUND", message: "Template inexistente." });
  const { html, titulo, corpo } = construir(chave, campos, exemploCompleto(chave));
  return {
    html: html.replace(`cid:${LOGO_CID}`, `data:image/png;base64,${LOGO_PNG_BASE64}`),
    notifTitulo: titulo,
    notifCorpo: corpo
  };
}
async function enviarTeste(chave, para) {
  if (!EMAIL_TEMPLATES[chave]) throw new TRPCError({ code: "NOT_FOUND", message: "Template inexistente." });
  const { assunto, html, texto } = await renderTemplate(chave, exemploCompleto(chave));
  const { enviado } = await enviarEmail({ para, assunto: `[Teste] ${assunto}`, html, texto });
  if (!enviado) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "N\xE3o foi poss\xEDvel enviar o e-mail de teste (verifique a configura\xE7\xE3o SMTP)."
    });
  }
  return { enviado };
}

// src/modules/emails/enviados.service.ts
async function registrarEmailEnviado(para, assunto, corpo, template, enviado, erro) {
  try {
    const [user, cliente, lead] = await Promise.all([
      prisma.user.findFirst({ where: { email: para, deletedAt: null }, select: { id: true } }),
      prisma.cliente.findFirst({ where: { email: para, deletedAt: null }, select: { id: true } }),
      prisma.lead.findFirst({ where: { email: para, deletedAt: null }, orderBy: { createdAt: "desc" }, select: { id: true } })
    ]);
    await prisma.emailEnviado.create({
      data: {
        para,
        assunto,
        corpo,
        template,
        status: enviado ? "ENVIADO" : "FALHOU",
        erro: enviado ? null : erro ?? null,
        userId: user?.id ?? null,
        clienteId: cliente?.id ?? null,
        leadId: lead?.id ?? null
      }
    });
  } catch {
  }
}
async function enviarEmailTemplate(chave, para, vars) {
  const { assunto, html, texto } = await renderTemplate(chave, vars);
  const { enviado, erro } = await enviarEmail({ para, assunto, html, texto });
  await registrarEmailEnviado(para, assunto, texto ?? "", chave, enviado, erro);
  return { enviado };
}
var selecao = {
  id: true,
  para: true,
  assunto: true,
  template: true,
  corpo: true,
  status: true,
  erro: true,
  createdAt: true
};
function comRotulo(rows) {
  return rows.map((r) => {
    const meta = r.template ? EMAIL_TEMPLATES[r.template] : void 0;
    return { ...r, templateLabel: meta ? meta.label : "E-mail" };
  });
}
async function listPorLead(leadId) {
  const lead = await prisma.lead.findUnique({ where: { id: leadId }, select: { email: true } });
  const rows = await prisma.emailEnviado.findMany({
    where: lead?.email ? { OR: [{ leadId }, { para: lead.email }] } : { leadId },
    orderBy: { createdAt: "desc" },
    take: 50,
    select: selecao
  });
  return comRotulo(rows);
}
async function listPorCliente(clienteId) {
  const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { email: true } });
  const rows = await prisma.emailEnviado.findMany({
    where: cliente?.email ? { OR: [{ clienteId }, { para: cliente.email }] } : { clienteId },
    orderBy: { createdAt: "desc" },
    take: 50,
    select: selecao
  });
  return comRotulo(rows);
}
async function listMeus(userId, email) {
  const rows = await prisma.emailEnviado.findMany({
    where: { OR: [{ userId }, { para: email }] },
    orderBy: { createdAt: "desc" },
    take: 100,
    select: selecao
  });
  return comRotulo(rows);
}
async function resumoEnviados() {
  const agora = Date.now();
  const seteDias = new Date(agora - 7 * 24 * 60 * 60 * 1e3);
  const inicioHoje = /* @__PURE__ */ new Date();
  inicioHoje.setHours(0, 0, 0, 0);
  const [enviados7d, falhas7d, hoje, ultimaFalha, usados] = await Promise.all([
    prisma.emailEnviado.count({ where: { status: "ENVIADO", createdAt: { gte: seteDias } } }),
    prisma.emailEnviado.count({ where: { status: "FALHOU", createdAt: { gte: seteDias } } }),
    prisma.emailEnviado.count({ where: { createdAt: { gte: inicioHoje } } }),
    prisma.emailEnviado.findFirst({ where: { status: "FALHOU" }, orderBy: { createdAt: "desc" }, select: { createdAt: true } }),
    prisma.emailEnviado.findMany({ distinct: ["template"], select: { template: true }, orderBy: { template: "asc" } })
  ]);
  const total7d = enviados7d + falhas7d;
  const templates = usados.map((u) => u.template).filter((t) => !!t).map((t) => ({ chave: t, label: EMAIL_TEMPLATES[t]?.label ?? t }));
  return {
    enviados7d,
    falhas7d,
    hoje,
    taxaEntrega: total7d ? enviados7d / total7d : 1,
    isEmailReal,
    ultimaFalhaEm: ultimaFalha?.createdAt ?? null,
    templates
  };
}
async function listTodos(f) {
  const limite = Math.min(f.limite ?? 30, 500);
  const where = {};
  if (f.status) where.status = f.status;
  if (f.template) where.template = f.template;
  if (f.dias && f.dias > 0) where.createdAt = { gte: new Date(Date.now() - f.dias * 24 * 60 * 60 * 1e3) };
  const q = f.busca?.trim();
  if (q) where.OR = [{ para: { contains: q } }, { assunto: { contains: q } }];
  const rows = await prisma.emailEnviado.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: limite + 1,
    select: selecao
  });
  const temMais = rows.length > limite;
  return { itens: comRotulo(temMais ? rows.slice(0, limite) : rows), temMais };
}

// src/realtime/socket.ts
import { Server } from "socket.io";

// src/lib/session.ts
var SESSION_COOKIE = "sid";
var TTL_DAYS = 30;
async function createSession(userId, userAgent, ip) {
  const expiresAt = new Date(Date.now() + TTL_DAYS * 24 * 60 * 60 * 1e3);
  const session = await prisma.session.create({
    data: { userId, expiresAt, userAgent: userAgent ?? null, ip: ip ?? null }
  });
  return session.id;
}
async function getUserFromSession(sid) {
  if (!sid) return null;
  const session = await prisma.session.findUnique({
    where: { id: sid },
    include: { user: true }
  });
  if (!session || session.expiresAt < /* @__PURE__ */ new Date()) return null;
  const { user } = session;
  if (!user.ativo || user.deletedAt) return null;
  return {
    id: user.id,
    nome: user.nome,
    email: user.email,
    role: user.role,
    avatarUrl: user.avatarUrl,
    clienteId: user.clienteId
  };
}
async function destroySession(sid) {
  if (!sid) return;
  await prisma.session.deleteMany({ where: { id: sid } });
}
var SESSION_TTL_SECONDS = TTL_DAYS * 24 * 60 * 60;

// src/realtime/socket.ts
var io = null;
function initRealtime(app) {
  io = new Server(app.server, {
    cors: { origin: config.WEB_ORIGIN, credentials: true }
  });
  io.use(async (socket, next) => {
    try {
      const cookieHeader = socket.handshake.headers.cookie ?? "";
      const parsed2 = app.parseCookie(cookieHeader);
      const raw = parsed2[SESSION_COOKIE];
      const unsigned = raw ? app.unsignCookie(raw) : null;
      const sid = unsigned?.valid ? unsigned.value ?? void 0 : void 0;
      const user = await getUserFromSession(sid);
      if (!user) return next(new Error("unauthorized"));
      socket.data.userId = user.id;
      await socket.join(`user:${user.id}`);
      next();
    } catch (err) {
      next(err);
    }
  });
  return io;
}
var notificationService = {
  emitToUser(userId, event, payload) {
    io?.to(`user:${userId}`).emit(event, payload);
  }
};
function contarConexoesSocket() {
  return io?.engine.clientsCount ?? 0;
}

// src/modules/notificacoes/notificacoes.service.ts
function rotaEntidade(tipo, id) {
  switch (tipo) {
    case "projeto":
      return id ? `/projetos/${id}` : "/projetos";
    case "documento":
      return id ? `/documentos/${id}` : "/documentos";
    case "cliente":
      return id ? `/clientes/${id}` : "/clientes";
    case "evento":
      return "/agenda";
    case "conta":
      return "/financeiro";
    case "lead":
      return "/leads";
    case "incidente":
    case "erro":
      return "/sistema";
    default:
      return "/";
  }
}
function listNotificacoes(userId) {
  return prisma.notificacao.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 30
  });
}
async function markAllRead(userId) {
  await prisma.notificacao.updateMany({ where: { userId, lida: false }, data: { lida: true } });
  return { ok: true };
}
async function markRead(userId, id) {
  await prisma.notificacao.updateMany({ where: { id, userId }, data: { lida: true } });
  return { ok: true };
}
async function notificar(userId, tipo, vars, opts = {}) {
  if (opts.unico && opts.entidadeId) {
    const existe = await prisma.notificacao.findFirst({
      where: { userId, tipo, entidadeId: opts.entidadeId },
      select: { id: true }
    });
    if (existe) return;
  }
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { nome: true, email: true, ativo: true, deletedAt: true }
  });
  if (!user) return;
  const link = config.WEB_ORIGIN + rotaEntidade(opts.entidadeTipo, opts.entidadeId);
  const render = await renderTemplate(tipo, { ...vars, nome: user.nome, link });
  const notif = await prisma.notificacao.create({
    data: {
      userId,
      tipo,
      titulo: render.titulo,
      corpo: render.corpo || null,
      entidadeTipo: opts.entidadeTipo ?? null,
      entidadeId: opts.entidadeId ?? null
    }
  });
  notificationService.emitToUser(userId, "notificacao", notif);
  const podeEmail = EMAIL_TIPOS.includes(tipo) && user.ativo && !user.deletedAt && !!user.email && !user.email.startsWith("deleted+");
  if (podeEmail) {
    const pref = await prisma.preferenciaEmail.findUnique({
      where: { userId_tipo: { userId, tipo } },
      select: { ativo: true }
    });
    if (!pref || pref.ativo) {
      const para = user.email;
      void enviarEmail({ para, assunto: render.assunto, html: render.html, texto: render.texto }).then(({ enviado, erro }) => registrarEmailEnviado(para, render.assunto, render.texto ?? "", tipo, enviado, erro)).catch(() => {
      });
    }
  }
}
async function listarPreferenciasEmail(userId, role) {
  const rows = await prisma.preferenciaEmail.findMany({ where: { userId }, select: { tipo: true, ativo: true } });
  const map = new Map(rows.map((r) => [r.tipo, r.ativo]));
  return EMAIL_CATEGORIAS.filter((c) => !c.minRole || hasRoleLevel(role, c.minRole)).map((c) => ({
    tipo: c.tipo,
    label: c.label,
    descricao: c.descricao,
    ativo: map.get(c.tipo) ?? true
  }));
}
async function setPreferenciaEmail(userId, tipo, ativo) {
  await prisma.preferenciaEmail.upsert({
    where: { userId_tipo: { userId, tipo } },
    create: { userId, tipo, ativo },
    update: { ativo }
  });
  return { ok: true };
}

export {
  config,
  isProd,
  isAiEnabled,
  ROLE_LEVEL,
  hasRoleLevel,
  qualificacaoContratada,
  loginSchema,
  updateProfileSchema,
  changePasswordSchema,
  aceitarConviteSchema,
  solicitarResetSchema,
  redefinirSenhaSchema,
  SITUACOES_CLIENTE,
  setAtivoClienteSchema,
  createClienteSchema,
  updateClienteSchema,
  portalMeusDadosSchema,
  createContatoSchema,
  createNotaSchema,
  createLeadSchema,
  updateLeadSchema,
  moveLeadSchema,
  novaOportunidadeSchema,
  solicitarServicosSchema,
  capturaLeadSchema,
  createServicoSchema,
  updateServicoSchema,
  setRoteiroSchema,
  createOrigemSchema,
  updateOrigemSchema,
  addServicoPassoSchema,
  updateServicoPassoSchema,
  addRequisitoSchema,
  updateRequisitoSchema,
  ativarServicoClienteSchema,
  cancelarServicoClienteSchema,
  atualizarContratacaoClienteSchema,
  createProjetoSchema,
  updateProjetoSchema,
  setParticipantesSchema,
  createCardSchema,
  updateCardSchema,
  moveCardSchema,
  addChecklistSchema,
  createEventoSchema,
  updateEventoSchema,
  listEventosSchema,
  conflitoEventoSchema,
  resumoAgendaSchema,
  carteiraInputSchema,
  createContaSchema,
  updateContaSchema,
  listContasSchema,
  marcarPagaSchema,
  listCategoriasSchema,
  createCategoriaSchema,
  updateCategoriaSchema,
  createUsuarioSchema,
  inviteUsuarioSchema,
  updateUsuarioSchema,
  deleteUsuarioSchema,
  startIndividualSchema,
  createGrupoSchema,
  sendMensagemSchema,
  renomearGrupoSchema,
  gerirParticipanteSchema,
  addParticipantesSchema,
  conversaIdSchema,
  iniciarChamadoSchema,
  setChamadoStatusSchema,
  setChamadoResponsavelSchema,
  setChamadoAssuntoSchema,
  setChamadoPrioridadeSchema,
  editarMensagemSchema,
  mensagemIdSchema,
  togglePreferenciaSchema,
  portalAbrirChamadoSchema,
  portalEnviarChamadoSchema,
  assinarSchema,
  statusDocumentoEnum,
  situacaoDocumento,
  createModeloSchema,
  updateModeloSchema,
  createDocumentoSchema,
  OPERADORAS_COMUNS,
  criarPropostaSchema,
  criarContratoSchema,
  contextoClienteDocSchema,
  updateConteudoSchema,
  responderPropostaSchema,
  setStatusDocumentoSchema,
  gerarComIASchema,
  melhorarComIASchema,
  resumirReuniaoSchema,
  gerarPautaSchema,
  createFormularioSchema,
  updateFormularioSchema,
  addCampoSchema,
  updateCampoSchema,
  salvarRespostaSchema,
  getSlowQueries,
  prisma,
  src_exports,
  SESSION_COOKIE,
  createSession,
  getUserFromSession,
  destroySession,
  SESSION_TTL_SECONDS,
  listarTemplates,
  atualizarTemplate,
  resetarTemplate,
  gerarPreview,
  enviarTeste,
  enviarEmailTemplate,
  listPorLead,
  listPorCliente,
  listMeus,
  resumoEnviados,
  listTodos,
  initRealtime,
  notificationService,
  contarConexoesSocket,
  listNotificacoes,
  markAllRead,
  markRead,
  notificar,
  listarPreferenciasEmail,
  setPreferenciaEmail
};
//# sourceMappingURL=chunk-RQVINKOG.js.map