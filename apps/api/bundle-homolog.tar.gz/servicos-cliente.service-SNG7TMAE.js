import {
  ativarServicoCliente,
  atualizarContratacaoCliente,
  cancelarServicoCliente,
  servicosDoCliente,
  servicosDoClientePortal,
  sincronizarServicosContratados
} from "./chunk-UT3JPKGF.js";
import "./chunk-RC5JM4L5.js";
import "./chunk-RQVINKOG.js";
export {
  ativarServicoCliente,
  atualizarContratacaoCliente,
  cancelarServicoCliente,
  servicosDoCliente,
  servicosDoClientePortal,
  sincronizarServicosContratados
};
//# sourceMappingURL=servicos-cliente.service-SNG7TMAE.js.map