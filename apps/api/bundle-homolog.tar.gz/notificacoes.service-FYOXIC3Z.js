import {
  listNotificacoes,
  listarPreferenciasEmail,
  markAllRead,
  markRead,
  notificar,
  setPreferenciaEmail
} from "./chunk-RQVINKOG.js";
export {
  listNotificacoes,
  listarPreferenciasEmail,
  markAllRead,
  markRead,
  notificar,
  setPreferenciaEmail
};
//# sourceMappingURL=notificacoes.service-FYOXIC3Z.js.map