import {
  garantirCardDoServicoContratado,
  reconciliarCardsDoServico
} from "./chunk-RC5JM4L5.js";
import {
  config,
  enviarEmailTemplate,
  isProd,
  notificar,
  prisma,
  src_exports
} from "./chunk-RQVINKOG.js";

// src/modules/servicos/servicos-cliente.service.ts
import { TRPCError as TRPCError3 } from "@trpc/server";

// src/modules/arquivos/arquivos.service.ts
import { TRPCError } from "@trpc/server";

// src/lib/storage.ts
import { resolve, sep, extname, isAbsolute } from "path";
import { mkdir, unlink, writeFile, readFile } from "fs/promises";
import { createWriteStream } from "fs";
import { pipeline } from "stream/promises";
import { randomUUID } from "crypto";
var BASE = resolve(process.cwd(), config.UPLOADS_DIR);
var MIMETYPES_ACEITOS = /* @__PURE__ */ new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
]);
var TAMANHO_MAX = 20 * 1024 * 1024;
var MIMETYPES_IMAGEM = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp"]);
var AVATAR_MAX = 5 * 1024 * 1024;
async function validarPastaUploads() {
  const absoluto = isAbsolute(config.UPLOADS_DIR);
  const relatorio = { ok: false, base: BASE, absoluto, escrita: false, detalhe: void 0 };
  if (isProd && !absoluto) {
    relatorio.detalhe = `Em produ\xE7\xE3o, UPLOADS_DIR deve ser um caminho ABSOLUTO e persistente (fora do diret\xF3rio do deploy). Valor atual (relativo): "${config.UPLOADS_DIR}". Ajuste no .env do servidor.`;
    if (isProd) throw new Error("[uploads] " + relatorio.detalhe);
    return relatorio;
  }
  try {
    await mkdir(BASE, { recursive: true });
    const teste = resolve(BASE, `.rwtest-${randomUUID()}`);
    await writeFile(teste, "ok");
    const lido = await readFile(teste, "utf8");
    await unlink(teste);
    relatorio.escrita = lido === "ok";
    relatorio.ok = relatorio.escrita && (!isProd || absoluto);
    if (!relatorio.escrita) relatorio.detalhe = "Escrita/leitura de teste falhou (conte\xFAdo divergente).";
  } catch (e) {
    relatorio.detalhe = `Sem permiss\xE3o de escrita em "${BASE}": ${e.message}`;
    if (isProd) throw new Error("[uploads] " + relatorio.detalhe);
  }
  return relatorio;
}
function caminhoAbsoluto(rel) {
  const abs = resolve(BASE, rel);
  if (abs !== BASE && !abs.startsWith(BASE + sep)) {
    throw new Error("Caminho de arquivo inv\xE1lido.");
  }
  return abs;
}
async function salvarArquivo(clienteId, nomeOriginal, stream) {
  const ext = extname(nomeOriginal).slice(0, 12).replace(/[^.\w]/g, "");
  const rel = `clientes/${clienteId}/${randomUUID()}${ext}`;
  const abs = caminhoAbsoluto(rel);
  await mkdir(resolve(abs, ".."), { recursive: true });
  let tamanho = 0;
  stream.on("data", (chunk) => {
    tamanho += chunk.length;
  });
  await pipeline(stream, createWriteStream(abs));
  return { caminho: rel, tamanho };
}
async function salvarAvatar(userId, nomeOriginal, stream) {
  const ext = extname(nomeOriginal).slice(0, 12).replace(/[^.\w]/g, "") || ".png";
  const rel = `avatars/${userId}/${randomUUID()}${ext}`;
  const abs = caminhoAbsoluto(rel);
  await mkdir(resolve(abs, ".."), { recursive: true });
  let tamanho = 0;
  stream.on("data", (chunk) => {
    tamanho += chunk.length;
  });
  await pipeline(stream, createWriteStream(abs));
  return { caminho: rel, tamanho };
}
async function removerArquivo(rel) {
  try {
    await unlink(caminhoAbsoluto(rel));
  } catch {
  }
}

// src/modules/arquivos/arquivos.service.ts
async function equipeDoCliente(clienteId, excluir) {
  const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { responsavelId: true } });
  const gestao = await prisma.user.findMany({
    where: { ativo: true, deletedAt: null, role: { in: ["ADMIN", "ROOT"] } },
    select: { id: true }
  });
  const ids = new Set(gestao.map((g) => g.id));
  if (cliente?.responsavelId) ids.add(cliente.responsavelId);
  if (excluir) ids.delete(excluir);
  return [...ids];
}
async function registrarUpload(input) {
  const arquivo = await prisma.arquivo.create({
    data: {
      clienteId: input.clienteId,
      servicoId: input.servicoId ?? null,
      requisitoId: input.requisitoId ?? null,
      nome: input.nome,
      mimetype: input.mimetype,
      tamanho: input.tamanho,
      caminho: input.caminho,
      enviadoPorTipo: input.enviadoPorTipo,
      enviadoPorId: input.enviadoPorId
    }
  });
  if (input.enviadoPorTipo === "CLIENTE") {
    const cliente = await prisma.cliente.findUnique({ where: { id: input.clienteId }, select: { nome: true } });
    const destinos = await equipeDoCliente(input.clienteId);
    for (const uid of destinos) {
      await notificar(
        uid,
        "documento_cliente_enviado",
        { cliente: cliente?.nome ?? "Cliente", documento: input.nome },
        { entidadeTipo: "cliente", entidadeId: input.clienteId }
      ).catch(() => {
      });
    }
  }
  if (input.requisitoId) {
    const servicoId = input.servicoId ?? (await prisma.servicoRequisito.findUnique({ where: { id: input.requisitoId }, select: { servicoId: true } }))?.servicoId ?? null;
    if (servicoId) await reconciliarCardsDoServico(input.clienteId, servicoId).catch(() => {
    });
  }
  return arquivo;
}
async function listarArquivos(clienteId, servicoId) {
  const rows = await prisma.arquivo.findMany({
    where: { clienteId, deletedAt: null, ...servicoId ? { servicoId } : {} },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      nome: true,
      mimetype: true,
      tamanho: true,
      servicoId: true,
      requisitoId: true,
      enviadoPorTipo: true,
      createdAt: true,
      servico: { select: { nome: true } },
      requisito: { select: { titulo: true } }
    }
  });
  return rows;
}
async function getArquivo(id) {
  const arquivo = await prisma.arquivo.findFirst({
    where: { id, deletedAt: null },
    select: { id: true, nome: true, mimetype: true, caminho: true, clienteId: true }
  });
  if (!arquivo) throw new TRPCError({ code: "NOT_FOUND", message: "Arquivo n\xE3o encontrado." });
  return arquivo;
}
async function removerArquivo2(id, clienteScope, removidoPorId) {
  const arquivo = await prisma.arquivo.findFirst({
    where: { id, deletedAt: null },
    select: { id: true, caminho: true, clienteId: true, servicoId: true, requisitoId: true }
  });
  if (!arquivo) throw new TRPCError({ code: "NOT_FOUND", message: "Arquivo n\xE3o encontrado." });
  if (clienteScope && arquivo.clienteId !== clienteScope) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sem acesso a este arquivo." });
  }
  await prisma.arquivo.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  await removerArquivo(arquivo.caminho);
  if (removidoPorId) {
    await prisma.activityLog.create({ data: { userId: removidoPorId, acao: "arquivo.removido", entidadeTipo: "arquivo", entidadeId: id } }).catch(() => {
    });
  }
  if (arquivo.requisitoId) {
    const servicoId = arquivo.servicoId ?? (await prisma.servicoRequisito.findUnique({ where: { id: arquivo.requisitoId }, select: { servicoId: true } }))?.servicoId ?? null;
    if (servicoId) await reconciliarCardsDoServico(arquivo.clienteId, servicoId).catch(() => {
    });
  }
  return { ok: true };
}

// src/modules/servicos/servicos.service.ts
import { TRPCError as TRPCError2 } from "@trpc/server";
var CLAUSULAS_SERVICOS = {
  "Gest\xE3o Operacional": "A CONTRATADA far\xE1 o mapeamento dos processos da cl\xEDnica (da agenda ao pagamento), identificar\xE1 gargalos e propor\xE1 melhorias, treinar\xE1 a equipe e definir\xE1 indicadores de acompanhamento. Entreg\xE1veis: diagn\xF3stico operacional, plano de organiza\xE7\xE3o e rotina de acompanhamento dos resultados. A CONTRATANTE fornecer\xE1 as informa\xE7\xF5es da opera\xE7\xE3o e disponibilizar\xE1 a equipe para as atividades de implanta\xE7\xE3o.",
  Faturamento: "A CONTRATADA realizar\xE1 a gest\xE3o do faturamento m\xE9dico: auditoria e confer\xEAncia das guias, processamento junto \xE0s operadoras, concilia\xE7\xE3o de pagamentos, recurso de glosas e relat\xF3rios gerenciais. A remunera\xE7\xE3o observar\xE1 o percentual acordado sobre o valor efetivamente faturado, apurado mensalmente. A CONTRATANTE fornecer\xE1 tempestivamente as guias, os demonstrativos das operadoras e o acesso necess\xE1rio aos portais de faturamento.",
  "Credenciamento m\xE9dico e odontol\xF3gico": "A CONTRATADA conduzir\xE1 o processo de credenciamento da CONTRATANTE junto \xE0s operadoras e conv\xEAnios selecionados \u2014 organiza\xE7\xE3o documental, cadastro, protocolo e acompanhamento at\xE9 a efetiva\xE7\xE3o. A CONTRATADA envidar\xE1 os melhores esfor\xE7os na condu\xE7\xE3o; a aprova\xE7\xE3o final, contudo, \xE9 ato exclusivo de cada operadora e n\xE3o constitui obriga\xE7\xE3o de resultado da CONTRATADA. A CONTRATANTE fornecer\xE1 os documentos exigidos de forma completa e ver\xEDdica.",
  "Negocia\xE7\xE3o com operadoras": "A CONTRATADA analisar\xE1 os contratos e tabelas vigentes com as operadoras e conduzir\xE1 a renegocia\xE7\xE3o de valores, prazos e condi\xE7\xF5es, buscando melhores termos para a CONTRATANTE. Os resultados dependem da aceita\xE7\xE3o das operadoras; a CONTRATADA n\xE3o garante \xEDndice espec\xEDfico de reajuste. A CONTRATANTE autorizar\xE1 a CONTRATADA a represent\xE1-la nas tratativas e fornecer\xE1 os contratos e demonstrativos necess\xE1rios.",
  "Identidade visual (Branding)": "A CONTRATADA desenvolver\xE1 a identidade visual da marca \u2014 logotipo, paleta de cores e tipografia \u2014 com base no briefing aprovado. Est\xE3o inclu\xEDdas as rodadas de ajuste previstas no escopo; ap\xF3s a aprova\xE7\xE3o final, os arquivos s\xE3o entregues nos formatos padr\xE3o de uso. A cess\xE3o do direito de uso da identidade visual \xE0 CONTRATANTE se d\xE1 com a quita\xE7\xE3o integral do servi\xE7o.",
  "Manual da marca": "A CONTRATADA produzir\xE1 o manual da marca com as diretrizes de aplica\xE7\xE3o da identidade visual (usos corretos, cores, tipografia, espa\xE7amentos e exemplos). O entreg\xE1vel \xE9 o documento do manual em formato digital. Este servi\xE7o pressup\xF5e uma identidade visual j\xE1 definida, pr\xF3pria ou desenvolvida pela CONTRATADA.",
  "Desenvolvimento de site": "A CONTRATADA desenvolver\xE1 o site/p\xE1gina conforme o escopo e o briefing aprovados \u2014 layout responsivo, otimiza\xE7\xE3o b\xE1sica para busca (SEO) e publica\xE7\xE3o. Dom\xEDnio, hospedagem e licen\xE7as de terceiros correm por conta da CONTRATANTE, salvo ajuste em contr\xE1rio. A CONTRATANTE fornecer\xE1 textos, imagens e acessos necess\xE1rios; altera\xE7\xF5es fora do escopo aprovado poder\xE3o ser or\xE7adas \xE0 parte.",
  "Gest\xE3o de redes sociais": "A CONTRATADA far\xE1 a gest\xE3o das redes sociais conforme o plano contratado \u2014 planejamento de pauta, cria\xE7\xE3o e publica\xE7\xE3o de conte\xFAdo e acompanhamento de resultados. A CONTRATANTE aprovar\xE1 o calend\xE1rio de postagens e observar\xE1 as normas dos conselhos (CFM/CRO) sobre publicidade na \xE1rea da sa\xFAde. Custos de m\xEDdia paga n\xE3o est\xE3o inclu\xEDdos, salvo previs\xE3o expressa.",
  "Conte\xFAdo & SEO": "A CONTRATADA produzir\xE1 conte\xFAdo e executar\xE1 a\xE7\xF5es de otimiza\xE7\xE3o para busca (SEO) conforme o plano contratado, visando aumentar a relev\xE2ncia e o alcance org\xE2nico. O posicionamento nos mecanismos de busca depende de fatores externos; a CONTRATADA n\xE3o garante posi\xE7\xE3o espec\xEDfica. A CONTRATANTE aprovar\xE1 as pautas e fornecer\xE1 as informa\xE7\xF5es necess\xE1rias.",
  "Tr\xE1fego pago": "A CONTRATADA planejar\xE1, configurar\xE1 e gerenciar\xE1 campanhas de tr\xE1fego pago (an\xFAncios) conforme o plano contratado, com acompanhamento e otimiza\xE7\xE3o dos resultados. O investimento em m\xEDdia (verba dos an\xFAncios) \xE9 custeado diretamente pela CONTRATANTE e n\xE3o integra os honor\xE1rios da CONTRATADA. Os resultados dependem das plataformas e do mercado; n\xE3o h\xE1 garantia de retorno espec\xEDfico."
};
var CONTEUDO_SERVICOS = [
  {
    nome: "Gest\xE3o Operacional",
    categoria: "Gest\xE3o",
    valor: 3500,
    valorRecorrencia: "MENSAL",
    descricao: "Organizamos a opera\xE7\xE3o da cl\xEDnica de ponta a ponta \u2014 da agenda ao pagamento: mapeamento de processos, redu\xE7\xE3o de gargalos, treinamento da equipe e indicadores para acompanhar os resultados.",
    requisitos: [
      { titulo: "Lista da equipe atual", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Quem faz o qu\xEA hoje (fun\xE7\xF5es e respons\xE1veis)." },
      { titulo: "Organograma da equipe", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Estrutura hier\xE1rquica e fun\xE7\xF5es de cada membro da equipe." },
      { titulo: "Fluxo de atendimento atual (se houver)", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Tabela de hor\xE1rios e escalas da equipe", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Qual o hor\xE1rio de funcionamento da cl\xEDnica?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Dias e hor\xE1rios de atendimento, incluindo intervalos." },
      { titulo: "Quais os principais gargalos que voc\xEA percebe hoje?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Onde a opera\xE7\xE3o trava: agenda, faturamento, atendimento, no-show\u2026" },
      { titulo: "Quantos atendimentos, em m\xE9dia, por dia?", tipo: "INFORMACAO", obrigatorio: false },
      { titulo: "Quais sistemas a cl\xEDnica usa hoje?", tipo: "INFORMACAO", obrigatorio: false, descricao: "Agenda, prontu\xE1rio, financeiro \u2014 cite os nomes (sem senhas)." }
    ],
    passos: [
      { titulo: "Mapear os processos atuais da cl\xEDnica", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Levantar equipe e ferramentas em uso", etapaChave: "qualificacao", obrigatorio: false },
      { titulo: "Aplicar diagn\xF3stico operacional (da agenda ao pagamento)", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Montar plano de organiza\xE7\xE3o operacional", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Apresentar indicadores e metas de melhoria", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Definir escopo e cronograma de implanta\xE7\xE3o", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Alinhar respons\xE1veis e rotina de acompanhamento", etapaChave: "negociacao", obrigatorio: false },
      { titulo: "Kickoff de implanta\xE7\xE3o com a equipe", etapaChave: "fechado", obrigatorio: true },
      { titulo: "Configurar a rotina de monitoramento de resultados", etapaChave: "fechado", obrigatorio: false }
    ]
  },
  {
    nome: "Faturamento",
    categoria: "Faturamento",
    // Faturamento de contas médicas: normalmente um % sobre o valor faturado, cobrado por mês.
    // (É o único serviço com opção de %.) A Med pode ajustar para valor fixo + % se quiser.
    valor: null,
    percentual: 5,
    percentualRecorrencia: "MENSAL",
    descricao: "Cuidamos do faturamento m\xE9dico completo: auditoria das guias, processamento, concilia\xE7\xE3o de pagamentos, recurso de glosas e relat\xF3rios gerenciais \u2014 para voc\xEA receber tudo o que \xE9 seu, no prazo.",
    requisitos: [
      { titulo: "Rela\xE7\xE3o de guias/atendimentos do per\xEDodo", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Planilha ou relat\xF3rio dos atendimentos a faturar." },
      { titulo: "Demonstrativos de pagamento das operadoras (\xFAltimos 3 meses)", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Extratos/demonstrativos que mostram pagamentos e glosas." },
      { titulo: "Tabelas de procedimentos das operadoras", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Relat\xF3rio de glosas do per\xEDodo (se houver)", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Quais operadoras voc\xEA atende?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Liste os conv\xEAnios (Unimed, Bradesco, Amil, SUS\u2026)." },
      { titulo: "Qual o volume m\xE9dio de guias por m\xEAs?", tipo: "INFORMACAO", obrigatorio: false },
      { titulo: "Como a equipe acessa os portais das operadoras?", tipo: "INFORMACAO", obrigatorio: false, descricao: "Descreva o acesso aos portais de faturamento (sem senhas por escrito)." }
    ],
    passos: [
      { titulo: "Analisar hist\xF3rico de faturamento e glosas", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Auditar uma amostra de guias e glosas", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Apresentar diagn\xF3stico e plano de recupera\xE7\xE3o de glosas", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Estimar o valor recuper\xE1vel de glosas", etapaChave: "proposta", obrigatorio: false },
      { titulo: "Definir a rotina de auditoria e relat\xF3rios", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Implantar a confer\xEAncia pr\xE9-envio das guias", etapaChave: "fechado", obrigatorio: true },
      { titulo: "Definir o relat\xF3rio gerencial mensal", etapaChave: "fechado", obrigatorio: false }
    ]
  },
  {
    nome: "Credenciamento m\xE9dico e odontol\xF3gico",
    categoria: "Networking",
    valor: 1500,
    descricao: "Cuidamos de todo o processo de credenciamento de m\xE9dicos e dentistas junto \xE0s operadoras de sa\xFAde \u2014 da documenta\xE7\xE3o \xE0 efetiva\xE7\xE3o, sem burocracia para voc\xEA.",
    requisitos: [
      { titulo: "RG e CPF do m\xE9dico", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Documento de identidade e CPF de cada profissional a credenciar." },
      { titulo: "CRM/CRO e comprovante de especializa\xE7\xE3o", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Registro no conselho e certificados de especialidade/RQE." },
      { titulo: "Diploma e certificado de especializa\xE7\xE3o (RQE)", tipo: "DOCUMENTO", obrigatorio: true },
      { titulo: "Comprovante de endere\xE7o da cl\xEDnica", tipo: "DOCUMENTO", obrigatorio: true },
      { titulo: "CNPJ e contrato social da cl\xEDnica (se PJ)", tipo: "DOCUMENTO", obrigatorio: false, descricao: "Necess\xE1rio quando o credenciamento \xE9 por pessoa jur\xEDdica." },
      { titulo: "Alvar\xE1 de funcionamento e licen\xE7a sanit\xE1ria", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Dados banc\xE1rios para repasse", tipo: "DOCUMENTO", obrigatorio: false, descricao: "Banco, ag\xEAncia e conta para os pagamentos da operadora." },
      { titulo: "Quais operadoras deseja credenciar?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Liste os conv\xEAnios de interesse (Unimed, Bradesco, Amil\u2026)." },
      { titulo: "J\xE1 possui algum credenciamento ativo?", tipo: "INFORMACAO", obrigatorio: false }
    ],
    passos: [
      { titulo: "Levantar operadoras de interesse", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Coletar documentos do profissional/cl\xEDnica", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Conferir documenta\xE7\xE3o e apontar pend\xEAncias", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Apresentar proposta de credenciamento", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Definir operadoras-alvo e prioridades", etapaChave: "proposta", obrigatorio: false },
      { titulo: "Negociar tabelas e contrato com a operadora", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Protocolar a solicita\xE7\xE3o junto \xE0s operadoras", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Acompanhar a an\xE1lise e efetivar o credenciamento", etapaChave: "fechado", obrigatorio: true }
    ]
  },
  {
    nome: "Negocia\xE7\xE3o com operadoras",
    categoria: "Networking",
    valor: 1200,
    descricao: "Analisamos e renegociamos seus contratos e tabelas com as operadoras para corrigir valores defasados, melhorar prazos e aumentar a sua rentabilidade.",
    requisitos: [
      { titulo: "Contratos vigentes com as operadoras", tipo: "DOCUMENTO", obrigatorio: true, descricao: "C\xF3pia dos contratos atuais a renegociar." },
      { titulo: "Tabelas de valores praticadas hoje", tipo: "DOCUMENTO", obrigatorio: true },
      { titulo: "Hist\xF3rico de faturamento por operadora", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Quais operadoras deseja renegociar e por qu\xEA?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Ex.: valores defasados, glosas recorrentes, prazo de pagamento." },
      { titulo: "Qual seu volume mensal com cada operadora?", tipo: "INFORMACAO", obrigatorio: false }
    ],
    passos: [
      { titulo: "Levantar contratos e tabelas vigentes", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Comparar valores com a m\xE9dia de mercado", etapaChave: "qualificacao", obrigatorio: false },
      { titulo: "Apresentar diagn\xF3stico e metas de reajuste", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Conduzir a negocia\xE7\xE3o com a operadora", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Formalizar o aditivo / atualiza\xE7\xE3o de tabela", etapaChave: "fechado", obrigatorio: true }
    ]
  },
  {
    nome: "Identidade visual (Branding)",
    categoria: "Desenvolvimento",
    valor: 2500,
    descricao: "Criamos a identidade visual da sua marca \u2014 logotipo, paleta de cores e tipografia \u2014 para transmitir confian\xE7a e profissionalismo em cada ponto de contato.",
    requisitos: [
      { titulo: "Logo e materiais atuais (se houver)", tipo: "DOCUMENTO", obrigatorio: false, descricao: "Arquivos da marca atual, em qualquer formato." },
      { titulo: "Fotos suas / do consult\xF3rio (se for usar)", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Como quer que a marca seja percebida em 3 palavras?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Ex.: acolhedora, moderna, confi\xE1vel." },
      { titulo: "Marcas/concorrentes que voc\xEA admira", tipo: "INFORMACAO", obrigatorio: false }
    ],
    passos: [
      { titulo: "Enviar e receber o briefing de identidade", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Analisar posicionamento e p\xFAblico", etapaChave: "qualificacao", obrigatorio: false },
      { titulo: "Apresentar proposta e conceito criativo", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Aprovar a dire\xE7\xE3o visual (moodboard)", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Entregar logo e aplica\xE7\xF5es finais", etapaChave: "fechado", obrigatorio: true }
    ]
  },
  {
    nome: "Manual da marca",
    categoria: "Desenvolvimento",
    valor: 1500,
    descricao: "Produzimos o manual da marca com todas as diretrizes de uso da identidade visual, garantindo consist\xEAncia em site, redes, impressos e ambiente.",
    requisitos: [
      { titulo: "Arquivos da identidade visual aprovada", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Logo, cores e tipografia j\xE1 definidos." },
      { titulo: "Onde a marca ser\xE1 mais usada?", tipo: "INFORMACAO", obrigatorio: false, descricao: "Site, redes, fachada, jaleco, papelaria\u2026" }
    ],
    passos: [
      { titulo: "Reunir os elementos da identidade aprovada", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Apresentar a estrutura do manual", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Aprovar as diretrizes de uso", etapaChave: "negociacao", obrigatorio: false },
      { titulo: "Entregar o manual da marca (PDF)", etapaChave: "fechado", obrigatorio: true }
    ]
  },
  {
    nome: "Desenvolvimento de site",
    categoria: "Desenvolvimento",
    valor: 4e3,
    descricao: "Desenvolvemos sites e p\xE1ginas r\xE1pidos, responsivos e otimizados para SEO, pensados para transformar visitantes em agendamentos.",
    requisitos: [
      { titulo: "Logo em alta resolu\xE7\xE3o (vetor)", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Preferencialmente .SVG, .AI ou .PDF." },
      { titulo: "Materiais de marca atuais (logo, cores)", tipo: "DOCUMENTO", obrigatorio: false, descricao: "Se j\xE1 tiver identidade visual, envie os arquivos." },
      { titulo: "Fotos do consult\xF3rio e da equipe", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Refer\xEAncias visuais que voc\xEA gosta", tipo: "INFORMACAO", obrigatorio: false, descricao: "Cole links de sites/perfis e diga o que gostou em cada um." },
      { titulo: "J\xE1 tem dom\xEDnio e hospedagem?", tipo: "INFORMACAO", obrigatorio: false, descricao: "Ex.: www.suaclinica.com.br \u2014 se sim, informe qual e onde est\xE1." },
      { titulo: "Quais servi\xE7os/textos devem aparecer no site?", tipo: "INFORMACAO", obrigatorio: false }
    ],
    passos: [
      { titulo: "Entender objetivos de marca e presen\xE7a digital", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Enviar e receber o briefing de site", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Apresentar proposta de site", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Apresentar a estrutura de p\xE1ginas (sitemap)", etapaChave: "proposta", obrigatorio: false },
      { titulo: "Aprovar escopo criativo e cronograma", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Publicar o site e configurar o SEO b\xE1sico", etapaChave: "fechado", obrigatorio: true },
      { titulo: "Treinar o cliente para atualizar o conte\xFAdo", etapaChave: "fechado", obrigatorio: false }
    ]
  },
  {
    nome: "Gest\xE3o de redes sociais",
    categoria: "Marketing",
    valor: 1800,
    valorRecorrencia: "MENSAL",
    descricao: "Cuidamos das suas redes sociais de ponta a ponta \u2014 estrat\xE9gia, conte\xFAdo e publica\xE7\xE3o \u2014 sempre dentro das normas de publicidade m\xE9dica do CFM.",
    requisitos: [
      { titulo: "Acesso aos perfis (ou convite de administrador)", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Como daremos entrada nas contas (Meta Business, convite\u2026)." },
      { titulo: "Fotos e v\xEDdeos dispon\xEDveis", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Quais perfis/@ vamos gerenciar?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Instagram, Facebook, TikTok\u2026 informe os @." },
      { titulo: "Frequ\xEAncia de postagem desejada", tipo: "INFORMACAO", obrigatorio: false }
    ],
    passos: [
      { titulo: "Enviar e receber o briefing de redes", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Auditar a presen\xE7a atual nas redes", etapaChave: "qualificacao", obrigatorio: false },
      { titulo: "Apresentar plano de conte\xFAdo e frequ\xEAncia", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Aprovar a linha editorial e o tom de voz", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Montar o calend\xE1rio do 1\xBA m\xEAs", etapaChave: "fechado", obrigatorio: true }
    ]
  },
  {
    nome: "Conte\xFAdo & SEO",
    categoria: "Marketing",
    valor: 1500,
    valorRecorrencia: "MENSAL",
    descricao: "Produzimos conte\xFAdo relevante e otimizamos seu site para o Google, aumentando sua autoridade e atraindo pacientes que j\xE1 est\xE3o procurando por voc\xEA.",
    requisitos: [
      { titulo: "Acesso ao site / Google Search Console", tipo: "DOCUMENTO", obrigatorio: false, descricao: "Convite de acesso para acompanharmos o desempenho." },
      { titulo: "Quais assuntos/especialidades quer destacar?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Temas que o seu p\xFAblico mais pesquisa." },
      { titulo: "Cidade/regi\xE3o que voc\xEA quer atingir", tipo: "INFORMACAO", obrigatorio: true, descricao: "Importante para o SEO local." }
    ],
    passos: [
      { titulo: "Levantar palavras-chave e concorrentes", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Apresentar o plano de conte\xFAdo e SEO", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Aprovar a pauta e o cronograma", etapaChave: "negociacao", obrigatorio: false },
      { titulo: "Publicar os primeiros conte\xFAdos otimizados", etapaChave: "fechado", obrigatorio: true }
    ]
  },
  {
    nome: "Tr\xE1fego pago",
    categoria: "Marketing",
    valor: 1200,
    valorRecorrencia: "MENSAL",
    descricao: "Criamos e gerimos campanhas de an\xFAncios no Google e nas redes, dentro das normas do CFM, para gerar mais agendamentos com previsibilidade.",
    requisitos: [
      { titulo: "Acesso \xE0 conta de an\xFAncios (Meta/Google Ads)", tipo: "DOCUMENTO", obrigatorio: true, descricao: "Convite de administrador no Gerenciador de Neg\xF3cios." },
      { titulo: "Materiais/criativos dispon\xEDveis", tipo: "DOCUMENTO", obrigatorio: false },
      { titulo: "Qual o objetivo da campanha?", tipo: "INFORMACAO", obrigatorio: true, descricao: "Ex.: mais agendamentos, divulgar um servi\xE7o, autoridade." },
      { titulo: "Qual a verba mensal de an\xFAncios?", tipo: "INFORMACAO", obrigatorio: true },
      { titulo: "Regi\xE3o e p\xFAblico que quer alcan\xE7ar", tipo: "INFORMACAO", obrigatorio: false }
    ],
    passos: [
      { titulo: "Definir objetivo e p\xFAblico da campanha", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Verificar a conformidade com o CFM", etapaChave: "qualificacao", obrigatorio: true },
      { titulo: "Apresentar o plano de m\xEDdia e a verba", etapaChave: "proposta", obrigatorio: true },
      { titulo: "Aprovar criativos e segmenta\xE7\xE3o", etapaChave: "negociacao", obrigatorio: true },
      { titulo: "Subir a campanha e configurar as m\xE9tricas", etapaChave: "fechado", obrigatorio: true }
    ]
  }
];
var ROTEIROS_SERVICO = {
  "Gest\xE3o Operacional": [
    { titulo: "Diagn\xF3stico da opera\xE7\xE3o", itens: ["Mapear os processos atuais", "Levantar equipe e ferramentas em uso", "Aplicar o diagn\xF3stico (da agenda ao pagamento)"] },
    { titulo: "Plano de a\xE7\xE3o", itens: ["Definir os gargalos priorit\xE1rios", "Montar o plano de organiza\xE7\xE3o", "Definir indicadores e metas"] },
    { titulo: "Implanta\xE7\xE3o", itens: ["Kickoff com a equipe", "Implantar os novos fluxos", "Treinar a equipe"] },
    { titulo: "Acompanhamento", itens: ["Configurar o monitoramento de resultados", "Primeira revis\xE3o de resultados"] }
  ],
  Faturamento: [
    { titulo: "Diagn\xF3stico do faturamento", itens: ["Analisar o hist\xF3rico e as glosas", "Auditar uma amostra de guias"] },
    { titulo: "Plano de recupera\xE7\xE3o", itens: ["Montar o plano de recupera\xE7\xE3o de glosas", "Estimar o valor recuper\xE1vel"] },
    { titulo: "Rotina de faturamento", itens: ["Definir a rotina de auditoria", "Implantar a confer\xEAncia pr\xE9-envio", "Definir o relat\xF3rio gerencial mensal"] }
  ],
  "Credenciamento m\xE9dico e odontol\xF3gico": [
    { titulo: "Prepara\xE7\xE3o", itens: ["Conferir a documenta\xE7\xE3o", "Definir as operadoras-alvo e prioridades"] },
    { titulo: "Submiss\xE3o \xE0s operadoras", itens: ["Apresentar a proposta de credenciamento", "Protocolar a solicita\xE7\xE3o"] },
    { titulo: "Negocia\xE7\xE3o", itens: ["Negociar tabelas e contrato"] },
    { titulo: "Efetiva\xE7\xE3o", itens: ["Acompanhar a an\xE1lise", "Efetivar o credenciamento"] }
  ],
  "Negocia\xE7\xE3o com operadoras": [
    { titulo: "Diagn\xF3stico", itens: ["Levantar contratos e tabelas vigentes", "Comparar com a m\xE9dia de mercado"] },
    { titulo: "Negocia\xE7\xE3o", itens: ["Apresentar as metas de reajuste", "Conduzir a negocia\xE7\xE3o"] },
    { titulo: "Fechamento", itens: ["Formalizar o aditivo / atualiza\xE7\xE3o de tabela"] }
  ],
  "Identidade visual (Branding)": [
    { titulo: "Imers\xE3o", itens: ["Analisar o briefing", "Estudar o posicionamento e o p\xFAblico"] },
    { titulo: "Cria\xE7\xE3o", itens: ["Montar o moodboard / conceito", "Criar propostas de logotipo"] },
    { titulo: "Refinamento", itens: ["Aprovar a dire\xE7\xE3o visual", "Ajustes finais"] },
    { titulo: "Entrega", itens: ["Entregar o logo e as aplica\xE7\xF5es"] }
  ],
  "Manual da marca": [
    { titulo: "Reunir elementos", itens: ["Reunir a identidade aprovada"] },
    { titulo: "Produ\xE7\xE3o do manual", itens: ["Definir as diretrizes de uso", "Diagramar o manual"] },
    { titulo: "Entrega", itens: ["Revisar e entregar (PDF)"] }
  ],
  "Desenvolvimento de site": [
    { titulo: "Planejamento", itens: ["Receber o briefing", "Definir o mapa do site (sitemap)", "Aprovar o escopo"] },
    { titulo: "Design", itens: ["Wireframe", "Layout", "Aprova\xE7\xE3o do cliente"] },
    { titulo: "Desenvolvimento", itens: ["Montar as p\xE1ginas", "Deixar responsivo", "SEO b\xE1sico"] },
    { titulo: "Publica\xE7\xE3o", itens: ["Publicar no ar", "Treinar o cliente"] }
  ],
  "Gest\xE3o de redes sociais": [
    { titulo: "Setup", itens: ["Auditar a presen\xE7a atual", "Definir a linha editorial e o tom", "Aprovar o plano"] },
    { titulo: "Produ\xE7\xE3o", itens: ["Montar o calend\xE1rio do m\xEAs", "Produzir artes e textos"] },
    { titulo: "Publica\xE7\xE3o", itens: ["Agendar e publicar", "Acompanhar m\xE9tricas"] }
  ],
  "Conte\xFAdo & SEO": [
    { titulo: "Estrat\xE9gia", itens: ["Levantar palavras-chave", "Analisar concorrentes", "Definir a pauta"] },
    { titulo: "Produ\xE7\xE3o", itens: ["Escrever os conte\xFAdos", "Otimizar para SEO"] },
    { titulo: "Publica\xE7\xE3o", itens: ["Publicar", "Acompanhar o desempenho"] }
  ],
  "Tr\xE1fego pago": [
    { titulo: "Configura\xE7\xE3o", itens: ["Definir objetivo e p\xFAblico", "Verificar a conformidade com o CFM"] },
    { titulo: "Campanha", itens: ["Montar o plano de m\xEDdia", "Organizar os criativos", "Configurar a segmenta\xE7\xE3o"] },
    { titulo: "Gest\xE3o", itens: ["Subir a campanha", "Configurar as m\xE9tricas", "Otimizar"] }
  ]
};
async function seedIfEmpty() {
  const existentes = new Set((await prisma.servico.findMany({ select: { nome: true } })).map((s) => s.nome));
  const faltando = CONTEUDO_SERVICOS.filter((s) => !existentes.has(s.nome));
  if (faltando.length > 0) {
    await prisma.servico.createMany({
      data: faltando.map((s) => ({
        nome: s.nome,
        categoria: s.categoria,
        valor: s.valor,
        valorRecorrencia: s.valorRecorrencia ?? "AVULSO",
        percentual: s.percentual ?? null,
        percentualRecorrencia: s.percentualRecorrencia ?? "MENSAL",
        descricao: s.descricao,
        roteiro: ROTEIROS_SERVICO[s.nome] ?? void 0,
        clausulasContrato: CLAUSULAS_SERVICOS[s.nome] ?? null,
        // Mantém a ordem canônica do catálogo, independente do que já houvesse no banco.
        ordem: CONTEUDO_SERVICOS.findIndex((c) => c.nome === s.nome)
      }))
    });
  }
  if (await prisma.servico.count({ where: { clausulasContrato: null } }) > 0) {
    for (const [nome, clausula] of Object.entries(CLAUSULAS_SERVICOS)) {
      await prisma.servico.updateMany({ where: { nome, clausulasContrato: null }, data: { clausulasContrato: clausula } });
    }
  }
  const semPassos = await prisma.servico.findMany({
    where: { passos: { none: {} } },
    select: { id: true, nome: true }
  });
  for (const s of semPassos) {
    const def = CONTEUDO_SERVICOS.find((c) => c.nome === s.nome)?.passos;
    if (def?.length) {
      await prisma.servicoPasso.createMany({
        data: def.map((d, i) => ({ servicoId: s.id, titulo: d.titulo, obrigatorio: d.obrigatorio, etapaChave: d.etapaChave, ordem: i }))
      });
    }
  }
}
async function listServicos() {
  await seedIfEmpty();
  return prisma.servico.findMany({
    orderBy: [{ ativo: "desc" }, { ordem: "asc" }],
    include: { _count: { select: { requisitos: true, passos: true } } }
  });
}
async function listServicosAtivos() {
  await seedIfEmpty();
  return prisma.servico.findMany({
    where: { ativo: true },
    orderBy: { ordem: "asc" },
    select: {
      id: true,
      nome: true,
      descricao: true,
      categoria: true,
      valor: true,
      valorRecorrencia: true,
      percentual: true,
      percentualRecorrencia: true
    }
  });
}
async function criarServico(input) {
  const max = await prisma.servico.aggregate({ _max: { ordem: true } });
  return prisma.servico.create({
    data: {
      nome: input.nome.trim(),
      descricao: input.descricao?.trim() || null,
      categoria: input.categoria?.trim() || null,
      valor: input.valor ?? null,
      valorRecorrencia: input.valorRecorrencia ?? "AVULSO",
      percentual: input.percentual ?? null,
      percentualRecorrencia: input.percentualRecorrencia ?? "MENSAL",
      ordem: (max._max.ordem ?? -1) + 1
    }
  });
}
async function atualizarServico(id, dados) {
  const data = {};
  if (dados.nome !== void 0) data.nome = dados.nome.trim();
  if (dados.descricao !== void 0) data.descricao = dados.descricao?.trim() || null;
  if (dados.categoria !== void 0) data.categoria = dados.categoria?.trim() || null;
  if (dados.valor !== void 0) data.valor = dados.valor ?? null;
  if (dados.valorRecorrencia !== void 0) data.valorRecorrencia = dados.valorRecorrencia;
  if (dados.percentual !== void 0) data.percentual = dados.percentual ?? null;
  if (dados.percentualRecorrencia !== void 0) data.percentualRecorrencia = dados.percentualRecorrencia;
  if (dados.clausulasContrato !== void 0) data.clausulasContrato = dados.clausulasContrato?.trim() || null;
  if (dados.ativo !== void 0) data.ativo = dados.ativo;
  try {
    return await prisma.servico.update({ where: { id }, data });
  } catch {
    throw new TRPCError2({ code: "NOT_FOUND", message: "Servi\xE7o n\xE3o encontrado." });
  }
}
async function setRoteiro(servicoId, roteiro) {
  await prisma.servico.update({ where: { id: servicoId }, data: { roteiro } }).catch(() => {
    throw new TRPCError2({ code: "NOT_FOUND", message: "Servi\xE7o n\xE3o encontrado." });
  });
  return { ok: true };
}
async function removerServico(id) {
  await prisma.servico.delete({ where: { id } }).catch(() => {
    throw new TRPCError2({ code: "NOT_FOUND", message: "Servi\xE7o n\xE3o encontrado." });
  });
  return { ok: true };
}
async function reordenarServicos(ids) {
  await prisma.$transaction(ids.map((id, ordem) => prisma.servico.update({ where: { id }, data: { ordem } })));
  return { ok: true };
}
async function listPassosDoServico(servicoId) {
  await seedIfEmpty();
  return prisma.servicoPasso.findMany({ where: { servicoId }, orderBy: [{ etapaChave: "asc" }, { ordem: "asc" }] });
}
async function addServicoPasso(servicoId, titulo, etapaChave, obrigatorio) {
  const max = await prisma.servicoPasso.aggregate({ where: { servicoId, etapaChave }, _max: { ordem: true } });
  return prisma.servicoPasso.create({
    data: { servicoId, titulo: titulo.trim(), etapaChave, obrigatorio, ordem: (max._max.ordem ?? -1) + 1 }
  });
}
async function atualizarServicoPasso(id, dados) {
  const data = {};
  if (dados.titulo !== void 0) data.titulo = dados.titulo.trim();
  if (dados.obrigatorio !== void 0) data.obrigatorio = dados.obrigatorio;
  if (dados.etapaChave !== void 0) data.etapaChave = dados.etapaChave;
  return prisma.servicoPasso.update({ where: { id }, data }).catch(() => {
    throw new TRPCError2({ code: "NOT_FOUND", message: "Passo n\xE3o encontrado." });
  });
}
async function removerServicoPasso(id) {
  await prisma.servicoPasso.deleteMany({ where: { id } });
  return { ok: true };
}
async function reordenarServicoPassos(ids) {
  await prisma.$transaction(ids.map((id, ordem) => prisma.servicoPasso.update({ where: { id }, data: { ordem } })));
  return { ok: true };
}
async function seedRequisitosSeVazio() {
  if (await prisma.servicoRequisito.count() > 0) return;
  const servicos = await prisma.servico.findMany({ select: { id: true, nome: true } });
  for (const s of servicos) {
    const itens = CONTEUDO_SERVICOS.find((c) => c.nome === s.nome)?.requisitos;
    if (!itens?.length) continue;
    let ordem = 0;
    for (const it of itens) {
      let formularioId = null;
      if (it.tipo === "INFORMACAO") {
        const form = await prisma.formulario.create({
          data: {
            titulo: it.titulo,
            descricao: it.descricao ?? null,
            interno: true,
            campos: { create: { rotulo: it.titulo, tipo: "TEXTO_LONGO", obrigatorio: it.obrigatorio, ordem: 0 } }
          }
        });
        formularioId = form.id;
      }
      await prisma.servicoRequisito.create({
        data: {
          servicoId: s.id,
          titulo: it.titulo,
          descricao: it.descricao ?? null,
          tipo: it.tipo,
          obrigatorio: it.obrigatorio,
          formularioId,
          ordem: ordem++
        }
      });
    }
  }
}
async function listRequisitos(servicoId) {
  await seedRequisitosSeVazio();
  return prisma.servicoRequisito.findMany({ where: { servicoId }, orderBy: { ordem: "asc" } });
}
async function addRequisito(input) {
  const max = await prisma.servicoRequisito.aggregate({ where: { servicoId: input.servicoId }, _max: { ordem: true } });
  const titulo = input.titulo.trim();
  let formularioId = null;
  if (input.tipo === "BRIEFING") {
    formularioId = input.formularioId || null;
  } else if (input.tipo === "INFORMACAO") {
    const form = await prisma.formulario.create({
      data: {
        titulo,
        descricao: input.descricao?.trim() || null,
        interno: true,
        campos: { create: { rotulo: titulo, tipo: "TEXTO_LONGO", obrigatorio: input.obrigatorio, ordem: 0 } }
      }
    });
    formularioId = form.id;
  }
  return prisma.servicoRequisito.create({
    data: {
      servicoId: input.servicoId,
      titulo,
      descricao: input.descricao?.trim() || null,
      tipo: input.tipo,
      obrigatorio: input.obrigatorio,
      formularioId,
      ordem: (max._max.ordem ?? -1) + 1
    }
  });
}
async function atualizarRequisito(id, dados) {
  const data = {};
  if (dados.titulo !== void 0) data.titulo = dados.titulo.trim();
  if (dados.descricao !== void 0) data.descricao = dados.descricao?.trim() || null;
  if (dados.tipo !== void 0) data.tipo = dados.tipo;
  if (dados.obrigatorio !== void 0) data.obrigatorio = dados.obrigatorio;
  if (dados.formularioId !== void 0) data.formularioId = dados.formularioId || null;
  return prisma.servicoRequisito.update({ where: { id }, data }).catch(() => {
    throw new TRPCError2({ code: "NOT_FOUND", message: "Exig\xEAncia n\xE3o encontrada." });
  });
}
async function removerRequisito(id) {
  const req = await prisma.servicoRequisito.findUnique({
    where: { id },
    select: { formularioId: true, formulario: { select: { interno: true } } }
  });
  await prisma.servicoRequisito.deleteMany({ where: { id } });
  if (req?.formularioId && req.formulario?.interno) {
    await prisma.formulario.delete({ where: { id: req.formularioId } }).catch(() => {
    });
  }
  return { ok: true };
}
async function reordenarRequisitos(ids) {
  await prisma.$transaction(ids.map((id, ordem) => prisma.servicoRequisito.update({ where: { id }, data: { ordem } })));
  return { ok: true };
}

// src/modules/servicos/servicos-cliente.service.ts
async function servicosDoCliente(clienteId) {
  await seedRequisitosSeVazio();
  const [servicos, contratacoes, arquivos, respostas] = await Promise.all([
    prisma.servico.findMany({
      where: { ativo: true },
      orderBy: { ordem: "asc" },
      include: { requisitos: { orderBy: { ordem: "asc" } } }
    }),
    prisma.clienteServico.findMany({ where: { clienteId } }),
    prisma.arquivo.findMany({
      where: { clienteId, deletedAt: null },
      orderBy: { createdAt: "desc" },
      select: { id: true, nome: true, tamanho: true, mimetype: true, servicoId: true, requisitoId: true, enviadoPorTipo: true, createdAt: true }
    }),
    prisma.formularioResposta.findMany({ where: { clienteId }, select: { id: true, requisitoId: true, status: true } })
  ]);
  return servicos.map((s) => {
    const c = contratacoes.find((x) => x.servicoId === s.id);
    const requisitos = s.requisitos.map((r) => {
      const arqs = arquivos.filter((a) => a.requisitoId === r.id);
      const resp = respostas.find((x) => x.requisitoId === r.id);
      const atendido = r.tipo === "DOCUMENTO" ? arqs.length > 0 : resp?.status === "ENVIADO";
      return {
        id: r.id,
        titulo: r.titulo,
        descricao: r.descricao,
        tipo: r.tipo,
        obrigatorio: r.obrigatorio,
        atendido,
        arquivos: arqs,
        respostaId: resp?.id ?? null,
        respostaStatus: resp?.status ?? null
      };
    });
    const arquivosAvulsos = arquivos.filter((a) => a.servicoId === s.id && !a.requisitoId);
    const obrigatorios = requisitos.filter((r) => r.obrigatorio);
    const pendentes = obrigatorios.filter((r) => !r.atendido).length;
    return {
      servico: { id: s.id, nome: s.nome, descricao: s.descricao, categoria: s.categoria },
      contratado: c?.status === "ATIVO",
      contratacao: c ? {
        status: c.status,
        origem: c.origem,
        valor: c.valor,
        valorRecorrencia: c.valorRecorrencia,
        percentual: c.percentual,
        percentualRecorrencia: c.percentualRecorrencia,
        contratadoEm: c.contratadoEm,
        canceladoEm: c.canceladoEm,
        canceladoPorTipo: c.canceladoPorTipo
      } : null,
      requisitos,
      arquivosAvulsos,
      totalObrigatorios: obrigatorios.length,
      pendentes
    };
  });
}
async function ativarServicoCliente(clienteId, servicoId, opts, ator) {
  const servico = await prisma.servico.findUnique({
    where: { id: servicoId },
    select: { nome: true, valor: true, valorRecorrencia: true, percentual: true, percentualRecorrencia: true }
  });
  const jaContratado = await prisma.clienteServico.findUnique({
    where: { clienteId_servicoId: { clienteId, servicoId } },
    select: { id: true }
  });
  const cs = await prisma.clienteServico.upsert({
    where: { clienteId_servicoId: { clienteId, servicoId } },
    update: { status: "ATIVO", canceladoEm: null, canceladoPorTipo: null, valor: opts.valor ?? void 0, observacao: opts.observacao ?? void 0 },
    create: {
      clienteId,
      servicoId,
      status: "ATIVO",
      origem: opts.origem ?? "MANUAL",
      valor: opts.valor ?? servico?.valor ?? null,
      valorRecorrencia: servico?.valorRecorrencia ?? "AVULSO",
      percentual: servico?.percentual ?? null,
      percentualRecorrencia: servico?.percentualRecorrencia ?? "MENSAL",
      observacao: opts.observacao ?? null
    }
  });
  await prisma.activityLog.create({
    data: { userId: ator.id, acao: "servico.contratado", entidadeTipo: "cliente", entidadeId: clienteId, dados: { servicoId } }
  });
  await garantirCardDoServicoContratado(clienteId, servicoId, servico?.nome ?? "Servi\xE7o", ator.id).catch(() => {
  });
  if (!jaContratado && (opts.origem ?? "MANUAL") === "MANUAL" && servico?.valor && servico.valor > 0) {
    try {
      const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true } });
      const vencimento = /* @__PURE__ */ new Date();
      vencimento.setDate(vencimento.getDate() + 30);
      vencimento.setHours(12, 0, 0, 0);
      const mensal = servico.valorRecorrencia === "MENSAL";
      await prisma.conta.create({
        data: {
          tipo: "RECEBER",
          descricao: `${mensal ? "Mensalidade" : "Servi\xE7o"}: ${servico.nome} \u2014 ${cliente?.nome ?? "cliente"}`,
          valor: servico.valor,
          vencimento,
          clienteId,
          recorrencia: mensal ? "MENSAL" : "NENHUMA",
          observacoes: "Provisionado ao contratar o servi\xE7o pela ficha do cliente. Revise o valor e o vencimento."
        }
      });
      await prisma.activityLog.create({
        data: { userId: ator.id, acao: "conta.criada", entidadeTipo: "cliente", entidadeId: clienteId, dados: { origem: "contratou_servico", servicoId } }
      });
    } catch {
    }
  }
  if (opts.avisarCliente) {
    const [cliente, servico2] = await Promise.all([
      prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true, email: true } }),
      prisma.servico.findUnique({ where: { id: servicoId }, select: { nome: true } })
    ]);
    if (cliente?.email) {
      void enviarEmailTemplate("servico_ativado", cliente.email, {
        nome: cliente.nome,
        servico: servico2?.nome ?? "servi\xE7o",
        link: config.WEB_ORIGIN
      }).catch(() => {
      });
    }
  }
  return cs;
}
async function sincronizarServicosContratados(clienteId, itens, ator) {
  for (const it of itens) {
    if (!it.servicoId) continue;
    await prisma.clienteServico.upsert({
      where: { clienteId_servicoId: { clienteId, servicoId: it.servicoId } },
      update: {
        status: "ATIVO",
        canceladoEm: null,
        canceladoPorTipo: null,
        valor: it.valor ?? void 0,
        valorRecorrencia: it.recorrencia ?? void 0,
        percentual: it.percentual ?? void 0
      },
      create: {
        clienteId,
        servicoId: it.servicoId,
        status: "ATIVO",
        origem: "FUNIL",
        valor: it.valor ?? null,
        valorRecorrencia: it.recorrencia ?? "AVULSO",
        percentual: it.percentual ?? null
      }
    });
  }
  await prisma.activityLog.create({ data: { userId: ator.id, acao: "servico.sincronizado_aceite", entidadeTipo: "cliente", entidadeId: clienteId, dados: { qtd: itens.length } } }).catch(() => {
  });
}
async function cancelarServicoCliente(clienteId, servicoId, porTipo, motivo, atorId) {
  const existente = await prisma.clienteServico.findUnique({ where: { clienteId_servicoId: { clienteId, servicoId } } });
  if (!existente || existente.status !== "ATIVO") {
    throw new TRPCError3({ code: "BAD_REQUEST", message: "Este servi\xE7o n\xE3o est\xE1 ativo para o cliente." });
  }
  const cs = await prisma.clienteServico.update({
    where: { clienteId_servicoId: { clienteId, servicoId } },
    data: {
      status: "CANCELADO",
      canceladoEm: /* @__PURE__ */ new Date(),
      canceladoPorTipo: porTipo,
      observacao: motivo?.trim() ? motivo.trim() : existente.observacao
    }
  });
  await prisma.activityLog.create({
    data: { userId: atorId ?? null, acao: "servico.cancelado", entidadeTipo: "cliente", entidadeId: clienteId, dados: { servicoId, porTipo } }
  });
  await prisma.projeto.updateMany({ where: { clienteId, servicoId, status: "ATIVO", deletedAt: null }, data: { status: "PAUSADO" } }).catch(() => {
  });
  if (porTipo === "CLIENTE") {
    const [cliente, servico] = await Promise.all([
      prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true } }),
      prisma.servico.findUnique({ where: { id: servicoId }, select: { nome: true } })
    ]);
    const destinos = await equipeDoCliente(clienteId);
    for (const uid of destinos) {
      await notificar(
        uid,
        "servico_cancelado",
        { cliente: cliente?.nome ?? "Cliente", servico: servico?.nome ?? "um servi\xE7o" },
        { entidadeTipo: "cliente", entidadeId: clienteId }
      ).catch(() => {
      });
    }
  }
  return cs;
}
async function atualizarContratacaoCliente(clienteId, servicoId, dados) {
  const existente = await prisma.clienteServico.findUnique({ where: { clienteId_servicoId: { clienteId, servicoId } } });
  if (!existente) throw new TRPCError3({ code: "NOT_FOUND", message: "Este servi\xE7o n\xE3o est\xE1 contratado para o cliente." });
  const data = {};
  if (dados.valor !== void 0) data.valor = dados.valor ?? null;
  if (dados.valorRecorrencia !== void 0) data.valorRecorrencia = dados.valorRecorrencia;
  if (dados.percentual !== void 0) data.percentual = dados.percentual ?? null;
  if (dados.percentualRecorrencia !== void 0) data.percentualRecorrencia = dados.percentualRecorrencia;
  if (dados.observacao !== void 0) data.observacao = dados.observacao?.trim() || null;
  return prisma.clienteServico.update({ where: { clienteId_servicoId: { clienteId, servicoId } }, data });
}
async function servicosDoClientePortal(clienteId) {
  const todos = await servicosDoCliente(clienteId);
  return todos.filter((s) => s.contratado).map((s) => ({
    servico: s.servico,
    requisitos: s.requisitos,
    // documentos (upload) + briefings (preencher online)
    pendentes: s.pendentes,
    totalObrigatorios: s.totalObrigatorios
  }));
}

export {
  MIMETYPES_ACEITOS,
  TAMANHO_MAX,
  MIMETYPES_IMAGEM,
  AVATAR_MAX,
  validarPastaUploads,
  caminhoAbsoluto,
  salvarArquivo,
  salvarAvatar,
  removerArquivo,
  equipeDoCliente,
  registrarUpload,
  listarArquivos,
  getArquivo,
  removerArquivo2,
  listServicos,
  listServicosAtivos,
  criarServico,
  atualizarServico,
  setRoteiro,
  removerServico,
  reordenarServicos,
  listPassosDoServico,
  addServicoPasso,
  atualizarServicoPasso,
  removerServicoPasso,
  reordenarServicoPassos,
  listRequisitos,
  addRequisito,
  atualizarRequisito,
  removerRequisito,
  reordenarRequisitos,
  servicosDoCliente,
  ativarServicoCliente,
  sincronizarServicosContratados,
  cancelarServicoCliente,
  atualizarContratacaoCliente,
  servicosDoClientePortal
};
//# sourceMappingURL=chunk-UT3JPKGF.js.map