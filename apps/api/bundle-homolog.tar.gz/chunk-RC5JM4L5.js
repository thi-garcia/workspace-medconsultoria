import {
  notificar,
  prisma,
  src_exports
} from "./chunk-RQVINKOG.js";

// src/modules/projetos/projetos.service.ts
import { TRPCError } from "@trpc/server";
var clean = (v) => {
  const t = v?.trim();
  return t ? t : null;
};
function listProjetos(clienteId) {
  return prisma.projeto.findMany({
    where: { deletedAt: null, ...clienteId ? { clienteId } : {} },
    orderBy: { createdAt: "desc" },
    include: {
      cliente: { select: { id: true, nome: true } },
      responsavel: { select: { nome: true } },
      // Cartões (status + prazo) para calcular progresso e atrasos na lista.
      cards: { where: { deletedAt: null }, select: { status: true, prazo: true } },
      // Próxima reunião do projeto (integração Agenda).
      eventos: {
        where: { inicio: { gte: /* @__PURE__ */ new Date() } },
        orderBy: { inicio: "asc" },
        take: 1,
        select: { id: true, titulo: true, inicio: true }
      }
    }
  });
}
async function getProjeto(id) {
  const projeto = await prisma.projeto.findFirst({
    where: { id, deletedAt: null },
    include: {
      cliente: { select: { id: true, nome: true } },
      responsavel: { select: { nome: true } },
      participantes: {
        include: { user: { select: { id: true, nome: true } } },
        orderBy: { createdAt: "asc" }
      }
    }
  });
  if (!projeto) throw new TRPCError({ code: "NOT_FOUND", message: "Projeto n\xE3o encontrado" });
  return projeto;
}
async function setParticipantes(projetoId, userIds, atorId) {
  const projeto = await prisma.projeto.findFirst({
    where: { id: projetoId, deletedAt: null },
    select: { id: true, nome: true }
  });
  if (!projeto) throw new TRPCError({ code: "NOT_FOUND", message: "Projeto n\xE3o encontrado" });
  const atuais = await prisma.projetoParticipante.findMany({
    where: { projetoId },
    select: { userId: true }
  });
  const atuaisSet = new Set(atuais.map((p) => p.userId));
  const novosSet = new Set(userIds);
  const paraRemover = [...atuaisSet].filter((id) => !novosSet.has(id));
  const paraAdicionar = userIds.filter((id) => !atuaisSet.has(id));
  await prisma.$transaction([
    prisma.projetoParticipante.deleteMany({ where: { projetoId, userId: { in: paraRemover } } }),
    prisma.projetoParticipante.createMany({
      data: paraAdicionar.map((userId) => ({ projetoId, userId })),
      skipDuplicates: true
    })
  ]);
  for (const userId of paraAdicionar) {
    if (userId === atorId) continue;
    await notificar(
      userId,
      "projeto_participante",
      { projeto: projeto.nome },
      { entidadeTipo: "projeto", entidadeId: projetoId }
    );
  }
  return { ok: true };
}
async function createProjeto(input, userId) {
  const projeto = await prisma.projeto.create({
    data: {
      clienteId: input.clienteId,
      nome: input.nome.trim(),
      descricao: clean(input.descricao),
      previsaoFim: input.previsaoFim ?? null,
      responsavelId: input.responsavelId || userId
    }
  });
  await prisma.activityLog.create({
    data: { userId, acao: "projeto.criado", entidadeTipo: "projeto", entidadeId: projeto.id }
  });
  return projeto;
}
async function updateProjeto(input) {
  const { id, ...rest } = input;
  const data = {};
  if (rest.nome !== void 0) data.nome = rest.nome.trim();
  if (rest.descricao !== void 0) data.descricao = clean(rest.descricao);
  if (rest.status !== void 0) data.status = rest.status;
  if (rest.previsaoFim !== void 0) data.previsaoFim = rest.previsaoFim ?? null;
  if (rest.responsavelId !== void 0) data.responsavelId = rest.responsavelId || null;
  return prisma.projeto.update({ where: { id }, data });
}
async function removeProjeto(id, userId) {
  await prisma.projeto.update({ where: { id }, data: { deletedAt: /* @__PURE__ */ new Date() } });
  await prisma.activityLog.create({
    data: { userId, acao: "projeto.removido", entidadeTipo: "projeto", entidadeId: id }
  });
  return { ok: true };
}
async function reconciliarStatusProjeto(projetoId) {
  const projeto = await prisma.projeto.findUnique({ where: { id: projetoId }, select: { status: true } });
  if (!projeto) return;
  const [total, concluidos] = await Promise.all([
    prisma.card.count({ where: { projetoId, deletedAt: null } }),
    prisma.card.count({ where: { projetoId, deletedAt: null, status: "CONCLUIDO" } })
  ]);
  const todosConcluidos = total > 0 && concluidos === total;
  if (todosConcluidos && projeto.status === "ATIVO") {
    await prisma.projeto.update({ where: { id: projetoId }, data: { status: "CONCLUIDO" } });
    await prisma.activityLog.create({ data: { userId: null, acao: "projeto.concluido", entidadeTipo: "projeto", entidadeId: projetoId, dados: { auto: true } } });
  } else if (!todosConcluidos && projeto.status === "CONCLUIDO") {
    await prisma.projeto.update({ where: { id: projetoId }, data: { status: "ATIVO" } });
    await prisma.activityLog.create({ data: { userId: null, acao: "projeto.reaberto", entidadeTipo: "projeto", entidadeId: projetoId, dados: { auto: true } } });
  }
}
async function fulfillmentDoServico(clienteId, servicoId) {
  const requisitos = await prisma.servicoRequisito.findMany({
    where: { servicoId },
    orderBy: { ordem: "asc" },
    select: { id: true, titulo: true, tipo: true, obrigatorio: true }
  });
  const reqIds = requisitos.map((r) => r.id);
  const [arquivos, respostas] = await Promise.all([
    reqIds.length ? prisma.arquivo.findMany({ where: { clienteId, deletedAt: null, requisitoId: { in: reqIds } }, select: { requisitoId: true } }) : Promise.resolve([]),
    reqIds.length ? prisma.formularioResposta.findMany({ where: { clienteId, status: "ENVIADO", requisitoId: { in: reqIds } }, select: { requisitoId: true } }) : Promise.resolve([])
  ]);
  const comArquivo = new Set(arquivos.map((a) => a.requisitoId));
  const comResposta = new Set(respostas.map((r) => r.requisitoId));
  const atendido = /* @__PURE__ */ new Map();
  for (const r of requisitos) atendido.set(r.id, r.tipo === "DOCUMENTO" ? comArquivo.has(r.id) : comResposta.has(r.id));
  return { requisitos, atendido };
}
async function reconciliarStatusCard(cardId) {
  const card = await prisma.card.findUnique({
    where: { id: cardId },
    select: { id: true, status: true, projetoId: true, checklist: { select: { concluido: true, requisitoId: true } } }
  });
  if (!card || card.status === "AGUARDANDO_TERCEIROS") return null;
  const total = card.checklist.length;
  const feitos = card.checklist.filter((c) => c.concluido).length;
  const pendenteCliente = card.checklist.some((c) => c.requisitoId && !c.concluido);
  const novo = pendenteCliente ? "AGUARDANDO_CLIENTE" : total > 0 && feitos === total ? "CONCLUIDO" : feitos > 0 ? "EM_ANDAMENTO" : "A_FAZER";
  if (novo !== card.status) {
    const max = await prisma.card.aggregate({ where: { projetoId: card.projetoId, status: novo, deletedAt: null }, _max: { ordem: true } });
    await prisma.card.update({ where: { id: cardId }, data: { status: novo, ordem: (max._max.ordem ?? -1) + 1 } });
    await reconciliarStatusProjeto(card.projetoId);
    return novo;
  }
  return null;
}
async function criarCardsDoServico(projetoId, servicoId, servicoNome, clienteId, responsavelId) {
  const [servico, { requisitos, atendido }] = await Promise.all([
    prisma.servico.findUnique({ where: { id: servicoId }, select: { roteiro: true } }),
    fulfillmentDoServico(clienteId, servicoId)
  ]);
  const roteiro = Array.isArray(servico?.roteiro) ? servico.roteiro.filter((t) => !!t && typeof t.titulo === "string") : [];
  const obrigatorias = requisitos.filter((r) => r.obrigatorio);
  const maxAgg = await prisma.card.aggregate({ where: { projetoId, status: "A_FAZER", deletedAt: null }, _max: { ordem: true } });
  let ordem = (maxAgg._max.ordem ?? -1) + 1;
  const criados = [];
  if (obrigatorias.length) {
    const card = await prisma.card.create({
      data: {
        projetoId,
        titulo: "Entregas do cliente",
        servicoId,
        status: "A_FAZER",
        ordem: ordem++,
        responsavelId,
        checklist: { create: obrigatorias.map((r, i) => ({ texto: r.titulo, requisitoId: r.id, concluido: atendido.get(r.id) ?? false, ordem: i })) }
      },
      select: { id: true }
    });
    criados.push(card.id);
  }
  for (const tarefa of roteiro) {
    const itens = (Array.isArray(tarefa.itens) ? tarefa.itens : []).filter((t) => typeof t === "string" && t.trim());
    const card = await prisma.card.create({
      data: {
        projetoId,
        titulo: tarefa.titulo,
        servicoId,
        status: "A_FAZER",
        ordem: ordem++,
        responsavelId,
        checklist: { create: itens.map((texto, i) => ({ texto, ordem: i })) }
      },
      select: { id: true }
    });
    criados.push(card.id);
  }
  if (!criados.length) {
    const card = await prisma.card.create({
      data: { projetoId, titulo: servicoNome, servicoId, status: "A_FAZER", ordem: ordem++, responsavelId },
      select: { id: true }
    });
    criados.push(card.id);
  }
  for (const id of criados) await reconciliarStatusCard(id);
}
async function garantirCardDoServicoContratado(clienteId, servicoId, servicoNome, atorId) {
  const existente = await prisma.projeto.findFirst({ where: { clienteId, servicoId, deletedAt: null }, select: { id: true } });
  if (existente) return existente.id;
  const cliente = await prisma.cliente.findUnique({ where: { id: clienteId }, select: { nome: true, responsavelId: true } });
  const responsavelId = cliente?.responsavelId ?? atorId ?? null;
  const projeto = await prisma.projeto.create({
    data: { clienteId, servicoId, nome: `${servicoNome} \u2014 ${cliente?.nome ?? "Cliente"}`, responsavelId },
    select: { id: true }
  });
  await prisma.activityLog.create({ data: { userId: atorId ?? null, acao: "projeto.criado", entidadeTipo: "projeto", entidadeId: projeto.id } });
  await criarCardsDoServico(projeto.id, servicoId, servicoNome, clienteId, responsavelId);
  return projeto.id;
}
async function reconciliarCardsDoServico(clienteId, servicoId) {
  const cards = await prisma.card.findMany({
    where: { servicoId, deletedAt: null, projeto: { clienteId, deletedAt: null } },
    select: { id: true, checklist: { select: { id: true, concluido: true, requisitoId: true } } }
  });
  if (!cards.length) return;
  const { atendido } = await fulfillmentDoServico(clienteId, servicoId);
  for (const card of cards) {
    for (const item of card.checklist) {
      if (!item.requisitoId) continue;
      const deve = atendido.get(item.requisitoId) ?? false;
      if (item.concluido !== deve) await prisma.checklistItem.update({ where: { id: item.id }, data: { concluido: deve } });
    }
    await reconciliarStatusCard(card.id);
  }
}

export {
  listProjetos,
  getProjeto,
  setParticipantes,
  createProjeto,
  updateProjeto,
  removeProjeto,
  reconciliarStatusProjeto,
  reconciliarStatusCard,
  garantirCardDoServicoContratado,
  reconciliarCardsDoServico
};
//# sourceMappingURL=chunk-RC5JM4L5.js.map